# CrunpBot Racer v0.3 (Godot 4.7.2)

Wyścigi robotów sprzątających w mieszkaniu. Projekt dla Godot **4.7.2**, przygotowany pod Androida
(renderer Mobile, sterowanie dotykowe, żyroskop, wibracje).

## Uruchomienie

1. Rozpakuj archiwum.
2. W Godot 4.7.2: **Import** → wskaż `project.godot` (pierwsze otwarcie zaimportuje zasoby).
3. Uruchom projekt (F5) – scena główna: `scenes/MainMenu.tscn`.
   Uruchomienie samej trasy (`scenes/TrackApartment.tscn`, F6) startuje wyścig na tej trasie.

Sterowanie na PC (do testów): **W/S lub strzałki** – gaz/hamulec (przytrzymany po zatrzymaniu = cofanie),
**A/D** – skręt, **Spacja/Shift** – aktywacja boosta, **TAB** – następny boost, **Ctrl** – poślizg, **Esc/P** – pauza. W wyścigu przytrzymaj przycisk RESET na HUD-zie przez 1,5 s, aby wrócić na trasę.

## Tryby gry

| Tryb | Opis |
|---|---|
| **Wyścig** | Gracz + 1–4 przeciwników AI, 4 poziomy trudności, 1–10 okrążeń, pozycje, wyniki, nagrody. |
| **Jazda na czas** | Bez przeciwników, duch najlepszego okrążenia, rekordy zapisywane per trasa i liczba okrążeń, szybkie ponowienie. |
| **Testuj grafikę** | Losowa trasa, losowy robot i skórki, panel FPS (średnie/min/1% low, draw calls), zmiana grafiki na żywo, autopilot, przełączanie kamery, zakończenie w dowolnym momencie. Brak nagród, statystyk i rekordów. |


## Menu główne v0.3

- **GRAJ** prowadzi do wyboru: Single-player, Multi lub Monster City.
- **Single-player** zawiera działające wejścia do wyścigu, jazdy na czas i testu grafiki; kolejne tryby są widoczne jako WKRÓTCE.
- **Multi** grupuje tryb lokalny i LAN/Wi-Fi; multiplayer online pozostaje oznaczony jako WKRÓTCE, dopóki nie powstanie infrastruktura serwerowa.
- **Monster City** jest widoczne w sekcji GRAJ, ale pozostaje WKRÓTCE.
- **EDYTUJ** prowadzi do centrum tworzenia: generator/edytor tras, warsztat boostów, garaż robotów i stacji oraz planowany kreator skórek ze zdjęć.
- **Skanuj i Stwórz** jest na razie opisanym modułem WKRÓTCE. Docelowy przepływ obejmie szablon dla konkretnego modelu, zdjęcie z aparatu lub galerii, korektę perspektywy, przycięcie i podgląd 3D.

## Dodatkowa zawartość — Style Pack Modern Home

W **Ustawienia → Dodatkowa zawartość** można odświeżyć katalog modeli Poly Haven, wyszukiwać modele, pobierać wariant 1K lub 2K, przypisywać pobrane modele do kategorii mebli oraz usuwać pakiety. Modele są pobierane dopiero po wybraniu przez gracza, a po instalacji działają offline. Każdy model otrzymuje osobny manifest licencji i pochodzenia.

Wymagane oznaczenie źródła API: **Powered by Poly Haven**. Modele Poly Haven są publikowane jako CC0 1.0 Universal; warunki korzystania z live API są odrębne. Szczegóły: `THIRD_PARTY_NOTICES.md` oraz `docs/licenses/POLY_HAVEN_ASSET_LICENSE.md`.

Pobieranie wymaga internetu. Jeśli katalog jest niedostępny, model nie przejdzie weryfikacji lub nie zostanie przypisany, gra korzysta z dotychczasowych modeli proceduralnych. W tej wersji zewnętrzne modele mogą zastępować wizualizacje kategorii mebli/wyposażenia oraz pięciu typów przeszkód; roboty, stacje i geometria kolizji pozostają bez zmian.

## Konto, postęp i zasoby w chmurze

Konfiguracja Cloudflare, API kont, rewizjonowanego zapisu, profilu i prywatnych plików R2 znajduje się w `cloudflare-worker/`. Instrukcja kolejnego etapu: `docs/CLOUD_ACCOUNTS_AND_ASSETS_STAGE_3.md`. Logowanie e-mail działa po skonfigurowaniu D1 i wdrożeniu Workera. Google Sign-In wymaga zbudowania natywnego pluginu Android z kodu w `android/google_signin/` oraz uzupełnienia OAuth client ID. Pliki skinów i tras są przesyłane jako ZIP; pobrane archiwa nie są automatycznie instalowane.

## Struktura projektu

```
scripts/autoload/   SaveManager (zapis), GameSettings (grafika/sterowanie/dźwięk/HUD),
                    PlayerProgress (ekonomia, garaż, rekordy), GameManager (sesja, sceny),
                    AudioManager (dźwięk)
scripts/data/       RobotDatabase (roboty, skórki, neony, ulepszenia), AIDifficulty, TrackDatabase
scripts/robots/     Robot (wspólna fizyka), PlayerDriver, AIDriver, DirtTank, BoostSystem,
                    DamageSystem, EnergySystem, RobotVisuals, RobotAudio
scripts/station/    StationConfig, StationDatabase, StationVisuals, StationUpgradeSystem
scripts/tracks/     TrackBase, ApartmentTrack, TrackGenerator, TrackLibrary, ProceduralTrack
scripts/race/       RaceScene (kompozycja), RaceManager, RaceStatistics, PitStrategySystem,
                    PitStopSystem, DirtManager, CameraFollow, Ghost
scripts/ui/hud/     moduły HUD + navigation/ (moduły nawigacji)
scripts/ui/menus/   MainMenu, ModeSelect, TrackSelect, TrackGeneratorMenu, BoostWorkshop, Garage, Settings, HUDEditorScene
scenes/             sceny menu, TrackApartment, race/RaceScene, robots/Robot
ui/hud/             osobna scena dla każdego modułu HUD
tests/              testy automatyczne
```

**Zasada:** robot nie wie, kto nim kieruje. Gracz (`PlayerDriver`) i AI (`AIDriver`) ustawiają te same
wejścia (skręt, gaz, hamulec, boost), więc fizyka jest identyczna i AI nie może oszukiwać.
Systemy komunikują się sygnałami (np. `RaceManager.lap_completed`, `BoostSystem.state_changed`,
`DamageSystem.damage_changed`), a HUD tylko je obserwuje.

### Dodawanie nowej trasy
1. Utwórz scenę z korzeniem `Node3D` i skryptem dziedziczącym po `TrackBase`
   (nadpisz `_build_geometry()`; wzór: `ApartmentTrack.gd`).
2. Dodaj węzeł `Waypoints` z punktami `Marker3D` (kolejność = kierunek jazdy, pierwszy = start/meta).
3. Opcjonalnie: przeszkody `register_obstacle()`, punkty brudu (Marker3D w grupie `dirt_spawn`),
   lampy `add_lamp()`, kolory środowiska i parametry wyścigu w eksportach.
4. Dopisz trasę w `scripts/data/TrackDatabase.gd`.

Wyścig, AI, brud, minimapa, pamięć mapy, rekordy i duch zadziałają automatycznie.


### Generator tras i boosty
- Z konfiguracji wyścigu lub zakładki EDYTOR TRAS otwórz generator proceduralny. Ustaw seed, rozmiar, złożoność, przeszkody i motyw, a następnie generuj ponownie, zapisuj lokalnie lub od razu rozpocznij wyścig.
- W Warsztacie Boostów skonfiguruj sloty i presety oraz kupuj ulepszenia parametrów za CR. Podczas jazdy przycisk NASTĘPNY zmienia wybrany boost, a BOOST go aktywuje.
- Rzadkość zwykła jest aktualnie używana w wyścigu; pozostałe rzadkości mają osobne zapisy ulepszeń, ale ich system zdobywania nie jest jeszcze wdrożony.

### Dźwięk
Projekt nie zawierał plików audio, więc efekty (silnik, boost, kolizje, zbieranie brudu, interfejs,
odliczanie, meta) są **syntezowane w pamięci** przy starcie. Aby użyć własnych plików, umieść je jako
`assets/audio/<nazwa>.ogg` (lub `.wav`), nazwy: `engine, boost, hit, hit_light, pickup, click, beep,
beep_go, finish, denied, lap` – zostaną użyte automatycznie.

## Testy automatyczne

Uruchamiane z katalogu projektu (argument `--test-save` używa osobnego pliku zapisu i nie zmienia
postępu gracza, mapy ani ducha):

```
godot --headless --path . --script res://tests/load_all.gd
godot --headless --path . res://tests/UIFlowTest.tscn -- --test-save
godot --headless --path . res://tests/RaceSimTest.tscn --fixed-fps 60 -- --test-save --scenario=race --difficulty=3 --laps=3
godot --headless --path . res://tests/RaceSimTest.tscn --fixed-fps 60 -- --test-save --scenario=time_trial
godot --headless --path . res://tests/RaceSimTest.tscn --fixed-fps 60 -- --test-save --scenario=graphics_test
godot --path . res://tests/ScreenshotTest.tscn --resolution 1560x720 --rendering-method mobile -- --test-save --out=C:/zrzuty --quality=1
```

## Android

- Preset eksportu „Android” (arm64-v8a) – dodano uprawnienie wibracji.
- Na Androidzie używany jest renderer **Mobile** (SSAO/SSR z poziomu ULTRA działają tylko w Forward+ na PC –
  ustawienia to opisują).
- Włączono czujniki akcelerometru i grawitacji (w Godot 4.7 są domyślnie wyłączone – bez tego tryb
  żyroskopu nie działa).
- Orientacja: pozioma z obrotem czujnikiem.
- Przed publikacją zmień `package/unique_name` (obecnie `com.example.$genname`) i skonfiguruj klucz.


## Bateria, pit stop i strategie serwisowe
- `EnergySystem` prowadzi osobne pomiary baterii, zużycia na okrążenie i energii zużytej przez boost. Bateria jest niezależna od zbiornika brudu.
- `PitStrategySystem` wyznacza ostrzeżenie na podstawie zużycia poprzedniego okrążenia i rezerwy bezpieczeństwa; AI korzysta z tej samej logiki planowania zjazdu.
- `PitStopSystem` obsługuje osobną stację każdego robota, dojazd do własnego pasa, cofanie do dokowania, ładowanie, naprawę i wyjazd. Zielona strefa jest wyłącznie przy stacji gracza.
- `StationUpgradeSystem` przelicza wpływ poziomu i modułów stacji na szybkość ładowania oraz napraw.
- `RaceStatistics` zbiera zużycie baterii na okrążenie, zużycie boostu, liczbę postojów, czas serwisu i naprawione uszkodzenia.
- W garażu dodano niezależne ulepszenie pojemności baterii; ulepszenie zbiornika brudu nadal wpływa wyłącznie na brud.
- HUD pokazuje komunikat „SŁABA BATERIA” oraz procent zużycia na ostatnim okrążeniu.

**Uwaga testowa:** projekt został zmodyfikowany i sprawdzony strukturalnie, ale w tym środowisku nie ma uruchomionego silnika Godot, więc nie mogłem wykonać testu runtime. Po otwarciu projektu w Godot sprawdź przede wszystkim wjazdy do pięciu zatok (gracz + maksymalnie czterech przeciwników), zachowanie AI i położenie strefy względem otworu w bandzie.

### Dodatkowe testy tej iteracji

```bash
godot --headless --path . --script res://tests/BoostUpgradeTest.gd -- --test-save
godot --headless --path . --script res://tests/TrackGeneratorTest.gd -- --test-save
```

Testy zostały dodane, ale nie zostały uruchomione w środowisku przygotowującym tę paczkę.


## Cloud account UI — stage 2

Settings → Progress now includes email account registration/login, sign-out, cloud upload/download, and a save-conflict comparison dialog. Conflict resolution requires an explicit choice; applying a cloud save creates a local backup first. Revision tracking is per account. See `docs/CLOUD_ACCOUNTS_AND_SAVE_STAGE_2.md`. Google sign-in still needs native Android token acquisition, and R2 user-asset transfer is not included yet.
