# Robot Racing — Third-party notices

## Poly Haven assets and live API

Robot Racing includes an optional in-game browser/downloader for 3D models hosted by Poly Haven. Models are downloaded by the player on demand; they are not bundled in the base game. Each successfully installed asset receives its own `license_manifest.json` in the local content directory. That manifest records the asset ID, asset name, author information returned by the API, original asset page, license, source file URLs, file sizes, MD5 checksums, selected resolution and installation timestamp.

- Asset source: https://polyhaven.com/
- Asset license: **CC0 1.0 Universal** (Poly Haven states that its assets are CC0 and may be used for commercial purposes without attribution).
- License information: https://polyhaven.com/license
- CC0 legal text: https://creativecommons.org/publicdomain/zero/1.0/
- Public API: https://api.polyhaven.com
- API terms: https://polyhaven.com/our-api
- Required visible API credit: **Powered by Poly Haven**

The public API is used directly by the game. The game sends the application-specific HTTP User-Agent `RobotRacing/0.3 (StylePackManager)` as required by Poly Haven's API terms. The `Powered by Poly Haven` credit is displayed in the main-menu introduction and in Settings → Dodatkowa zawartość.

The Poly Haven API server implementation is separately licensed under AGPL-3.0. Robot Racing does not bundle or redistribute that server implementation; it only makes HTTP requests to the public service. The API's software license must not be confused with the CC0 license of the downloadable 3D assets.

### Important rights note

CC0 applies to the asset as supplied by Poly Haven. It does not automatically grant rights to third-party trademarks, logos, character likenesses, or other separately protected material that might appear in a particular model. Review each asset before including it in a public/commercial release and reject assets containing unlicensed branded or protected content. The per-asset manifest is provenance documentation, not legal advice or a warranty.

### Download integrity and storage

The downloader prefers the requested model-file resolution where available, downloads the glTF/GLB model and every dependency listed by the API, preserves dependency-relative paths, verifies each file's byte size and MD5 checksum, and validates the resulting glTF scene before installation. Downloads are staged and only committed after validation. Installed content is stored in the user's writable data directory, not in the read-only application bundle. Removing a downloaded asset does not remove the original procedural fallback models.

## Other third-party code

No Poly Haven API server source code is copied into this project. Existing Godot Engine and other project dependencies remain governed by their own upstream licenses; consult their respective distributions for complete notices.
