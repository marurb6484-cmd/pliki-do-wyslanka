# Native Google Sign-In plugin source (Godot Android)

This folder contains the Kotlin source and Gradle dependency declaration for the native Google Credential Manager bridge. It is source, not a precompiled AAR: Godot Android plugins must be compiled and packaged for the exact Godot Android export template. No binary is falsely presented as ready-to-install.

## OAuth configuration

1. In Google Cloud Console create an OAuth **Web application** client and an OAuth **Android** client.
2. Set the Android client package name to the final APK application ID and register the SHA-1/SHA-256 fingerprints of the signing key used for that APK.
3. Set the Worker variable `GOOGLE_CLIENT_ID` to the Web application client ID.
4. Use that same Web client ID as `serverClientId` in the plugin configuration.
5. Never include a client secret in the Android app.

## Bridge contract

The plugin singleton is named `GoogleSignIn`, exposes `sign_in()`, and emits `google_id_token(token)` or `google_sign_in_failed(message)`. `CloudSaveManager.login_google(token)` submits the token to the existing Worker validation endpoint.

Compile the module against the Android plugin API shipped with the project's exact Godot 4.7.2 Android build. Export templates, plugin API artifacts and signing fingerprints are environment-specific and cannot be generated from the game source ZIP alone.
