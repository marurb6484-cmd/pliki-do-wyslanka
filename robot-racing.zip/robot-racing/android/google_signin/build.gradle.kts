plugins {
    id("com.android.library") version "8.7.3"
    id("org.jetbrains.kotlin.android") version "2.0.21"
}

android {
    namespace = "com.crunpbot.google"
    compileSdk = 35
    defaultConfig { minSdk = 23 }
}

dependencies {
    // Add the Godot 4.7.2 Android plugin API artifact from the matching Godot Android build.
    // Keep it compileOnly; Godot supplies the runtime classes in the exported application.
    compileOnly(files("godot-android-plugin-api-4.7.2.aar"))
    implementation("androidx.credentials:credentials:1.5.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.5.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
}
