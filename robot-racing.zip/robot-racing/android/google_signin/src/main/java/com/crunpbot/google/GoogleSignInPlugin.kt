package com.crunpbot.google

import android.os.CancellationSignal
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import org.godotengine.godot.plugin.GodotPlugin
import org.godotengine.godot.plugin.SignalInfo
import org.godotengine.godot.plugin.UsedByGodot

/** Native Credential Manager bridge. serverClientId must be the Web OAuth client ID. */
class GoogleSignInPlugin(godot: org.godotengine.godot.Godot) : GodotPlugin(godot) {
    override fun getPluginName() = "GoogleSignIn"
    override fun getPluginSignals(): Set<SignalInfo> = setOf(
        SignalInfo("google_id_token", String::class.java),
        SignalInfo("google_sign_in_failed", String::class.java)
    )

    // Set this to the Web application OAuth client ID before compiling the plugin.
    private val serverClientId = "REPLACE_WITH_WEB_OAUTH_CLIENT_ID"

    @UsedByGodot
    fun sign_in() {
        val activity = activity ?: run {
            emitSignal("google_sign_in_failed", "Android activity is unavailable")
            return
        }
        if (serverClientId.startsWith("REPLACE_")) {
            emitSignal("google_sign_in_failed", "Configure serverClientId in GoogleSignInPlugin.kt")
            return
        }
        activity.runOnUiThread {
            val option = GetGoogleIdOption.Builder()
                .setServerClientId(serverClientId)
                .setFilterByAuthorizedAccounts(false)
                .setAutoSelectEnabled(false)
                .build()
            val request = GetCredentialRequest.Builder()
                .addCredentialOption(option)
                .build()
            val manager = CredentialManager.create(activity)
            manager.getCredentialAsync(
                activity,
                request,
                CancellationSignal(),
                activity.mainExecutor,
                object : androidx.credentials.CredentialManagerCallback<androidx.credentials.GetCredentialResponse, GetCredentialException> {
                    override fun onResult(result: androidx.credentials.GetCredentialResponse) {
                        try {
                            val credential = result.credential
                            if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                                val google = GoogleIdTokenCredential.createFrom(credential.data)
                                emitSignal("google_id_token", google.idToken)
                            } else {
                                emitSignal("google_sign_in_failed", "Google did not return an ID token")
                            }
                        } catch (error: Exception) {
                            emitSignal("google_sign_in_failed", error.message ?: "Could not read Google ID token")
                        }
                    }
                    override fun onError(error: GetCredentialException) {
                        emitSignal("google_sign_in_failed", error.message ?: "Google sign-in failed")
                    }
                }
            )
        }
    }
}
