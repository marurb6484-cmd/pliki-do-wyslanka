shader_type spatial;
// Brud do zebrania: obrót i unoszenie liczone na GPU (bez kosztu CPU).
render_mode cull_back;

uniform vec4 albedo : source_color = vec4(0.5, 0.4, 0.3, 1.0);
uniform float emission_strength = 0.35;

void vertex() {
	float phase = NODE_POSITION_WORLD.x * 0.37 + NODE_POSITION_WORLD.z * 0.21;
	float t = TIME * 1.8 + phase;
	float c = cos(t);
	float s = sin(t);
	VERTEX.xz = mat2(vec2(c, -s), vec2(s, c)) * VERTEX.xz;
	NORMAL.xz = mat2(vec2(c, -s), vec2(s, c)) * NORMAL.xz;
	VERTEX.y += sin(TIME * 2.6 + phase) * 0.07;
}

void fragment() {
	ALBEDO = albedo.rgb;
	ROUGHNESS = 0.9;
	EMISSION = albedo.rgb * emission_strength + vec3(0.05, 0.04, 0.02);
}
