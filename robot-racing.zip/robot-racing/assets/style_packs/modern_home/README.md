# Modern Home – pilot

This pack currently contains a verified-source candidate manifest, not bundled mesh files. Candidate GLB entries are recorded in `pack.json` with source, author, CC0 license, direct download address and reported size. Download and import were not possible in the current build environment, so runtime fallback remains active.
