# Tekstury pomieszczeń

Podłogi i ściany generują się proceduralnie, ale każdą z nich można zastąpić własną
teksturą - bez zmian w kodzie. Wystarczy dodać pliki do tego folderu:

    <id>_albedo.png   kolor (wymagany)
    <id>_normal.png   mapa normalnych (opcjonalna)
    <id>_rough.png    szorstkość (opcjonalna)

`<id>` to klucz z `scripts/tracks/room/RoomStyleCatalog.gd`, np. `oak_planks`,
`tiles_light`, `paint_sage`, `brick_red`. Plik zastępuje teksturę wygenerowaną.
Tekstura powinna być bezszwowa (powtarza się). Rozmiar jednego kafla w świecie
gry ustawia pole `tile` we wpisie katalogu.

## Dodawanie nowych stylów
Dopisz wpis do `FLOORS` lub `WALLS` (nowy klucz, nazwa, `kind`, kolory, `tile`) albo
do `ROOM_TYPES` (nowy rodzaj pokoju). Nowa pora dnia: wpis w `TIMES_OF_DAY`
oraz widok za oknem w `RoomTextures.window_view`. Układ mebli w pokojach:
`scripts/tracks/room/RoomFurnisher.gd` (funkcje `_plan_*`).
