# Robot Racing v0.3 — Cloudflare multiplayer, etap 2

## Zakres

Ten etap rozszerza istniejący transport Cloudflare o lobby i uzgodnienie startu:

- lista uczestników z nazwą i stanem gotowości,
- przycisk gotowości / anulowania gotowości,
- host pokoju to najwcześniej dołączony uczestnik,
- tylko host może wysłać żądanie startu,
- serwer wymaga co najmniej dwóch uczestników i gotowości wszystkich,
- serwer rozsyła `race_starting` z planowanym czasem startu 5 sekund później,
- po opuszczeniu pokoju host jest wyznaczany ponownie spośród pozostałych uczestników.

## Ograniczenia

- Sygnał `race_starting` nie uruchamia jeszcze sceny wyścigu.
- Nie ma jeszcze synchronizacji pozycji, fizyki, checkpointów, okrążeń ani wyników.
- Nie ma jeszcze walidacji uczciwości wyścigu ani autorytatywnej symulacji serwerowej.
- Nie wykonano testu end-to-end z wdrożonym Workerem i dwoma urządzeniami.
- Projekt Godot nie został uruchomiony w edytorze w tym środowisku.

## Wdrożenie

Po zmianach serwera ponownie wdrożyć Worker z katalogu `cloudflare-worker` poleceniem `npm run deploy` w środowisku z zainstalowanymi zależnościami i skonfigurowanym Wranglerem.
