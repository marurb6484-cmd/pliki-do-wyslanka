# Robot Racing v0.3 — Cloudflare multiplayer, etap 3

## Zakres
- Worker przekazuje snapshoty `race_state` pomiędzy graczami w pokoju.
- Snapshot zawiera pozycję 3D, yaw oraz poziomą prędkość.
- Serwer przypisuje `player_id` i `server_time`; klient nie może podszyć się pod innego gracza.
- Serwer ogranicza zakres wartości, rozmiar wiadomości i częstotliwość (wspólny limit 20 wiadomości/s).
- Klient Godot ogranicza wysyłanie snapshotów do 10 Hz i odrzuca stare sekwencje od danego gracza.
- `RemoteRaceStateBuffer.gd` udostępnia interpolację dwóch snapshotów z opóźnieniem 120 ms.

## Ważne ograniczenia
To jest warstwa transportu i interpolacji, a nie kompletna integracja z wyścigiem. RaceScene nadal nie tworzy zdalnych robotów i nie wysyła automatycznie pozycji gracza. Nie ma walidacji fizyki, checkpointów, okrążeń ani wyników po stronie serwera. Nie należy traktować pozycji klienta jako wiarygodnego źródła wyniku.

## Test etapu
1. Wdrożyć nową wersję Workera z katalogu `cloudflare-worker`.
2. Połączyć dwa urządzenia z tym samym pokojem.
3. Z poziomu kodu testowego wywołać `send_race_state(...)` na obu urządzeniach.
4. Sprawdzić sygnał `race_state_received` i przekazać pakiety do osobnego `RemoteRaceStateBuffer`.

## Zachowanie istniejących trybów
Nie zmieniono LAN ENet, trybu offline, modeli robotów, scen tras ani ustawień grafiki.
