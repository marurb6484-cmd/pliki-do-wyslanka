# Robot Racing v0.3 — multiplayer online, etap 4

## Dodane
- Start wyścigu z lobby po sygnale `race_starting` od serwera.
- Wspólny czas startu oparty na `start_at` z Durable Object i korekcie zegara serwera.
- Automatyczne utworzenie lokalnego robota oraz wizualnych robotów pozostałych graczy.
- Wysyłanie stanu lokalnego robota przez `race_state` z limitem 10 Hz.
- Odbieranie snapshotów pozostałych graczy i płynna interpolacja przez `RemoteRaceStateBuffer`.
- Zdalne roboty są wyłączone z lokalnej fizyki i kolizji; ich pozycje pochodzą z sieci.
- Multiplayer online nie przyznaje CR ani rekordów lokalnych, ponieważ serwer nie weryfikuje jeszcze wyników.
- Wyjście lub ponowienie wyścigu rozłącza pokój i wraca do sekcji multiplayer.

## Ograniczenia tego etapu
- Wspólna jest pierwsza trasa i 3 okrążenia; wybór trasy i liczby okrążeń nie jest jeszcze przesyłany między graczami.
- Wygląd zdalnych robotów jest tymczasowo dobierany lokalnie na podstawie kolejności w lobby; wybrany robot/skórka gracza nie są jeszcze przesyłane.
- Okrążenia i pozycje są liczone lokalnie na podstawie odebranych pozycji. Worker przekazuje snapshoty, ale nie waliduje fizyki, checkpointów, okrążeń ani wyników.
- Gracze dołączający po rozpoczęciu wyścigu nie są dodawani do bieżącej sceny.
- LAN i tryb offline pozostają oddzielne.

## Weryfikacja
- Sprawdzono statycznie obecność wywołań, ścieżek i plików w projekcie.
- Nie uruchomiono Godota ani dwóch urządzeń; działanie sceny i synchronizacji wymaga testu w grze.
