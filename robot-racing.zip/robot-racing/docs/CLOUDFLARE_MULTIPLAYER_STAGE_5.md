# Multiplayer Stage 5 — room browser and lobby roster

- Added `GET /api/rooms` backed by a global `RoomDirectory` Durable Object.
- Active room metadata includes room code, player count and roster; empty rooms are removed and stale entries expire after 120 seconds.
- Added a refreshable room list with one-tap join.
- Replaced the single lobby text line with a visible per-player roster showing host and ready/waiting state.
- Existing WebSocket race relay and stage 4 race integration are retained.

Deployment note: Worker source now requires the `ROOM_DIRECTORY` binding and Durable Object migration `v2`. Deploy the complete Worker project before using room discovery. The game client can still join by code, but the public room list requires the new Worker deployment.
