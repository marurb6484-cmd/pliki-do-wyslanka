
# CrunpBot Racer v0.3 — Stage 3: Cloud accounts and profiles

## Current implementation

This stage includes:

- Account registration and email/password authentication.
- Session-based authentication using Bearer tokens.
- D1 database for accounts, sessions and cloud saves.
- Cloud save synchronization with revision history.
- Cloud profile read/update endpoints.
- Existing multiplayer functionality using Durable Objects.
- Existing RaceRoom and RoomDirectory Durable Object classes.

## Cloud assets status

Cloud asset storage is intentionally disabled.

- R2 is not configured.
- No R2 bucket should be created.
- Asset upload, list, download and delete endpoints are disabled.
- Requests to `/api/assets` return HTTP 410 with `CLOUD_ASSETS_DISABLED`.
- Cloud skin and track sharing is not available in this stage.

Do not configure or deploy R2 resources.

## Cloud API

Authenticated endpoints:

- `GET /api/profile`
- `PUT /api/profile` with:
  `{ "public_name": "...", "country_code": "PL", "selected_robot_id": "..." }`

Account and save endpoints remain available according to the Worker implementation.

Asset endpoints are disabled and must not be treated as available features.

## Required Cloudflare configuration

D1 database:

- Name: `crunpbot-racer-db`
- Database ID: `00000002-00000000-00005128-3133029678e1bd57c2254dde1272074a`
- Worker binding: `DB`

The existing Worker configuration must preserve:

- `RACE_ROOMS`
- `ROOM_DIRECTORY`
- Durable Object migration history
- Existing multiplayer routes

Do not recreate the Worker from scratch.

Do not create an R2 bucket or add an R2 binding.

## D1 migrations

The migrations must be applied in this order:

1. `0001_accounts_saves.sql`
2. `0002_assets_profiles.sql`

The second migration now creates only the `user_profiles` table.

Before applying migrations, verify the current migration state and avoid executing an already-applied migration again.

Do not apply migrations until the complete project configuration has been reviewed.

## Google Sign-In status

Google Sign-In integration is deferred.

The Worker may contain a prepared Google authentication endpoint, but the complete Android integration is not considered finished.

Google Sign-In will be implemented together with the future advertising integration in one coordinated update.

Do not configure OAuth credentials or add a native Android plugin at this stage.

Email/password authentication remains the current account login method.

Never put Google client secrets in the game, Worker source code or chat.

## Security and usage limits

- Cloud profiles are separate from progression save revisions.
- Local progress must not be silently replaced by cloud data.
- Save conflicts must be presented to the player for a decision.
- Both local and cloud save versions must show their update date and time and the active robot's OVR.
- Do not automatically resolve save conflicts.
- Client-reported OVR and race statistics are untrusted.
- Downloaded or imported packages must be validated before installation.
- Rate limiting for registration, login, save operations and room creation is required before public launch.

Cloudflare Free quotas and application-side limits do not guarantee protection against abuse or unexpected service costs.

## Deployment status

Do not assume that the database migrations or latest Worker changes have been deployed.

Deployment must wait until:

1. All relevant project files have been reviewed.
2. The D1 migration state has been checked.
3. The Worker configuration has been verified.
4. The security and rate-limiting plan has been reviewed.

The current configuration intentionally excludes R2 and postpones Google Sign-In.

