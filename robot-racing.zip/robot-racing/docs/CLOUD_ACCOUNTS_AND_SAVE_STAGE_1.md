# CrunpBot cloud foundation — Stage 1

- Preserved Cloudflare room/lobby and race relay; lobby now includes selected robot and its existing OVR calculation.
- Added D1-backed email registration/login, token sessions, Google ID-token verification endpoint, and revisioned cloud-save endpoints.
- Added a CloudSaveManager autoload with email auth calls, upload/download methods, conflict signal, and explicit import method.
- Added D1 migration and R2 bucket binding for future player assets.

Deployment requires creating the D1 database and R2 bucket, inserting the D1 ID into wrangler.jsonc, and deploying the Worker. Stage 1 supplied the backend foundation. Stage 2 adds the in-game email account and conflict-resolution UI; native Google token acquisition remains outstanding. The patch does not claim the backend is deployed or runtime-tested.
