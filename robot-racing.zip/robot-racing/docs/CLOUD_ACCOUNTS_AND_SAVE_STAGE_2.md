# Cloud accounts and save UI — stage 2

## Added in this stage
- Settings → Progress now contains email registration, email login, sign-out, cloud upload and cloud download controls.
- The UI displays the signed-in account and operation status; sign-out also attempts to revoke the server session.
- A save conflict opens a comparison dialog with local and cloud summaries: currency, unlocked robot count, selected robot and career stage.
- The player can keep the local save, apply the cloud save, or cancel without changing either copy.
- Applying the cloud save uses `SaveManager.import_progress()`, which creates a local backup before replacing progress sections.
- Keeping the local save retries the upload against the latest cloud revision; the Worker stores the previous cloud revision in `save_history`.
- Cloud revision numbers are tracked per account ID to avoid reusing one account's revision after switching accounts.
- New account controls have English catalog entries.

## Current limitations
- Google sign-in still requires a native Android sign-in integration to obtain an ID token; the Worker endpoint alone does not provide a Google button that can authenticate users.
- Cloudflare deployment and D1/R2 provisioning are not performed by this project patch.
- R2 is still reserved for future user assets; this stage synchronizes progress through D1.
- No runtime Godot test was available in the build environment.

## Player workflow
1. Open Settings → Progress.
2. Register or sign in with email and password (minimum 10 characters).
3. Use Upload Local Save to publish this device's progress, or Download From Cloud to open a comparison of the local and cloud copies.
4. If a conflict appears, inspect both summaries and choose the desired copy. Cancel leaves the current local save untouched.
