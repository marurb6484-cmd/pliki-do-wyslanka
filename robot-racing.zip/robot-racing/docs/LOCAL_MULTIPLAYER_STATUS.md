# Lokalny multiplayer – stan implementacji

## Dostępne w tej iteracji
- Tryb dwóch lokalnych graczy wybierany z ekranu „GRAJ”.
- Wspólna trasa, start, odliczanie, fizyka robotów i klasyfikacja wyścigu.
- Gracz 1: WASD, kontroler o indeksie 0 albo dotykowy HUD.
- Gracz 2: strzałki albo kontroler o indeksie 1.
- Każdy gracz steruje własnym robotem i ma własny system energii, boostów i pit stopu.
- Wyścig uwzględnia ukończenie obu lokalnych graczy.

## Ograniczenia – nie oznaczać jako gotowych
- Kamera jest wspólna i śledzi Gracza 1; nie ma podziału ekranu.
- HUD jest pojedynczy i pokazuje dane Gracza 1.
- Gracz 2 nie ma osobnego wyboru profilu/robota w lobby.
- Nagrody i trwałe statystyki są obecnie rozliczane według dotychczasowego profilu Gracza 1.
- Brak lokalnego multiplayera 3–4 osoby.
- Nie przetestowano jeszcze wielu kontrolerów na Androidzie ani równoczesnego dotyku i pada.

## Kontrola
Kod sprawdzony statycznie i archiwum ZIP sprawdzone pod kątem integralności. Godot 4.7 nie był dostępny w środowisku roboczym, więc nie wykonano importu projektu ani testu runtime.
