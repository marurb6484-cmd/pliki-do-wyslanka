# Robot Racing – architektura modułowa

## Zasada nadrzędna

Każdy system ma jedną odpowiedzialność. Moduł nie powinien znać szczegółów implementacji innych modułów. Integracja odbywa się przez jawne metody publiczne, sygnały Godot i przekazywany kontekst.

Nie rozdrabniamy projektu na pliki bez sensu: granica modułu ma odpowiadać osobnej odpowiedzialności, którą da się rozwijać lub testować niezależnie.

## Obecne granice modułów

| Obszar | Odpowiedzialność |
|---|---|
| `scripts/autoload/` | usługi globalne: zapis, ustawienia, postęp, sesja, audio |
| `scripts/data/` | katalogi i konfiguracje danych, bez logiki widoku |
| `scripts/robots/` | fizyka robota, kierowcy, energia, brud, boosty, uszkodzenia, wygląd i audio |
| `scripts/station/` | dane, wygląd, części i ulepszanie stacji |
| `scripts/tracks/` | baza trasy i konkretne implementacje tras |
| `scripts/race/` | składanie wyścigu, przebieg, statystyki, pit stop, kamera i ghost |
| `scripts/ui/hud/` | prezentacja stanu gry i obsługa HUD-u |
| `scripts/ui/menus/` | ekrany menu i ich interakcje |
| `ui/` oraz `scenes/` | osobne sceny UI i kompozycje świata |

## Reguły dla nowych modułów

1. Logika gry nie może zależeć od animacji, modelu, materiału ani dźwięku.
2. Wygląd i audio subskrybują sygnały lub odczytują publiczny stan; nie zmieniają mechaniki.
3. Balans, ceny, limity i parametry powinny trafiać do zasobów/konfiguracji danych, a nie być rozrzucone po UI.
4. UI nie modyfikuje prywatnych pól systemów. Korzysta z publicznych metod i sygnałów.
5. Moduły nie powinny bezpośrednio zmieniać wewnętrznych pól innych modułów. Gdy potrzebna jest operacja, udostępniamy metodę z walidacją.
6. Zapis ma osobne sekcje i wersjonowanie; migracje muszą zachowywać starszy postęp.
7. Każdy moduł powinien mieć jasno określony właściciel danych i cykl życia.
8. Zależności muszą być jednokierunkowe tam, gdzie to możliwe. Unikamy cykli między systemami.
9. Nowe funkcje powinny być możliwe do wyłączenia konfiguracyjnie bez usuwania ich kodu.
10. Przed zmianą publicznego API sprawdzamy wszystkie wywołania i sceny korzystające z modułu.

## Konwencja integracji

- `setup(context)` – jawne przekazanie zależności podczas inicjalizacji.
- `signal` – powiadomienie o zmianie stanu, bez bezpośredniego sterowania odbiorcą.
- Publiczne metody – jedyny sposób żądania zmiany stanu innego modułu.
- Dane konfiguracyjne – osobne od skryptów prezentacji.
- Testy – test pojedynczego modułu, następnie test integracyjny.

## Ważne ograniczenie

Sam podział katalogów nie oznacza pełnej modularności. Podczas kolejnych zmian trzeba kontrolować rzeczywiste zależności i nie dopuszczać do tego, by moduły zaczęły wzajemnie znać swoje szczegóły.
