# Multiplayer – zapisane serwery

Ekran Multiplayer Online ma domyślnie wpisany oficjalny adres Cloudflare Worker projektu Robot Racing:
`https://robot-racing-multiplayer.marurb6484.workers.dev`

Użytkownik nie musi już ręcznie wklejać adresu przy zwykłym korzystaniu z gry. Lista serwerów jest zapisywana lokalnie w `user://online_servers.cfg`. Można dodać kolejny własny serwer, wpisując jego adres HTTPS i wybierając „DODAJ / ZAPISZ TEN SERWER”. Zapisane adresy są dostępne z listy wyboru przy kolejnych uruchomieniach gry.

Dodanie tej funkcji nie wymaga zmian ani ponownego wdrożenia Cloudflare Workera.
