# Robot Racing v0.3 — alfa i pierwsza aktualizacja

Dokument kontrolny zakresu. Nie oznacza funkcji jako gotowych, jeśli nie istnieją w kodzie.

## Wdrożone w tej iteracji
- Po ręcznym resecie pozycji robot pozostaje nieruchomy przez 3 sekundy; RaceManager emituje odliczanie, a HUD pokazuje „START ZA 3/2/1”.
- Zbieranie zabrudzeń ma dodatkowe wykrywanie przecięcia odcinka ruchu robota z obszarem punktu zbierania. To zabezpieczenie przed pominięciem małego Area3D przy dużej prędkości, również po Turbo. Dotychczasowa wartość zbierania podczas Turbo (70%) pozostaje bez zmian.
- Wyjazd z pit stopu kończy się poza strefą wejściową, aby ponowne podjechanie mogło ponownie wywołać wejście w Area3D.
- Dodano wyłącznie kolizje fizyczne obudowy i bocznych prowadnic stacji. Model wizualny stacji nie jest zmieniany; przód zatoki pozostaje otwarty.

## Nadal do wdrożenia — alfa i pełny zakres v0.3

### Języki
- Polski jako język podstawowy.
- Angielski oraz system lokalizacji przygotowany do kolejnych języków.
- Wszystkie menu, HUD, komunikaty, opisy, samouczki, ustawienia i błędy mają korzystać z tłumaczeń, bez mieszania języków.

### Tryby gry
- Single Player, Multiplayer, Monster Robots — City Tour, Free Roam, Time Trial, Kariera, mistrzostwa, turnieje i wydarzenia.
- Clean Race, Obstacle Challenge, Ghost Challenge, Team Race 2v2, Night Race, Survival Race.
- Underground: osobne pojedynki 1 na 1 oraz osobne wyścigi 1/8 mili (201,17 m) z przeszkodami.
- Split-screen, LAN, Wi-Fi/hotspot; później multiplayer online.

### Kariera i generator tras
- Dopóki biblioteka gotowych tras jest mała, kariera generuje własne trasy.
- Później korzysta z miksu tras ręcznych, opublikowanych i proceduralnych.
- Każdy event przechowuje seed i dane trasy, aby wznowienie zawodów nie losowało nowego układu.
- Walidacja przejezdności, checkpointów, kolizji, długości i trudności przed dopuszczeniem trasy do zawodów.
- Generowanie asynchroniczne, podgląd, ponowne losowanie i cache; podstawowe generowanie ma działać offline.

### Profile i wiek
- Przy tworzeniu profilu zapytać o przedział wiekowy, bez zbędnego zbierania dokładnej daty urodzenia.
- Tryb gościa / bez logowania traktować domyślnie jako użytkownika poniżej 18 lat.
- Dobór reklam i ustawienia SDK muszą respektować deklarację wieku, grupę docelową gry, zgodę i wymagania regionu.
- Nie wolno traktować samego oświadczenia o wieku jako zamiennika wymaganych mechanizmów ochrony.

### Reklamy — pierwsza aktualizacja po alfie
- Mały, stały panel reklamowy w menu, bez zasłaniania przycisków i treści.
- Dobrowolna reklama z nagrodą po zwycięstwie: podwójne CR; zwykła nagroda zawsze przyznawana niezależnie.
- Maksymalnie jedna nagroda reklamowa na wyścig, maksymalnie 3 dziennie, minimum 30 minut przerwy — konserwatywne limity projektu, nie oficjalne limity Google.
- Brak reklam podczas wyścigu, automatycznego odtwarzania, automatycznych kliknięć i zachęcania do klikania.
- Testowe reklamy / testowe urządzenia w fazie testów. Aktywne reklamy dopiero po konfiguracji i weryfikacji konta.
- Oficjalny SDK, polityka prywatności, Data safety, deklaracja reklam, grupa docelowa, wymagane zgody i kontrola AdMob.

### Texture Manager
- Tryb automatyczny i ręczny.
- Pobieranie przez Wi-Fi i dane mobilne; limit biblioteki 1024 MB.
- Legalne źródła (np. ambientCG, Poly Haven), kontrola licencji, plików i jakości, zapis atrybucji.
- Podgląd, usuwanie, ponowne pobieranie, pauza, dostęp offline.
- Biblioteka dostępna w generatorze i ręcznym edytorze.
- Wygląd tekstury oddzielony od fizyki nawierzchni.

### Modele
- Można nakładać materiały/tekstury na modele dostarczone przez użytkownika lub Claude.
- Nie zmieniać geometrii, wymiarów, proporcji, kształtu, położenia ani zatwierdzonych dodatków istniejących modeli.
- Jeśli model nie ma UV lub podziału materiałów, zgłosić ograniczenie zamiast przebudowywać model bez zgody.

## Zasady Google Play przed publikacją alfy
- Zweryfikować docelowy poziom Android API aktualny w dniu wysyłki.
- Przygotować politykę prywatności i prawidłową deklarację Data safety.
- Prawidłowo zadeklarować reklamy, grupę docelową i rating treści.
- Sprawdzić uprawnienia, SDK, zgody, usuwanie danych/konta jeśli dotyczy oraz wymagania dla funkcji online.
- Nie traktować tej listy jako gwarancji akceptacji sklepu; przed wysyłką sprawdzić aktualne Play Console policy status.

## Ograniczenia weryfikacji
- Zmiany kodu tej iteracji sprawdzono statycznie i kontrolą ZIP.
- Nie uruchomiono parsera GDScript, importu ani symulacji Godot 4.7, ponieważ środowisko robocze nie ma dostępnego wykonywalnego Godot.
- Kolizje stacji, ponowne dokowanie, wykrywanie zbierania przy dużej prędkości i odliczanie po resecie wymagają testu runtime na urządzeniu.
