# Robot Racing v0.3 — przebudowa trasy mieszkalnej

## Status

Dokument projektowy. Nie oznacza, że nowa geometria, dachy, drzwi ani kolizje zostały już wdrożone lub przetestowane w Godot.

## Inspiracje i wnioski

Inspirujemy się ogólnymi zasadami projektowania tras w domowych środowiskach, bez kopiowania gotowych układów, modeli, nazw ani charakterystycznych elementów:

- **Re-Volt — Home 1:** czytelny parter zwykłego domu, rozpoznawalne pomieszczenia i domowy klimat. Ważny wniosek: pokój ma wyglądać jak prawdziwe miejsce, ale jednocześnie musi mieć odpowiednio szeroką, przejezdną linię.
- **Toy Home:** sypialnia, kuchnia i pokój dziecięcy, duże z perspektywy małego pojazdu zabawki, punkty kontrolne oraz skoki. Wniosek: zwykłe wyposażenie może tworzyć ciekawe, ale czytelne przeszkody.
- **Micro Overdrive: Home Tour:** kuchnia, stół roboczy, wanna i salon, skróty oraz przeszkody. Wniosek: trasa powinna oferować wybór linii i precyzyjne, ale przystępne prowadzenie.

## Układ nowej trasy

Jedna ciągła, zamknięta pętla prowadząca przez kilka wyraźnie odróżnialnych pomieszczeń:

1. Przedpokój / odcinek startowy — długa, prosta sekcja i czytelna linia startu.
2. Salon — szybki łuk wokół stolika i kanapy, z bezpiecznym marginesem od mebli.
3. Kuchnia — slalom przy wyspie kuchennej, bez przejazdu pod niebezpiecznie niskimi elementami.
4. Łazienka — techniczny fragment na płytkach, z szerokim nawrotem.
5. Sypialnia — spokojniejszy łuk na wykładzinie i czytelny objazd łóżka.
6. Pokój dziecięcy — szykana z zabawek i bezpieczny skrót.
7. Powrót korytarzem do mety.

Układ ma być inspirowany typowym polskim mieszkaniem z nowoczesnymi elementami. Nie kopiujemy map z wymienionych gier.

## Punkt startowy i przejezdność

- Punkt startowy oraz kierunek startu muszą być zgodne z istniejącym, sprawdzonym systemem `TrackBase` i ustawieniem pól startowych.
- Nie wolno ustalać nowego początku wyłącznie na podstawie wyglądu sceny.
- Przed dodaniem trasy do `TrackDatabase` trzeba sprawdzić położenie linii startu, kierunek jazdy, pola wszystkich robotów i otwór w bandzie przy starcie.
- Cała pętla ma być zamknięta, bez skrzyżowań z samą sobą, ślepych odnóg i przerw w nawierzchni.
- Meble i dekoracje nie mogą nachodzić na pas jazdy ani na pola startowe.
- Szerokość przejazdów i otworów drzwiowych musi uwzględniać rzeczywisty obrys robota, szerokość trasy i zapas na omijanie.
- Trasa nie jest gotowa, dopóki robot gracza i AI nie potrafią przejechać pełnego okrążenia bez utknięcia.

## Ściany, drzwi i dach

### Ściany zewnętrzne

- Ciągłe ściany zewnętrzne zamykają mieszkanie.
- Okna występują wyłącznie w ścianach zewnętrznych; przez nie widać polskie osiedle.
- Ściany mają prawidłowe kolizje, nie tylko dekoracyjną siatkę.

### Ściany wewnętrzne

- Każde pomieszczenie ma czytelne granice i własny charakter.
- Ściany działowe są budowane z osobnych odcinków po obu stronach otworu drzwiowego.
- Otwór drzwiowy jest prawdziwą przerwą w geometrii i kolizji ściany, a nie teksturą lub namalowanym prostokątem.
- Nad otworem może znajdować się nadproże, a po bokach ościeżnica.
- Drzwi mogą być otwarte i odsunięte przy ścianie; ich skrzydło nie może blokować zaplanowanej trasy.
- Kolizje muszą odpowiadać widocznej geometrii. Nie może pozostać niewidzialna ściana w przejściu.

### Dachy i sufity

- Każde pomieszczenie ma sufit, a mieszkanie ma pełne zadaszenie.
- Sufity są podzielone na sekcje odpowiadające pomieszczeniom, aby można było kontrolować ich widoczność.
- Lampy sufitowe, plafony i inne źródła światła są umieszczone pod sufitem.
- Gdy kamera znajduje się wewnątrz mieszkania, zasłaniająca ją sekcja sufitu powinna płynnie zanikać lub przechodzić w tryb podglądu, aby nie zasłaniać robota i trasy. Po zmianie widoku dach wraca do normalnej widoczności.
- Nie wolno usuwać dachu z całej sceny tylko po to, aby kamera widziała trasę.

## Testy wymagane przed uznaniem trasy za gotową

1. Sprawdzenie startu dla każdego pola startowego.
2. Przejazd gracza przez całą pętlę i powrót na linię mety.
3. Przejazd każdego przeciwnika AI przez pełne okrążenie.
4. Test wszystkich otworów drzwiowych z kolizjami włączonymi.
5. Test, czy robot nie zahacza o ściany, ościeżnice, meble i skrzydła drzwi.
6. Test widoczności sufitu i dachu z kamery wyścigu oraz innych kamer.
7. Test minimapy, punktów kontrolnych, brudu i stacji.
8. Test wydajności na Androidzie.

## Zasada zachowania projektu

Nowa trasa jest dodatkiem do istniejącej zawartości. Nie zastępuje ani nie usuwa poprzedniej trasy. Nie wolno zmieniać istniejących modeli 3D ani ich tekstur. Nowe elementy architektury mają być osobnymi zasobami i korzystać ze wspólnych bibliotek, gdzie to możliwe.


## Aktualizacja generatora v15 — proporcje i zagospodarowanie

- Zmniejszono margines mieszkania wokół trasy i zwiększono liczbę podziałów, aby powstawało zwykle 6–17 mniejszych pomieszczeń zamiast kilku bardzo dużych stref.
- Katalog stylów może powtarzać sypialnie i tworzyć osobną bawialnię; bawialnia ma własny układ z dywanem, półką, schowkiem, stolikiem, krzesłami i zabawkami.
- Zwiększono skalę głównych mebli w skali świata gry. Zestawy salonu, jadalni i sypialni nadal są rozmieszczane według funkcji pomieszczenia.
- Wysokość ścian pomieszczeń wynosi 2,75 m w skali rzeczywistej świata gry, a otworów drzwiowych 2,05 m; okna i oświetlenie dopasowano do wyższych ścian. Podniesiono też ściany w stałej trasie mieszkania.
- Zwiększono liczbę dekoracji w pomieszczeniach położonych bliżej trasy, bez rezygnacji z testów odstępu od toru, drzwi i innych mebli.
- Usunięto ściany/bariery biegnące wzdłuż krawędzi jezdni. Granice toru wyznaczają teraz cienkie linie krawędziowe; usunięto też przerywane paski ze środka jezdni.
- Dodano osobny model telewizora ściennego do salonu oraz powierzchnie promocyjne na jego ekranie, stolikach, regałach i szafkach; ramki promocyjne pojawiają się też na wybranych ścianach wewnętrznych. Korzystają z miniatur kanału YouTube, jeśli uda się pobrać je z publicznego kanału; bez sieci pozostaje neutralne tło.
- Nakładki promocyjne są osobnymi siatkami i nie zmieniają geometrii istniejących modeli mebli.

Zmiany są zapisane w kodzie, ale nie zostały uruchomione w Godot ani sprawdzone na Androidzie. W szczególności trzeba zweryfikować przejezdność bez band, ustawienie większych mebli, widoczność reklam na ekranach i wydajność przy większej liczbie pomieszczeń.


## Aktualizacja generatora v22 — mniejsze, gęściej zagospodarowane mieszkanie

- Zmniejszono margines obrysu mieszkania wokół trasy z 14 do 10 m z każdej strony; podłoga bazowa została dopasowana do nowego marginesu.
- Zwiększono liczbę losowanych podziałów pomieszczeń (22–48) i obniżono minimalny wymiar pokoju, aby układ częściej składał się z mniejszych, zróżnicowanych stref zamiast kilku dużych prostokątów.
- Zwiększono liczbę krótkich ścianek wnękowych do 2–4, dzięki czemu część pokoi otrzymuje dodatkowe załamania i kształty L.
- Podniesiono wersję generatora do v22, aby nowe układy nie korzystały ze starych identyfikatorów tras; zapisane trasy z wcześniejszą wersją otrzymują nowy układ pomieszczeń podczas normalizacji.
- Poprawiono zbieranie AABB modeli w podglądzie: uwzględniane są transformacje wszystkich potomnych węzłów MeshInstance3D. Centrowanie odbywa się według rzeczywistego obrysu geometrii, a nie punktu początku modelu.

Zmiany sprawdzono statycznie i pod kątem integralności archiwum. Nie uruchomiono Godot ani testu runtime na Androidzie.


## Aktualizacja 2026-11-18 — realistyczniejsze mieszkania i bezkolizyjne pasy toru

- Generator dzieli przestrzeń dopiero powyżej ok. 70 m² na pokój, tworzy maksymalnie pięć głównych pomieszczeń i pozostawia najwyżej jedną krótką wnękę w większym układzie.
- Szerokość toru wynosi teraz 1,25–2,05 m zależnie od rozmiaru planszy.
- Walidacja generatora v25 odrzuca skrzyżowania oraz nieprzyległe fragmenty toru bliższe niż szerokość jezdni + 0,35 m; nie ma wyjątku dla wysokiej złożoności.
- Podgląd 2D/3D i suwak zoomu są w jednym kontenerze pionowym; mapa ma elastyczną wysokość, a panel przycina zawartość do obramowania.
- Kamera główna: 1,35 m od robota, 0,82 m wysokości; ograniczono odsuwanie kamery podczas boosta.


## Aktualizacja 2026-11-18 – skala obiektów, map i geometria
- Zmniejszono skalę dekoracji i mebli w generatorze oraz w umeblowaniu pokoi; zwierzęta zachowują dotychczasową skalę.
- W v28 pięć poziomów rozmiaru mapy obejmuje orientacyjnie 100–500 m²; rzeczywista powierzchnia zależy od seedu i kształtu.
- Nowe losowe trasy otrzymują nieregularny, ortogonalny przebieg z prostymi odcinkami i narożnikami; dotychczasowe zapisane trasy nie są przepisywane.
- Zmniejszono szarą ramkę podglądu, grubość obramowania i wewnętrzne marginesy; rozmiar samego obszaru mapy pozostaje bez zmian.
- Obniżono prędkość maksymalną i przyspieszenie bazowych robotów o około 12–10%; mechanika boostów nie została zmieniona.


## Naprawa generatora i kolizji wizualnych — 2026-11-18
- Rewizja generatora 27 zachowuje nieregularne obrysy i proste odcinki bez sztucznego podwajania liczby punktów.
- Trasa awaryjna ma sprawdzony zapas odstępów dla wszystkich szerokości toru i poziomów złożoności.
- Meble i dekoracje są filtrowane względem granic pokoi oraz ścian działowych; obiekt jest pomijany, jeśli nie da się znaleźć bezpiecznego miejsca.
- Podgląd 2D dopasowuje zewnętrzne granice pokoi do mapy, bez sztucznego rozszerzenia.


### Aktualizacja v28
Rozmiary generatora map zostały rozszerzone do orientacyjnego zakresu 100–500 m². Jezdnia ma 1,65–2,25 m szerokości, a prosta start/meta 7 m. Stacje na trasie są skalowane do 0,40 i ustawiane z miejscem na platformę. Meble oraz dekoracje są mniejsze względem robotów; część drobnych modeli trafia na blaty stołów, szafek i kuchennych blatów. Zapisane wygenerowane trasy v27 są automatycznie migrowane, natomiast ręczne układy pozostają bez automatycznego skalowania.
