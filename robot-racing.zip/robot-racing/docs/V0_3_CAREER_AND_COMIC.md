# Robot Racing v0.3 — kampania S-01 i narracja komiksowa

## Kampania

Kampania jest lokalna/offline i zapisuje postęp w sekcji `career` zapisu gracza. Składa się z dziewięciu wydarzeń w trzech rozdziałach:

1. **Dno Harmonogramu** — kawalerka, salon i przedpokój; pierwsze wyścigi Modelu S-01.
2. **Korporacyjny Wyścig Szczurów** — biura i open space; dedykowane umeblowanie biurowe oraz większa trudność.
3. **Pro League** — futurystyczne, oficjalne mistrzostwa i finał o tytuł Króla Paneli.

## Narracja komiksowa — część kariery, nie osobny tryb

Komiks nie jest osobną pozycją menu. `CareerStoryPanel.gd` jest komponentem narracyjnym wbudowanym w przepływ kariery:

- **Przed wyścigiem:** po wybraniu wydarzenia gracz ogląda wprowadzenie i dopiero po ostatnim kadrze rozpoczyna wyścig.
- **Po wyścigu:** ekran wyników pokazuje dalszy ciąg historii zależny od awansu. Przycisk końcowy wraca do kariery.
- **Między wyścigami:** strona kariery pokazuje krótką scenę przygotowań S-01 i zapowiedź kolejnego wydarzenia.

Portret S-01 korzysta z aktualnej konfiguracji robota gracza. W przyszłości kolejne wydarzenia mogą dostać własne kadry i dialogi bez zmiany przepływu menu. Dawna strona `comic` jest przekierowywana do kariery, aby nie tworzyć osobnego trybu.

## GUI / UI

Aktywne zasoby interfejsu są w `res://ui/` i `res://scripts/ui/`. Katalog `res://gui/` zawiera indeks struktury i opis odpowiedzialności, nie duplikuje zasobów. Sekcja `[gui]` w `project.godot` to ustawienia silnika, a nie ścieżka do folderu.

## Uwagi testowe

Zmiany wymagają uruchomienia w Godot 4.7.2: przepływ intro → wyścig → wyniki → kontynuacja kariery, ponowienie nieudanego wydarzenia, przejście między rozdziałami i zapis postępu. Statyczna kontrola plików nie potwierdza poprawności runtime.
