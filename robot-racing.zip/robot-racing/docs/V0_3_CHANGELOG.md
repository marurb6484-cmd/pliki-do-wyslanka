# Robot Racing v0.3 – dziennik zmian

## Nowa kolekcja robotów — pięć dodatkowych konstrukcji (2026-11-19)

- Dodano na końcu bazy pięć robotów: Pan Pajączek Turbo, Skarpeciarz, Zenek Okrągły, Wacek Peryskop i Walenty Wieloryb. Otrzymały nowe identyfikatory oraz indeksy 10–14, ponieważ indeksy 5–9 są już zajęte przez wcześniejsze roboty w aktualnej wersji gry.
- Zachowano istniejące wpisy, kolejność, identyfikatory, statystyki, ceny, zapisy, stacje i modele. Nowe roboty korzystają z osobnych kluczy kształtów i własnych detali proceduralnych.
- Przeskalowano bazowe speed i acceleration z opisu starszej wersji do aktualnej skali statystyk gry (dzielenie przez 4,05), aby nowe roboty nie otrzymały kilkukrotnie większych parametrów niż obecna kolekcja. Pozostałe parametry zachowują wartości z opisu.
- Dodano obsługę matowego wykończenia oraz zmniejszonej skali kół dla płaskich platform; ulepszenie przyczepności zachowuje tę proporcję. Portret kariery rozpoznaje nowe kształty.
- Nie zmieniano fizyki, promienia kolizji, stacji, skórek, boostów ani systemu multiplayer.
- Nie wykonano testu runtime w Godot 4.7.2 — środowisko nie ma wykonywalnego Godota.


## Pięć nowych konstrukcji robotów — wymiana platform wizualnych (2026-11-18)

- Wymieniono mapowanie pięciu istniejących robotów na pięć odrębnych proceduralnych platform inspirowanych przekazanymi referencjami: płaski robot z ukrytym modułem dToF i mopami; ultra-płaski model z pięcioosiowym ramieniem; klasyczna bryła z tylną podnoszoną pokrywą mopa; robot z centralnym LDS i wysuwanym mopem; obła konstrukcja z dwiema kamerami AI i trójpłatowymi padami.
- Nie dodano logotypów ani nazw producentów. Zachowano istniejące identyfikatory robotów, nazwy w grze, statystyki, kolory bazowe, indeksy, ceny i zapis postępu — zmieniła się wyłącznie wartość `shape` wykorzystywana przez renderer.
- Każdy model zachowuje wspólne koła, szczotki, zderzak, dysze boosta i obwiednię fizyczną; elementy rozpoznawcze są oddzielnymi węzłami, a ramię Saros ma hierarchię węzłów przygotowaną do animacji.
- Dodano boczne szyny montażowe, a pojemnik, kondensatory i dodatki ulepszeń odsunięto do stref montażowych, aby nie nakładały się na kamery, ramię ani moduły mopujące.
- Modele są generowane z prostych siatek Godota i `StandardMaterial3D`; nie wymagają SSR, SDFGI, SSAO, ReflectionProbe, glow ani shaderów specyficznych dla wysokiej jakości. Istniejący `apply_graphics()` nadal steruje światłami i VFX niezależnie od geometrii.
- Zaktualizowano także `CareerRobotPortrait.gd`, aby portret komiksowy rozpoznawał nowe identyfikatory brył i pokazywał ich charakterystyczne elementy.
- Zmiany są ograniczone do `RobotVisuals.gd`, `RobotDatabase.gd`, `CareerRobotPortrait.gd` i dokumentacji. Stacje serwisowe nie zostały zmienione.
- Kontrola ZIP i kontrola statyczna plików: do wykonania po spakowaniu. Nie wykonano testu runtime w Godot 4.7.2 ani testu na Androidzie — w środowisku roboczym nie ma wykonywalnego Godota. Kompatybilność z presetami grafiki została zaprojektowana bez zależności od funkcji high-end, ale wymaga potwierdzenia na urządzeniu.

## Generator tras v31 — meble, stacje, skala i edytory tekstu (2026-11-18)

- Usunięto tworzenie dodatkowych stacji ładowania w połowie otwartego odcinka — zarówno z generatora, jak i z `RaceScene`. Stacje gracza i AI są skupione wyłącznie przy starcie; starsze dane po normalizacji czyszczą pole `midpoint_station`.
- Duże meble i wyposażenie nie są oznaczane ani rozmieszczane jako rekwizyty na jezdni. Dodatkowe meble w pokojach uwzględniają teraz większy margines od krawędzi toru i gabaryty danego rodzaju mebla.
- Małe rekwizyty torowe pozostają osobną kategorią. Test generatora sprawdza, czy meble nie trafiają na jezdnię.
- Usunięto dodatkowe mnożniki 0,72 i 0,78 zmniejszające modele po odczytaniu ich skali. Modele, kolizje i podgląd korzystają z tej samej skali instancji.
- Dopasowano hitboxy mebli do rzeczywistych wymiarów używanych przez `RoomFurnisher`; meble i rekwizyty pozostają zamrożone przed wyścigiem, ale odmarzają po uderzeniu robota.
- Poprawiono mapowanie sześciu poziomów skali podczas migracji starszych tras.
- W edytorze komiksu zamieniono wielowierszowy `TextEdit` na jednoliniowy `LineEdit`, ponieważ tekst dymków jest pojedynczym dialogiem. Usunięto również niepotrzebne sprawdzanie `TextEdit` w menu garażu i warsztatu.
- Wersja generatora podniesiona do 31. Kontrola ZIP i statyczna kontrola plików; nie wykonano testu runtime, ponieważ w środowisku nie ma Godota.

## Iteracja: integracja pit stopu i loadoutu

- Dodano automatyczny powrót do stacji po osiągnięciu 100% uszkodzeń.
- Naprawa może być przerwana gazem; gracz może kontynuować z niepełną naprawą.
- Zachowano oddzielną ścieżkę awaryjnego powrotu po wyczerpaniu baterii.
- Dodano reakcję na zapisany stan 100% uszkodzeń przed rozpoczęciem wyścigu.
- Dodano trwały zapis globalnego wyposażenia boostów i presetów.
- Naprawiono indeksowanie slotów po wyczyszczeniu jednego z nich.
- Dodano walidację danych i test systemu loadoutu.

## Ograniczenia

Zmiany nie oznaczają jeszcze, że wszystkie boosty są aktywne w wyścigu ani że wszystkie zaplanowane systemy v0.3 zostały ukończone. Szczegóły znajdują się w `V0_3_IMPLEMENTATION_STATUS.md`.

## Iteracja: rozbudowa menu i centrum gracza

- Rozbudowano menu główne o Karierę, Wyzwania, Multiplayer, Sklep, Edytor tras, Mody, Profil gracza, Boosty i O twórcy.
- Dodano Warsztat Boostów: wybór boostów do odblokowanych slotów, czyszczenie slotów, tworzenie i przełączanie presetów; konfiguracja korzysta z istniejącego trwałego systemu `BoostLoadoutSystem`.
- Dodano lokalny profil z edytowalnym nickiem, lokalnym identyfikatorem zapisu i podglądem statystyk.
- Dodano podsumowanie kariery, kolekcji i postępu celów długoterminowych.
- Dodano ekran O twórcy z odnośnikami do kanału Szakal PC Android i Facebooka.
- Niezrealizowane jeszcze usługi społecznościowe, multiplayer internetowy, sklep, edytor tras i mody są jawnie oznaczone jako WKRÓTCE.

## Ograniczenia tej iteracji

- Warsztat zapisuje konfigurację slotów i presetów, ale boosty nie są jeszcze aktywowane w trakcie wyścigu; pełna integracja mechaniki pozostaje osobnym zadaniem.
- Profil jest lokalny. Identyfikator nie jest globalnie unikalny i nie zapewnia synchronizacji między urządzeniami.
- Wyzwania są na razie podglądem postępu, bez nagród i rotacji dziennej/sezonowej.
- Edytor tras, sklep społecznościowy, mody i multiplayer nie zostały wdrożone.
- Nie wykonano testu uruchomieniowego Godot — w środowisku przygotowania nie ma dostępnego wykonywalnego Godot.

## Iteracja: reset pozycji, boosty w wyścigu i generator tras

- Dodano przycisk RESET POZYCJI na HUD-zie. Trzeba go przytrzymać przez 1,5 sekundy; powrót odbywa się na najbliższy punkt linii trasy.
- Reset nie zmienia okrążenia, czasu ani naliczonego postępu, nie naprawia robota, nie ładuje baterii i nie zeruje cooldownów boostów.
- Zintegrowano system wyboru boosta z rozgrywką. Przycisk NASTĘPNY w HUD-zie i klawisz TAB przełączają wyposażone sloty w trakcie jazdy; dotychczasowy przycisk BOOST aktywuje wybrany typ. Pad używa przycisku Y do zmiany i X do aktywacji.
- Dodano zużywanie energii baterii, indywidualne cooldowny i aktywne efekty 10 typów boostów: Turbo, Impuls elektryczny, Śliski ślad, Fala uderzeniowa, Tarcza, Magnes, Naprawa awaryjna, Regenerator energii, Overdrive i Hologram.
- Doprecyzowano zachowanie Turbo: 70% skuteczności zbierania brudu, słabsze hamowanie, o 50% mocniejsze odrzucenie przeciwnika i mniejsza własna reakcja przy kolizji z robotem; uderzenie w ścianę osłabia Turbo do końca aktywacji. Kara przyspieszenia po Turbo wraca stopniowo.
- Dodano trwałe ulepszenia parametrów boostów: osobne poziomy 0–20, progresywny koszt CR, osobne zapisy dla każdej rzadkości i panel zakupu w Warsztacie Boostów.
- Dodano generator proceduralny z seedem, rozmiarem, złożonością, gęstością przeszkód i motywem pomieszczenia.
- Generator pokazuje podgląd 3D, pozwala generować ponownie, zapisywać do lokalnej biblioteki (do 40 tras), wczytywać i usuwać zapisane trasy oraz natychmiast uruchamiać wyścig.
- Dodano scenę proceduralnej trasy z nawierzchnią, bandami, przeszkodami, linią startu i punktami brudu.

## Ograniczenia tej iteracji

- Aktywne ulepszenia w wyścigu korzystają obecnie z rzadkości zwykłej. Poziomy rzadki/unikalny/legendarny są zapisywane oddzielnie, ale system zdobywania i wyposażania tych rzadkości nie jest jeszcze gotowy.
- Hologram tworzy wizualną kopię, ale pełne wabienie AI nie jest jeszcze zintegrowane. AI korzysta obecnie przede wszystkim z Turbo, a nie z całej taktycznej puli boostów.
- Generator tworzy działające, proceduralne pętle i zapisuje je lokalnie. Pełny ręczny edytor obiektów, mebli i przeszkód nadal pozostaje osobnym etapem.
- Nie wykonano uruchomienia gry w Godot ani testu na Androidzie; środowisko robocze nie ma dostępnego wykonywalnego Godot 4.7.


## Generator tras — stacje, kolory i otoczenie (2026-11-14)

- Każda nowa trasa proceduralna zawiera dwie stacje dokujące po przeciwnych stronach linii startu (lewa i prawa). Stacje korzystają ze wspólnego systemu wyglądu używanego w Garażu i pit stopie.
- Zapisane starsze trasy są migrowane przy odczycie: brakujące stacje startowe są wyliczane z geometrii trasy.
- Nawierzchnia toru jest dzielona na kolorowe segmenty zależne od motywu; dodano jasne oznaczenia obu krawędzi, bardziej kontrastowe podłogi i kolorowe ściany.
- Każda nowa trasa otrzymuje modele kota, psa i królika oraz podstawowe elementy mieszkania: roślinę, sofę i stół. Dodatkowe losowe dekoracje obejmują m.in. lampy, zabawki, akwaria, regały, poduszki, krzesła, łóżka, szafki, miski dla zwierząt i zabawkowe roboty.
- Seed kontroluje również położenie, obrót, wariant i skalę dekoracji, dzięki czemu układ można odtworzyć.
- Rozszerzono testy generatora o obecność stacji, zwierząt, dekoracji i migrację starszych zapisów. Testy wymagają uruchomienia w Godot.

## 2026-11-14 — poprawka generatora i zwierzęta
- Usunięto nieistniejący w Godot 4 typ `ConeMesh`; stożki (uszy, kolce, dziób i klosz lampy) są budowane przez `CylinderMesh` z `top_radius = 0.0`.
- Generator każdej nowej trasy gwarantuje obecność kota, psa, królika, agamy brodatej i papugi.
- Dodano osobne, kolorowe modele dekoracyjne agamy brodatej i papugi oraz testy obecności obu zwierząt w danych generowanej trasy.
- Poprawka usuwa błąd parsowania `Identifier "ConeMesh" not declared`, który blokował ładowanie sceny proceduralnej i podgląd generatora.
- Nie wykonano testu runtime w Godot — środowisko Godot nie jest dostępne w tej sesji.

## Lokalny multiplayer – pierwsza implementacja (2026-11-14)
- Dodano wybór trybu „LOKALNY MULTIPLAYER – 2 GRACZY” w ekranie wyboru trybu.
- Dodano wspólny wyścig dwóch lokalnych kierowców na tej samej trasie.
- Sterowanie: Gracz 1 – WASD / kontroler 0 / dotykowy HUD; Gracz 2 – strzałki / kontroler 1.
- Obaj gracze są uwzględniani w klasyfikacji i warunku zakończenia wyścigu.
- Każdy gracz ma własny robot, energię, boosty i obsługę pit stopu.
- Ograniczenia tej wersji: wspólna kamera podążająca za Graczem 1, jeden HUD, brak osobnych profili i osobnego rozliczania nagród Gracza 2. Wersja obsługuje dwóch graczy, nie 2–4.
- Wymagane testy na urządzeniu: dwa kontrolery, klawiatura + kontroler oraz dotyk + kontroler.

## Iteracja: ruch zwierząt, awaryjny pit stop, zniszczenia i tory wyścigowe

- Zwierzęta otrzymały bardziej wyraźne wzorce ruchu: kot patroluje szerzej, pies aktywnie podbiega do robotów, królik wykonuje wyższe i częstsze podskoki, agama brodata patroluje powoli z kołysaniem, a papuga wykonuje szersze przeloty.
- Awaria baterii lub osiągnięcie 100% uszkodzeń przenosi robota bezpośrednio do stanowiska serwisowego. Okrążenie i czas wyścigu nie są resetowane; naprawa i ładowanie odbywają się już w stacji.
- Dodano stałe wartości uszkodzeń zależne od rodzaju mebla/przedmiotu. Lekkie przedmioty powodują małe uszkodzenia, a ciężkie meble i akwarium większe. Po kontakcie przedmiot zostaje usunięty.
- Różne przeszkody torowe mają różne rozmiary, wygląd i wartości uszkodzeń. Po kolizji znikają.
- Akwarium jest teraz nieprzezroczystym obiektem; pozostałe elementy otoczenia używają materiałów nieprzezroczystych.
- Generator tworzy nieregularny tor wyścigowy z długimi prostymi, nawrotami i sekwencją zakrętów zamiast symetrycznego owalu.
- Rozmiary mapy rozszerzono do pięciu poziomów, szerokość toru do 10–17 m, a podgląd 3D automatycznie oddala kamerę dla większych map.
- Zwiększono bazową szybkość skrętu i przyczepność boczną robotów, aby reagowały mocniej na sterowanie.
- Rozszerzono regresyjne testy generatora o pięć rozmiarów map, minimalną długość segmentów i różne seedy.

## Ograniczenia tej iteracji

- Nie uruchomiono Godot 4.7 ani gry na Androidzie; zmiany przeszły kontrolę statyczną i kontrolę danych generatora, ale nie test runtime.
- Zniszczenie obiektów jest natychmiastowe; nie dodano jeszcze osobnych animacji rozpadu ani odłamków.
- Zwierzęta mają ruch całej sylwetki i własne zachowania, ale nie mają jeszcze osobnych animacji szkieletowych łap, skrzydeł czy pyska.

## 2026-11-14 — poprawka błędu generatora i klinowe przeszkody
- Naprawiono wcięcie instrukcji w gałęzi `bearded_dragon` w `TrackAnimal.gd`, które powodowało błąd parsowania `Expected indented block after match pattern block` i blokowało ładowanie generatora.
- Przeszkody generowane bezpośrednio na trasie mają teraz trójkątny, klinowy przód skierowany zgodnie z kierunkiem jazdy na najbliższym segmencie trasy.
- Zmieniono kolizję przeszkody z prostopadłościanu na wypukły klin, obniżono masę i tarcie oraz dodano niewielką sprężystość. Cel: łagodniejsze odbicie/rozsunięcie robota zamiast zatrzymania na płaskiej ścianie.
- Przeszkody nadal znikają po kontakcie i zachowują przypisane wartości uszkodzeń.
- Nie wykonano testu parsera ani fizyki w Godot 4.7 — zmiany sprawdzono statycznie.

## Generator tras – losowe układy i większa przestrzeń
- Zastąpiono stały obrys trasy generowaniem nieregularnej pętli z losowaną liczbą punktów, odstępami kątowymi i promieniami.
- Zachowano prosty odcinek startowy oraz dwie stacje dokujące po jego bokach.
- Zwiększono skalę pięciu poziomów przestrzeni do 1.6 / 2.1 / 2.7 / 3.4 / 4.2.
- Wprowadzono kontrolę przecięć nie sąsiadujących odcinków trasy.
- Zmieniono skalowanie podglądu i zasięgu odbić tak, aby odpowiadały nowym rozmiarom.

## Iteracja: losowe kształty tras, odstęp ścian i ulepszanie całych boostów
- Generator nie używa już jednego eliptycznego obwodu. Losuje różne profile promieni, proporcje osi, asymetrię i sześć rodzin kształtów; seed nadal pozwala odtworzyć trasę.
- Skale map powiększono do mnożników 2.0–6.2.
- Kandydat trasy jest odrzucany, gdy odcinki nieprzylegające przecinają się albo są zbyt blisko siebie. Kontrola uwzględnia większy margines niż szerokość jezdni.
- Usunięto powielony końcowy punkt startowy, który tworzył zerowej długości segment zamknięcia pętli.
- Ściany proceduralne są budowane z gęstszych, krótszych segmentów bez celowego wydłużania brył na zakładkę.
- Warsztat boostów otrzymał zakup ulepszenia całego boosta: wszystkie parametry dostają +1 poziom w ramach jednego zakupu CR. Zachowano też ulepszanie pojedynczych parametrów i limit 20 poziomów.

## 2026-11-14 — dopasowanie podglądu, widoczność ulepszeń i kliny
- Podgląd generatora używa kamery ortograficznej, która wylicza granice trasy, stacji i przeszkód, uwzględnia proporcje okna oraz ponownie dopasowuje zoom po zmianie rozmiaru panelu. Cała trasa ma mieścić się w podglądzie niezależnie od rozmiaru mapy.
- Panel „ULEPSZENIA BOOSTÓW” przeniesiono bezpośrednio pod wybór boostów w wyposażeniu, przed katalogiem. Zmiana boosta w slocie synchronizuje wybór w panelu ulepszeń.
- Podgląd ulepszeń pokazuje aktualną oraz przewidywaną wartość parametru po następnym poziomie.
- Nazwy czterech rang dostosowano do ustaleń: zwykły → rzadki → unikalny → legendarny. Każdy parametr nadal ma 20 poziomów, a koszty rosną progresywnie.
- Klinowe przeszkody zachowują czubek skierowany w kierunku nadjeżdżającego robota. Po kontakcie robot dostaje kontrolowany impuls boczny i niewielki impuls do przodu, a przeszkoda znika; celem jest odbicie na bok bez całkowitego zatrzymania.
- Łączenie identycznych egzemplarzy boostów w celu awansu rzadkości pozostaje do dokończenia: wcześniejsze ustalenia wymagają zużywania identycznych składników o tym samym poziomie, ale konkretne liczby składników dla kolejnych rang nie zostały jednoznacznie ustalone. Nie wpisano arbitralnych wartości.
- Testy Godot i fizyki nie zostały uruchomione — środowisko nie ma dostępnego Godot 4.7.


## Generator / AI / boost pass — 2026-11-14
- Zmieniono ściany proceduralnych tras na ciemny grafit z jasną listwą górną, aby były czytelne w podglądzie generatora i podczas wyścigu.
- Generator używa sześciu łagodniejszych rodzin profili toru; losowe promienie są filtrowane pomiędzy sąsiednimi punktami, aby ograniczyć gwałtowne załamania.
- AI odświeża projekcję pozycji na trasę cyklicznie i po większym odchyleniu, ma adaptacyjny punkt patrzenia zależny od prędkości i krzywizny oraz odzyskuje linię po odbiciu/teleporcie.
- AI wybiera moment użycia boosta zależnie od jego typu: atak, obrona, zbieranie znajdziek, naprawa, regeneracja lub wabik.
- Hologram został dodany do grupy wabików AI; przeciwnicy mogą delikatnie zmienić linię jazdy w jego stronę.
- Nie wykonano testu runtime Godot/Android; zmiany wymagają sprawdzenia w grze.


## Aktualizacja 2026-11-14 — czytelność ścian, AI i profile torów
- Ściany toru zmieniono na ciemny grafit z jasną listwą górną, poprawiając widoczność na mapie generatora.
- Profil generatora wygładzono i podzielono na sześć rodzin układów: płynne łuki, asymetryczne nawroty, szykany, szerokie sekcje i techniczne sekwencje zakrętów. To inspiracja ogólnymi zasadami projektowania torów, bez kopiowania konkretnych tras.
- AI częściej weryfikuje swoje położenie na trasie, szybciej odzyskuje właściwy odcinek po odbiciu lub dużym odchyleniu i lepiej dobiera punkt patrzenia w zakrętach.
- AI ma warunkowe użycie wszystkich typów boostów, zależnie od sytuacji na torze. Hologram został zintegrowany z grupą wabików wpływających na decyzje przeciwników.
- Test geometrii w Pythonie: 500 prób, 100 dla każdego rozmiaru mapy, wszystkie zakończone znalezieniem trasy spełniającej przyjęty margines odstępu. Nie jest to test silnika Godot.
- Testy parsera Godot, fizyki i rozgrywki na Androidzie nie zostały wykonane.


## Aktualizacja – okrągłe przeszkody i odrębne boosty
- Przeszkody proceduralne zmienione z kierunkowych klinów na niskie, okrągłe walce z okrągłym oznaczeniem na górze; kolizja odbija robota głównie stycznie, aby nie zatrzymywać go całkowicie.
- Efekty wizualne boostów rozdzielone: Turbo – płomień, Impuls – niebieska fala, Śliski ślad – różowo-fioletowy pas, Fala uderzeniowa – pomarańczowy pierścień, Tarcza – niebieska kopuła, Magnes – fioletowe pierścienie, Naprawa – zielony znak, Regenerator – turkusowe pierścienie, Overdrive – złote pierścienie stabilizacji, Hologram – kopia robota.
- Tylko Turbo zwiększa prędkość i przyspieszenie. Overdrive zmieniony na stabilizację prowadzenia i odporność na odrzut; AI używa go w zakrętach lub ciasnej walce.
- Ulepszenia nadal są przypisane kluczem do konkretnego boosta i rzadkości; nie są współdzielone pomiędzy różnymi boostami.
- Dodano statyczne sprawdzenia regresji do testu ulepszeń. Godot runtime nie był dostępny, więc testów silnikowych nie wykonano.


### Poprawki stabilności ruchu i edycji HUD (14.11.2026)
- Ratowanie robota uruchamia się już przy spadku poniżej Y = -1.25; po teleportacji synchronizowany jest dystans okrążenia, aby nie naliczać fałszywego postępu.
- Edytor HUD obsługuje natywny dotyk Androida i przechwytuje przeciąganie poza pierwotnym modułem; pasek narzędzi nadal pozostaje klikalny.
- Linia trasy na minimapie jest wyraźnie grubsza.
- Zwierzęta mają korytarze ruchu przecinające całą szerokość toru, mogą przekraczać boczne bandy i wykonują skoki zależne od gatunku.
- Wymagają testu w Godot i na telefonie; nie wykonano testu runtime.


## Aktualizacja UI i czytelności generatora — 2026-11-14
- W panelach ulepszeń garażu przyciski zakupu są mniejszymi polami; opisy i etykiety przekazują gest przesuwania palcem do przewijania listy.
- Warsztat boostów pokazuje wybór parametrów jako siatkę małych, osobnych przycisków z poziomem ulepszenia.
- Dodano obsługę przewijania ScrollContainer gestem dotykowym w obszarach ulepszeń i warsztatu.
- Pod trasą proceduralną dodano wąski, ciemny kontur kontrastowy (0,28 m na stronę), bez istotnego zwiększania szerokości samej jezdni.
- Weryfikacja: kontrola statyczna zmian i integralności ZIP; brak uruchomienia projektu w silniku Godot i brak testu na urządzeniu Android.

## Podgląd 3D generatora i ręczna edycja przeszkód — 2026-11-14
- W podglądzie 3D generatora ciemny obrys pod trasą ma 10-krotnie większą szerokość niż standardowy pas obrysu. Zmiana jest ograniczona do podglądu; geometria toru w wyścigu pozostaje bez zmian.
- Dodano pierwszy praktyczny etap ręcznego edytora tras: wybór poprzedniej/następnej przeszkody, przesuwanie jej po osi X/Z co 1 m, dodawanie i usuwanie okrągłych przeszkód.
- Zaznaczona przeszkoda ma żółty, świecący pierścień w podglądzie 3D.
- Zmiany edytora są zapisywane razem z trasą po użyciu przycisku „ZAPISZ TRASĘ LOKALNIE”.
- To nie jest jeszcze pełny edytor wszystkich mebli, dekoracji i zwierząt; to pierwszy etap zaplanowanego edytora obiektów.
- Nie uruchomiono testów Godot 4.7 ani testu na Androidzie w środowisku przygotowania.


## Stacje dokujące i strefa startowa — 2026-11-14
- Przed platformą każdej stacji dodano wyraźną, zieloną, świecącą matę naprowadzająco-ładującą z jasnymi znacznikami prowadzącymi.
- Generator od wersji 6 wydłuża prosty odcinek startowy z 28 do 36 jednostek skali bazowej; walidator wymaga teraz minimum 32 m dla nowego formatu.
- Stacje są odsunięte dalej od krawędzi jezdni, aby zostawić więcej miejsca na platformę i zieloną strefę najazdu. Powiększono również podłogę pomieszczenia, żeby strefy stacji nie wypadały poza jej obrys.
- Na prostej startowej dodano trzy pary świecących strzałek kierunkowych. Są elementami wizualnymi bez kolizji.
- Zaktualizowano regresyjny test generatora pod nowy numer wersji i minimalną długość prostej. Test nie został uruchomiony w Godot — brak silnika w środowisku przygotowania.

## 2026-11-14 — kolory tras, czytelniejszy podgląd, edytor obiektów i billboardy
- Nawierzchnia każdej trasy proceduralnej ma teraz jeden spójny kolor zależny od motywu; podłoga, ściany, krawędzie, meble i przeszkody pozostają odrębnymi elementami kolorystycznymi.
- Dodano jasne, przerywane oznaczenie środka jezdni.
- Podgląd 3D generatora korzysta z ukośnego kąta kamery, obejmuje też położenie dekoracji i ma znacznie szerszy obrys wyłącznie w podglądzie.
- Edytor pozwala wybrać typ obiektu (mebel, dekoracja lub zwierzę), dodawać go, wybierać na liście, przesuwać i usuwać. Wybrany obiekt ma żółty pierścień i wysoki znacznik widoczny w podglądzie.
- Dodawanie i usuwanie zwierząt aktualizuje liczbę zwierząt w danych trasy; limit wynosi pięć, zgodnie z walidatorem generatora.
- Na trasach proceduralnych pojawiają się trzy statyczne billboardy „SZAKAL PC ON ANDROID / YOUTUBE • GRY PC NA ANDROIDZIE”. Nie pobierają treści z sieci, nie migają i nie odtwarzają dźwięku.
- Centrum wyzwań otrzymało pięć lokalnych osiągnięć z jednorazowymi nagrodami CR; odebrane nagrody są zapisywane i uwzględniane w kopii/wyczyszczeniu postępu.
- Testy parsera Godot i uruchomienie na Androidzie nie zostały wykonane.


## Generator tras — poprawki czytelności i edycji (2026-11-14)
- Banery SZAKAL PC ON ANDROID mają teraz osobny napis na obu stronach panelu.
- Zaznaczony mebel/dekoracja/zwierzę jest mocniej powiększony w podglądzie, ma większy znacznik, wysoki słupek i etykietę. Powiększenie podglądu nie zmienia zapisanego rozmiaru obiektu.
- Kolejne dodawane obiekty są rozkładane po różnych fragmentach trasy i naprzemiennie po obu stronach, zamiast nakładać się w jednym miejscu.
- Edytor przedmiotów otrzymał obracanie co 15° oraz skalowanie w zakresie 0,6–2,4.
- Dodano piąty poziom złożoności oraz cztery dodatkowe profile geometrii tras. Wersja danych generatora: 7.
- Opcje przeszkód i przedmiotów mają teraz jednoznaczne nazwy, aby nie mylić dwóch osobnych edytorów.

## Naprawa parsera generatora tras i analiza trasy — 2026-11-14
- Naprawiono wcięcia gałęzi 6–9 instrukcji `match style` w `scripts/tracks/TrackGenerator.gd`. Były poza blokiem `match`, co powodowało błąd parsera i uniemożliwiało załadowanie globalnej klasy `TrackGenerator`.
- Dodano do podglądu generatora panel analizy: szacowana długość pętli, liczba zakrętów, liczba ciasnych zakrętów, przeszkód, dekoracji i zwierząt.
- Analiza odświeża się przy ponownym generowaniu oraz po zmianach obiektów i przeszkód.
- Kontrola statyczna poprawności wcięć i spójności zmian wykonana. Parser Godot 4.7 oraz testy runtime nie zostały uruchomione — brak wykonywalnego Godot w środowisku przygotowania.

## Generator tras — korekta stacji, edycji elementów i tekstur podłogi (2026-11-14)
- Wersja danych generatora wzrosła do 8. Obie stacje są teraz odtwarzane z geometrii prostej startowej: stoją obok siebie, w jednej linii, po tej samej stronie toru. Nie korzystamy ze starych, błędnych współrzędnych stacji zapisanych w trasie.
- Walidator rozróżnia stary układ stacji (wersje 1–7) i nowy układ v8; nowe trasy wymagają dwóch stacji w tej samej linii i po tej samej stronie startu.
- Układ pierwszych punktów trasy i prostej startowej pozostaje stałym elementem generatora; losowanie dotyczy dalszego przebiegu trasy.
- Podłoga pomieszczenia otrzymała pięć generowanych proceduralnie wzorów: ceramika, drewno, wykładzina, beton/kamień i panele futurystyczne. Wzór jest losowany przy każdym nowym seedzie, zapisywany w danych trasy i odtwarzany przy podglądzie oraz wyścigu.
- Poprawiono odświeżanie podglądu po zmianach: poprzedni świat podglądu jest usuwany przed utworzeniem nowego. Dodawanie przeszkód i dekoracji pracuje na kopii listy, zapisuje nową listę w danych trasy, rozkłada obiekty w różnych punktach i pilnuje limitów walidatora.
- Generator pokazuje wybrany rodzaj podłogi w statusie i analizie trasy.
- Kontrole statyczne i integralność archiwum wykonano. Godot 4.7.2 nie jest dostępny w środowisku przygotowania, więc parser, runtime i urządzenie Android nie zostały przetestowane.


## Modele proceduralnych elementów trasy — 2026-11-14
- Przebudowano wizualne modele wszystkich 17 rodzajów mebli/dekoracji: rośliny, sofy, stoły, lampy, zabawki, akwaria, regały, poduszki, krzesła, łóżka, szafki, miski, zabawkowe roboty, dywany, telewizory, drapaki i legowiska. Dodano m.in. poduszki, obrzeża, nóżki, uchwyty, półki, książki, liście, ziemię w donicy, detale akwarium i ekrany.
- Przebudowano modele pięciu gatunków zwierząt: kot, pies, królik, agama brodata i papuga. Dodano wyraźniejsze proporcje, pysk, nos, oczy z refleksami, uszy, łapy, palce, ogony, oznaczenia gatunkowe i szczegóły upierzenia/łusek.
- Pięć wariantów wizualnych przeszkód otrzymało odmienne sylwetki (miękka bryła, metalowa puszka, klocek, pachołek, bęben) i dodatkowe detale. Geometria kolizji pozostała okrągła i nie zmienia zasad fizyki.
- Ujednolicono bazowe właściwości materiałów: bardziej naturalna szorstkość, delikatne odbicia i metaliczność tylko tam, gdzie ma sens.
- Dodano test regresyjny obecności modeli dla wszystkich typów mebli i zwierząt. Test wymaga uruchomienia w Godot 4.7.2; nie został tu uruchomiony.
- Weryfikacja w tej iteracji ograniczona do kontroli statycznej kodu i integralności ZIP. Nie wykonano testu parsera, renderingu, fizyki ani wydajności na Androidzie.

## Aktualizacja 2026-11-14 — historia edycji tras i kopiowanie obiektów
- Dodano lokalną historię cofania i ponawiania zmian w edytorze tras (do 40 kroków).
- Historia obejmuje dodawanie, usuwanie, przesuwanie, obracanie, skalowanie i kopiowanie obiektów oraz edycję przeszkód; nowa trasa lub wczytanie innej trasy rozpoczyna czystą historię.
- Dodano duplikowanie wybranego mebla/dekoracji/zwierzęcia z zachowaniem jego ustawień, z kontrolą limitu 48 obiektów i 5 zwierząt.
- Poprawiono opisy przycisków przesuwania obiektów, aby nie sugerowały edycji przeszkód.
- Analiza podglądu 3D pokazuje teraz bieżący wynik walidacji trasy.
- Dodano test regresyjny katalogu 10 boostów i parametrów ulepszeń. Test wymaga uruchomienia w Godot 4.7.2 i nie został wykonany w tym środowisku.
- Dodano również duplikowanie zaznaczonej przeszkody z zachowaniem jej typu geometrii (okrągła kolizja) i kontrolą limitu 60 przeszkód.
- Dodano pięć kroków przesuwania obiektów: 0,25 m, 0,5 m, 1 m, 2,5 m i 5 m; ustawienie działa dla dekoracji oraz przeszkód.
- Dodano reset obrotu i skali zaznaczonej dekoracji do wartości domyślnych, z obsługą cofania/ponawiania.


## 2026-11-15 — Brud, przedmioty i tryb umieszczania w generatorze

- Przebudowano modele zbieranego brudu: kurz, okruchy, kłaczki, grudki błota, piasek i sierść składają się z wielu matowych, nieregularnych elementów zamiast pojedynczych kul.
- Rozszerzono bibliotekę dekoracji o but sportowy, skarpetkę, kubek, książkę, pilot, piłkę tenisową, kłębek włóczki, papier, resztki jedzenia, kabel i plecak.
- Dodano tryb dodawania przez dotknięcie miejsca na podglądzie 3D.
- Podgląd wymusza idempotentną budowę trasy po dodaniu jej do drzewa sceny i rysuje osobne znaczniki lokalizacji dekoracji, również w widoku mobilnym.
- Nie wykonano testu uruchomieniowego w Godot 4.7.2; wymaga weryfikacji na urządzeniu użytkownika.


## Aktualizacja 2026-11-15 — poprawione stacje i wytrzymałość dekoracji
- Wersja generatora tras wzrosła do 9. Stacje dokujące stoją po przeciwnych stronach długiej prostej startowej, dokładnie naprzeciwko siebie. Każda jest obrócona frontem i zieloną matą najazdową w stronę jezdni.
- Pozycje stacji wylicza jedna wspólna funkcja na podstawie szerokości toru; ta sama funkcja obsługuje nowe trasy, starsze zapisy i podgląd ProceduralTrack.
- Walidator sprawdza, czy stacje są po różnych stronach, nie nachodzą na jezdnię, stoją przy starcie i są skierowane do toru.
- Dodano wytrzymałość przedmiotów dekoracyjnych. Lekkie przedmioty niszczą się szybciej, ciężkie meble wymagają kilku uderzeń. Kontakt nadal powoduje odpowiednie obrażenia robota, a przedmiot ma krótką animację uderzenia i znikania po zniszczeniu.
- Zaktualizowano testy generatora i rozmieszczania dekoracji. Nie wykonano testu parsera Godot, runtime ani Androida — brak dostępnego silnika Godot 4.7.2 w środowisku przygotowania.


## Aktualizacja 2026-11-15 — banery i wyzwania offline
- Banery promocyjne przy trasie proceduralnej ustawiają szeroką powierzchnię w stronę nadjeżdżającego zawodnika; tekst jest dwustronny dla jazdy w przeciwnym kierunku.
- Dodano trzy wyzwania dzienne: ukończenie dwóch wyścigów, zebranie 100 jednostek brudu i zwycięstwo w wyścigu. Postęp, data i odbiór CR są zapisywane lokalnie.
- Rozszerzono osiągnięcia długoterminowe do 10 celów.
- Wyzwania działają offline; wydarzenia sezonowe i rankingi online nadal wymagają backendu.
- Test Godot runtime nie został wykonany w tym środowisku.


## Aktualizacja 2026-11-15 — skórki obiektów i edytor dotykowy (etap 1)
- Dodano system skórek obiektów `scripts/visual/ObjectSkins.gd`: Kreskówkowa (domyślna, wygląd bez zmian), Realistyczna, Neonowa i Pastelowa. Skórki zmieniają wyłącznie materiały — geometria, kolizje i logika modeli pozostają te same. Oryginalne materiały są zapamiętane, więc powrót do kreskówkowej przywraca pierwotny wygląd.
- Skórka jest zapisywana w ustawieniach (`graphics/object_skin`, `GameSettings.object_skin`) i stosowana do mebli, przedmiotów, zwierząt i przeszkód w wyścigu oraz w podglądzie edytora. Stacje dokujące są pomijane — ich wygląd nie został ruszony.
- Edytor tras (Generator): kategorie MEBLE / PRZEDMIOTY / DEKORACJE / ZWIERZĘTA / PRZESZKODY, duże kafelki przedmiotów, podgląd 3D wybranego modelu (ten sam kod modelu co na trasie), wybór wariantu, wybór skórki, panel przesuwania/obrotu/skali w układzie D-pad oraz większe przyciski (66 px).
- `ProceduralTrack.build_model_preview()` udostępnia edytorowi dokładnie ten sam kod budowy modeli, którego używa trasa.
- Dodano test `tests/ObjectSkinsTest.gd`. Nie został uruchomiony — w środowisku przygotowania nie ma Godot 4.7.2.

## Aktualizacja 2026-11-15 — nowe modele zwierząt i przeszkód (etap 2)
- Dodano `scripts/visual/ModelBuilder.gd`: budowniczy modeli z miękkich superelipsoid, walców, stożków i torusów. Bryły o tym samym materiale są scalane w jedną siatkę (mniej draw calls na Androidzie), a model dzieli się na nazwane części z pivotami (Body, Head, Tail, LegFL…), co przygotowuje go do animacji.
- `scripts/models/AnimalModels.gd`: nowe, osobne sylwetki kota, psa, królika, agamy brodatej i papugi (cztery warianty kolorystyczne każdego). Logika ruchu i wpływ na wyścig (`TrackAnimal.gd`) bez zmian — zwierzę porusza się jako całość.
- `scripts/models/ObstacleModels.gd`: pięć rozpoznawalnych przeszkód (puf, puszka, klocek z wypustkami, pachołek, bęben). Kolizje walcowe, masa, obrażenia i system niszczenia pozostają niezmienione.
- Zweryfikowano numerycznie kolejność wierzchołków (front = zgodnie z ruchem wskazówek zegara) generowanych siatek. Test w Godot 4.7.2 nie został wykonany w tym środowisku.


## Aktualizacja 2026-11-15 — wspólna biblioteka modeli i edycja dotykowa obiektów
- Wersja danych generatora tras: 10.
- Dodano `scripts/models/TrackModelLibrary.gd`. Modele mebli, zwierząt i przeszkód są budowane jako szablony raz na sesję, a trasy oraz podglądy edytora pobierają z biblioteki kolejne instancje współdzielące zasoby siatek.
- Trasa mieszkania (`ApartmentTrack`) korzysta teraz z gotowych modeli biblioteki dla głównych mebli i przeszkód zamiast tworzyć ich wygląd jako proste pudełka/kule. Kolizje i układ toru zachowano; elementy architektury nadal korzystają z geometrii ścian i podłóg.
- Dodano modele lodówki, wanny, umywalki i blatu kuchennego do wspólnego katalogu oraz palety edytora.
- Losowe trasy automatycznie rozstawiają podstawowy zestaw mebli (roślina, sofa, stół, krzesło, szafka, lampa), a pozostałe dekoracje losują z rozszerzonej biblioteki. Zwiększono typową skalę mebli i dodano ponawianie pozycji, aby ograniczać nakładanie się obiektów.
- Dotknięcie istniejącego obiektu na podglądzie wybiera go; przeciągnięcie palcem przesuwa go po mapie. Nadal dostępne są precyzyjne przyciski przesuwania, obracania i skalowania. Tryb dodawania zachowuje dotychczasowe działanie.
- Rozszerzono test regresyjny o sprawdzanie współdzielenia siatek i korzystania z modeli w istniejącej trasie mieszkania.
- Nie uruchomiono parsera Godot, testów runtime ani testu na Androidzie — w środowisku przygotowania nie ma wykonywalnego Godot 4.7.2.

## Aktualizacja 2026-11-15 — zaawansowane rozmieszczanie elementów tras
- Rozszerzono generator do wersji danych 11; starsze zapisane trasy nadal zachowują dotychczasowe wartości domyślne.
- Dodano cztery poziomy zagęszczenia mebli i wyposażenia: 5, 9, 13 lub 17 głównych elementów. Pozostałe miejsca uzupełniają mniejsze przedmioty z biblioteki modeli.
- Zestaw mebli jest dobierany do motywu: mieszkanie, kuchnia, sypialnia lub arena futurystyczna.
- Dodano trzy układy przeszkód: bliżej krawędzi jezdni, losowo w bezpiecznej części jezdni oraz naprzemienne sekcje slalomowe.
- Rozmieszczenie przeszkód jest równomierniej rozłożone wzdłuż trasy; pozostają one elementami toru, a meble i wyposażenie są lokowane poza jezdnią.
- Generator zachowuje wybór liczby zwierząt 0–5, dotychczasowy rozmiar mapy, złożoność, motyw, seed, dwie stacje startowe oraz niezależny edytor ręczny.
- Panel analizy podglądu pokazuje liczbę mebli i rodzaj układu przeszkód.
- Dodano testy regresyjne dla wszystkich 4 poziomów zagęszczenia mebli i 3 układów przeszkód. Testy wymagają uruchomienia w Godot 4.7.2 i nie zostały wykonane w tym środowisku.

## Aktualizacja 2026-11-15 — generator 2D i dotykowy edytor tras
- Podgląd generatora został przeniesiony z kamery 3D na czytelny rzut 2D z jezdnią, linią startu, stacjami, przeszkodami i oznaczeniami obiektów.
- Dodano przesuwanie mapy jednym palcem po włączeniu trybu PRZESUŃ MAPĘ, powiększanie gestem dwóch palców oraz dotykowy suwak zoomu i przycisk wyśrodkowania.
- Generator losowy nie udostępnia już ręcznego dodawania przedmiotów. Zagęszczenie wyposażenia ma dwa ustawienia: MAŁO i DUŻO.
- Generator gwarantuje dodatkowo 2 lub 5 małych, niszczalnych przedmiotów bezpośrednio na jezdni, zależnie od wybranego zagęszczenia.
- Dodano tryb TWORZENIE TRASY: stały odcinek startowy i stacje po obu jego stronach, budowanie kolejnych odcinków PROSTO / LEWO / PRAWO, regulowaną długość fragmentu, zamykanie i ponowne otwieranie pętli oraz walidację przed testem.
- Test ręcznej trasy pozostaje zablokowany do chwili poprawnego zamknięcia pętli. Gotową trasę można zapisać w lokalnej bibliotece.
- Paleta obiektów, przesuwanie, obrót i skalowanie są dostępne w edytorze ręcznym. Dodano duży suwak rozmiaru obiektu oraz suwak kroku przesuwania.
- Zwiększono wysokość i odstępy kontrolek oraz przycisków, aby ułatwić obsługę palcem na telefonie.
- Dodano regresyjne sprawdzenie dwóch poziomów zagęszczenia i gwarantowanych przedmiotów na jezdni. Testy Godot, renderowania i obsługi dotykiem nie zostały uruchomione w środowisku przygotowania — brak wykonywalnego Godot 4.7.2.


## 2026-11-15 — poprawki generatora 2D, przewijania i otoczenia
- Zwężono panel ustawień generatora do 260 px, aby większa część ekranu była przeznaczona na podgląd mapy 2D. Zmniejszono też podgląd modelu przedmiotu i dopasowano siatki przycisków do węższego panelu.
- Podgląd 2D otrzymał wyraźny obrys całego obszaru planszy, cztery strefy pomieszczeń i etykiety pomieszczeń. Dopasowanie mapy jest ponawiane po ułożeniu kontrolek, aby uniknąć pustego podglądu przy pierwszym otwarciu.
- Suwak powiększenia mapy przeniesiono poza przewijany obszar, aby gest przeciągania nie był przejmowany przez przewijanie. Suwaki edytora mają większe pola dotykowe.
- Dodano wspólny, szerszy pasek przewijania do menu z zawartością przewijaną; po dotknięciu uchwyt powiększa się, a po puszczeniu wraca do standardowej szerokości.
- Generator losowy uzupełnia wolne obszary poza trasą o dodatkowe umeblowanie dobrane do motywu. Pozycje są odsuwane od toru, a istniejące ustawienie dwóch stacji na początku trasy pozostaje bez zmian.
- Proceduralne pomieszczenia otrzymały zewnętrzne ściany, półprzezroczysty sufit i plakaty na ścianach.
- Zwiększono liczbę banerów przy trasie do pięciu oraz dodano cztery plakaty ścienne. Napisy są billboardowe i zwrócone do kamery, a obie strony tablic mają osobne powierzchnie obrazu, aby nie pokazywać grafiki od tyłu.
- Dodano pobieranie losowych miniatur z najnowszych publikacji kanału SZAKAL PC ON ANDROID przez publiczną stronę kanału i kanał Atom YouTube; przy braku sieci lub błędzie pobierania pozostaje czytelna wersja tekstowa.
- Nie wykonano uruchomienia Godot 4.7.2 ani testu na Androidzie. Pobrane miniatury zależą od dostępności sieci i odpowiedzi YouTube; nie można zagwarantować ich działania offline.

## Aktualizacja: realistyczne roboty, skala świata, efekty boostów, układ generatora
- Roboty: nowe realistyczne bryły (okrągły, „D”, zaokrąglony kwadrat, wysoki z LiDAR-em, ultra-płaski), czujniki, szczotki boczne, koła z bieżnikiem. Stacje dokujące bez zmian.
- Kolory: realistyczne kolory fabryczne; skórki robotów w kategoriach jak skórki mebli (fabryczna, realistyczna, kreskówkowa, neonowa, pastelowa). Uwaga: indeksy skórek 1+ mają nowe znaczenie.
- Skala: meble i zwierzęta większe względem robota (`ProceduralTrack.realism_scale`).
- Boosty: nowy płomień turbo (shader + cząstki), smuga, iskry, fala zapłonu, efekt na ekranie (`BoostScreenFX`), nowe efekty pozostałych boostów (`BoostEffects`).
- Generator: meble nie stają przy innych odcinkach trasy; edytor ręczny ma skręty 45° i kontrolę kolizji na żywo.
- UI: proporcje 36/64 panel/podgląd, przełącznik podglądu 2D/3D, marginesy bezpieczne ekranu, większe suwaki i menu.

## Aktualizacja 2: ulepszenia widoczne na robocie, moduły boostów, turbo tylko przyspiesza
- Każdy poziom ulepszenia robota (prędkość, przyspieszenie, przyczepność, pojemność, bateria, moc boosta) dodaje element: pasy/splitter/płetwy/spoiler, kondensatory, szersze opony i osłony, pojemnik na kurz ze wskaźnikami, komórki LED i ogniwa, większe dysze i dopalacz.
- Każdy wybrany boost dodaje moduł na robocie (antena, zbiornik, taran, pas tarczy, magnes, apteczka, panel słoneczny, stabilizatory, projektor); poziom ulepszenia boosta powiększa i rozjaśnia moduł.
- Turbo zachowuje swoje kary (gorsze prowadzenie, spowolnienie po boostcie); jako jedyny boost przyspiesza robota, pozostałe mają własne unikalne działanie.
- Edytor tras: panel boczny nie rozpycha już ekranu (zawijanie tekstów), podgląd 2D/3D mieści się na ekranie.


## Aktualizacja 2026-11-16 — sufit i ściany do sufitu, lądowanie oraz powrót na trasę
- Sufit proceduralnego mieszkania jest wyraźniejszy (większa widoczność), a ściany zewnętrzne i działowe mają teraz wysokość 5,8 m, dochodząc do sufitu.
- Otwory drzwiowe zachowują prześwit 3,2 m; nad każdym otworem dodano pełny, kolizyjny fragment ściany aż do sufitu.
- Roboty mają dłuższy floor snap, łagodniejsze wykrywanie podłoża i stabilizację pionowej prędkości po kontakcie z podłożem, aby ograniczyć podbijanie i drgania przy lądowaniu.
- Na obu bandach proceduralnej trasy dodano cztery szerokie bramy powrotne z widocznymi znacznikami, umożliwiające ręczny wjazd na jezdnię po przypadkowym wyjechaniu poza trasę. Dotychczasowy przycisk RESET POZYCJI nadal pozostaje awaryjną alternatywą.
- Stacje startowe oraz stacja pit stopu odsunięto dalej od jezdni; front i zatoka serwisowa pozostają skierowane do toru, aby ograniczyć ryzyko przejeżdżania przez tył stacji.
- Dodano statyczne sprawdzenie regresyjne dodatkowego odstępu stacji. Testy Godot, renderowania, fizyki lądowania i jazdy przez bramy nie zostały uruchomione w tym środowisku.


## Aktualizacja generatora v14 – pomieszczenia, fizyczne przedmioty i oznaczenie stacji
- Generator zapisuje deterministyczny układ 4–9 pomieszczeń o zróżnicowanych proporcjach oraz krótkie ścianki wnękowe tworzące otwarte, L-kształtne strefy, zamiast dwóch pełnych ścian przecinających się w krzyż.
- Podłoga i podgląd 2D korzystają z tych samych granic pomieszczeń; otwory drzwiowe mają większy zapas szerokości.
- Drobne niszczalne przedmioty na trasie mają osobne, proporcjonalne hitboxy i są fizycznymi bryłami RigidBody3D: blokują przejazd, odbijają się/przesuwają po uderzeniu i zadają robotowi obrażenia. Duże dekoracje zachowują statyczną pozycję.
- Pod istniejącymi modelami punktów brudu dodano nieregularne, czarne, matowe i nieświecące owale na podłodze. Istniejące modele brudu nie zostały podmienione.
- Stacja dokująca gracza otrzymuje zielony pierścień i strzałkę. Wybór stacji jest dopasowany do rzeczywistej kolumny startowej; w lokalnym multiplayerze oznaczane są obie stacje graczy.
- Zwiększono długość przyciągania do podłoża i stabilizację pionowej prędkości przy lądowaniu.
- Nie zmieniano katalogu, efektów ani parametrów boostów. Nie przebudowywano edytora ręcznego. Nie podmieniano istniejących modeli budynków, mebli, robotów ani stacji.

## Aktualizacja 3: realistyczne pomieszczenia, pory dnia, oświetlenie
- Nowy system pomieszczeń w `scripts/tracks/room/`: katalog stylów (`RoomStyleCatalog`), tekstury (`RoomTextures`), budowa ścian/okien/lamp (`RoomBuilder`), umeblowanie (`RoomFurnisher`).
- Podłogi: deski, parkiet, płytki, szachownica, wykładziny, beton, marmur (z mapami normalnych). Ściany: farba, tapety, boazeria, kafelki, cegła, listwy przypodłogowe i sufitowe.
- Okna z widokiem (dzień / wieczór / noc), zasłony, parapety.
- Pory dnia (edytor: PORA DNIA): w dzień lampy zgaszone i światło nie wylewa się z okien; wieczorem lampy częściowo; w nocy lampy sufitowe, stojące i na szafkach, jeden ciemny pokój bez lamp (opcja w edytorze).
- Umeblowanie wg zasad aranżacji: salon (TV, kanapa, stolik, dywan, fotele), kuchnia, sypialnia, łazienka, gabinet, przedpokój, pokój dziecięcy; meble nie stoją na torze, w drzwiach ani przed oknami.
- Własne tekstury: `assets/textures/rooms/README.md`.


## 2026-11-17 — poprawki resetu, zbierania i stacji
- Po ręcznym resecie pozycji dodano 3-sekundową blokadę sterowania i widoczne odliczanie na HUD; reset nadal nie zmienia postępu, okrążeń, czasu, uszkodzeń, energii ani cooldownów.
- DirtManager sprawdza również odcinek ruchu robota między klatkami, co ogranicza pomijanie punktów zbierania przy dużej prędkości. Współczynnik Turbo 70% nie został zmieniony.
- Wyjazd z pit stopu prowadzi poza obszar wejściowy, umożliwiając ponowne aktywowanie strefy po powrocie.
- Dodano niewidoczne kolizje obudowy i bocznych prowadnic stacji; model wizualny nie został zmieniony.
- Dodano dokument `V0_3_ALPHA_AND_FIRST_UPDATE_PLAN.md` z pozostałym zakresem kariery, lokalizacji, profili/wieku, reklam, Texture Managera i wymagań Google Play.
- Weryfikacja: statyczna kontrola zmian i ZIP; bez uruchomienia Godot 4.7.


## Generator proceduralny v15 — mniejsze, pełniejsze mieszkania

- Zmniejszono obszar mieszkania wokół pętli i zwiększono liczbę podziałów pomieszczeń; dodano możliwość osobnej bawialni i powtarzających się sypialni.
- Zwiększono skalę głównych mebli, dopasowano wysokość ścian, drzwi, okien i oświetlenia do skali świata gry.
- Zwiększono zagęszczenie wyposażenia w pokojach bliżej trasy.
- Zastąpiono ściany wzdłuż krawędzi toru liniami krawędziowymi i usunięto środkowe kreski jezdni.
- Dodano osobny model telewizora ściennego do salonu oraz promocyjne powierzchnie na ekranach TV, stołach, regałach i szafkach, a także ramki na wybranych ścianach.
- Nie zmieniano geometrii istniejących modeli ani systemu boostów.
- Nie uruchomiono Godot ani testów Android; zmiany wymagają sprawdzenia runtime.

### Generator / checkpoint update (v0.3)
- Dodano sygnał dźwiękowy po zaliczeniu checkpointu oraz komunikat z czasem od poprzedniej bramki i czasem łącznym.
- Poprawiono wykrywanie ostatniej bramki na otwartych odcinkach: meta jest zaliczana przy końcu trasy, a nie przy jej starcie.
- Generator częściej losuje przebieg bliżej środka pomieszczeń; nowe trasy mają łagodniejszy próg odległości między nieprzecinającymi się fragmentami, nadal odrzucając rzeczywiste przecięcia.


## Aktualizacja – małe pomieszczenia, pit stop AI, audio i muzyka
- Generator dzieli mieszkanie na znacznie mniejsze strefy (docelowo 18–38 podziałów; próg dzielenia 13,5 jednostki); zwężono otwory drzwiowe, aby krótkie ściany nadal były widoczne.
- Każdy robot AI otrzymuje własny punkt serwisowy wzdłuż trasy, aby ograniczyć zbieganie się do jednego wjazdu; poszerzono też prześwit kolizyjny prowadnic stacji bez zmiany modelu.
- Komunikaty checkpointów są małe, krótkotrwałe i przeniesione poza środek ekranu.
- Garaż oferuje trzy profile dźwięku robota, w tym głębszy basowy, zapisywane osobno dla robota.
- Dodano odtwarzacz własnej muzyki z importem MP3/OGG/WAV, playlistą zapisywaną lokalnie i przyciskiem następnego utworu w HUD.


## 2026-11-17 — uporządkowanie testu grafiki

- Usunięto pozycję „TESTUJ GRAFIKĘ” z wyboru trybów Single-player. Test uruchamia się teraz z Ustawienia → Grafika → Uruchom test grafiki.
- Zachowano osobną jazdę testową, panel pomiarowy HUD, autopilota, przełączanie kamery i ekran wyników bez nagród. Po zakończeniu testu przycisk menu wraca do Ustawień.
- Poprawiono pomiar minimalnego FPS (na podstawie najwolniejszej zarejestrowanej klatki) oraz 1% low (średnia FPS z najwolniejszego 1% próbek). Panel nie zbiera danych podczas zwykłych wyścigów.
- Zachowano istniejące presety jakości, przełączniki efektów, limit FPS i zapis ustawień. Dodano dwa widoki ustawień: prosty (presety) i zaawansowany (indywidualne przełączniki oraz limit FPS). Dopisano informację, że renderer jest wybierany przy uruchomieniu kompilacji i nie przełącza się go samym presetem.
- Nie wykonano testu uruchomieniowego w Godot 4.7.2 ani na Androidzie — w środowisku przygotowania nie ma dostępnego wykonywalnego Godot.


## 2026-11-17 — naprawa pobierania modeli, usuwanie pakietów i animowane zwierzęta
- Naprawiono ważny błąd `HTTPRequest.download_file`: po zakończonym pobieraniu pozostawała poprzednia ścieżka pliku, więc kolejne żądanie API mogło nie zwrócić JSON do parsera. Ścieżka jest czyszczona przed każdym żądaniem API i po instalacji.
- Pobieranie listy plików korzysta z aktualnego `/v2/files/{id}` i obsługuje opakowanie odpowiedzi `data`.
- Dodano potwierdzane usuwanie wybranego modelu i wszystkich pobranych modeli; modele wbudowane nie są usuwane.
- Wykrzyknik nad zabrudzeniem znika po zebraniu i wraca po respawnie.
- Małe przedmioty mają kolizję z warstwą świata i robotami, więc mogą się przemieszczać po uderzeniu i reagować na otoczenie.
- Dopasowanie modeli jest jednolite dla wszystkich osi — bez deformowania proporcji.
- Dodano animowanie pivotów zwierząt oraz możliwość przypisania zewnętrznego modelu tylko wtedy, gdy zawiera animację glTF/GLB.
- Nie zmieniano robotów, stacji ani efektów boostów. Brak testu uruchomieniowego Godot/Android.


## 2026-11-17 — poprawki pomieszczeń, fizyki i podglądu modeli
- Generator tras v23 używa znacznie bardziej kompaktowych skal mapy i dzieli pomieszczenia według docelowej powierzchni 5–20 m², zamiast stałej liczby podziałów.
- Ściany działowe wycinają fragmenty w miejscach skrzyżowań, aby ograniczyć nakładanie geometrii i podwójne kolizje.
- Zmniejszono pięć poziomów skali generowanych tras; walidacja v23 uwzględnia krótszą linię startu i mniejszy rozmiar mapy.
- Słupy bramy startowej w ApartmentTrack otrzymały fizyczne kolizje.
- Drobne elementy wyposażenia pokoi otrzymały fizykę RigidBody3D i mogą być przesuwane po uderzeniu; duże meble pozostają nieruchome.
- Podgląd modeli 3D centruje geometrię na podstawie AABB siatek i dopasowuje skalę; przeciąganie palcem przesuwa oraz obraca model.
- Przycisk muzyki w HUD jest stale widoczny; przełącza utwór, a bez playlisty otwiera ustawienia.
- Zmiany sprawdzone statycznie; test uruchomieniowy Godot/Android nie został wykonany.


## Skala świata v0.3 — 2026-11-17
- Ujednolicono rozmiar robota, collider, AI, szerokość trasy, przeszkody, stacje, meble, zwierzęta i wyposażenie pokoi.
- Pokoje są nadal dzielone na 5–20 m²; obudowa mieszkania i wysokość pomieszczeń zostały dopasowane do ludzkich wymiarów.
- Starsze zapisane szerokości tras są migrowane do nowego zakresu, a układ pokoi jest odtwarzany dla nowej skali.

## Kampania S-01, komiks i przybliżona minimapa
- Dodano dziewięć wydarzeń kampanii w trzech rozdziałach: Dno Harmonogramu, Korporacyjny Wyścig Szczurów i Pro League.
- Dodano warunki awansu (podium w zwykłych wydarzeniach, zwycięstwo w bossach), zapis progresu i premie za porę dnia.
- Wydarzenia wykorzystują generowane trasy: dzień, wieczór i noc; wieczór ma większe zagęszczenie przeszkód, noc mniejszą przyczepność i większy mnożnik nagród.
- Dodano motyw pomieszczeń biurowych i plan umeblowania stanowisk pracy oraz osobny motyw areny Pro League.
- Bossowie kampanii otrzymali własne nazwy i agresywniejszy styl AI.
- Dodano sześć plansz komiksu z edytowalnymi i zapisywanymi dymkami; portret 2D pobiera aktualny kształt i kolory robota gracza.
- Minimapa HUD jest większa i przybliża teren wokół pozycji gracza.
- Dodano ulepszenie pancernego zderzaka: do 30% mniej uszkodzeń i widoczne osłony modelu.

## 2026-11-18 — skala prędkości, kamera i podgląd generatora
- Kamera główna za robotem została przybliżona: dystans 2,05 m, wysokość 1,08 m, krótszy punkt patrzenia; zachowano wykrywanie ścian i płynne podążanie.
- Prędkości maksymalne i przyspieszenia pięciu robotów przeskalowano do 28% wcześniejszych wartości, zachowując ich wzajemne różnice. Statystyka prędkości w garażu jest wyświetlana w km/h.
- Zmniejszono mnożnik prędkości boosta oraz dostosowano progi AI, cofanie, hamowanie, opór toczenia i prędkość wyjazdu z pit stopu do nowej skali.
- W generatorze zwiększono obszar podglądu 2D i 3D do 520 px wysokości, przydzielono większą część szerokości podglądowi mapy, powiększono widok 3D i wyłączono przycinanie obramowania panelu.
- Zwiększono bezpieczny margines dopasowania mapy i zmniejszono grubość obrysu pomieszczenia, aby ramka mieściła się w podglądzie.
- Test symulacyjny raportuje prędkość w km/h. Nie uruchomiono go w tej sesji — środowisko nie zawiera pliku wykonywalnego Godot.


## Aktualizacja naprawcza 2026-11-18
- Usunięto podwajanie punktów trasy przy konwersji na odcinki proste; generator zachowuje limit punktów walidatora.
- Poprawiono awaryjny układ trasy, aby nie zawierał bardzo krótkiego segmentu tuż za linią startu.
- Zwężono proporcjonalnie panel podglądu generatora i usunięto wymuszoną minimalną szerokość 520 px.
- Obniżono linie krawędziowe do poziomu nawierzchni.
- Odsunięto stację serwisową od toru, skrócono zatokę i zmniejszono/ściemniono strefę aktywacji naprawy.
- Zmniejszono kafelki głównego menu i dodano neutralne miejsce rezerwowe na małą reklamę (bez aktywnego systemu reklamowego).
- Dodatkowo obliczanie pomieszczeń odbywa się przed ustawianiem dekoracji; rozmieszczenie mebli odrzuca punkty zbyt bliskie ścianom i granicom pomieszczeń.
- Stacje startowe i stacja środkowa otrzymały taki sam większy odstęp od krawędzi toru jak pit stop.
- Generator zapisuje nową rewizję 27; awaryjna geometria ma sprawdzony zapas minimalnej odległości dla pięciu szerokości toru i pięciu poziomów złożoności.
- Podgląd 2D dopasowuje teraz również granice pomieszczeń; usunięto sztuczny margines 23 m, który rozciągał rysunek poza mapę.
- Po nieudanych próbach ustawienia dekoracja jest pomijana, zamiast trafiać na inną dekorację lub zbyt blisko ściany.
- Materiały robota otrzymały wyższy priorytet renderowania niż oznaczenia toru; zachowano dotychczasowe kolory i skórki robotów.


## Generator tras v28 – większe mapy, szerszy tor i wyposażenie na blatach

- Pięć poziomów rozmiaru mapy obejmuje teraz orientacyjnie 100–500 m²; najmniejszy poziom został powiększony, a największy rozszerzony.
- Szerokość jezdni zwiększona do zakresu 1,65–2,25 m.
- Odcinek start/meta wydłużony do 7 m, aby pozostawić prostą na wyścig i obsługę stacji.
- Stacje tras mają skalę 0,40 i są odsunięte od toru z zachowaniem miejsca na platformę oraz wjazd.
- Zmniejszono skalę losowych mebli i drobnych obiektów względem robotów.
- Drobne modele są dodawane jako dzieci stołów, szafek, blatów kuchennych i stolików; pozostają na meblu podczas jego przesuwania.
- Monitor i laptop w stanowiskach biurowych obniżono do poziomu blatu.
- Zapisane trasy generatora v27 są automatycznie powiększane przy odczycie; ręcznie edytowane trasy nie są automatycznie skalowane.
- Dodano regresję migracji v27 → v28.


## Generator v30 – poprawka kompilacji i większe hale
- Usunięto odwołanie do `RoomFurnisher.DIMS` z `StylePackManager`, które powodowało błąd `Could not resolve external class member DIMS`; dopasowanie pobranych modeli korzysta z lokalnej, jawnej tabeli wymiarów.
- Dodano sześć poziomów wielkości tras, od około 100 do około 1000 m²; wartości są orientacyjne, generator może tworzyć nieregularne i wydłużone układy.
- Dodano motyw „Hala do sprzątania”, zwiększono limit podziału dużych pomieszczeń do 8 stref i dostosowano liczbę sekcji trasy dla największych map.

## Poprawka kompilacji BoostEffects / RoomFurnisher – 2026-11-18
- Usunięto drugi, identyczny klucz `candle` z tabeli wymiarów `RoomFurnisher.DIMS`; pozostawiono dotychczasową definicję z linii wcześniejszej.
- Nie zmieniano efektów wizualnych ani mechaniki działania boostów.


## Generator i edytor tras — kontrola geometrii 2026-11-18
- Powiększono strefę otworów w ścianach działowych, aby słupki i krawędzie drzwi nie wchodziły w pas przejazdu; usunięto pionowe słupki z opraw drzwiowych, pozostawiając nadproże.
- Motyw „Hala do sprzątania” tworzy teraz jedną otwartą przestrzeń bez ścian działowych; podgląd 2D nie rysuje dla niej sztucznego podziału.
- Ręczny edytor przelicza granice pomieszczeń i ściany po każdym dodaniu, cofnięciu, zamknięciu lub otwarciu fragmentu trasy.
- Edytor ignoruje przestarzałe, nadmiernie duże `board_size`, które rozciągało podgląd względem rzeczywistych współrzędnych świata; podgląd 2D pokazuje też delikatny pas bezpieczeństwa wokół trasy.
- Dodano kontrolę kolizji podczas dodawania, kopiowania i przesuwania dekoracji: duże meble nie mogą blokować trasy ani stać na ścianach, a obiekty nie mogą nachodzić na siebie. Małe drobiazgi nadal mogą być celowo ustawiane na jezdni.
- Poprawiono obliczanie obwiedni obróconych mebli i wymiary mebli ustawianych przy ścianach; ogranicza to przenikanie modeli ze ścianami i sąsiednim wyposażeniem.
- Szósty poziom skali zachowuje szerokość jezdni 2,45 m w walidacji i w geometrii 3D; motyw hali został dopuszczony przez walidator.
- Testy regresji rozszerzono o gigantyczną halę, szerokość otworów drzwiowych i obwiednie mebli pod kątem 45°. Testy Godot nie zostały uruchomione w tym środowisku.

## Grafika i efekty renderowania – ustawienia zaawansowane
- Dodano zapisywane osobno opcje Glow, SSAO, SSIL, SSR, SDFGI, mgły wolumetrycznej, TAA, debanding i ogranicznika migotania odbić.
- Opcje są stosowane do środowiska wyścigu i głównego Viewportu; ustawienia wymagające Forward+ lub nieobsługiwane przez dany renderer są wyszarzane w menu.
- Odbicia SSR są niezależne od odbić ReflectionProbe; ReflectionProbe aktualizuje się dynamicznie w jakości ULTRA.
- Efekty boostów i strumień dopalacza otrzymały wyższy priorytet renderowania oraz wyłączony test głębi, aby nie znikały pod teksturami robota.
- Nie zmieniano modeli 3D ani mechaniki boostów.
- Uwaga: wymagane testy runtime w Godot pozostają do wykonania; dostępne środowisko nie zawiera edytora/uruchomienia Godot.


## 2026-11-18 — poprawka wywołania Roughness Limiter
- Poprawiono wywołanie `RenderingServer.screen_space_roughness_limiter_set_active()`: przekazywane są teraz wszystkie trzy wymagane argumenty (`enable`, `amount`, `limit`).
- Wartości `amount` i `limit` są pobierane z ustawień projektu Godota, z wartościami zapasowymi 0.25 i 0.18. Zachowano istniejący przełącznik w ustawieniach grafiki.
- Nie zmieniano efektów BoostEffect ani pozostałych ustawień graficznych.
- Nie wykonano testu runtime w Godot 4.7.2; poprawność sprawdzono przez kontrolę kodu i archiwum.


### Poprawka mobilnego renderera i wykrywania GPU
- Dodano brakującą metodę `reflection_probe_allowed()`; ReflectionProbe jest dostępny w rendererze Mobile i nie powoduje już wywołania nieistniejącej funkcji.
- Opcje post-processingu nieobsługiwane przez aktywny renderer są ukrywane, a nie tylko wyszarzane.
- Dla Mobile pozostawiono obsługiwane: Glow, klasyczną mgłę głębiową/wysokościową, debanding, screen-space roughness limiter i ReflectionProbe. Efekty SSR, SSAO, SSIL, SDFGI, volumetric fog i TAA są ukryte.
- Debanding na Mobile jest stosowany zarówno na Viewporcie, jak i materiałach. Roughness limiter jest wywoływany tylko w rendererach Mobile/Forward+. Klasyczna mgła głębiowa jest dostępna w Mobile i może działać obok mgły wolumetrycznej w Forward+.
- Dodano diagnostyczne rozpoznawanie rodzin GPU Qualcomm Adreno, ARM Mali, Samsung Xclipse/Exynos i innych. Nazwa GPU nie jest używana jako fałszywy test zgodności funkcji; obsługę określa renderer Godota.
- ReflectionProbe na Mobile korzysta z UPDATE_ONCE, aby nie wymuszać ciągłego odświeżania odbić na GPU telefonu.
- Nie zmieniano modeli 3D ani mechaniki BoostEffect.
- Wymagane testy w Godot 4.7.2 na rzeczywistym urządzeniu; w tym środowisku silnik Godot nie jest dostępny.


## Podłoga – przebudowa warstwy wizualnej
- Wzmocniono czytelność śladów zabrudzeń na podłodze: większa skala i prawidłowe osadzenie w powierzchni ograniczają efekt unoszenia oraz migotania.
- Materiały płytek i marmuru otrzymały subtelny clearcoat i kontrolowane refleksy; drewno, wykładziny i beton zachowują bardziej matowe wykończenie.
- Zmniejszono szczeliny pomiędzy panelami podłogi w pokojach, zachowując wysokość górnej powierzchni i istniejące tekstury proceduralne.
- Zmiany nie ingerują w modele robotów, stacje ani logikę boostów.


## Podłogi — gęstsze kafelkowanie tekstur
- Zmniejszono fizyczny rozmiar powtarzanego wzoru tekstury podłogi: drewno, parkiet, płytki i wykładziny powtarzają się co ok. 2,2–2,4 m, a beton i marmur co 3 m.
- W jednym pomieszczeniu widać teraz wiele mniejszych powtórzeń materiału zamiast pojedynczego, rozciągniętego wzoru na całej powierzchni.
- Takie samo gęstsze kafelkowanie zastosowano w podłodze awaryjnej/bez RoomBuildera. Nie dodano osobnych geometrycznych płytek ani nakładanych paneli — wzór jest powtarzany w materiale płaskiej powierzchni.
- Zachowano istniejące rodzaje podłóg, generator pomieszczeń, kolizje, modele i mechanikę boostów.
- Kontrola ZIP i statyczna kontrola zmian; Godot 4.7.2 nie jest dostępny w tym środowisku, więc testu runtime nie wykonano.

- Generator tras v32: najpierw rozmieszcza umeblowanie pomieszczeń, następnie zwierzęta i drobne rekwizyty; drobne przedmioty są odsunięte za krawędź jezdni. Dodano osobną zatokę startową poza liczeniem pokoi użytkowych, rząd stacji po prawej stronie i zielone oznaczenie stacji gracza. Usunięto dodatkowe, zdublowane modele stacji startowych — widoczne są właściwe stacje systemu pit stop.

## 2026-11-18 — integracja narracji kariery i jawne odwołania do generatora
- Narracja S-01 została przeniesiona do przepływu kariery: krótkie kadry przed wyścigiem, rozwinięcie po wynikach i scena pomiędzy kolejnymi wydarzeniami.
- Usunięto osobny przycisk otwierania komiksu z ekranu kariery; stara ścieżka `comic` przekierowuje do kariery.
- Dodano `CareerStoryPanel.gd`, który wyświetla kadry z portretem aktualnej konfiguracji robota i przechodzi dalej do wyścigu lub kolejnego etapu.
- Dodano zapis indeksu wydarzenia i informacji o awansie na potrzeby sceny po wyścigu.
- Dodano dokumentację katalogu `gui/`. Aktywne zasoby pozostają w dotychczasowych ścieżkach `ui/` i `scripts/ui/`, bez kopiowania i rozbijania referencji.
- Odwołania do `TrackGenerator` i `BoostEffects` w głównych skryptach zmieniono na jawne `preload()` zasobów, aby nie polegać wyłącznie na globalnym cache klas Godota.
- Nie zmieniano wyglądu ani mechaniki efektów boostów.
- Wymagany test runtime w Godot 4.7.2. W środowisku przygotowawczym nie ma dostępnego silnika Godot, więc nie można potwierdzić usunięcia wszystkich błędów parsera ani działania przejść kariery.

## 2026-11-18 — wydzielony suwak i kompaktowy pokój startowy
- Suwaki w ustawieniach otrzymały osobną, wizualnie odseparowaną strefę po prawej stronie; logika i zakresy ustawień pozostają bez zmian.
- Pokój startowy ma prostokątną geometrię opartą na kierunku trasy, dwie równoległe ściany boczne i otwarte oba końce.
- Zachowano pustą strefę przed linią startu, miejsce na dwie stacje i wolny margines za nimi.
- Wybrane wydarzenia kariery korzystają z tras odcinkowych; pozostałe zachowują pętle.

### Generator v35 — pokój startowy wycentrowany na linii startu
- Pokój startowy jest teraz wycentrowany na osi trasy; linia startu oraz wszystkie pola startowe znajdują się wewnątrz pomieszczenia, a nie na jego bocznej ścianie.
- Boczne ściany pokoju startowego są odsunięte symetrycznie od osi trasy; przód i tył pozostają otwarte.
- `ProceduralTrack.configure()` zawsze przelicza chronione granice pokoju z aktualnej trasy i stacji, także dla starszych zapisanych seedów.
- Generator otrzymał wersję 35, aby nowe generacje używały poprawionego układu.


## Generator v36 — stacje obok siebie i prosty wyjazd ze startu
- Dwie stacje startowe ustawione obok siebie po prawej stronie toru.
- Strefa startowa kończy się przed pierwszym punktem skrętu, z zapasem od ścian.
- Zwiększono szerokość stałej strefy, aby pomieścić obie stacje bez wchodzenia w pas jazdy.

## Aktualizacja — wybór interfejsu, kamera GTA i połączenie online
- Dodano ekran wyboru trybu prostego lub zaawansowanego przed menu głównym.
- Tryb prosty otrzymał osobne, uproszczone menu, większe przyciski/teksty w fabrykach UIKit i ograniczenie nieukończonych opcji w wyborze trybu oraz multiplayerze.
- Tryb zaawansowany zachowuje dotychczasowe menu i sekcje.
- Kamera „Z GÓRY” została zmieniona na pionowy widok ortogonalny dokładnie nad robotem, bez przesunięcia kadru w przód; nadal ukrywa sufity.
- Dodano ekran bezpośredniego multiplayera online oraz rozszerzono wspólny transport ENet o obsługę większej liczby klientów i portu konfigurowalnego.
- Multiplayer online jest obecnie testem połączenia/pokoju. Synchronizacja wyścigu, matchmaking i serwer publiczny pozostają do wykonania.


## Aktualizacja konfiguracji wyścigu i stacji
- Dodano w zaawansowanej konfiguracji wyścigu wybór źródła trasy, jej rozmiaru oraz zestawu modeli (standardowe/mieszane/pobrane).
- Przycisk pobierania modeli otwiera bezpośrednio zakładkę Dodatkowa zawartość w ustawieniach.
- Pierwsze uruchomienie pyta o jakość grafiki z informacją, że można ją później zmienić.
- Kamera top-down GTA została przybliżona, a liczba punktów brudu ograniczona.
- Stacje AI skupiono bliżej startu i zmniejszono ich modele; poprawiono też rozstaw metadanych stacji na mapie.

## Korekta konfiguracji wyścigu i nazw robotów
- Dodatkowy wybór gotowej/losowej trasy oraz rozmiaru małej, średniej lub dużej jest dostępny w trybie prostym.
- Tryb zaawansowany nie otrzymuje nowych opcji wyboru modeli ani rozmiaru trasy; pozostaje przy dotychczasowym układzie.
- Zmieniono wyłącznie nazwy pięciu bazowych robotów; ich identyfikatory, statystyki, ceny i modele pozostały bez zmian.
- Usunięto czarne, płaskie ślady spod standardowych modeli zabrudzeń.

## Very Low graphics preset and adaptive 3D resolution

- Added a `VERY_LOW` quality preset with 45% initial 3D render scale.
- The preset disables shadows, reflections, lights, particles and post-processing effects.
- Added optional adaptive 3D resolution scaling. It lowers render scale when measured FPS falls below the target and slowly restores it when performance has headroom.
- Added a settings toggle for adaptive resolution; it is enabled by default.
- Existing saved quality values are migrated once to the expanded five-level quality scale.
- This is a GPU/rendering fallback, not a guarantee that the game will run on every device. CPU, memory, drivers, physics and scene complexity still impose minimum requirements.

## Multiplayer online — Cloudflare WSS MVP scaffold (2026-11-18)
- Added a separate `CloudflareOnlineSession.gd` WebSocket client; existing `LanNetworkSession.gd` (ENet/LAN) is retained unchanged.
- Reworked the internet multiplayer screen to create rooms and join by an 8-character room code using a Cloudflare Worker URL.
- Added `cloudflare-worker/` with Worker routes, one SQLite-backed Durable Object per room, a six-player cap, join/leave events, and a rate-limited compact input relay.
- This milestone only establishes transport and room membership. It does not yet synchronize robot physics, checkpoints, laps, race results, accounts, or matchmaking. Client input is not authoritative and must not be trusted for results.

## Aktualizacja – skala renderowania i czytelniejsze podglądy
- Dodano ręczny suwak skali renderowania 3D od 35% do 150% (krok 5%). 100% oznacza natywną skalę, wartości powyżej 100% uruchamiają supersampling.
- Skala jest zapisywana w ustawieniach gracza; presety jakości ustawiają własną wartość bazową (45/65/82/100/100%).
- Automatyczne skalowanie nadal działa i może obniżyć bieżącą rozdzielczość względem ustawionego maksimum, gdy spada wydajność.
- Kosztowne efekty graficzne i przełączniki obciążające GPU otrzymały czerwone oznaczenia; wartość skali powyżej 100% jest oznaczana na zielono.
- Powiększono i odseparowano strefę dotykową suwaków.
- Zwiększono około dwukrotnie przybliżenie podglądu robota w garażu i stacji w edytorze stacji.

## 2026-11-19 – widoczność pokoju online
- Lobby multiplayer pokazuje teraz wyróżniony kod aktualnego pokoju oraz liczbę graczy.
- HUD wyścigu online pokazuje kod pokoju i aktualną liczbę uczestników, dzięki czemu gracz może sprawdzić, w której sesji się znajduje.
- Wskaźnik jest ukrywany poza wyścigiem online; nie zmienia protokołu ani kodu Workera.
- Zmiana jest przyrostowa i nie modyfikuje istniejących modeli, tras ani efektów.

## 2026-11-19 – przewijanie multiplayera, przeciwnicy AI i PL/EN
- Ekran multiplayera online korzysta teraz z kontenera przewijania obsługującego gest przesunięcia palcem; lista pokoi i lista graczy pozostają w jednym przewijalnym lobby.
- Host może wybrać od 0 do 3 przeciwników AI przed startem. Liczba jest wysyłana w komunikacie startowym Workera, więc wszyscy klienci otrzymują tę samą konfigurację.
- AI jest symulowane po stronie hosta; jego pozycje są przekazywane pozostałym klientom 10 razy na sekundę. Konfiguracja wizualna AI jest deterministyczna dla uczestników sesji.
- Liczba AI jest ograniczana liczbą wolnych miejsc na starcie (maksymalnie pięciu zawodników łącznie na obecnej trasie).
- Dodano wybór języka polskiego/angielskiego przy pierwszym uruchomieniu oraz zmianę języka w Ustawieniach. Dodano centralny moduł językowy, tłumaczenia podstawowych ekranów, lobby, ustawień, nazw i opisów robotów oraz części nazw skórek/ulepszeń.
- Lokalizacja jest pierwszą warstwą PL/EN; nie wszystkie opisy, komunikaty systemowe i teksty we wszystkich podmenu zostały jeszcze przetłumaczone.
