# Robot Racing v0.3 — generator and LAN update

## Generator
- Every generation uses a fresh random seed; the current preview remains unchanged until the user saves or generates again.
- The first segment is a 22 m straight section. Start obstacles are excluded.
- Two docking stations are placed on opposite sides of the start segment, offset beyond the track edge.
- Generator option selects 0–5 animals. The five species are cat, dog, rabbit, bearded dragon and parrot; selected species are unique per generated track.
- Each animal has a distinct movement/contact behavior in `TrackAnimal.gd`.
- On-track generated obstacle blocks are rigid bodies and are removed on robot impact. Household decoration trigger zones are also destructible when reached.
- Saved track data stores animal count and behavior metadata; existing saved routes remain readable through the existing legacy normalization path.

## LAN
- Added an ENet LAN host/client lobby for two Android devices on the same Wi-Fi network or a phone hotspot.
- Host uses port 27840; client enters the host IPv4 address.
- Android export enables INTERNET and ACCESS_NETWORK_STATE permissions.
- The current implementation confirms transport connection and exchanges room metadata only. It does **not** yet synchronize race state, player transforms, input, countdown or results. Full cross-device race gameplay is not complete.
- Bluetooth is not implemented. Godot's ENet transport is IP-based; Bluetooth would require a separate native Android plugin and platform integration.

## Menu
- Main-menu quick links duplicating Garage, Boost and Profile entries were removed.
- Multiplayer opens the LAN lobby directly.
- Generator/track-editor menu entry opens the existing procedural generator screen.

## Verification
- ZIP integrity and static text/resource checks are performed when packaging.
- Godot runtime is not available in this environment; the regression test script is included but has not been run in Godot.
