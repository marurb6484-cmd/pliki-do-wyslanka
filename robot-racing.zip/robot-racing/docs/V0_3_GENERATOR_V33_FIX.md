# Robot Racing v0.3 — generator v33

- Fixed a generator/validator mismatch: both docking stations are intentionally placed on the right side of the start straight, and validation now checks that exact layout and their spacing.
- Removed the manual placement-mode toggle. New decorations are added through the Add action and automatically positioned beside the road; manual movement rejects positions inside the road clearance.
- Removed the obstacle-placement selector from the track generator UI. The UI now uses the safe edge layout by default.
- Added route-distance checks to procedural decoration placement and migrated older saved decorations away from the driving surface when they overlap it.
- Dirt pickups are randomized across the drivable route at race setup and move to a new random road position after collection and respawn. The pickup's route projection is refreshed for AI navigation.
- Increased the generated dirt pickup count to 66–90, based on complexity.

Runtime validation still requires opening the project in Godot 4.7.2.
