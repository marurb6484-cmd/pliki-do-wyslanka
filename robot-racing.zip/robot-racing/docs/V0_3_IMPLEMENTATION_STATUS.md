# Robot Racing v0.3 – stan integracji

Ta paczka jest kontynuacją projektu Robot Racing v0.3. Wszystkie wcześniejsze ustalenia pozostają częścią zakresu v0.3. Dokument odróżnia elementy wdrożone, częściowe i planowane.

## Poprawki integracyjne — 2026-11-17
- [x] Ręczny reset pozycji: blokada jazdy przez 3 sekundy z odliczaniem na HUD.
- [x] Zbieranie brudu: dodatkowe wykrywanie przecięcia odcinka ruchu z punktem zbierania, aby ograniczyć pomijanie punktów przy dużej prędkości. Współczynnik 70% zbierania podczas Turbo pozostaje bez zmian.
- [x] Pit stop: wyjazd kończy się poza strefą wejściową, aby umożliwić ponowne wejście i ponowne uruchomienie ładowania.
- [x] Stacja: dodano kolizje fizyczne obudowy i bocznych prowadnic bez zmiany modelu wizualnego; pozostawiono otwarty wjazd od frontu.
- [ ] Test runtime tych zmian w Godot 4.7 na Androidzie — wymagany; nie został wykonany w tym środowisku.
- Szczegółowy zakres alfy, kariery proceduralnej, języków, profili/wieku, reklam i Texture Managera znajduje się w `docs/V0_3_ALPHA_AND_FIRST_UPDATE_PLAN.md`. Funkcje wymienione tam w sekcji „Nadal do wdrożenia” nie są jeszcze zaimplementowane.

## Dodane w tej iteracji

### Reset pozycji na trasie
- HUD ma przycisk RESET POZYCJI, dostępny podczas aktywnego wyścigu.
- Wymaga przytrzymania przez 1,5 sekundy.
- Robot wraca na najbliższy punkt linii trasy i zostaje ustawiony zgodnie z kierunkiem jazdy.
- RaceManager aktualizuje punkt projekcji, ale zachowuje całkowity postęp, okrążenie i czas.
- Reset nie naprawia, nie ładuje baterii i nie zeruje cooldownów ani aktywnego boosta.
- Przycisk jest zablokowany podczas odliczania, pauzy, pit stopu i po zakończeniu wyścigu.

### Boosty podczas jazdy
- `BoostSystem.gd` zachowuje zgodność z dotychczasowym API, ale obsługuje 10 typów boostów z `BoostCatalog.gd`.
- Globalny loadout jest odczytywany z `PlayerProgress.boost_loadout`.
- Przycisk NASTĘPNY w HUD-zie przełącza wyposażone sloty bez zatrzymywania wyścigu.
- Przycisk BOOST aktywuje wybrany boost; TAB zmienia wybór na klawiaturze, a pad używa Y do zmiany i X do aktywacji.
- Koszt aktywacji pobierany jest z baterii; koszt jest liczony do statystyk zużycia energii przez boosty. Nie jest dodatkowo pobierana stara opłata za brud.
- Cooldown każdego typu jest osobny i rozpoczyna się po zakończeniu efektu. Turbo można przedłużać, płacąc proporcjonalnie do czasu.
- Wdrożone efekty: Turbo i Overdrive wpływają na osiągi; Turbo dodatkowo ogranicza zbieranie brudu do 70%, osłabia hamowanie, zwiększa odrzut przeciwnika o 50%, zmniejsza własną reakcję na kolizję i słabnie o 20% po uderzeniu w ścianę; kara przyspieszenia po Turbo wraca stopniowo. Impuls elektryczny nakłada osłabienie prędkości/przyspieszenia, przerywa aktywny boost i blokuje kolejne aktywacje; Śliski ślad tworzy obszary poślizgu; Fala uderzeniowa odpycha; Tarcza blokuje jedno lub więcej negatywnych trafień i ma kopułę wizualną; Magnes przyciąga obiekty brudu; Naprawa awaryjna naprawia uszkodzenia; Regenerator energii stopniowo ładuje baterię; Hologram tworzy wizualną kopię.
- Gracz ma próg energii 20%, AI 40%; Regenerator energii może być aktywowany także przy rozładowanej baterii.

### Ulepszenia boostów
- `BoostUpgradeSystem.gd` zapisuje poziomy każdego parametru osobno, w zakresie 0–20.
- Koszt CR rośnie progresywnie wraz z poziomem i mnożnikiem rzadkości.
- Warsztat Boostów pozwala wybrać typ boosta, rzadkość, parametr, sprawdzić poziom/wartość/koszt i kupić kolejny poziom.
- Aktualnie działająca konfiguracja w wyścigu używa rzadkości zwykłej. Poziomy pozostałych rzadkości są przechowywane oddzielnie, ale system zdobywania i przypisywania rzadkości do egzemplarzy boostów nie jest jeszcze wdrożony.

### Generator proceduralny
- `TrackGenerator.gd` generuje deterministyczne pętle na podstawie seeda i parametrów: rozmiar, złożoność, przeszkody i motyw pomieszczenia.
- `ProceduralTrack.gd` buduje podłogę, nawierzchnię, bandy, przeszkody i linię startu, korzystając z bazowego `TrackBase`.
- `TrackGeneratorMenu.gd` zapewnia podgląd 3D, ponowne losowanie, walidację, zmianę nazwy, zapis, wczytanie i usuwanie tras lokalnych oraz start wyścigu.
- `TrackLibrary.gd` zapisuje do 40 tras w lokalnym pliku zapisu. Zapis nie wykonuje automatycznie publikacji online.
- Generator jest dostępny z konfiguracji wyścigu oraz z zakładki EDYTOR TRAS.

## Częściowe / nadal do wykonania
- Hologram jest wabikiem dla AI i może delikatnie odciągać przeciwników od ich optymalnej linii; wymaga strojenia w runtime.
- AI dobiera aktywację do rodzaju wybranego boosta (atak, obrona, zbieranie, naprawa, regeneracja, wabik); skuteczność i balans wymagają testów w grze.
- Rzadkości rare/unique/legendary mają osobne poziomy ulepszeń w zapisie, ale nie ma jeszcze ekwipunku egzemplarzy boostów, łączenia i systemu zdobywania rzadkości.
- Generator tworzy proceduralne pętle z pomieszczeniowymi wariantami kolorystycznymi i przeszkodami. Nie jest to jeszcze pełny generator mieszkania z realistycznym układem pokoi, drzwiami i meblami.
- Pełny ręczny edytor tras z dodawaniem, przesuwaniem, obracaniem i skalowaniem dowolnych obiektów pozostaje do wdrożenia. Zapisane trasy można już wczytywać do generatora i uruchamiać.
- Dodatkowe efekty cząsteczkowe, animacje, dźwięki i balans wszystkich boostów wymagają dalszego dopracowania.
- Stabilność AI na nowych profilach torów wymaga testów runtime na kilku seedach i poziomach trudności.

## Wcześniej istniejące elementy projektu
- Menu główne, wybór trybu i trasy, garaż, ustawienia, edytor HUD i scena wyścigu.
- Roboty, kierowca gracza, AI, podstawowa fizyka, kolizje i uszkodzenia.
- Energia, brud, HUD, minimapa/nawigacja, ghost jazdy na czas.
- Stacje dokujące, pit stop, naprawa i ładowanie, system ulepszeń stacji.
- CR, odblokowywanie robotów i skórek, ulepszenia robotów, rekordy i statystyki.
- Globalne wyposażenie boostów i presety z poprzednich iteracji.

## Nadal zaplanowane w ramach v0.3
- Pełna ekonomia boostów: rzadkości jako egzemplarze, ekwipunek, łączenie, sprzedaż i nagrody.
- Ręczny edytor tras i paczki treści.
- Rozbudowa kariery, wyzwań, turniejów, profili, osiągnięć, kolekcji i historii wyścigów.
- Sklep społecznościowy, Testownia, oceny, moderacja, panel twórcy i mody lokalne.
- Split-screen, LAN, hotspot, obsługa wielu padów; multiplayer internetowy po przygotowaniu infrastruktury.
- Powtórki, rozbudowane ghosty, AI adaptacyjne i Anti-Stuck.
- Synchronizacja Android–Windows, konta, kopie zapasowe i bezpieczna ekonomia online.
- Lokalizacja PL/EN, regulamin, ekran aktualizacji, O twórcy, billboardy kanału YouTube i przygotowane sloty reklamowe.
- Eksport Android/Windows i przygotowanie dystrybucji.

## Testy i ograniczenia tej iteracji
- Sprawdzono statycznie ścieżki zasobów, referencje scen, strukturę archiwum i spójność zmian w skryptach.
- Nie uruchomiono parsera/importu Godot, testów GDScript ani symulacji runtime: środowisko robocze nie ma wykonywalnego Godot 4.7.
- ZIP przechodzi test integralności archiwum, ale nie jest to test działania gry.

## Zasady architektury
Każdy moduł ma jedną odpowiedzialność. Dane są oddzielone od mechaniki, mechanika od prezentacji, a komunikacja między systemami odbywa się przez jawne API/sygnały. Nie wolno uruchamiać niezweryfikowanego kodu z dodatków społecznościowych. Zmiany w zapisie wymagają zachowania kompatybilności.


### Generator tras — aktualizacja 2026-11-14

- [x] Gwarantowane dwie stacje dokujące przy starcie: po lewej i prawej stronie.
- [x] Migracja starszych zapisanych tras, aby również otrzymały stacje startowe.
- [x] Kontrastowe, wielokolorowe segmenty nawierzchni i jasne krawędzie toru.
- [x] Zwierzęta 3D (kot, pies, królik) oraz różnorodne dekoracje i meble generowane deterministycznie z seedu.
- [ ] Weryfikacja wyglądu, kolizji i wydajności na urządzeniu z Androidem w Godot 4.7.

## Ostatnia aktualizacja: zachowanie zwierząt, awaryjny pit stop i generator torów

**Dodane w kodzie:**
- Awaryjne przeniesienie do stanowiska serwisowego po osiągnięciu 100% uszkodzeń albo całkowitym rozładowaniu baterii; serwis rozpoczyna się od razu na stanowisku.
- Bardziej dynamiczny ruch pięciu gatunków zwierząt i odrębne reakcje na kontakt.
- Nieprzezroczysty model akwarium w generatorze.
- Niszczenie obiektów dekoracyjnych i przeszkód po uderzeniu; naliczanie różnych, stałych uszkodzeń zależnie od rodzaju obiektu.
- Nieregularny układ toru z długimi prostymi, nawrotami i sekwencją zakrętów; pięć rozmiarów mapy i szerokość 10–17 m.
- Zwiększona bazowa reakcja układu kierowniczego.

**Weryfikacja:** wykonano kontrolę statyczną zmian oraz niezależną kontrolę geometrii bazowej i losowych wariantów (10 000 prób w skrypcie pomocniczym: bez przecięć segmentów; minimalna długość segmentu powyżej 5 m). Testy Godot/GDScript i uruchomienie na Androidzie nie zostały wykonane, ponieważ środowisko nie ma dostępnego Godot 4.7.

## Poprawka generatora i klinowe przeszkody — 2026-11-14
- [x] Poprawiono wcięcie gałęzi `bearded_dragon` w `TrackAnimal.gd`, usuwając wskazany błąd parsowania.
- [x] Przeszkody proceduralne otrzymały trójkątny, klinowy przód i dopasowanie kierunku do przebiegu toru.
- [x] Kolizja klina ma mniejszą masę, mniejsze tarcie i niewielką sprężystość, aby ograniczyć gwałtowne zatrzymywanie robota.
- [x] Zachowano znikanie przeszkody po trafieniu i różne wartości uszkodzeń.
- [ ] Test uruchomieniowy generatora i fizyki w Godot 4.7 na Androidzie — nie został wykonany w środowisku bez Godot.

## Generator tras – aktualizacja losowości
- Nowy generator tworzy nieregularne zamknięte pętle o zmiennej geometrii i różnych kierunkach zakrętów; odcinek startowy pozostaje prosty.
- Poziomy przestrzeni są większe niż w poprzedniej iteracji.
- Walidator odrzuca trasę z przecinającymi się nie sąsiadującymi odcinkami.
- Testy geometrii wykonane zewnętrznym skryptem Python; nie zastępują uruchomienia projektu w Godot.

## Ostatnia iteracja – generator i ulepszanie boostów
- Zmieniono generator na losowanie wielokształtnych tras z sześcioma rodzinami profili, niezależnymi promieniami osi i większymi rozmiarami map.
- Dodano odrzucanie tras z przecinającymi się lub zbyt bliskimi odcinkami; sprawdzany jest margines szerokości potrzebny na ściany.
- Usunięto duplikat punktu startowego na końcu tablicy trasy.
- Ściany proceduralne mają gęstsze segmentowanie i nie są celowo nakładane długością na sąsiednie segmenty.
- Warsztat boostów ma przycisk ulepszania wszystkich parametrów wybranego boosta o jeden poziom za łączną cenę CR.
- Testy Godot nie zostały uruchomione: w środowisku nie ma dostępnego pliku wykonywalnego Godot. Wykonano zewnętrzne testy geometrii generatora i kontrolę statyczną plików.

## Aktualizacja 2026-11-14 — podgląd i warsztat boostów
- [x] Kamera podglądu generatora automatycznie dopasowuje całą trasę, stacje i przeszkody do proporcji okna; reaguje na zmianę rozmiaru panelu.
- [x] Panel ulepszeń widoczny bezpośrednio pod wyborem wyposażonych boostów.
- [x] Podgląd aktualnej i przewidywanej wartości parametru.
- [x] Słownik rang: zwykły, rzadki, unikalny, legendarny.
- [x] Klin przeszkody ma czubek skierowany w stronę nadjeżdżającego robota i boczny impuls kolizyjny.
- [ ] Łączenie egzemplarzy boostów i rzeczywiste odblokowanie kolejnych rang — czeka na ustalenie dokładnej liczby identycznych egzemplarzy wymaganych dla każdego awansu. Zgodnie z wcześniejszymi zasadami składniki mają być identyczne, na tym samym poziomie, zużywane, a awans gwarantowany o jedną rangę.
- [ ] Testy w Godot 4.7 i na Androidzie.


## Aktualizacja 2026-11-14 — czytelność ścian, profile torów i prowadzenie AI
- Ściany proceduralne mają ciemny grafitowy materiał i jaśniejszą listwę górną, żeby były widoczne na podglądzie generatora i w wyścigu.
- Generator używa sześciu rodzin łagodniejszych profili toru; losowe promienie są filtrowane między sąsiednimi punktami, ograniczając nagłe zmiany kierunku.
- AI co 0,45 s odświeża globalną projekcję na trasę, szybciej ponawia wyszukiwanie po dużym odchyleniu, a punkt patrzenia dopasowuje do prędkości i krzywizny.
- AI używa boostów zgodnie z ich przeznaczeniem; hologram jest rejestrowany jako wabik, który może wpływać na linię przeciwników.
- Zewnętrzna symulacja geometrii: 500 losowań (100 na każdy rozmiar mapy), wszystkie znalazły trasę spełniającą kontrolę odstępu segmentów; maksymalnie 86 prób generatora dla jednego przypadku. To nie jest test Godot ani fizyki 3D.
- Godot 4.7 nie jest dostępny w środowisku przygotowania, więc parser GDScript i testy runtime/Android nie zostały uruchomione.


### Okrągłe przeszkody i odrębne efekty boostów
- Zaimplementowano okrągłe przeszkody typu cylinder z okrągłą kolizją i bocznym odbiciem.
- Zaimplementowano osobne efekty wizualne dla boostów; Turbo jest jedynym boostem zwiększającym własną prędkość i przyspieszenie.
- Overdrive pełni rolę stabilizatora i zmniejsza reakcję na zderzenia, nie podnosi prędkości.
- Wymaga testu w Godot na urządzeniu: fizyka przeszkód, czytelność efektów i zachowanie AI.


### Poprawki stabilności ruchu i edycji HUD (14.11.2026)
- Ratowanie robota uruchamia się już przy spadku poniżej Y = -1.25; po teleportacji synchronizowany jest dystans okrążenia, aby nie naliczać fałszywego postępu.
- Edytor HUD obsługuje natywny dotyk Androida i przechwytuje przeciąganie poza pierwotnym modułem; pasek narzędzi nadal pozostaje klikalny.
- Linia trasy na minimapie jest wyraźnie grubsza.
- Zwierzęta mają korytarze ruchu przecinające całą szerokość toru, mogą przekraczać boczne bandy i wykonują skoki zależne od gatunku.
- Wymagają testu w Godot i na telefonie; nie wykonano testu runtime.


## Aktualizacja UI i czytelności generatora — 2026-11-14
- W panelach ulepszeń garażu przyciski zakupu są mniejszymi polami; opisy i etykiety przekazują gest przesuwania palcem do przewijania listy.
- Warsztat boostów pokazuje wybór parametrów jako siatkę małych, osobnych przycisków z poziomem ulepszenia.
- Dodano obsługę przewijania ScrollContainer gestem dotykowym w obszarach ulepszeń i warsztatu.
- Pod trasą proceduralną dodano wąski, ciemny kontur kontrastowy (0,28 m na stronę), bez istotnego zwiększania szerokości samej jezdni.
- Weryfikacja: kontrola statyczna zmian i integralności ZIP; brak uruchomienia projektu w silniku Godot i brak testu na urządzeniu Android.

### Aktualizacja 2026-11-14 — obrys podglądu i edycja przeszkód
- Podgląd 3D generatora ma 10x szerszy ciemny obrys trasy; ustawienie nie wpływa na trasę wyścigową.
- Generator zawiera pierwszy etap ręcznej edycji przeszkód: zaznaczanie, przesuwanie po osiach X/Z, dodawanie i usuwanie okrągłych przeszkód.
- Wybrana przeszkoda jest wyróżniana żółtym, świecącym pierścieniem.
- Edycja jest zachowywana w lokalnym zapisie trasy.
- Pełny edytor mebli, dekoracji, zwierząt i pozostałych obiektów nadal pozostaje do wykonania.
- Testy parsera Godot i urządzenia Android nie zostały wykonane.


### Aktualizacja 2026-11-14 — zielona strefa dokowania i dłuższy start
- [x] Każda stacja ma zieloną, emissive matę najazdową przed platformą oraz jasne znaczniki prowadzące.
- [x] Generator tras v6 zwiększa długość prostej startowej i wymaga minimum 32 m w walidacji.
- [x] Stacje odsunięte dalej od toru; zwiększono margines podłogi dla strefy dokowania.
- [x] Dodano trzy pary świecących strzałek na prostej startowej.
- [x] Zaktualizowano test regresyjny generatora.
- [ ] Uruchomienie testów Godot 4.7 i testu na Androidzie — nie wykonano, brak silnika Godot w środowisku przygotowania.

### Aktualizacja 2026-11-14 — czytelność generatora, edytor obiektów i promocja kanału
- [x] Jednolity kolor jezdni zależny od motywu, oddzielony od kolorów podłogi, ścian, krawędzi i dekoracji.
- [x] Jasne przerywane oznaczenie środka trasy.
- [x] Ukośny podgląd 3D generatora; szerszy ciemny obrys pozostaje wyłącznie w podglądzie.
- [x] Paleta 23 rodzajów obiektów: meble, dekoracje i pięć gatunków zwierząt.
- [x] Dodawanie, wybieranie, przesuwanie i usuwanie dekoracji; widoczny żółty pierścień i słupek zaznaczenia.
- [x] Synchronizacja liczby zwierząt z danymi edytowanej trasy; limit pięciu zwierząt.
- [x] Trzy nieinwazyjne billboardy kanału SZAKAL PC ON ANDROID na proceduralnych trasach.
- [x] Pięć osiągnięć offline z jednorazowymi nagrodami CR i trwałym zapisem odbioru.
- [ ] Weryfikacja wyglądu i działania edytora, billboardów oraz osiągnięć w Godot 4.7.2 na Androidzie.


### Generator tras — poprawki 14.11.2026
- Wdrożone w kodzie: dwustronne banery, mocniejsze oznaczenie zaznaczonego obiektu, rozstawianie kolejnych obiektów w różnych miejscach, obrót i skalowanie dekoracji, piąty poziom złożoności i cztery dodatkowe profile kształtu.
- Nadal do sprawdzenia w Godot na urządzeniu: faktyczna czytelność napisów 3D z obu kierunków, skala modeli w podglądzie oraz płynność bardzo złożonych tras. Nie wykonano testu silnika ani Androida w tym środowisku.

## Poprawka parsera TrackGenerator i analiza trasy — 2026-11-14
- [x] Naprawiono wcięcia profili 6–9 w `match style`; przyczyna błędu parsera klasy `TrackGenerator` została zidentyfikowana i poprawiona.
- [x] Dodano panel analizy długości trasy, zakrętów (w tym ciasnych), przeszkód, dekoracji i zwierząt.
- [x] Panel analizy odświeża się podczas odświeżania podglądu, także po edycji obiektów.
- [ ] Import projektu i uruchomienie testów GDScript w Godot 4.7 — niewykonane, brak silnika w środowisku.

### Aktualizacja 2026-11-14 — stacje startowe, dodawanie elementów i tekstury podłogi
- [x] Generator v9 ustawia dwie stacje po przeciwnych stronach prostej startowej, naprzeciwko siebie.
- [x] Wspólny helper oblicza pozycję i orientację stacji dla generatora, migracji zapisów oraz podglądu 3D.
- [x] Front każdej stacji i zielona mata są skierowane do jezdni; walidacja sprawdza odstęp od toru, stronę i kierunek frontu.
- [x] Starsze zapisane trasy otrzymują skorygowany układ stacji przy migracji i podczas budowania ProceduralTrack.
- [x] Dodano pięć proceduralnych tekstur podłogi, wybieranych przy generowaniu i zapisywanych w danych trasy.
- [x] Uporządkowano odświeżanie świata podglądu po edycji oraz zabezpieczono limity dodawanych przeszkód i dekoracji.
- [ ] Parser Godot 4.7.2, test runtime i test na Androidzie — niewykonane w środowisku przygotowania.


## Modele proceduralnych elementów trasy — 2026-11-14
- Przebudowano wizualne modele wszystkich 17 rodzajów mebli/dekoracji: rośliny, sofy, stoły, lampy, zabawki, akwaria, regały, poduszki, krzesła, łóżka, szafki, miski, zabawkowe roboty, dywany, telewizory, drapaki i legowiska. Dodano m.in. poduszki, obrzeża, nóżki, uchwyty, półki, książki, liście, ziemię w donicy, detale akwarium i ekrany.
- Przebudowano modele pięciu gatunków zwierząt: kot, pies, królik, agama brodata i papuga. Dodano wyraźniejsze proporcje, pysk, nos, oczy z refleksami, uszy, łapy, palce, ogony, oznaczenia gatunkowe i szczegóły upierzenia/łusek.
- Pięć wariantów wizualnych przeszkód otrzymało odmienne sylwetki (miękka bryła, metalowa puszka, klocek, pachołek, bęben) i dodatkowe detale. Geometria kolizji pozostała okrągła i nie zmienia zasad fizyki.
- Ujednolicono bazowe właściwości materiałów: bardziej naturalna szorstkość, delikatne odbicia i metaliczność tylko tam, gdzie ma sens.
- Dodano test regresyjny obecności modeli dla wszystkich typów mebli i zwierząt. Test wymaga uruchomienia w Godot 4.7.2; nie został tu uruchomiony.
- Weryfikacja w tej iteracji ograniczona do kontroli statycznej kodu i integralności ZIP. Nie wykonano testu parsera, renderingu, fizyki ani wydajności na Androidzie.

## Aktualizacja 2026-11-14 — historia edytora tras
- [x] Cofanie i ponawianie zmian edytora do 40 kroków.
- [x] Historia zmian obiektów dekoracyjnych i przeszkód; czyszczenie historii po wygenerowaniu lub wczytaniu innej trasy.
- [x] Duplikowanie obiektów z zachowaniem typu, skali, obrotu i danych zachowania zwierząt.
- [x] Kontrola limitu obiektów i limitu pięciu zwierząt przy duplikowaniu.
- [x] Bieżący status walidacji w panelu analizy trasy.
- [ ] Test parsera GDScript, testy scen i test na Androidzie — niewykonane, brak Godot 4.7.2 w środowisku przygotowania.

## Ograniczenia funkcji boostów — stan jawny
- Silnik zawiera efekty 10 boostów, energię, odnowienie, wymagania specjalne, efekty wizualne i wspólne wyposażenie.
- Ulepszenia parametrów 0–20 są zapisane oddzielnie dla każdej rzadkości, ale runtime używa obecnie rzadkości zwykłej. Wyższe rzadkości nie są jeszcze przyznawane ani wyposażane jako egzemplarze.
- Łączenie identycznych egzemplarzy pozostaje nieaktywne do czasu zatwierdzenia wymaganej liczby egzemplarzy na awans; nie przyjęto arbitralnej liczby.
- [x] Regulowany krok przesuwania obiektów: 0,25 / 0,5 / 1 / 2,5 / 5 m.
- [x] Reset obrotu i skali dekoracji do wartości domyślnych.


### Aktualizacja 2026-11-15 — wygląd brudu i edytor dekoracji
- [x] Modele proceduralne sześciu rodzajów zabrudzeń z rozproszonych drobin i nieregularnych brył.
- [x] Dodatkowe obiekty otoczenia w generatorze i modelach proceduralnych.
- [x] Tryb umieszczania obiektów przez dotknięcie podglądu 3D.
- [x] Znaczniki lokalizacji elementów w podglądzie edytora.
- [ ] Test parsera, renderowania i dotykowego umieszczania w Godot 4.7.2 — niedostępny w środowisku przygotowania paczki.


### Aktualizacja 2026-11-15 — stacje startowe i niszczalne przedmioty
- Generator danych tras podniesiono do wersji 9. Dwie stacje stoją po przeciwnych stronach prostej startowej, naprzeciwko siebie, z frontami skierowanymi do toru. Pozycje są liczone z szerokości trasy i wymiarów platformy; nie są już przesunięte razem na jedną stronę.
- ProceduralTrack korzysta z tej samej funkcji obliczania pozycji, więc stare zapisane współrzędne stacji nie nadpisują poprawnego układu. Zielona mata najazdowa pozostaje skierowana do jezdni dzięki orientacji modelu stacji.
- Walidator sprawdza obie strony, odległość od krawędzi jezdni, położenie wzdłuż prostej i kierunek frontu.
- Dodano system wytrzymałości przedmiotów dekoracyjnych: różne obiekty mają różną trwałość, kolejne uderzenia stopniowo ją zmniejszają, przedmiot znika dopiero po wyczerpaniu trwałości, a robot otrzymuje obrażenia zależne od rodzaju przedmiotu.
- Testy regresyjne generatora zaktualizowano do układu dwustronnego; test dekoracji sprawdza obecność skryptu i strefy kolizji. Testy wymagają Godot 4.7.2 i nie zostały uruchomione w tym środowisku.


## Aktualizacja 2026-11-15 — banery i wyzwania offline
- Banery promocyjne przy trasie proceduralnej ustawiają szeroką powierzchnię w stronę nadjeżdżającego zawodnika; tekst jest dwustronny dla jazdy w przeciwnym kierunku.
- Dodano trzy wyzwania dzienne: ukończenie dwóch wyścigów, zebranie 100 jednostek brudu i zwycięstwo w wyścigu. Postęp, data i odbiór CR są zapisywane lokalnie.
- Rozszerzono osiągnięcia długoterminowe do 10 celów.
- Wyzwania działają offline; wydarzenia sezonowe i rankingi online nadal wymagają backendu.
- Test Godot runtime nie został wykonany w tym środowisku.


### Aktualizacja 2026-11-15 — biblioteka modeli i wybieranie przez dotknięcie
- Generator tras korzysta z wersji danych 10.
- [x] Wspólna biblioteka szablonów modeli 3D dla mebli, zwierząt i przeszkód; trasy i podgląd edytora korzystają z tych samych modeli.
- [x] Główne meble i przeszkody istniejącej trasy mieszkania przełączone z prostych brył na modele z biblioteki.
- [x] Dodane dedykowane modele lodówki, wanny, umywalki i blatu kuchennego.
- [x] Generator losowy zawsze umieszcza bazowy zestaw mebli i ogranicza nakładanie pozycji; zwiększono skalę dekoracji.
- [x] Dotknięcie modelu zaznacza go, przeciąganie przesuwa, a przyciski nadal umożliwiają precyzyjną edycję.
- [ ] Potwierdzenie poprawności parsera GDScript, renderingu, fizyki i gestów dotykowych w Godot 4.7.2 na Androidzie — niewykonane.

## Aktualizacja 2026-11-15 — zaawansowane ustawienia generatora (wersja danych 11)

**Dodane w kodzie:**
- Cztery poziomy zagęszczenia umeblowania: 5 / 9 / 13 / 17 głównych mebli i elementów wyposażenia.
- Tematyczne zestawy obiektów dla mieszkania, kuchni, sypialni i areny futurystycznej.
- Trzy sposoby rozmieszczania przeszkód: przy krawędziach, losowo w obrębie jezdni i naprzemienne sekcje slalomowe.
- Rozmieszczenie przeszkód wzdłuż różnych fragmentów trasy zamiast skupiania ich na kilku losowych odcinkach.
- Panel podsumowania podglądu prezentuje zagęszczenie mebli i wybrany układ przeszkód.
- Walidator sprawdza zakres nowych parametrów i metadane liczby mebli.
- Zachowano zgodność wywołań generatora ze starszymi testami i zapisami dzięki domyślnym argumentom.

**Nadal częściowe / do wykonania:**
- Nie jest to jeszcze pełny symulator układu mieszkania z osobnymi pomieszczeniami, drzwiami i korytarzami; generowanie nadal bazuje na trasie zamkniętej i dekoracjach ustawianych wokół niej.
- Kolizje mebli z meblami i przeszkodami wymagają końcowego sprawdzenia w Godot oraz dalszego strojenia na dużych mapach.
- Nie wykonano testów parsera Godot, testów runtime ani Androida. Dodano testy regresyjne do uruchomienia w Godot 4.7.2.

### Aktualizacja 2026-11-15 — generator 2D i ręczne budowanie tras
- [x] Podgląd 2D generatora z trasą, stacjami, przeszkodami i przedmiotami.
- [x] Przesuwanie mapy, pinch-zoom, suwak zoomu i wyśrodkowanie widoku.
- [x] Generator losowy z dwoma poziomami zagęszczenia przedmiotów; ręczne dodawanie przedmiotów przeniesione do edytora ręcznego.
- [x] Gwarantowane drobne przedmioty na jezdni: 2 przy MAŁO i 5 przy DUŻO.
- [x] Tryb ręcznego budowania trasy z zachowaniem stałego odcinka startowego i wspólnego układu dwóch stacji.
- [x] Zamknięcie pętli, walidacja, blokada testu do poprawnego zamknięcia, ponowne otwarcie i zapis lokalny.
- [x] Dotykowe suwaki długości fragmentu, kroku przesuwania, skali obiektu i zoomu.
- [ ] Test parsera GDScript, uruchomienie sceny, test generowania/rysowania i test dotykowy na Androidzie — niewykonane, brak Godot 4.7.2 w środowisku przygotowania.
