# Robot Racing v0.3 — aktualizacja mapy edytora ręcznego

## Zakres
- Generator losowy pozostaje bez zmian w logice generowania i parametrach.
- Panel podglądu 2D nie jest już zawijany w dodatkowy pionowy ScrollContainer; mapa dostaje dostępną wysokość panelu.
- W edytorze ręcznym mapa otrzymuje stały obszar planszy zależny od wybranego rozmiaru (280, 380, 500, 650 lub 820 jednostek), dzięki czemu początkowe dwa punkty trasy nie są sztucznie powiększane do pełnego ekranu ani nie wyglądają jak mały fragment na pustej planszy.
- Jeżeli ręcznie budowana trasa wyjdzie poza początkowy obszar, podgląd automatycznie rozszerza granice, aby nie ucinać dalszych odcinków.
- Podział planszy na cztery pomieszczenia wykorzystuje pełny obszar planszy ręcznej.
- Obiekty i przeszkody są rysowane czytelniejszymi, większymi znacznikami z krótkimi oznaczeniami. Legenda pokazuje liczbę obiektów i przeszkód w generatorze oraz edytorze ręcznym.
- Dodano opcjonalne przyciąganie obiektów do siatki 1 m podczas przeciągania i przesuwania przyciskami. Można je wyłączyć przełącznikiem w edytorze.

## Weryfikacja
- Sprawdzono obecność i spójność zmienionych sekcji skryptów oraz zawartość archiwum ZIP.
- Godot 4.7.2 nie jest dostępny w środowisku przygotowania paczki; parser GDScript i działanie na Androidzie wymagają testu w Godot.
