# Robot Racing v0.3 — menu i warsztat

## Dostępne teraz

- GRAJ — dotychczasowy wybór trybu.
- GARAŻ / ROBOTY — dotychczasowy garaż.
- BOOSTY — warsztat konfiguracji globalnego loadoutu.
- KARIERA — lokalne statystyki, kolekcja i skrót do wyścigu.
- WYZWANIA — podgląd celów oparty na zapisanych statystykach.
- PROFIL GRACZA — lokalny nick, identyfikator zapisu i statystyki.
- O TWÓRCY — linki do kanału YouTube i Facebooka.
- USTAWIENIA — dotychczasowy ekran ustawień.

## Zakładki przygotowane, ale jeszcze nieaktywne

- MULTIPLAYER — podzielony ekran/LAN/hotspot i późniejszy online.
- SKLEP — sklep społecznościowy i Testownia.
- EDYTOR TRAS — pełny edytor dotykowy.
- MODY — bezpieczne paczki lokalnych dodatków.

Nie należy traktować powyższych czterech zakładek jako działających funkcji. Są oznaczone w aplikacji jako WKRÓTCE.

## Warsztat Boostów

- Korzysta z `PlayerProgress.boost_loadout`.
- Zmiana wyposażenia i presetów jest zapisywana przez istniejący `BoostLoadoutSystem`.
- Zachowuje dwa początkowe sloty i pokazuje pozostałe jako zablokowane.
- Nie pozwala wyposażyć dwóch identycznych boostów (walidacja jest wykonywana przez system loadoutu).
- Katalog pokazuje 10 typów i ich bazowe czasy/koszty z `BoostCatalog`.
- To konfigurator, a nie implementacja działania efektów podczas wyścigu.
