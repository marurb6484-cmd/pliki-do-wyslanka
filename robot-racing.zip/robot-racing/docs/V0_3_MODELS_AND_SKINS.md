# Modele 3D, skórki obiektów i edytor dotykowy

## Architektura
| Plik | Rola |
|---|---|
| `scripts/visual/ModelBuilder.gd` | Budowa modeli z miękkich brył (superelipsoidy, walce, stożki, torusy); bryły o tym samym materiale są scalane w jedną siatkę; model dzieli się na nazwane części z pivotami (gotowe do animacji). |
| `scripts/visual/ObjectSkins.gd` | Skórki: zmieniają tylko materiały. Oryginał zapamiętany w metadanych, więc powrót do „Kreskówkowej” przywraca pierwotny wygląd. |
| `scripts/models/AnimalModels.gd` | Kot, pies, królik, agama brodata, papuga (po 4 warianty kolorystyczne). |
| `scripts/models/ObstacleModels.gd` | Pięć przeszkód okrągłych: puf, puszka, klocek, pachołek, bęben. |
| `scripts/models/FurnitureModels.gd` | 29 rodzajów mebli, przedmiotów, zabawek i dekoracji. |
| `ProceduralTrack.build_model_preview()` | Ten sam kod modeli jest używany na trasie i w podglądzie edytora (brak osobnych atrap). |

Stacje dokujące (`scripts/station`, `assets/station`) nie zostały zmodyfikowane — porównanie z archiwum wejściowym nie wykazało różnic.

## Skórki
Dostępne: Kreskówkowa (domyślna), Realistyczna, Neonowa, Pastelowa. Wybór w edytorze tras
(„SKÓRKA OBIEKTÓW”), zapis w `graphics/object_skin`, stosowanie na żywo przez sygnał `graphics_changed`.
Nowa skórka: dopisz wpis w `ObjectSkins.SKINS` i przypadek w `_make_skinned_material`.
Skórki nie obejmują jeszcze skórek robotów (te mają własny system w `RobotDatabase`) ani stacji.

## Edytor tras
Kategorie: Meble, Przedmioty, Dekoracje, Zwierzęta, Przeszkody. Kafelki 3-kolumnowe, podgląd 3D wybranego
modelu z obrotem, wybór wariantu, panel obrotu/przesuwania/skali w układzie D-pad, przyciski 66 px.
Logika dodawania, cofania, zapisu i walidacji pozostała bez zmian.

## Podłogi tras
Cztery strefy podłogi mają różne materiały (płytki, drewno, wykładzina, kamień/panele) zależnie od motywu,
a na granicach stref leżą listwy przejściowe. Ściany grafitowe z jasną listwą i generator nie były zmieniane.

## Co NIE zostało zweryfikowane
Brak silnika Godot 4.7.2 w środowisku przygotowania: żaden skrypt nie został sparsowany ani uruchomiony przez Godot.
Wykonano wyłącznie kontrole statyczne (nawiasy, wcięcia, unikalność `class_name`, pokrycie rodzajów obiektów,
numeryczną weryfikację kolejności wierzchołków siatek). Pierwszy krok po otwarciu projektu:
`godot --headless --path . --script res://tests/load_all.gd`, potem testy `TrackObjectVisualRegressionTest` i `ObjectSkinsTest`.
