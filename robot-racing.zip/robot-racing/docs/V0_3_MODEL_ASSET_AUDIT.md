# Robot Racing v0.3 — audyt modeli 3D i plan wymiany

## Cel i granice zmian

Docelowo wymieniamy modele otoczenia, mebli, dekoracji, przedmiotów, zwierząt i przeszkód tras. **Nie wymieniamy ani nie modyfikujemy istniejących modeli robotów oraz stacji serwisowych.** Oryginalne zasoby pozostają w projekcie jako kopia/fallback; nowe modele są dodawane osobno.

Wymiana ma być wizualna i przyrostowa. Nie wolno zmieniać identyfikatorów obiektów, logiki zbierania brudu, destrukcji, punktów interakcji, zachowania zwierząt, colliderów, generatora tras, stacji ani fizyki robotów tylko po to, żeby dopasować je do nowego modelu.

## Inwentaryzacja aktualnego źródła modeli

### Meble, wyposażenie i drobne przedmioty — 68 typów

`FurnitureModels.gd` buduje obecnie 68 typów proceduralnie przez `ModelBuilder`:

- Meble i wyposażenie: `sofa`, `table`, `bookshelf`, `chair`, `bed`, `cabinet`, `fridge`, `bathtub`, `sink`, `kitchen_counter`, `nightstand`, `wardrobe`, `coffee_table`, `side_table`, `shoe_rack`, `ottoman`, `laundry_basket`, `floor_mirror`, `trash_bin`, `floor_fan`, `radiator`, `coat_rack`, `umbrella_stand`, `water_dispenser`, `towel_rack`.
- Oświetlenie i elektronika: `lamp`, `tv`, `tv_wall`, `wall_clock`, `speaker`, `game_console`, `laptop`, `monitor`, `microwave`, `toaster`, `kettle`.
- Dekoracje i rośliny: `plant`, `rug`, `vase`, `candle`, `hanging_plant`.
- Zwierzęta domowe i akcesoria: `fish_tank`, `pet_bowl`, `scratching_post`, `pet_bed`, `pet_tunnel`.
- Zabawki i drobiazgi: `toy`, `box`, `pillow`, `robot_toy`, `shoe`, `sock`, `mug`, `book`, `remote`, `tennis_ball`, `yarn`, `paper_scrap`, `food_scraps`, `cable`, `backpack`, `fruit_bowl`, `dish_rack`, `suitcase`, `toy_car`.

### Przeszkody na trasach — 5 typów

`ObstacleModels.gd`: puf, puszka, klocek-zabawka, pachołek i bęben. Wygląd jest oddzielony od kolizji budowanej w `ProceduralTrack.gd`.

### Zwierzęta — 5 gatunków

`AnimalModels.gd`: kot, pies, królik, agama brodata i papuga. Ruch, przechodzenie przez trasę i reakcje na kontakt obsługuje `TrackAnimal.gd`; nowy model musi współpracować z tym kontrolerem.

### Pomieszczenia i materiały

`RoomBuilder.gd`, `RoomStyleCatalog.gd` i `RoomTextures.gd` generują geometrię ścian, okien, sufitów, lamp i tekstury podłóg/ścian. To osobny obszar od modeli mebli. Zmiana mebli nie może naruszać geometrii pokoi ani przejść.

## Jak obecnie działa pipeline

- `TrackModelLibrary.gd` tworzy szablony modeli i cache'uje ich kopie.
- `FurnitureModels.gd`, `ObstacleModels.gd` i `AnimalModels.gd` generują geometrię przez `ModelBuilder.gd`.
- `ObjectSkins.gd` zmienia materiały istniejących modeli; **nie jest systemem Style Packów i nie wymienia geometrii**.
- Kolizje oraz logika obiektów są w skryptach tras i systemach rozgrywki, a nie w samych modelach wizualnych.

Nowy pipeline powinien więc działać jako warstwa wizualna za `TrackModelLibrary`, z dotychczasowymi modelami proceduralnymi jako fallbackiem.

## Docelowy system bibliotek i Style Packów

Każdy zasób otrzymuje metadane:

- `asset_id`, kategoria i podkategoria;
- `style_tags` oraz lista zgodnych `style_pack_ids`;
- źródło, oryginalny identyfikator i URL źródłowy;
- autor i dokładna licencja;
- format importu (preferowany GLB/glTF);
- wymiary źródłowe, skala docelowa i punkt podparcia;
- liczba trójkątów, liczba materiałów i szacowany koszt renderowania;
- wariant tekstur (1K / 2K), rozmiary plików i kompletność map PBR;
- profil kolizji/interakcji, który pozostaje niezależny od modelu wizualnego;
- suma kontrolna plików i informacja o wersji zasobu.

Jeden typ, np. fotel, może mieć wiele modeli z różnych bibliotek i należeć do wielu Style Packów. Generator wybiera tylko modele z wybranego zestawu lub z jego jawnie dozwolonych podstylów. Nie wolno losować obiektów z niezgodnych stylów tylko dlatego, że mają tę samą kategorię.

Planowane Style Packi do przygotowania: Cartoon Home, Modern Home, Luxury Apartment, Kids Room, Toy World, Retro/PSX, Realistic Home i Futuristic. To propozycje zestawów, nie gotowe zasoby.

### Zasady wydajności i tekstur

- Standardowo tekstury 1K (1024×1024), jeśli dany model ma tekstury.
- Wariant 2K (2048×2048) jako opcjonalny dodatek pobierany niezależnie od geometrii.
- Geometria modelu pozostaje identyczna między wariantami 1K i 2K.
- Modele bez sensownych tekstur (np. proste małe drobiazgi) mogą pozostać materiałami proceduralnymi.
- Limity trójkątów, materiałów, rozdzielczości i LOD będą ustalane per kategoria po sprawdzeniu rzeczywistych modeli i pomiarach na Androidzie.

## Źródła i licencje — zasady selekcji

1. Pierwszy wybór: oficjalny katalog Poly Haven. Modele są publikowane jako CC0; katalog obejmuje m.in. meble, dekoracje, elektronikę, kuchnię, oświetlenie i naturę. Preferować pobieranie statycznych plików GLB/glTF i zachowanie danych autora/źródła w metadanych projektu.
2. Jeśli korzystamy z działającego API Poly Haven w samej grze lub narzędziu, należy dodać widoczny kredyt „Powered by Poly Haven” oraz unikalny User-Agent zgodnie z warunkami API. To wymóg korzystania z API, odrębny od licencji CC0 samych pobranych assetów.
3. Sketchfab i inne katalogi: każdy model weryfikować osobno. Dopuszczać CC0 oraz licencje pozwalające na użycie i dystrybucję w grze (np. CC BY z zachowaniem wymaganej atrybucji). Odrzucać NC, ND, niejasne licencje i zasoby bez potwierdzonego prawa do użycia.
4. Nie wybierać modelu wyłącznie na podstawie miniatury lub liczby poligonów. Sprawdzić podgląd, skalę, orientację, materiały, UV, tekstury, liczbę materiałów i warunki licencji.

## Bezpieczna kolejność wdrożenia

1. Wybrać jeden Style Pack pilotażowy i kilka reprezentatywnych modeli (np. sofa, fotel, stół, krzesło, lampa, roślina, mały przedmiot i przeszkoda).
2. Zaimportować je jako osobne zasoby GLB, bez nadpisywania modeli proceduralnych.
3. Dopasować skalę i orientację, przygotować warianty tekstur oraz profile LOD/kolizji.
4. Podłączyć je za pośrednictwem `TrackModelLibrary`; w razie braku lub błędu importu użyć dotychczasowego modelu proceduralnego.
5. Sprawdzić generator, zapisane trasy, kolizje, destrukcję, brud, interakcje i animację zwierząt.
6. Dopiero po sprawdzeniu pilota rozszerzać katalog na kolejne kategorie i Style Packi.

## Status

Audyt źródeł kodu wykonany na `Robot-Racing-v0.3-sciany-bez-kolizji-wiecej-elementow.zip`. Na tym etapie nie podmieniono żadnego modelu i nie dodano zewnętrznych plików 3D. Nie wykonano testu runtime w Godot 4.7.2 ani na Androidzie. Roboty, stacje, istniejące modele, collidery i logika gry pozostają nietknięte przez etap audytu.

## Zweryfikowane punkty startowe

- Poly Haven — katalog modeli: https://polyhaven.com/models
- Poly Haven — meble: https://polyhaven.com/models/furniture
- Poly Haven — API i warunki użycia: https://polyhaven.com/our-api
- Poly Haven — publiczne API: https://api.polyhaven.com
- Sketchfab — dokumentacja Download API (każdy asset wymaga osobnej weryfikacji licencji): https://sketchfab.com/developers/download-api


## Aktualizacja 2026-11-18 — pięć platform robotów

Późniejsza, jawna decyzja projektowa użytkownika zmieniła wcześniejsze ograniczenie audytu: pięć aktualnych modeli robotów należy zastąpić nowymi konstrukcjami opartymi na referencjach wizualnych, natomiast pozostałe zasady ochrony logiki, fizyki i stacji pozostają w mocy. W bieżącej iteracji wykonano proceduralne platformy `model_dreame`, `model_saros`, `model_roomba`, `model_xiaomi` i `model_narwal` w `RobotVisuals.gd`; mapowanie istniejących pięciu pozycji znajduje się w `RobotDatabase.gd`. Nazwy/ID, statystyki i dane zapisu pozostają niezmienione. Stacje serwisowe pozostają nietknięte do osobnej oceny po zatwierdzeniu robotów.

Geometria nowych modeli nie używa zewnętrznych shaderów ani funkcji renderowania wymagających najwyższego presetu. To projektowa zgodność z trybami Low–Ultra, a nie wynik testu urządzeniowego; wymagany jest test w Godot 4.7.2 i na Androidzie.
