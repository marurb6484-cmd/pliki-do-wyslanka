# Robot Racing v0.3 — aktualizacja konfiguracji wyścigu

- Zaawansowana konfiguracja wyścigu pozwala wybrać gotową trasę albo losową trasę proceduralną o rozmiarze małym, średnim lub dużym.
- Zestaw modeli można przełączyć na standardowy, mieszany lub wyłącznie pobrany. Przycisk pobierania otwiera zakładkę „Dodatkowa zawartość” w ustawieniach.
- Pierwsze uruchomienie pyta o jakość grafiki i informuje, że wybór można zmienić później w ustawieniach.
- Widok top-down GTA został przybliżony (mniejszy rozmiar projekcji ortograficznej i niższa wysokość kamery).
- Zmniejszono domyślną liczbę punktów brudu.
- Stanowiska AI są ustawiane co 1,15 m wzdłuż początkowej prostej, mają mniejsze modele i węższe zatoki serwisowe.
- Wybór poziomu trudności AI pozostaje dostępny w konfiguracji wyścigu zaawansowanego (ŁATWY, NORMALNY, TRUDNY, EKSPERT).

Uwaga: projekt nie został uruchomiony w silniku Godot w tym środowisku. Zmiany sprawdzono statycznie i pod kątem integralności archiwum; test na urządzeniu nadal jest konieczny.
