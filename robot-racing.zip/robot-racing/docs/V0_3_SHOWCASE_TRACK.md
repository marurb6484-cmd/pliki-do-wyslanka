# Robot Racing v0.3 — wcześniejszy prototyp trasy Showcase

> STATUS: DRAFT / NIEGOTOWE. Zachowano ten prototyp jako materiał do przebudowy. Nie jest zarejestrowany w `TrackDatabase`, nie należy traktować go jako gotowej ani przejezdnej trasy.

Poprzednia wersja nie spełniała wymagań użytkownika: miała nieprawidłowy układ startu/przejezdności, nie zawierała pełnego dachu ani prawidłowych otworów drzwiowych. Nie uruchomiono jej w Godot.

Właściwa specyfikacja przebudowy znajduje się w `V0_3_APARTMENT_TRACK_REDESIGN.md`.

---

# Robot Racing v0.3 — MIESZKANIE SHOWCASE

## Cel

Druga, niezależna trasa mieszkalna. Pierwsza trasa `MIESZKANIE` pozostaje dostępna i nie została zastąpiona.

## Układ trasy

- Jedna zamknięta pętla.
- Długa prosta startowa.
- Szybkie łuki w obu kierunkach.
- Ciasny nawrót i techniczna szykana.
- 3 okrążenia domyślnie.
- 48 punktów brudu.
- Szerokość trasy 9,5 m.

## Wykorzystane zasoby

- Wspólna biblioteka mebli i dekoracji (`TrackModelLibrary` / `FurnitureModels`).
- Pięć istniejących gatunków zwierząt (`AnimalModels`): kot, pies, królik, agama brodata i papuga.
- Istniejące stacje, roboty i systemy wyścigu nie zostały zmodyfikowane.

## Nawierzchnie

Dodano wizualne strefy drewna/paneli, gresu, wykładziny i kamienia. W tej iteracji nie wpływają jeszcze na parametry fizyki. Nie należy zakładać, że przyczepność lub opór toczenia są już różne.

## Ograniczenia obecnej architektury

`TrackBase._read_route()` zeruje wysokość waypointów, a obecne prowadzenie i nawigacja bazują na płaskiej linii trasy. Z tego powodu ta iteracja nie udaje trasy wielopoziomowej. Piętra, schody, wspólna stacja transportowa FIFO, połączenia rampami i pełna nawigacja po wysokościach wymagają osobnej, kompatybilnej rozbudowy systemu trasy i AI.

## Weryfikacja

- Kontrola geometrii punktów trasy zewnętrznym skryptem: 19 punktów, łączna długość około 240,5 m, brak przecięć nieprzylegających segmentów, najkrótszy segment około 5,39 m.
- Kontrola integralności ZIP i ścieżek scen wykonana po spakowaniu.
- Nie wykonano importu/parsera Godot, testu runtime ani testu na Androidzie — Godot 4.7.2 nie jest dostępny w środowisku przygotowania.
