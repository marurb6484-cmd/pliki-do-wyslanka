# Robot Racing v0.3 — tryby interfejsu i połączenie online

## Wybór interfejsu
- Aplikacja startuje ekranem `InterfaceModeSelect.tscn`.
- Wybór prosty/zaawansowany zapisuje się w `GameSettings` i można go zmienić w Ustawieniach.
- Tryb prosty ma osobny, większy ekran główny z wejściami do gry, garażu, multiplayera, ustawień, kanału SZAKAL i miejscem na reklamę.
- Tryb zaawansowany zachowuje dotychczasowy ekran główny.
- Oba tryby korzystają z tych samych danych i systemów gry.

## Kamera GTA 1
Tryb kamery 3 jest teraz ścisłym widokiem z góry: pozycja dokładnie nad robotem, cel dokładnie na robocie, projekcja ortogonalna i ukrywanie sufitów z grupy `race_room_ceiling`. Kadr nie jest przesuwany do przodu ani obracany za robotem.

## Multiplayer online — etap połączenia
`LanNetworkSession.gd` udostępnia bezpośrednie połączenie ENet (wspólny transport LAN/online): hostowanie pokoju, dołączanie po adresie IP/domenie i RPC z informacją o pokoju. Ekran `OnlineMultiplayer.tscn` jest dostępny z centrum multiplayera w obu trybach interfejsu.

To nie jest jeszcze pełny multiplayer wyścigowy. Nie ma matchmakingu, kont online, synchronizacji pozycji robotów, stanu wyścigu ani wyników. Hostowanie z telefonu przez internet wymaga publicznego adresu IP i dostępnego portu UDP; CGNAT u operatora może to uniemożliwić. Do publicznej gry zalecany będzie dedykowany serwer/VPS lub usługa relay.
