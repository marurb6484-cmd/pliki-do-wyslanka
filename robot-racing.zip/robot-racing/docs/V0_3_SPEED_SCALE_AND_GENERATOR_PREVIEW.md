# Robot Racing v0.3 — skala prędkości i podgląd generatora

## Prędkości bazowe

Wartości `max_speed` i `acceleration` są zapisane w jednostkach SI (m/s i m/s²). Wartość w garażu jest przeliczana na km/h.

| Robot | Limit bazowy | Prędkość bazowa | Mnożnik boosta | Prędkość z boostem |
|---|---:|---:|---:|---:|
| DustMower X1 | 2,94 m/s | 10,6 km/h | ×1,280 | 13,5 km/h |
| TurboSweep Pro | 3,36 m/s | 12,1 km/h | ×1,385 | 16,8 km/h |
| CleanBot Ultra | 2,66 m/s | 9,6 km/h | ×1,175 | 11,3 km/h |
| Vortex Heavy | 3,08 m/s | 11,1 km/h | ×1,315 | 14,6 km/h |
| NanoVac 3000 | 3,64 m/s | 13,1 km/h | ×1,490 | 19,5 km/h |

To prędkości wynikające z konfiguracji, a nie pomiar z uruchomionej symulacji. Ulepszenia gracza mogą je podnieść.

## Kamera
- Odległość za robotem: 2,05 m.
- Wysokość: 1,08 m.
- Punkt patrzenia: 0,34 m nad podłożem i 0,75 m przed robotem.
- Zachowano raycast ochrony przed ścianami, interpolację i lekką zmianę FOV.

## Generator
- Podgląd 2D i 3D: minimalna wysokość 520 px.
- Panel mapy otrzymuje większą część szerokości; panel boczny ma minimalną szerokość 300 px.
- Panel podglądu nie przycina obramowania/cienia.
- Dopasowanie mapy pozostawia 64 px marginesu, a obrys zewnętrzny jest cieńszy.
- Kamera podglądu 3D jest bliżej mapy (1,75 × zasięg zamiast 2,1 ×).
