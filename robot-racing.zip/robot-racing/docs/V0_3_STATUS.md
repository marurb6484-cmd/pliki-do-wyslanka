# Robot Racing v0.3 – rejestr zakresu i audytu

Ten dokument rozróżnia elementy obecne w przekazanym projekcie od planowanych funkcji. Nie oznaczamy funkcji jako gotowej tylko dlatego, że istnieje folder, nazwa lub prototyp.

## Stan wejściowy

- Projekt Godot 4.7.2, renderer Mobile/Forward Mobile.
- Scena startowa: `scenes/MainMenu.tscn`.
- Istnieją osobne moduły zapisu, ustawień, postępu, robotów, AI, energii, brudu, boostu, uszkodzeń, stacji, wyścigu, tras i HUD-u.
- Istnieją testy `load_all`, `UIFlowTest`, `RaceSimTest` i `ScreenshotTest`.
- Projekt ma działający szkielet wyścigu, jazdy na czas, testu grafiki, garażu, stacji, pit stopu, energii, uszkodzeń, minimapy/nawigacji i ducha okrążenia.
- W archiwum znajdował się cache `.godot`; nie jest potrzebny do przenoszenia projektu i nie powinien być traktowany jako źródło prawdy.
- W środowisku przygotowania nie ma uruchomionego silnika Godot, więc testy runtime i eksportu Android/Windows nie mogą być tu potwierdzone.

## Zmiana wykonana w tej rewizji

- `PitStopSystem` nasłuchuje teraz również zmian uszkodzeń.
- Po osiągnięciu 100% uszkodzeń robot automatycznie przechodzi w awaryjny powrót do stacji na początku bieżącego okrążenia.
- W stacji naprawa przebiega automatycznie. Dla gracza naciśnięcie gazu przerywa serwis i rozpoczyna wyjazd, nawet jeśli naprawa nie dobiegła końca.
- Dla AI zachowane jest automatyczne zakończenie obsługi według jego strategii.
- Zmiana nie dodaje energii ani nie resetuje okrążenia.
- Statycznie sprawdzono odwołania `res://`; wykryte dwa dopasowania to przykładowe ścieżki opisowe w komentarzu `AudioManager.gd`, nie zasoby wymagane przez projekt.

## Obecne systemy – istniejące lub częściowe

| System | Stan w ZIP-ie wejściowym |
|---|---|
| Menu, wybór trybu i trasy | istnieją |
| Garaż, roboty, skórki, ulepszenia | istnieją, zakres mniejszy niż plan docelowy |
| Stacje dokujące i edytor stacji | istnieją, dalsza rozbudowa zaplanowana |
| Fizyka, sterowanie dotykowe, żyroskop | istnieją |
| AI i poziomy trudności | istnieją, brak pełnego planowanego systemu uczenia/adaptacji |
| Energia, brud, boost, uszkodzenia | istnieją, system boostów wymaga rozbudowy do uzgodnionych 10 typów i progresji |
| Pit stop | istnieje; dodano obsługę 100% uszkodzeń |
| HUD, edytor HUD, minimapa/nawigacja | istnieją, część planowanych kontrolek i funkcji wymaga integracji |
| Kariera, wyzwania, turnieje | nie są pełnym systemem docelowym |
| Profile, znajomi i ID gracza | brak docelowego systemu |
| Multiplayer split-screen/LAN/online | brak docelowego systemu |
| Sklep społecznościowy, Testownia i panel twórcy | brak docelowego systemu |
| Generator proceduralny i pełny edytor tras | brak docelowego systemu |
| System modów i bezpieczne paczki | brak docelowego systemu |
| Powtórki pełnych wyścigów | brak docelowego systemu |
| Wydarzenia sezonowe i rankingi online | brak docelowego systemu |
| Konta, chmura i synchronizacja Android/Windows | brak backendu i pełnego systemu kont |
| Reklamy i promocja kanału | brak zintegrowanego systemu |
| Billboardy z losowymi miniaturami kanału YouTube | zaplanowane; wymaga rozwiązania źródła listy filmów, kanału i pamięci podręcznej |
| Dystrybucja Android + Windows | istnieje tylko wstępny preset Android; Windows wymaga przygotowania i testów |

## Zakres v0.3, który pozostaje obowiązujący

Wszystkie wcześniej uzgodnione systemy pozostają częścią Robot Racing v0.3. W szczególności: profile i konta, synchronizacja zapisów, multiplayer lokalny i online, wszystkie boosty, kariera, wyzwania, mistrzostwa, generator i edytor tras, sklep społecznościowy, Testownia, ekonomia twórców, oceny i rankingi, stacje, kolekcje, powtórki, ghost, AI adaptacyjne, wydarzenia, mody, lokalna rozgrywka offline, ustawienia i języki, regulamin, prywatność, monetyzacja, reklamy oraz promocja kanału.

Funkcje wymagające backendu, zewnętrznych kont, kluczy API, usług sieciowych lub testów na urządzeniach nie mogą być uczciwie oznaczone jako gotowe bez ich skonfigurowania i sprawdzenia. Nie wolno włączać płatnych usług ani ryzyka niekontrolowanych rachunków bez osobnej zgody.

## Testy przed oznaczeniem v0.3 jako gotowej

1. Otworzyć projekt w Godot 4.7.2 i sprawdzić błędy importu.
2. Uruchomić `tests/load_all.gd`.
3. Uruchomić `UIFlowTest` i scenariusze `RaceSimTest`.
4. Sprawdzić na urządzeniu Android: sterowanie, HUD, stacje, pit stop, wydajność i zapis.
5. Zbudować i przetestować eksport Android.
6. Przygotować oraz przetestować eksport Windows.
7. Przeprowadzić test migracji zapisów i testy offline/online.
8. Dopiero po testach oznaczyć konkretne funkcje jako gotowe.


## Zmiany generatora v15 (kod — bez testu runtime)

- Wprowadzono 6–17 mniejszych pomieszczeń, powtarzane sypialnie i osobną bawialnię; podniesiono również ściany w stałej trasie mieszkania.
- Zwiększono skalę mebli, wysokość ścian/drzwi i rozmiar okien; zagęszczono wyposażenie bliżej trasy.
- Krawędzie trasy oznaczają linie zamiast band; usunięto środkowe paski.
- Dodano powierzchnie promocyjne na TV, stołach, regałach, szafkach i wybranych ścianach.
- Wymaga testu w Godot 4.7.2 i na Androidzie; szczególnie przejazdy bez band oraz kolizje z większym umeblowaniem.
