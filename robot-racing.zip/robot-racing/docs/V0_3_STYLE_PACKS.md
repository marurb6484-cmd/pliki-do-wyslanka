# Robot Racing v0.3 — pakiety modeli

## Zmiany w tej aktualizacji
- Ustawienia > Dodatkowa zawartość: automatyczne pobieranie pakietu Modern Home z limitem 5, 10, 20, 50, 100, 150 lub 200 modeli.
- Pobieranie jest sekwencyjne, z dotychczasową walidacją glTF/GLB, zależności, rozmiaru i MD5.
- Automatyczne przypisywanie korzysta z nazw i tagów katalogu Poly Haven oraz jawnej mapy słów kluczowych. Każda kategoria może mieć wiele pobranych wariantów; generator losuje wariant dla kolejnego wystąpienia obiektu.
- Niedopasowane kategorie nadal korzystają z modeli proceduralnych. Ręczne przypisywanie pozostaje dostępne.
- Generator ma przełącznik modeli standardowych / pobranego pakietu Modern Home.
- Usunięto starą wyszukiwarkę i downloader tekstur z interfejsu generatora. Zachowano pola danych tras i odczyt wcześniejszych ścieżek tekstur.

## Ograniczenia tej iteracji
- Limit 200 oznacza maksymalną liczbę modeli pobieranych z katalogu w jednym przebiegu, o ile katalog zawiera tyle rozpoznanych pozycji. Nie oznacza gwarancji 200 różnych kategorii.
- Automatyczne dopasowanie jest konserwatywne i oparte o nazwy/tagi; nie analizuje semantycznie geometrii modeli. Ręczna korekta pozostaje możliwa.
- Układanie drobnych przedmiotów na blatach i półkach wymaga osobnego systemu punktów powierzchniowych w generatorze. Ta paczka nie deklaruje jeszcze pełnego automatycznego rozmieszczania na meblach; istniejące rozmieszczenie obiektów i kolizje pozostają bez zmian.
- Nie wykonano testu uruchomieniowego w Godot 4.7.2 w tym środowisku. Wymagany test na urządzeniu: odświeżenie katalogu, pobranie małego pakietu (5 modeli), wybór źródła modeli i wygenerowanie trasy.

## Katalog, podgląd i tryb wyłącznie pobranych modeli

- Lista zainstalowanych modeli jest przewijana; wybór pozycji ładuje jej podgląd 3D w panelu ustawień wraz z nazwą, autorem, licencją i źródłem.
- Modele można ręcznie przypisać do mebli, domowych przeszkód oraz siedmiu rodzajów zabrudzeń.
- Automatyczne dopasowanie rozpoznaje część domowych przedmiotów, zabrudzeń i przeszkód po nazwach/tagach. Jest to dopasowanie heurystyczne, a nie analiza geometrii modelu.
- Tryb „wyłącznie pobrane modele” nie korzysta z proceduralnych modeli zastępczych dla mebli, przeszkód ani wizualizacji zabrudzeń. Brakujące przypisania pozostają puste; przed włączeniem trybu należy sprawdzić i uzupełnić kategorie.
- Wizualizacje zabrudzeń korzystają z osobnych przypisań dla kurzu, okruchów, kłaczków, błota, piasku, sierści i plam/rozlanych płynów. Mechanika zbierania, wartości punktów i kolizje zabrudzeń pozostają bez zmian.
- Obiekty przeszkód otrzymują zewnętrzny model wizualny, natomiast dotychczasowe kształty kolizji pozostają bez zmian.
- Katalog w tej implementacji nadal pochodzi z Poly Haven i zawiera tylko te modele, które ta biblioteka faktycznie udostępnia. Nie gwarantujemy, że znajdzie się tam model każdego rodzaju zabrudzenia lub przeszkody; brakujące zasoby trzeba będzie uzupełnić przez obsługę kolejnych bibliotek zewnętrznych.


## Aktualizacja interfejsu i pobierania
- Komunikat startowy jest krótszy i ma ograniczony rozmiar okna.
- Pakiety większe niż 10 MiB wymagają potwierdzenia przed pobraniem; rozmiar obejmuje model i zależności.
- Lista modeli zainstalowanych ma większy obszar przewijania, a podgląd skaluje model do mniejszego kadru.
- Generator ma trzeci tryb: wyłącznie modele dodatkowe, bez standardowych zamienników.
- Stacje AI są grupowane przy starcie zamiast rozstawiania ich na odcinkach okrążenia. Odcinki zachowują dodatkową stację środkową.
- Drobne obiekty dekoracyjne są jawnie ustawiane jako ruchome bryły; po uderzeniu otrzymują mocniejszy impuls i mogą przesunąć się po podłodze.


## Korekta modeli, oznaczenia brudu i przeszkód (17.11.2026)

- Usunięto podwójną deklarację `_style_download_confirm` w `Settings.gd`, która blokowała parser.
- Dopasowanie pobranych modeli mebli korzysta teraz z tych samych wymiarów kategorii co `RoomFurnisher`; nowe instancje i już zainstalowane modele są automatycznie skalowane przy tworzeniu trasy. Zachowywane są proporcje źródłowego modelu.
- Obliczanie obwiedni modelu odbywa się w lokalnym układzie węzłów, bez polegania na `global_transform` przed dodaniem modelu do drzewa sceny.
- Dodano mały wykrzyknik z jasnym wypełnieniem i złotym obrysem nad każdym punktem zabrudzenia.
- Usunięto dekoracyjne pierścienie na górze przeszkód, które mogły wyglądać jak aureole.
- Dopasowanie rozmiaru do wymiarów planowania pomieszczeń ogranicza ryzyko wchodzenia pobranych mebli w ściany; nie zastępuje to testu każdej losowej aranżacji w Godot.


## Aktualizacja interfejsu, proporcji i diagnostyki pobierania
- Podgląd modelu w Ustawieniach ma teraz kontener o proporcjach 1:1.
- Listy katalogu i zainstalowanych modeli otrzymały osobne suwaki przewijania, zsynchronizowane z pionowym przewijaniem list.
- Dodano przełącznik „AUTOMATYCZNIE POPRAWIAJ PROPORCJE MODELI (także już pobranych)”. Korekta jest stosowana przy tworzeniu instancji modeli z katalogu lokalnego; nie zmienia źródłowych plików ani geometrii kolizji. Przy wyłączonej opcji pozostaje jednolite skalowanie zachowujące proporcje.
- Diagnostyka błędów API/pobierania pokazuje teraz skróconą treść odpowiedzi serwera, co pozwala rozpoznać m.in. HTTP 400/403/429 zamiast ogólnego komunikatu. Dopuszczono zaufane hosty pobierania Poly Haven: dl.polyhaven.org, cdn.polyhaven.com i assets.polyhaven.com (wyłącznie HTTPS).
- Zwierzęta w tej wersji nadal są pięcioma modelami proceduralnymi: kot, pies, królik, agama brodata i papuga. Nie są to modele zwierząt pobierane z Poly Haven; wymagają osobnej wymiany/rozbudowy artystycznej.


## Układ podglądu, kolejka dużych pakietów i zwierzęta
- Lista pobranych modeli jest po lewej stronie, a duży podgląd 3D 1:1 po prawej. Model jest dopasowywany jednolitą skalą i centrowany w obszarze podglądu.
- Automatyczny pakiet najpierw obsługuje modele do 10 MB. Pakiety większe są odkładane do drugiej kolejki; po zakończeniu małych modeli pojawia się decyzja POBIERZ / POMIŃ dla każdego dużego pakietu. ANULUJ PAKIET przerywa cały automatyczny proces.
- Dodano gatunki: chomik, świnka morska, żółw, jeż i fretka; są uwzględniane w generatorze tras i mają osobne sylwetki oraz ruch części modelu.
