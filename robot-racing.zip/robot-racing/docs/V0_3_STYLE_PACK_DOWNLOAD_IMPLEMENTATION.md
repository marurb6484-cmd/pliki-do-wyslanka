# Robot Racing v0.3 — Style Pack Modern Home

## Implemented in this update

- Added `StylePackManager` as an autoload service.
- Added Settings → Dodatkowa zawartość with live Poly Haven model catalog, local search, 1K/2K preference, selected-model download, installed-model list, category assignment and removal.
- Added a first-start introduction with `ZOBACZ PAKIETY`, `PÓŹNIEJ` and `NIE POKAZUJ PONOWNIE` actions. The live catalog is only requested after the user chooses to refresh it.
- Catalog uses Poly Haven's model type filter and sorts results by download count.
- The downloader reads the actual `/files/{id}` response. It prefers the selected resolution, falls back to 1K and then the smallest available model file.
- Supports glTF/GLB and the dependency files returned by Poly Haven. Relative dependency paths are preserved so glTF texture and buffer references can resolve.
- Every downloaded file is written to a staging directory, checked against the API byte size and MD5, and then the glTF document is validated by Godot before the package is committed.
- Existing installed content is backed up during an update and restored if commit fails.
- Per-asset `license_manifest.json` records asset ID/name, author, source page, CC0 license, source URLs, API terms, file sizes, MD5 values, resolution, timestamp and provenance.
- The UI and first-start dialog display `Powered by Poly Haven`. Requests send the unique `RobotRacing/0.3 (StylePackManager)` User-Agent.
- Downloaded models can be assigned to any `FurnitureModels.KINDS` category (including household props and small debris) or to one of the five obstacle visuals (pouf, can, toy block, traffic cone, drum). `TrackModelLibrary` loads and caches the external glTF model and duplicates it for subsequent objects.
- Existing procedural furniture remains the fallback if a package is not installed, is deleted, cannot load or the game is offline. Existing robot and service-station models are not touched. Collision geometry is not replaced by downloaded visual models.

## Important current boundaries

- The in-game catalog is a live browser of Poly Haven models, not a pre-approved fixed collection. The user chooses the model and category. Review the preview/source page before using a model in a public release.
- A downloaded model is not assigned automatically. It must be assigned to a furniture category in Settings.
- This integration replaces assigned furniture/prop visuals and the five procedural obstacle visuals. It does not replace robot models, service-station models, track barriers, animals or every other possible scene prop. Collision geometry remains the existing project geometry.
- The selected 1K/2K option chooses an available model-file resolution in the API. If a model does not offer the requested resolution, the manager uses a lower/default available variant and records the actual selected API variant in its manifest.
- No exact package size is estimated in advance. The UI displays actual file size after download/installation.
- Poly Haven's API is best-effort; API outages, network interruptions, unsupported assets and insufficient storage are handled as failures. Procedural models remain available offline.

## Licensing and attribution

See `THIRD_PARTY_NOTICES.md` and `docs/licenses/POLY_HAVEN_ASSET_LICENSE.md`. Poly Haven states that its assets are CC0 1.0 Universal and permits commercial use. Use of the live API separately requires a visible `Powered by Poly Haven` credit and a unique User-Agent. Each installed asset has its own provenance/license manifest. CC0 does not clear third-party trademarks or other separately protected material that may appear in a model; inspect each asset before release.

## Validation status

The ZIP structure and project integration were statically inspected in this environment. This environment does not have Godot 4.7.2 installed and cannot resolve the Poly Haven API host, so a real Android runtime download/import test could not be executed here. Do not treat this package as runtime-tested until the in-game checks below pass.

## Android acceptance test

1. Open the project in Godot 4.7.2 and run the game.
2. Open Settings → Dodatkowa zawartość; tap `ODŚWIEŻ KATALOG ONLINE` while online.
3. Search for a model, select it and download it at 1K. Check progress, installed listing and the per-asset license manifest.
4. Assign it to a suitable furniture category. Generate/open an apartment track and verify model scale, materials and placement. Repeat for one obstacle visual and confirm its original collision behavior remains unchanged.
5. Repeat with 2K for a model that exposes a 2K variant.
6. Delete the model and verify the procedural fallback returns.
7. Repeat with airplane mode/offline, an interrupted connection and a model without supported glTF/GLB data. The base game must remain usable.
8. Verify robots, service stations, boost effects, track generation, graphics settings and the graphics test still behave as before.

### Korekta zgodności API (17.11.2026)
Endpoint katalogu modeli używa parametru `type=models` zgodnie z aktualną dokumentacją Poly Haven. Wartość numeryczna `type=2` powodowała odpowiedź HTTP 400. Limit odpowiedzi HTTPRequest pozostaje ustawiony na `-1` (bez limitu).


### Poprawka pobierania, usuwania i animacji (17.11.2026)
- Lista plików modelu jest pobierana przez aktualny endpoint `/v2/files/{id}`; odpowiedź w formacie `{message, data}` jest rozpakowywana przed analizą drzewa plików.
- Naprawiono stan `HTTPRequest.download_file`: po pobraniu pliku pozostawała ścieżka poprzedniego pliku, przez co następne żądanie JSON mogło zostać zapisane na dysk zamiast trafić do parsera. Ścieżka jest teraz czyszczona przed każdym żądaniem API i po zakończeniu instalacji.
- Pozostawiono pobieranie pliku głównego i zależności, weryfikację rozmiaru/MD5 oraz staging z manifestem. Dodano większy limit przekierowań HTTP.
- Dodano bezpieczne usuwanie pojedynczego pakietu oraz wszystkich pakietów z osobnym potwierdzeniem. Usuwane są wyłącznie pakiety zarejestrowane w grze i z poprawnym, zweryfikowanym manifestem; zasoby wbudowane pozostają nietknięte. Przypisania i cache usuniętego pakietu są czyszczone.
- Znacznik „!” nad zabrudzeniem jest teraz ukrywany razem z modelem i śladami po zebraniu; pojawia się ponownie dopiero po odrodzeniu zabrudzenia.
- Drobne fizyczne przedmioty kolidują z warstwą świata i robotami, dzięki czemu mogą reagować na podłoże i otoczenie, a nie tylko na robota.
- Wszystkie pobrane modele są skalowane jednolicie (jedna wartość X/Y/Z), co zachowuje ich naturalne proporcje. Automatyczna korekta dopasowuje model do obrysu bez nierównomiernego rozciągania.
- Zwierzęta mają animację części wbudowanych modeli (ruch łap, głowy, ogona i skrzydeł). Dodano też przypisywanie pobranego modelu zwierzęcia, ale tylko jeśli plik glTF/GLB zawiera `AnimationPlayer` z animacją; modele statyczne są odrzucane.
- Nie podmieniano modeli robotów, stacji ani efektów boostów.
- Weryfikacja: kontrola statyczna kodu i integralności ZIP. Godot 4.7.2 oraz test na Androidzie nie były uruchamiane w tym środowisku.
