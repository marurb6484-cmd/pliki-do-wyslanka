# Robot Racing v0.3 – Style Pack pilot: Modern Home

## Status

This is the first runtime foundation for external style packs. The current project archive did not contain downloaded third-party GLB/GLTF files. The execution environment could retrieve Poly Haven's public catalogue metadata, but direct asset download was unavailable during this pass. Therefore **no third-party model is falsely marked as installed** and the game continues to use its existing procedural meshes until a verified scene is added.

## First pack

- ID: `modern_home`
- Display name: `Modern Home – pilot`
- Intended look: bright contemporary home, neutral upholstery, light/warm wood, simple silhouettes.
- Source catalogue: https://polyhaven.com/models/furniture
- Asset license: CC0 1.0 (Poly Haven models)
- License information: https://polyhaven.com/license
- Attribution label for the pack: `Modele 3D: Poly Haven (CC0).`

## Candidate model mapping

The following five GLB entries are listed by Image3D as CC0 assets sourced from Poly Haven. The listing reports GLB validation and file sizes. The files could not be downloaded into this build environment, so none is yet imported into Godot or activated in the game.

| Game kind | Model | Author | Listed size | Status |
|---|---|---|---:|---|
| chair | Modern Arm Chair 01 | Vibrant Nordic | 2.57 MB | verified listing; not imported |
| table | Wooden Table 02 | Serhii Khromov | 473 KB | verified listing; not imported |
| bookshelf | Wooden Display Shelves 01 | James Ray Cock | 457 KB | verified listing; not imported |
| bookshelf | Steel Frame Shelves 01 | James Ray Cock | 1.52 MB | verified listing; not imported |
| chair / stool | Wooden Stool 02 | Kuutti Siitonen | 2.65 MB | verified listing; not imported |

The direct download addresses and reported sizes are recorded in `assets/style_packs/modern_home/pack.json`. These are candidate files, not assets bundled in this ZIP. The pack still needs a sofa, bed, cabinet and lighting model before it can replace a complete room set.

## Integration rules

1. Keep the original procedural model code intact as a fallback.
2. Put imported scenes under `res://assets/style_packs/modern_home/models/`.
3. Register only verified `.glb`/`.gltf` `PackedScene` paths in `StylePackCatalog.PACKS.modern_home.model_scenes`.
4. Normalize each source model's origin to floor level, forward direction to `-Z`, and scale to the existing `RoomFurnisher.DIMS` footprint. Do not change placement footprints or collision logic as part of model import.
5. Preserve source materials/textures, then prepare separate 1K and optional 2K texture variants where the source permits it. Do not upscale low-resolution source maps and call them native 2K.
6. Keep robots and service stations outside this replacement system.
7. Test each imported model for missing textures, orientation, floor contact, bounds, draw calls, and Android memory/performance before enabling it in a pack.

## Runtime behavior

`TrackModelLibrary.make_furniture(kind, variant, style_pack_id)` now checks the selected pack for an imported scene. If there is no verified scene for that kind, it uses the original cached `FurnitureModels` procedural model. Existing calls with two arguments are unchanged.

## Source notes

Poly Haven states that its assets are CC0 and can be used commercially. The Image3D furniture listings identify these GLBs as CC0 and cite Poly Haven as the original source. When a product integrates the live Poly Haven API, the API terms require a visible source credit and a unique User-Agent for API requests. The current game build does not make live API requests; source and license metadata are retained in the pack manifest.
