# Robot Racing v0.3 — spójna skala świata

## Docelowe jednostki
- 1 jednostka Godot = 1 metr.
- Robot: zależnie od bryły ok. 1,44–1,56 m w modelu bazowym × 0,22 = ok. 0,32–0,34 m; collider i promień AI: 0,17 m.
- Trasa: szerokość zależna od poziomu 1,65–2,45 m; przebieg mapy jest kompaktowy dla mieszkania, a podgląd 2D i edytor używają tych samych wymiarów.
- Starsze zapisane szerokości tras 8–18 m są migrowane proporcjonalnie (×0,1) do nowego zakresu.
- Edytor ręczny używa odcinków 3–10 m i siatki 0,25 m.
- Przeszkody fizyczne: promień 0,16–0,27 m, wysokość 0,18–0,28 m.
- Stacje: oryginalna geometria zachowana, cały model skaluje się proporcjonalnie do 0,40; stacje ładowania znajdują się wyłącznie przy starcie.
- Meble i wyposażenie: bazowe wymiary modeli są traktowane jako metry; skala instancji nie jest ponownie zmniejszana dodatkowymi mnożnikami.
- Zwierzęta: osobne mnożniki gatunkowe, aby modele miały realistyczne rozmiary.
- Pokoje: generator dzieli większe obszary na nieregularne pomieszczenia; dla nowych map v28 rozmiary generatora obejmują orientacyjnie 100–500 m²; wysokość ścian 2,75 m, drzwi 2,05 m.

## Zakres zmian
Dopasowano kolizję i AI do robota, szerokość tras, przeszkody, stacje i zatoki serwisowe, rozmiary mebli/zwierząt, rozmieszczenie wyposażenia w pokojach oraz wysokość ścian, drzwi, okien i oświetlenia. Geometria modeli robota i stacji nie została przebudowana — zastosowano jednolitą skalę rodzica.

## Weryfikacja
Wykonano kontrolę statyczną plików i integralności ZIP. Projekt nie został uruchomiony w Godot 4.7.2 ani na Androidzie; fizykę, nawigację AI i generator należy potwierdzić w runtime.


## Domyślna trasa
Scena MIESZKANIE korzysta teraz z deterministycznych danych generatora i sceny ProceduralTrack. Stary statyczny układ waypointów nie jest już używany w normalnym wyborze trasy. TrackShowcase pozostaje nieaktywnym prototypem poza katalogiem tras; aktywna trasa MIESZKANIE korzysta z nowej sceny proceduralnej.

- Pola startowe, rozstaw AI, promień omijania, bramki checkpointów i rozmieszczenie punktów brudu przeliczono na nową szerokość jezdni.

- Zmniejszono grubość ścian i elementów sufitu do wymiarów typowych dla mieszkania; probe odbić dopasowano do mniejszej planszy.

- Zmniejszono hitboxy i znaczniki zabrudzeń, dopasowując je do powierzchni odkurzacza; poprawiono też próg zbierania przy szybkiej jeździe.
