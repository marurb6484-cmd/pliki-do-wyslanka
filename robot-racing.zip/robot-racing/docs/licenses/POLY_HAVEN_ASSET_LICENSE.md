# Poly Haven asset license record

**Asset license stated by Poly Haven:** CC0 1.0 Universal.

Poly Haven's official license page states that its HDRIs, textures and 3D models are licensed as CC0 and may be used for any purpose, including commercial work. Attribution is not required for the assets themselves.

Official references:
- https://polyhaven.com/license
- https://creativecommons.org/publicdomain/zero/1.0/

**Separate API conditions:** applications using the live Poly Haven API must display a clear `Powered by Poly Haven` credit and send a unique User-Agent with every API request. These conditions apply to API access, not to the CC0 status of the asset files.

- https://polyhaven.com/our-api
- https://github.com/Poly-Haven/Public-API/blob/master/ToS.md

A per-asset manifest is written only after every downloaded file passes size and MD5 verification and the glTF/GLB loader accepts the model. The manifest records the exact asset and files used. Check the manifest and review the model before shipping it in a public release, particularly for third-party trademarks or other rights not covered by CC0.
