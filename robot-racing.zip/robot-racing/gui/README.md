# GUI — interfejs użytkownika

Folder `gui/` jest indeksem i dokumentacją podziału interfejsu. W tym projekcie działające zasoby UI pozostają w istniejących, używanych ścieżkach `res://ui/` oraz `res://scripts/ui/`. Nie kopiujemy ich do drugiego katalogu, bo powstałyby dwa źródła prawdy i łatwo byłoby podpiąć niewłaściwą scenę.

- `res://ui/hud/` — sceny HUD-u wyścigu, wyników i minimapy.
- `res://ui/theme/` — motyw i wspólne style kontrolek.
- `res://scripts/ui/menus/` — logika menu, kariery, garażu i generatora tras.
- `res://scripts/ui/hud/` — logika HUD-u, portret S-01 i elementy ekranowe.
- `res://scripts/ui/` — wspólne kontrolki, mapy i narzędzia interfejsu.

Folder `gui/` nie jest wymagany przez Godot. Nazwa sekcji `[gui]` w `project.godot` oznacza ustawienia silnika dotyczące kontrolek, a nie obowiązkowy katalog.
