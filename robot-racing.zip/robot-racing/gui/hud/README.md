# HUD

Sceny interfejsu wyścigu znajdują się w `res://ui/hud/`, a ich logika w `res://scripts/ui/hud/`.
