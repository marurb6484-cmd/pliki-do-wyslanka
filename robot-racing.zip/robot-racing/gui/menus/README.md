# Menu

Aktywne skrypty menu znajdują się w `res://scripts/ui/menus/`. Zachowujemy tę ścieżkę, ponieważ sceny projektu już z niej korzystają.
