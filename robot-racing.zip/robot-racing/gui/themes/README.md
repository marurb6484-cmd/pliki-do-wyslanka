# Motywy

Aktywny motyw Godot znajduje się w `res://ui/theme/` i jest podłączony w sekcji `[gui]` pliku `project.godot`.
