extends Node
## Dźwięk gry.
##
## Projekt nie zawiera plików audio, dlatego wszystkie efekty są generowane
## proceduralnie przy starcie (krótkie próbki PCM w pamięci, ~3 s łącznie).
## Jeżeli w przyszłości pojawią się pliki, wystarczy umieścić je jako
##   res://assets/audio/<nazwa>.ogg  lub  .wav
## (nazwy: engine, boost, hit, hit_light, pickup, click, beep, beep_go,
##  finish, denied, lap) - zostaną użyte automatycznie zamiast syntezy.

const MIX_RATE: int = 22050
const SFX_POOL_SIZE: int = 8
const AUDIO_DIR: String = "res://assets/audio/"

var _streams: Dictionary = {}
var _pool: Array[AudioStreamPlayer] = []
var _pool_index: int = 0
var _ui_player: AudioStreamPlayer
var _engine_preview_player: AudioStreamPlayer
var _engine_preview_timer: float = 0.0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_setup_buses()
	_generate_streams()
	_create_players()
	_apply_volumes()

	GameSettings.audio_changed.connect(_apply_volumes)
	get_tree().node_added.connect(_on_node_added)


# =========================================================
# MAGISTRALE AUDIO
# =========================================================

func _setup_buses() -> void:
	for bus_name: String in ["SFX", "Engine", "UI"]:
		if AudioServer.get_bus_index(bus_name) == -1:
			AudioServer.add_bus()
			var index: int = AudioServer.bus_count - 1
			AudioServer.set_bus_name(index, bus_name)
			AudioServer.set_bus_send(index, "Master")


func _apply_volumes() -> void:
	_set_bus_volume("Master", GameSettings.master_volume)
	_set_bus_volume("SFX", GameSettings.sfx_volume)
	_set_bus_volume("Engine", GameSettings.engine_volume)
	_set_bus_volume("UI", GameSettings.ui_volume)


func _set_bus_volume(bus_name: String, linear: float) -> void:
	var index: int = AudioServer.get_bus_index(bus_name)
	if index == -1:
		return
	AudioServer.set_bus_mute(index, linear <= 0.001)
	AudioServer.set_bus_volume_db(index, linear_to_db(maxf(linear, 0.001)))


func _create_players() -> void:
	for i: int in range(SFX_POOL_SIZE):
		var player := AudioStreamPlayer.new()
		player.bus = "SFX"
		add_child(player)
		_pool.append(player)

	_ui_player = AudioStreamPlayer.new()
	_ui_player.bus = "UI"
	add_child(_ui_player)
	_engine_preview_player = AudioStreamPlayer.new()
	_engine_preview_player.bus = "Engine"
	add_child(_engine_preview_player)


# =========================================================
# ODTWARZANIE
# =========================================================

func get_stream(sound_name: String) -> AudioStream:
	return _streams.get(sound_name, null) as AudioStream


func play(sound_name: String, volume_db: float = 0.0, pitch: float = 1.0) -> void:
	var stream: AudioStream = get_stream(sound_name)
	if stream == null:
		return

	var player: AudioStreamPlayer = _pool[_pool_index]
	_pool_index = (_pool_index + 1) % _pool.size()
	player.stream = stream
	player.volume_db = volume_db
	player.pitch_scale = clampf(pitch, 0.3, 3.0)
	player.play()


## Dźwięk w świecie - głośność maleje z odległością od kamery.
## Używamy puli odtwarzaczy 2D (tańsze na Androidzie niż wiele węzłów 3D).
func play_at(sound_name: String, world_position: Vector3, volume_db: float = 0.0, pitch: float = 1.0) -> void:
	var camera: Camera3D = get_viewport().get_camera_3d()
	if camera != null:
		var distance: float = camera.global_position.distance_to(world_position)
		if distance > 40.0:
			return
		volume_db -= distance * 0.55
	play(sound_name, volume_db, pitch)


func play_ui(sound_name: String = "click") -> void:
	var stream: AudioStream = get_stream(sound_name)
	if stream == null:
		return
	_ui_player.stream = stream
	_ui_player.play()


## Automatyczny dźwięk kliknięcia dla każdego przycisku w grze.
func _on_node_added(node: Node) -> void:
	if node is BaseButton:
		var button: BaseButton = node as BaseButton
		if not button.pressed.is_connected(_on_button_pressed):
			button.pressed.connect(_on_button_pressed)


func _on_button_pressed() -> void:
	play_ui("click")


# =========================================================
# SYNTEZA DŹWIĘKÓW
# =========================================================

func _generate_streams() -> void:
	var generators: Dictionary = {
		"engine": _gen_engine,
		"boost": _gen_boost,
		"hit": _gen_hit,
		"hit_light": _gen_hit_light,
		"pickup": _gen_pickup,
		"click": _gen_click,
		"beep": _gen_beep.bind(660.0, 0.16),
		"beep_go": _gen_beep.bind(990.0, 0.45),
		"finish": _gen_finish,
		"denied": _gen_denied,
		"lap": _gen_lap,
		"checkpoint": _gen_checkpoint
	}

	for sound_name: String in generators.keys():
		var external: AudioStream = _load_external(sound_name)
		if external != null:
			_streams[sound_name] = external
			continue
		var generator: Callable = generators[sound_name]
		_streams[sound_name] = generator.call()
	_streams["engine_profile_1"] = _gen_engine_profile(1)
	_streams["engine_profile_2"] = _gen_engine_profile(2)


func get_engine_stream(profile: int = 0) -> AudioStream:
	if profile <= 0:
		return get_stream("engine")
	return get_stream("engine_profile_%d" % clampi(profile, 1, 2))


func play_engine_preview(profile: int = 0) -> void:
	_engine_preview_player.stop()
	_engine_preview_player.stream = get_engine_stream(profile)
	_engine_preview_player.volume_db = -3.0
	_engine_preview_player.play()
	_engine_preview_timer = 1.8


func _process(delta: float) -> void:
	if _engine_preview_timer > 0.0:
		_engine_preview_timer -= delta
		if _engine_preview_timer <= 0.0 and is_instance_valid(_engine_preview_player):
			_engine_preview_player.stop()


func _load_external(sound_name: String) -> AudioStream:
	for extension: String in [".ogg", ".wav", ".mp3"]:
		var path: String = AUDIO_DIR + sound_name + extension
		if ResourceLoader.exists(path):
			var stream: AudioStream = load(path) as AudioStream
			if stream != null:
				return stream
	return null


func _make_wav(samples: PackedFloat32Array, loop: bool = false) -> AudioStreamWAV:
	var data := PackedByteArray()
	data.resize(samples.size() * 2)
	for i: int in range(samples.size()):
		data.encode_s16(i * 2, int(clampf(samples[i], -1.0, 1.0) * 32000.0))

	var wav := AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = MIX_RATE
	wav.stereo = false
	wav.data = data
	if loop:
		wav.loop_mode = AudioStreamWAV.LOOP_FORWARD
		wav.loop_begin = 0
		wav.loop_end = samples.size()
	return wav


## Silnik robota: pętla 0.5 s; częstotliwości mają całkowitą liczbę okresów,
## więc zapętlenie jest bezszwowe. Wysokość zmienia RobotAudio (pitch_scale).
func _gen_engine() -> AudioStreamWAV:
	var count: int = MIX_RATE / 2
	var samples := PackedFloat32Array()
	samples.resize(count)
	for i: int in range(count):
		var t: float = float(i) / MIX_RATE
		var value: float = 0.0
		value += sin(TAU * 110.0 * t) * 0.35
		value += sin(TAU * 220.0 * t) * 0.18
		value += sin(TAU * 330.0 * t) * 0.08
		value += sin(TAU * 880.0 * t) * 0.06     # pisk silniczka elektrycznego
		value += sin(TAU * 56.0 * t) * 0.12      # buczenie szczotek
		samples[i] = value * 0.8
	return _make_wav(samples, true)


func _gen_engine_profile(profile: int) -> AudioStreamWAV:
	var count: int = MIX_RATE / 2
	var samples := PackedFloat32Array()
	samples.resize(count)
	var fundamental: float = 74.0 if profile == 1 else 48.0
	var harmonic: float = 148.0 if profile == 1 else 96.0
	for i: int in range(count):
		var t: float = float(i) / MIX_RATE
		var value: float = sin(TAU * fundamental * t) * 0.48
		value += sin(TAU * harmonic * t) * (0.22 if profile == 1 else 0.32)
		value += sin(TAU * (fundamental * 3.0) * t) * 0.12
		if profile == 1:
			value += sin(TAU * 520.0 * t) * 0.045
		else:
			value += sin(TAU * 42.0 * t) * 0.16
		samples[i] = value * 0.72
	return _make_wav(samples, true)


func _gen_boost() -> AudioStreamWAV:
	var duration: float = 0.75
	var count: int = int(MIX_RATE * duration)
	var samples := PackedFloat32Array()
	samples.resize(count)
	var rng := RandomNumberGenerator.new()
	rng.seed = 1234
	var low: float = 0.0
	var phase: float = 0.0
	for i: int in range(count):
		var p: float = float(i) / count
		var noise: float = rng.randf_range(-1.0, 1.0)
		var cutoff: float = lerpf(0.05, 0.35, p)
		low += (noise - low) * cutoff
		phase += TAU * lerpf(180.0, 720.0, p) / MIX_RATE
		var envelope: float = minf(p * 8.0, 1.0) * (1.0 - p) * 1.4
		samples[i] = (low * 0.7 + sin(phase) * 0.35) * envelope
	return _make_wav(samples)


func _gen_hit() -> AudioStreamWAV:
	var duration: float = 0.3
	var count: int = int(MIX_RATE * duration)
	var samples := PackedFloat32Array()
	samples.resize(count)
	var rng := RandomNumberGenerator.new()
	rng.seed = 99
	var phase: float = 0.0
	for i: int in range(count):
		var p: float = float(i) / count
		phase += TAU * lerpf(140.0, 45.0, p) / MIX_RATE
		var envelope: float = exp(-p * 9.0)
		samples[i] = (sin(phase) * 0.8 + rng.randf_range(-1.0, 1.0) * 0.45 * exp(-p * 25.0)) * envelope
	return _make_wav(samples)


func _gen_hit_light() -> AudioStreamWAV:
	var duration: float = 0.12
	var count: int = int(MIX_RATE * duration)
	var samples := PackedFloat32Array()
	samples.resize(count)
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	for i: int in range(count):
		var p: float = float(i) / count
		samples[i] = (rng.randf_range(-1.0, 1.0) * 0.5 + sin(TAU * 320.0 * i / MIX_RATE) * 0.3) * exp(-p * 12.0)
	return _make_wav(samples)


func _gen_pickup() -> AudioStreamWAV:
	var duration: float = 0.14
	var count: int = int(MIX_RATE * duration)
	var samples := PackedFloat32Array()
	samples.resize(count)
	var phase: float = 0.0
	for i: int in range(count):
		var p: float = float(i) / count
		phase += TAU * lerpf(780.0, 1560.0, p) / MIX_RATE
		samples[i] = sin(phase) * 0.55 * (1.0 - p) * minf(p * 30.0, 1.0)
	return _make_wav(samples)


func _gen_click() -> AudioStreamWAV:
	var count: int = int(MIX_RATE * 0.035)
	var samples := PackedFloat32Array()
	samples.resize(count)
	for i: int in range(count):
		var p: float = float(i) / count
		samples[i] = sin(TAU * 1800.0 * i / MIX_RATE) * 0.4 * (1.0 - p) * (1.0 - p)
	return _make_wav(samples)


func _gen_beep(frequency: float, duration: float) -> AudioStreamWAV:
	var count: int = int(MIX_RATE * duration)
	var samples := PackedFloat32Array()
	samples.resize(count)
	for i: int in range(count):
		var p: float = float(i) / count
		var envelope: float = minf(p * 40.0, 1.0) * minf((1.0 - p) * 10.0, 1.0)
		samples[i] = (sin(TAU * frequency * i / MIX_RATE) * 0.5 + sin(TAU * frequency * 2.0 * i / MIX_RATE) * 0.12) * envelope
	return _make_wav(samples)


func _gen_finish() -> AudioStreamWAV:
	var notes: Array[float] = [523.25, 659.25, 783.99, 1046.5]
	var note_len: float = 0.15
	var count: int = int(MIX_RATE * (note_len * notes.size() + 0.35))
	var samples := PackedFloat32Array()
	samples.resize(count)
	for i: int in range(count):
		var t: float = float(i) / MIX_RATE
		var note_index: int = mini(int(t / note_len), notes.size() - 1)
		var local_t: float = t - note_index * note_len
		var envelope: float = exp(-local_t * (3.0 if note_index == notes.size() - 1 else 8.0))
		samples[i] = sin(TAU * notes[note_index] * t) * 0.45 * envelope
	return _make_wav(samples)


func _gen_denied() -> AudioStreamWAV:
	var count: int = int(MIX_RATE * 0.22)
	var samples := PackedFloat32Array()
	samples.resize(count)
	for i: int in range(count):
		var p: float = float(i) / count
		var square: float = 1.0 if fmod(float(i) * 150.0 / MIX_RATE, 1.0) < 0.5 else -1.0
		samples[i] = square * 0.22 * (1.0 - p)
	return _make_wav(samples)


func _gen_lap() -> AudioStreamWAV:
	var count: int = int(MIX_RATE * 0.3)
	var samples := PackedFloat32Array()
	samples.resize(count)
	for i: int in range(count):
		var t: float = float(i) / MIX_RATE
		var frequency: float = 880.0 if t < 0.12 else 1174.66
		var local_t: float = t if t < 0.12 else t - 0.12
		samples[i] = sin(TAU * frequency * t) * 0.4 * exp(-local_t * 9.0)
	return _make_wav(samples)


func _gen_checkpoint() -> AudioStreamWAV:
	# Krótki, wyraźny dwutonowy sygnał potwierdzający zaliczenie bramki.
	var notes: Array[float] = [880.0, 1320.0]
	var note_duration: float = 0.095
	var count: int = int(MIX_RATE * note_duration * notes.size())
	var samples := PackedFloat32Array()
	samples.resize(count)
	for i: int in range(count):
		var note_index: int = mini(int(float(i) / (MIX_RATE * note_duration)), notes.size() - 1)
		var local_progress: float = fmod(float(i) / MIX_RATE, note_duration) / note_duration
		var envelope: float = minf(local_progress * 18.0, 1.0) * (1.0 - local_progress)
		samples[i] = sin(TAU * notes[note_index] * float(i) / MIX_RATE) * 0.42 * envelope
	return _make_wav(samples)
