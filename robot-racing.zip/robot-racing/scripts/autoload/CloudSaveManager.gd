extends Node
## Cloud accounts and revisioned progress sync. Local progress remains authoritative until the player chooses.

signal status_changed(message: String)
signal authenticated(user: Dictionary)
signal auth_failed(message: String)
signal cloud_save_received(save: Dictionary)
signal save_conflict(local_updated_at: String, cloud_save: Dictionary)
signal sync_completed(revision: int)
signal profile_received(profile: Dictionary)
signal profile_updated(profile: Dictionary)
signal assets_received(assets: Array)
signal asset_operation_completed(operation: String, data: Dictionary)
signal asset_operation_failed(message: String)

const DEFAULT_ENDPOINT := "https://robot-racing-multiplayer.marurb6484.workers.dev"
const LOCAL_EXPORT := "user://crunpbot_cloud_upload.cfg"
const CLOUD_IMPORT := "user://crunpbot_cloud_download.cfg"

var endpoint: String = DEFAULT_ENDPOINT
var token: String = ""
var user: Dictionary = {}
var cloud_revision: int = 0
var _request: HTTPRequest
var _asset_request: HTTPRequest
var _asset_operation: String = ""
var _asset_target_path: String = ""
var _operation: String = ""
var _pending_payload: String = ""

func _ready() -> void:
	_request = HTTPRequest.new()
	_request.timeout = 30.0
	add_child(_request)
	_request.request_completed.connect(_on_request_completed)
	_asset_request = HTTPRequest.new()
	_asset_request.timeout = 60.0
	_asset_request.download_file = ""
	add_child(_asset_request)
	_asset_request.request_completed.connect(_on_asset_request_completed)
	token = SaveManager.get_string("cloud_account", "token", "")
	user = SaveManager.get_dict("cloud_account", "user")
	var revisions: Dictionary = SaveManager.get_dict("cloud_account", "revisions")
	var account_id := str(user.get("id", ""))
	cloud_revision = int(revisions.get(account_id, SaveManager.get_int("cloud_account", "revision", 0, 0, 2147483647))) if not account_id.is_empty() else 0

func set_endpoint(value: String) -> bool:
	var candidate := value.strip_edges().trim_suffix("/")
	if not candidate.begins_with("https://"):
		return false
	endpoint = candidate
	return true

func register_email(email: String, password: String, display_name: String) -> Error:
	return _post("/api/auth/register", {"email": email, "password": password, "display_name": display_name}, "register")

func login_email(email: String, password: String) -> Error:
	return _post("/api/auth/login", {"email": email, "password": password}, "login")

## Pass a Google ID token obtained from the native Google sign-in flow. No client secret belongs in the game.
func login_google(id_token: String) -> Error:
	if id_token.strip_edges().is_empty():
		return ERR_INVALID_PARAMETER
	return _post("/api/auth/google", {"id_token": id_token}, "google")

func upload_local_save() -> Error:
	if token.is_empty():
		status_changed.emit("Zaloguj się przed synchronizacją.")
		return ERR_UNAUTHORIZED
	if not SaveManager.export_progress(LOCAL_EXPORT):
		status_changed.emit("Nie udało się przygotować lokalnego zapisu.")
		return ERR_CANT_CREATE
	var file := FileAccess.open(LOCAL_EXPORT, FileAccess.READ)
	if file == null:
		return ERR_FILE_CANT_READ
	_pending_payload = file.get_as_text()
	var headers := PackedStringArray(["Content-Type: application/json", "Authorization: Bearer " + token])
	var body := JSON.stringify({"expected_revision": cloud_revision, "payload": _pending_payload})
	var err := _request.request(endpoint + "/api/save", headers, HTTPClient.METHOD_PUT, body)
	if err == OK:
		_operation = "upload"
		status_changed.emit("Wysyłanie lokalnego postępu do chmury…")
	return err

func download_cloud_save() -> Error:
	if token.is_empty():
		return ERR_UNAUTHORIZED
	var headers := PackedStringArray(["Authorization: Bearer " + token])
	var err := _request.request(endpoint + "/api/save", headers, HTTPClient.METHOD_GET)
	if err == OK:
		_operation = "download"
		status_changed.emit("Pobieranie zapisu z chmury…")
	return err


func get_cloud_profile() -> Error:
	return _authorized_request("/api/profile", HTTPClient.METHOD_GET, "", "profile_get")

func update_cloud_profile(public_name: String, country_code: String = "", selected_robot_id: String = "") -> Error:
	var payload := {"public_name": public_name}
	if not country_code.is_empty():
		payload["country_code"] = country_code.to_upper()
	if not selected_robot_id.is_empty():
		payload["selected_robot_id"] = selected_robot_id
	return _authorized_request("/api/profile", HTTPClient.METHOD_PUT, JSON.stringify(payload), "profile_put")

func list_cloud_assets(kind: String = "") -> Error:
	if not kind.is_empty() and kind not in ["skin", "track"]:
		return ERR_INVALID_PARAMETER
	return _authorized_asset_request("/api/assets" + ("?kind=" + kind if not kind.is_empty() else ""), HTTPClient.METHOD_GET, PackedByteArray(), "list")

## Uploads a ZIP package belonging to the signed-in account. kind: skin or track.
func upload_cloud_asset(local_path: String, kind: String) -> Error:
	if kind not in ["skin", "track"] or token.is_empty():
		return ERR_INVALID_PARAMETER if kind not in ["skin", "track"] else ERR_UNAUTHORIZED
	var file := FileAccess.open(local_path, FileAccess.READ)
	if file == null:
		return ERR_FILE_NOT_FOUND
	var bytes := file.get_buffer(file.get_length())
	if bytes.size() < 4 or bytes.size() > 8 * 1024 * 1024:
		return ERR_INVALID_DATA
	var file_name := local_path.get_file().uri_encode()
	var headers := PackedStringArray(["Authorization: Bearer " + token, "Content-Type: application/zip", "X-File-Name: " + file_name])
	var err := _asset_request.request_raw(endpoint + "/api/assets?kind=" + kind, headers, HTTPClient.METHOD_POST, bytes)
	if err == OK:
		_asset_operation = "upload"
		status_changed.emit("Wysyłanie pliku do chmury…")
	return err

func download_cloud_asset(asset_id: String, destination_path: String) -> Error:
	if token.is_empty():
		return ERR_UNAUTHORIZED
	if not asset_id.is_valid_identifier() and not asset_id.is_valid_filename():
		return ERR_INVALID_PARAMETER
	_asset_target_path = destination_path
	var headers := PackedStringArray(["Authorization: Bearer " + token])
	var err := _asset_request.request(endpoint + "/api/assets/" + asset_id, headers, HTTPClient.METHOD_GET)
	if err == OK:
		_asset_operation = "download"
		status_changed.emit("Pobieranie pliku z chmury…")
	return err

func delete_cloud_asset(asset_id: String) -> Error:
	if token.is_empty():
		return ERR_UNAUTHORIZED
	var headers := PackedStringArray(["Authorization: Bearer " + token])
	var err := _asset_request.request(endpoint + "/api/assets/" + asset_id, headers, HTTPClient.METHOD_DELETE)
	if err == OK:
		_asset_operation = "delete"
	return err

func _authorized_request(path: String, method: int, payload: String, operation: String) -> Error:
	if token.is_empty():
		return ERR_UNAUTHORIZED
	var headers := PackedStringArray(["Authorization: Bearer " + token, "Content-Type: application/json"])
	var err := _request.request(endpoint + path, headers, method, payload)
	if err == OK:
		_operation = operation
	return err

func _authorized_asset_request(path: String, method: int, payload: PackedByteArray, operation: String) -> Error:
	if token.is_empty():
		return ERR_UNAUTHORIZED
	var headers := PackedStringArray(["Authorization: Bearer " + token])
	var err := _asset_request.request_raw(endpoint + path, headers, method, payload)
	if err == OK:
		_asset_operation = operation
	return err

func _on_asset_request_completed(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	var operation := _asset_operation
	_asset_operation = ""
	if result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300:
		var parsed_error: Variant = JSON.parse_string(body.get_string_from_utf8())
		var message := str(parsed_error.get("error", "HTTP_%d" % response_code)) if parsed_error is Dictionary else "HTTP_%d" % response_code
		asset_operation_failed.emit(message)
		status_changed.emit("Pliki chmurowe: " + message)
		return
	if operation == "download":
		var file := FileAccess.open(_asset_target_path, FileAccess.WRITE)
		if file == null:
			asset_operation_failed.emit("Nie można zapisać pobranego pliku.")
			return
		file.store_buffer(body)
		file.close()
		asset_operation_completed.emit(operation, {"path": _asset_target_path, "size_bytes": body.size()})
		status_changed.emit("Plik pobrany.")
		return
	var parsed: Variant = JSON.parse_string(body.get_string_from_utf8())
	if not parsed is Dictionary or not bool(parsed.get("ok", false)):
		asset_operation_failed.emit("Nieprawidłowa odpowiedź serwera.")
		return
	if operation == "list":
		assets_received.emit(parsed.get("assets", []))
	else:
		asset_operation_completed.emit(operation, parsed.get("asset", {}))
	status_changed.emit("Operacja na plikach zakończona.")

## Call only after showing the player both local and cloud details and receiving their explicit choice.
func apply_cloud_save_after_confirmation() -> bool:
	if not FileAccess.file_exists(CLOUD_IMPORT):
		return false
	if not SaveManager.import_progress(CLOUD_IMPORT):
		status_changed.emit("Import chmury nie powiódł się; kopia lokalna została zachowana.")
		return false
	_store_revision()
	status_changed.emit("Zastosowano wybrany zapis chmurowy.")
	return true

func _store_revision() -> void:
	var account_id := str(user.get("id", ""))
	if account_id.is_empty():
		return
	var revisions: Dictionary = SaveManager.get_dict("cloud_account", "revisions")
	revisions[account_id] = cloud_revision
	SaveManager.set_value("cloud_account", "revisions", revisions)
	SaveManager.set_value("cloud_account", "revision", cloud_revision)
	SaveManager.save_now()


func _clear_cloud_import() -> void:
	if FileAccess.file_exists(CLOUD_IMPORT):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(CLOUD_IMPORT))


func logout_account() -> void:
	var old_token := token
	if not old_token.is_empty():
		var headers := PackedStringArray(["Content-Type: application/json", "Authorization: Bearer " + old_token])
		var err := _request.request(endpoint + "/api/auth/logout", headers, HTTPClient.METHOD_POST, "{}")
		if err == OK:
			_operation = "logout"
	logout_local()


func logout_local() -> void:
	token = ""
	user.clear()
	cloud_revision = 0
	SaveManager.erase_key("cloud_account", "token")
	SaveManager.erase_key("cloud_account", "user")
	SaveManager.save_now()
	status_changed.emit("Wylogowano. Zapis lokalny nie został zmieniony.")


func _post(path: String, payload: Dictionary, operation: String) -> Error:
	var headers := PackedStringArray(["Content-Type: application/json"])
	var err := _request.request(endpoint + path, headers, HTTPClient.METHOD_POST, JSON.stringify(payload))
	if err == OK:
		_operation = operation
		status_changed.emit("Łączenie z kontem…")
	return err

func _on_request_completed(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	var parsed: Variant = JSON.parse_string(body.get_string_from_utf8())
	if result != HTTPRequest.RESULT_SUCCESS or not parsed is Dictionary:
		auth_failed.emit("Brak odpowiedzi serwera (HTTP %d)." % response_code)
		status_changed.emit("Błąd połączenia z chmurą.")
		return
	if response_code == 409 and str(parsed.get("error", "")) == "SAVE_CONFLICT":
		var cloud_save: Dictionary = parsed.get("cloud_save", {}) if parsed.get("cloud_save", {}) is Dictionary else {}
		var payload := str(cloud_save.get("payload", ""))
		if not cloud_save.is_empty():
			cloud_revision = int(cloud_save.get("revision", cloud_revision))
			_store_revision()
		if not payload.is_empty():
			var f := FileAccess.open(CLOUD_IMPORT, FileAccess.WRITE)
			if f != null:
				f.store_string(payload)
				f.close()
		else:
			_clear_cloud_import()
		save_conflict.emit(Time.get_datetime_string_from_system(), cloud_save)
		status_changed.emit("Wykryto dwa różne zapisy. Wybór należy do gracza; niczego nie nadpisano.")
		return
	if response_code < 200 or response_code >= 300 or not bool(parsed.get("ok", false)):
		var message := str(parsed.get("error", "HTTP_%d" % response_code))
		if _operation in ["register", "login", "google"]:
			auth_failed.emit(message)
		status_changed.emit("Chmura: " + message)
		return
	match _operation:
		"register", "login", "google":
			token = str(parsed.get("token", ""))
			user = parsed.get("user", {}) if parsed.get("user", {}) is Dictionary else {}
			SaveManager.set_value("cloud_account", "token", token)
			SaveManager.set_value("cloud_account", "user", user)
			var revisions: Dictionary = SaveManager.get_dict("cloud_account", "revisions")
			cloud_revision = int(revisions.get(str(user.get("id", "")), 0))
			_store_revision()
			SaveManager.save_now()
			authenticated.emit(user.duplicate(true))
			status_changed.emit("Zalogowano do konta CrunpBot.")
		"upload":
			cloud_revision = int(parsed.get("revision", cloud_revision))
			_store_revision()
			SaveManager.save_now()
			sync_completed.emit(cloud_revision)
			status_changed.emit("Postęp zapisany w chmurze (wersja %d)." % cloud_revision)
		"profile_get":
			var profile: Dictionary = parsed.get("profile", {}) if parsed.get("profile", {}) is Dictionary else {}
			profile_received.emit(profile.duplicate(true))
		"profile_put":
			var updated_profile: Dictionary = parsed.get("profile", {}) if parsed.get("profile", {}) is Dictionary else {}
			profile_updated.emit(updated_profile.duplicate(true))
		"download":
			var save_data: Dictionary = parsed.get("save", {}) if parsed.get("save", {}) is Dictionary else {}
			cloud_save_received.emit(save_data.duplicate(true))
			if save_data.is_empty():
				_clear_cloud_import()
				status_changed.emit("Konto nie ma jeszcze zapisu chmurowego.")
			else:
				var f := FileAccess.open(CLOUD_IMPORT, FileAccess.WRITE)
				if f != null:
					f.store_string(str(save_data.get("payload", "")))
					f.close()
				cloud_revision = int(save_data.get("revision", 0))
				_store_revision()
				status_changed.emit("Zapis chmurowy pobrany. Przed zastosowaniem porównaj oba zapisy.")
