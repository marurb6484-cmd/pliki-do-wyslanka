extends Node

const TrackGeneratorScript = preload("res://scripts/tracks/TrackGenerator.gd")
## Sesja gry: wybrany tryb, trasa, trudność i przejścia między scenami.
##
## Postęp/ekonomia -> PlayerProgress, ustawienia -> GameSettings,
## zapis -> SaveManager. GameManager przechowuje tylko konfigurację bieżącego
## wyścigu oraz jego wyniki (dla ekranu wyników i ponowienia próby).

signal race_config_changed

enum GameMode { RACE, TIME_TRIAL, GRAPHICS_TEST, LOCAL_MULTIPLAYER }

const MODE_IDS: Array[String] = ["race", "time_trial", "graphics_test", "local_multiplayer"]
const MODE_NAMES: Array[String] = ["WYŚCIG", "JAZDA NA CZAS", "TEST GRAFIKI", "LOKALNY MULTIPLAYER"]

const SCENE_MAIN_MENU: String = "res://scenes/MainMenu.tscn"
const SCENE_INTERFACE_SELECT: String = "res://scenes/InterfaceModeSelect.tscn"
const SCENE_ONLINE_MULTIPLAYER: String = "res://scenes/OnlineMultiplayer.tscn"
const SCENE_MODE_SELECT: String = "res://scenes/ModeSelect.tscn"
const SCENE_SINGLE_PLAYER: String = "res://scenes/SinglePlayerSelect.tscn"
const SCENE_TRACK_SELECT: String = "res://scenes/TrackSelect.tscn"
const SCENE_GARAGE: String = "res://scenes/Garage.tscn"
const SCENE_SETTINGS: String = "res://scenes/Settings.tscn"
const SCENE_HUD_EDITOR: String = "res://scenes/HUDEditor.tscn"
const SCENE_BOOST_WORKSHOP: String = "res://scenes/BoostWorkshop.tscn"
const SCENE_TRACK_GENERATOR: String = "res://scenes/TrackGenerator.tscn"
const SCENE_FEATURE_HUB: String = "res://scenes/FeatureHub.tscn"
const SCENE_RACE: String = "res://scenes/race/RaceScene.tscn"

# ---------------------------------------------------------
# Konfiguracja bieżącego wyścigu
# ---------------------------------------------------------
var mode: int = GameMode.RACE
var track_index: int = 0
var total_laps: int = 3
var difficulty: int = AIDifficulty.Level.NORMAL
var opponent_count: int = 4
var ghost_enabled: bool = true

## Konfiguracja bieżącego wydarzenia kampanii.
var career_active: bool = false
var career_event_id: String = ""
var career_time_of_day: String = "day"
var career_result_event_index: int = -1
var career_result_advanced: bool = false

## Konfiguracja robota gracza nadpisana na czas sesji (tryb testu grafiki).
var player_config_override: Dictionary = {}
## Trasa wygenerowana lub zapisana lokalnie; pusta oznacza trasę z katalogu.
var generated_track_data: Dictionary = {}

# ---------------------------------------------------------
# Stan wyścigu (do odczytu przez inne systemy)
# ---------------------------------------------------------
var is_racing: bool = false
var race_finished: bool = false
var race_time: float = 0.0
var race_results: Array = []
var last_rewards: Dictionary = {}

## Scena, do której wraca przycisk "Wstecz" w ustawieniach / edytorze HUD.
var return_scene: String = SCENE_MAIN_MENU
var hub_page: String = "career"

## Dane bieżącego wyścigu online; transport pozostaje aktywny między scenami lobby i wyścigu.
var online_race_active: bool = false
var online_start_at_ms: int = 0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_register_input_actions()

	track_index = TrackDatabase.find_index(PlayerProgress.selected_track_id)
	total_laps = PlayerProgress.last_laps
	difficulty = PlayerProgress.last_difficulty
	opponent_count = PlayerProgress.last_opponents
	ghost_enabled = PlayerProgress.ghost_enabled

	# Przycisk "wstecz" na Androidzie nie zamyka gry od razu - obsługują go sceny.
	get_tree().set_quit_on_go_back(false)


func _exit_tree() -> void:
	RobotVisuals.clear_shared_cache()


## Akcje klawiatury (do testów na PC). Sterowanie dotykowe działa niezależnie.
func _register_input_actions() -> void:
	var actions: Dictionary = {
		"accelerate": [KEY_W, KEY_UP],
		"brake": [KEY_S, KEY_DOWN],
		"steer_left": [KEY_A, KEY_LEFT],
		"steer_right": [KEY_D, KEY_RIGHT],
		"boost": [KEY_SPACE, KEY_SHIFT],
		"boost_next": [KEY_TAB],
		"pause": [KEY_ESCAPE, KEY_P],
		"drift": [KEY_CTRL]
	}
	for action: String in actions.keys():
		if not InputMap.has_action(action):
			InputMap.add_action(action, 0.2)
		for keycode: int in actions[action]:
			var event := InputEventKey.new()
			event.physical_keycode = keycode as Key
			InputMap.action_add_event(action, event)

	var pad_events: Dictionary = {
		"accelerate": JOY_BUTTON_A,
		"brake": JOY_BUTTON_B,
		"boost": JOY_BUTTON_X,
		"boost_next": JOY_BUTTON_Y,
		"pause": JOY_BUTTON_START
	}
	for action: String in pad_events.keys():
		var pad_event := InputEventJoypadButton.new()
		pad_event.button_index = pad_events[action] as JoyButton
		InputMap.action_add_event(action, pad_event)


# =========================================================
# KONFIGURACJA
# =========================================================

func get_mode_id() -> String:
	return MODE_IDS[clampi(mode, 0, MODE_IDS.size() - 1)]


## Zwraca seed, który nigdy wcześniej nie był użyty przez automatyczne losowanie tras.
## Historia jest zapisywana trwale, więc nie resetuje się po zamknięciu gry.
func get_unique_random_track_seed() -> int:
	var used_seeds: Array = SaveManager.get_array("random_routes", "used_track_seeds")
	var used_lookup: Dictionary = {}
	for value: Variant in used_seeds:
		used_lookup[int(value)] = true
	# Zachowaj również seed ostatniej trasy z wcześniejszej wersji gry.
	var legacy_seed: int = SaveManager.get_int("random_routes", "last_time_trial_seed", 0)
	if legacy_seed > 0:
		used_lookup[legacy_seed] = true
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	var candidate: int = rng.randi_range(10000, 2147483000)
	while used_lookup.has(candidate):
		candidate = rng.randi_range(10000, 2147483000)
	used_seeds.append(candidate)
	SaveManager.set_value("random_routes", "used_track_seeds", used_seeds)
	SaveManager.save_now()
	return candidate


## Ponowienie losowej próby tworzy nowy układ, zamiast odtwarzać poprzedni.
## Trasy ręcznie zapisane lub utworzone w generatorze pozostają bez zmian.
func reroll_random_route_for_retry() -> void:
	if generated_track_data.is_empty() or not bool(generated_track_data.get("random_route_session", false)):
		return
	var previous: Dictionary = generated_track_data.duplicate(true)
	var was_career: bool = career_active
	var saved_career_event_id: String = career_event_id
	var saved_career_time: String = career_time_of_day
	var new_seed: int = get_unique_random_track_seed()
	var new_style: int = get_unique_random_track_style(int(previous.get("complexity", 2)))
	var generated: Dictionary = TrackGeneratorScript.generate(
		new_seed,
		int(previous.get("size_level", 2)),
		int(previous.get("complexity", 2)),
		int(previous.get("obstacle_density", 1)),
		str(previous.get("theme", "apartment")),
		str(previous.get("display_name", previous.get("name", "LOSOWA TRASA"))),
		int(previous.get("animal_count", 3)),
		int(previous.get("furniture_density", 2)),
		int(previous.get("obstacle_layout", 0)),
		str(previous.get("route_type", "lap")),
		new_style
	)
	generated["random_route_session"] = true
	generated["career_event_id"] = saved_career_event_id if was_career else ""
	if mode == GameMode.TIME_TRIAL:
		configure_generated_time_trial(generated, ghost_enabled, opponent_count, difficulty)
	else:
		configure_generated_race(generated, total_laps, difficulty, opponent_count)
	if was_career:
		career_active = true
		career_event_id = saved_career_event_id
		career_time_of_day = saved_career_time


## Wybiera archetyp, którego nie użyto w trzech ostatnich losowaniach.
## Dzięki temu kolejne trzy losowania mają różne, wyraźnie odmienne obrysy.
func get_unique_random_track_style(complexity: int = 2) -> int:
	var recent: Array = SaveManager.get_array("random_routes", "recent_track_styles")
	var available: Array[int] = []
	var style_start: int = 10 if complexity >= 5 else 0
	var style_end: int = 15 if complexity >= 5 else 10
	for style_index: int in range(style_start, style_end):
		if not recent.has(style_index):
			available.append(style_index)
	if available.is_empty():
		for style_index: int in range(style_start, style_end):
			available.append(style_index)
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	var selected: int = available[rng.randi_range(0, available.size() - 1)]
	recent.append(selected)
	while recent.size() > 3:
		recent.pop_front()
	SaveManager.set_value("random_routes", "recent_track_styles", recent)
	SaveManager.save_now()
	return selected


func get_track_data() -> Dictionary:
	if not generated_track_data.is_empty():
		return generated_track_data.duplicate(true)
	return TrackDatabase.get_track(track_index)


func get_track_id() -> String:
	return str(get_track_data()["id"])


func is_graphics_test() -> bool:
	return mode == GameMode.GRAPHICS_TEST


func configure_race(new_mode: int, new_track_index: int, laps: int, new_difficulty: int, opponents: int, ghost: bool) -> void:
	career_active = false
	career_event_id = ""
	generated_track_data.clear()
	mode = new_mode
	track_index = clampi(new_track_index, 0, TrackDatabase.count() - 1)
	total_laps = clampi(laps, 1, 10)
	difficulty = clampi(new_difficulty, 0, 3)
	opponent_count = clampi(opponents, 1, 4)
	ghost_enabled = ghost
	player_config_override.clear()

	# Test grafiki nie zmienia preferencji kariery.
	if mode != GameMode.GRAPHICS_TEST:
		PlayerProgress.set_race_preferences(get_track_id(), difficulty, total_laps, opponent_count, ghost_enabled)

	race_config_changed.emit()


func configure_online_race(start_at_ms: int, ai_count: int = 0) -> void:
	# MVP online używa wspólnej, pierwszej trasy i 3 okrążeń.
	# Wybór trasy/okrążeń zostanie zsynchronizowany w kolejnym etapie.
	generated_track_data.clear()
	mode = GameMode.RACE
	track_index = 0
	total_laps = 3
	difficulty = AIDifficulty.Level.NORMAL
	opponent_count = clampi(ai_count, 0, 3)
	ghost_enabled = false
	player_config_override.clear()
	online_race_active = true
	online_start_at_ms = start_at_ms
	race_config_changed.emit()


func clear_online_race() -> void:
	online_race_active = false
	online_start_at_ms = 0


func configure_local_multiplayer(track_idx: int, laps: int) -> void:
	career_active = false
	career_event_id = ""
	generated_track_data.clear()
	mode = GameMode.LOCAL_MULTIPLAYER
	track_index = clampi(track_idx, 0, TrackDatabase.count() - 1)
	total_laps = clampi(laps, 1, 10)
	difficulty = AIDifficulty.Level.NORMAL
	opponent_count = 0
	ghost_enabled = false
	player_config_override.clear()
	race_config_changed.emit()


func configure_generated_race(track_data: Dictionary, laps: int, new_difficulty: int = AIDifficulty.Level.NORMAL, opponents: int = 4) -> void:
	career_active = false
	career_event_id = ""
	generated_track_data = track_data.duplicate(true)
	mode = GameMode.RACE
	track_index = 0
	total_laps = clampi(laps, 1, 10)
	difficulty = clampi(new_difficulty, 0, 3)
	opponent_count = clampi(opponents, 1, 4)
	ghost_enabled = false
	player_config_override.clear()
	race_config_changed.emit()


## Konfiguruje świeżo wylosowany, otwarty odcinek do jazdy na czas (bez okrążeń).
func configure_generated_time_trial(track_data: Dictionary, ghost: bool = true, opponents: int = 0, new_difficulty: int = AIDifficulty.Level.NORMAL) -> void:
	career_active = false
	career_event_id = ""
	generated_track_data = track_data.duplicate(true)
	mode = GameMode.TIME_TRIAL
	track_index = 0
	total_laps = 1
	difficulty = clampi(new_difficulty, 0, 3)
	opponent_count = clampi(opponents, 0, 4)
	ghost_enabled = ghost
	player_config_override.clear()
	race_config_changed.emit()




## Uruchamia aktualne wydarzenie kampanii na deterministycznie generowanej trasie.
func launch_career_event() -> bool:
	var event: Dictionary = PlayerProgress.get_career_event()
	if event.is_empty():
		return false
	var event_index: int = PlayerProgress.get_career_event_index()
	var event_id: String = str(event.get("id", "career_event"))
	var seed_value: int = get_unique_random_track_seed()
	var route_style: int = get_unique_random_track_style(int(event.get("complexity", 2)))
	var generated: Dictionary = TrackGeneratorScript.generate(
		seed_value,
		int(event.get("size", 1)),
		int(event.get("complexity", 2)),
		int(event.get("obstacles", 1)),
		str(event.get("theme", "apartment")),
		str(event.get("location", "WYDARZENIE KARIERY")),
		3,
		int(event.get("furniture", 1)),
		1,
		str(event.get("route_type", "lap")),
		route_style
	)
	generated["random_route_session"] = true
	generated["id"] = event_id
	generated["track_id"] = event_id
	generated["name"] = str(event.get("title", "WYDARZENIE KARIERY"))
	generated["display_name"] = str(event.get("title", "WYDARZENIE KARIERY"))
	generated["description"] = str(event.get("goal", ""))
	generated["scene"] = TrackGeneratorScript.PROCEDURAL_SCENE
	generated["generated"] = true
	generated["time_of_day"] = str(event.get("time_of_day", "day"))
	generated["career_event_id"] = event_id
	generated["career_location"] = str(event.get("location", ""))
	generated_track_data = generated
	mode = GameMode.RACE
	track_index = 0
	total_laps = 1 if not bool(generated.get("route_closed", true)) else clampi(int(event.get("laps", 3)), 1, 10)
	difficulty = clampi(int(event.get("difficulty", 1)), 0, 3)
	opponent_count = clampi(int(event.get("opponents", 4)), 1, 4)
	ghost_enabled = false
	player_config_override.clear()
	career_active = true
	career_event_id = event_id
	career_result_event_index = -1
	career_result_advanced = false
	career_time_of_day = str(event.get("time_of_day", "day"))
	race_config_changed.emit()
	launch_race()
	return true

## Tryb TESTUJ GRAFIKĘ: losowa trasa, losowy robot i skórka, bez nagród.
func configure_graphics_test() -> void:
	career_active = false
	career_event_id = ""
	generated_track_data.clear()
	mode = GameMode.GRAPHICS_TEST
	track_index = randi() % TrackDatabase.count()
	total_laps = 0          # 0 = jazda bez końca, test kończy gracz
	difficulty = AIDifficulty.Level.NORMAL
	opponent_count = 4
	ghost_enabled = false

	var robot_index: int = randi() % RobotDatabase.count()
	player_config_override = RobotDatabase.build_config(
		robot_index,
		RobotDatabase.empty_upgrades(),
		randi() % RobotDatabase.SKINS.size(),
		randi() % RobotDatabase.NEON_COLORS.size()
	)
	race_config_changed.emit()


func get_player_config() -> Dictionary:
	if not player_config_override.is_empty():
		return player_config_override.duplicate()
	return PlayerProgress.get_player_robot_config()


# =========================================================
# STAN WYŚCIGU
# =========================================================

func start_race() -> void:
	is_racing = false
	race_finished = false
	race_time = 0.0
	race_results.clear()
	last_rewards.clear()


func finish_race() -> void:
	is_racing = false
	race_finished = true


# =========================================================
# PRZEJŚCIA MIĘDZY SCENAMI
# =========================================================

func change_scene(path: String) -> void:
	get_tree().paused = false
	var error: Error = get_tree().change_scene_to_file(path)
	if error != OK:
		push_error("GameManager: nie można wczytać sceny %s (kod %d)." % [path, error])


func launch_race() -> void:
	start_race()
	change_scene(SCENE_RACE)


## Pierwsza konfiguracja grafiki: uruchamia testowy wyścig z kreatorem jakości.
func launch_first_run_graphics_wizard() -> void:
	return_scene = SCENE_MAIN_MENU
	GameSettings.graphics_wizard_active = true
	configure_graphics_test()
	launch_race()


## Uruchamia test grafiki z menu Ustawienia i zapamiętuje miejsce powrotu.
func launch_graphics_test_from_settings() -> void:
	return_scene = SCENE_SETTINGS
	configure_graphics_test()
	launch_race()


func go_to_main_menu() -> void:
	change_scene(SCENE_MAIN_MENU)


func open_hub(page: String) -> void:
	hub_page = page
	change_scene(SCENE_BOOST_WORKSHOP if page == "boosts" else SCENE_FEATURE_HUB)


func open_settings(from_scene: String) -> void:
	return_scene = from_scene
	change_scene(SCENE_SETTINGS)


func open_hud_editor(from_scene: String) -> void:
	return_scene = from_scene
	change_scene(SCENE_HUD_EDITOR)


func go_back() -> void:
	var target: String = return_scene
	return_scene = SCENE_MAIN_MENU
	change_scene(target)


static func format_time(value: float) -> String:
	if value < 0.0:
		return "--:--.---"
	var total_ms: int = int(round(value * 1000.0))
	var minutes: int = total_ms / 60000
	var seconds: int = (total_ms / 1000) % 60
	var millis: int = total_ms % 1000
	return "%02d:%02d.%03d" % [minutes, seconds, millis]
