extends Node
## Ustawienia gry: grafika, sterowanie, dźwięk, układ HUD.
##
## Ustawienia graficzne są faktycznie stosowane:
##  - globalnie (limit FPS, skala renderowania, MSAA/FXAA, rozdzielczość cieni),
##  - w scenie (światło, środowisko, neony, reflektory, cząsteczki) - obiekty
##    sceny nasłuchują sygnału `graphics_changed` i same się przestawiają.

signal graphics_changed
signal controls_changed
signal audio_changed
signal hud_layout_changed

enum Quality { VERY_LOW, LOW, MEDIUM, HIGH, ULTRA }
enum ControlMode { JOYSTICK, BUTTONS, GYRO }

const QUALITY_NAMES: Array[String] = ["BARDZO NISKA", "NISKA", "ŚREDNIA", "WYSOKA", "ULTRA"]
const CONTROL_NAMES: Array[String] = ["JOYSTICK", "PRZYCISKI", "ŻYROSKOP"]
const FPS_OPTIONS: Array[int] = [30, 45, 60, 90, 0]

# ---------------------------------------------------------
# Grafika
# ---------------------------------------------------------
var quality: int = Quality.MEDIUM
var graphics_quality_chosen: bool = false
var graphics_wizard_active: bool = false
var dynamic_resolution_enabled: bool = true
## Ręczna skala renderowania 3D; 100% = natywna, >100% = supersampling.
var render_scale_percent: float = 100.0
var _dynamic_resolution_timer: float = 0.0
var _dynamic_render_scale: float = 0.0
var open_content_tab_requested: bool = false
var shadows_enabled: bool = true
var neon_enabled: bool = true
var headlights_enabled: bool = true
var reflections_enabled: bool = false
var effects_enabled: bool = true
var glow_enabled: bool = true
var ssao_enabled: bool = true
var ssil_enabled: bool = false
var ssr_enabled: bool = true
var sdfgi_enabled: bool = false
var volumetric_fog_enabled: bool = false
var depth_fog_enabled: bool = false
var taa_enabled: bool = false
var debanding_enabled: bool = true
var roughness_limiter_enabled: bool = true
var fps_limit: int = 60
var show_fps: bool = false
## Skórka wyglądu obiektów toru (patrz scripts/visual/ObjectSkins.gd).
var object_skin: String = "cartoon"

# ---------------------------------------------------------
# Sterowanie
# ---------------------------------------------------------
var control_mode: int = ControlMode.JOYSTICK
var steering_sensitivity: float = 1.0
var gyro_invert: bool = false
var gyro_neutral: float = 0.0
var gyro_max_tilt: float = 25.0
var haptics_enabled: bool = true

# ---------------------------------------------------------
# Dźwięk
# ---------------------------------------------------------
var master_volume: float = 1.0
var sfx_volume: float = 1.0
var engine_volume: float = 0.8
var ui_volume: float = 0.8

# ---------------------------------------------------------
# HUD: układy zapisywane osobno dla różnych proporcji ekranu
# { "16:9": { "module_id": {"x":0.1, "y":0.1, "scale":1.0, "visible":true} } }
# ---------------------------------------------------------
var hud_layouts: Dictionary = {}
var hud_opacity: float = 1.0

# Styl rozgrywki: prosty automatyzuje konfigurację, zaawansowany odsłania pełną kontrolę.
var play_style: String = "simple"
var play_style_chosen: bool = false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_load()
	# Ustawienia viewportu stosujemy po pełnej inicjalizacji drzewa.
	call_deferred("apply_global_graphics")


# =========================================================
# ODCZYT / ZAPIS
# =========================================================

func _load() -> void:
	# Sekcja "graphics" i nazwy kluczy są zgodne ze starym zapisem GameManager,
	# więc wcześniejsze ustawienia gracza zostają zachowane.
	# Migracja starych zapisów: dawniej LOW..ULTRA miały indeksy 0..3.
	var saved_quality: int = SaveManager.get_int("graphics", "quality", 1, 0, 4)
	var quality_schema: int = SaveManager.get_int("graphics", "quality_schema", 1, 1, 2)
	quality = clampi(saved_quality + 1, Quality.LOW, Quality.ULTRA) if quality_schema == 1 else clampi(saved_quality, 0, 4)
	SaveManager.set_value("graphics", "quality", quality)
	SaveManager.set_value("graphics", "quality_schema", 2)
	dynamic_resolution_enabled = SaveManager.get_bool("graphics", "dynamic_resolution", true)
	var default_scale: float = [45.0, 65.0, 82.0, 100.0, 100.0][quality]
	render_scale_percent = SaveManager.get_float("graphics", "render_scale_percent", default_scale, 35.0, 150.0)
	graphics_quality_chosen = SaveManager.get_bool("graphics", "quality_prompt_seen", false)
	shadows_enabled = SaveManager.get_bool("graphics", "shadows", true)
	neon_enabled = SaveManager.get_bool("graphics", "neons", true)
	headlights_enabled = SaveManager.get_bool("graphics", "headlights", true)
	reflections_enabled = SaveManager.get_bool("graphics", "reflections", false)
	effects_enabled = SaveManager.get_bool("graphics", "effects", true)
	glow_enabled = SaveManager.get_bool("graphics", "fx_glow", true)
	ssao_enabled = SaveManager.get_bool("graphics", "fx_ssao", true)
	ssil_enabled = SaveManager.get_bool("graphics", "fx_ssil", false)
	ssr_enabled = SaveManager.get_bool("graphics", "fx_ssr", true)
	sdfgi_enabled = SaveManager.get_bool("graphics", "fx_sdfgi", false)
	volumetric_fog_enabled = SaveManager.get_bool("graphics", "fx_volumetric_fog", false)
	depth_fog_enabled = SaveManager.get_bool("graphics", "fx_depth_fog", false)
	taa_enabled = SaveManager.get_bool("graphics", "fx_taa", false)
	debanding_enabled = SaveManager.get_bool("graphics", "fx_debanding", true)
	roughness_limiter_enabled = SaveManager.get_bool("graphics", "fx_roughness_limiter", true)
	show_fps = SaveManager.get_bool("graphics", "show_fps", false)
	object_skin = ObjectSkins.normalize(str(SaveManager.get_value("graphics", "object_skin", "cartoon")))

	var saved_fps: int = SaveManager.get_int("graphics", "fps_limit", 60)
	fps_limit = saved_fps if FPS_OPTIONS.has(saved_fps) else (0 if saved_fps > 90 else 60)

	control_mode = SaveManager.get_int("controls", "mode", ControlMode.JOYSTICK, 0, 2)
	steering_sensitivity = SaveManager.get_float("controls", "sensitivity", 1.0, 0.4, 2.0)
	gyro_invert = SaveManager.get_bool("controls", "gyro_invert", false)
	gyro_neutral = SaveManager.get_float("controls", "gyro_neutral", 0.0, -1.0, 1.0)
	gyro_max_tilt = SaveManager.get_float("controls", "gyro_max_tilt", 25.0, 10.0, 45.0)
	haptics_enabled = SaveManager.get_bool("controls", "haptics", true)

	master_volume = SaveManager.get_float("audio", "master", 1.0, 0.0, 1.0)
	sfx_volume = SaveManager.get_float("audio", "sfx", 1.0, 0.0, 1.0)
	engine_volume = SaveManager.get_float("audio", "engine", 0.8, 0.0, 1.0)
	ui_volume = SaveManager.get_float("audio", "ui", 0.8, 0.0, 1.0)

	hud_layouts = SaveManager.get_dict("hud", "layouts")
	hud_opacity = SaveManager.get_float("hud", "opacity", 1.0, 0.3, 1.0)
	play_style = str(SaveManager.get_value("gameplay", "play_style", "simple"))
	if not ["simple", "advanced"].has(play_style):
		play_style = "simple"
	play_style_chosen = SaveManager.get_bool("gameplay", "play_style_chosen", false)


func _save_graphics() -> void:
	SaveManager.set_value("graphics", "quality", quality)
	SaveManager.set_value("graphics", "quality_schema", 2)
	SaveManager.set_value("graphics", "dynamic_resolution", dynamic_resolution_enabled)
	SaveManager.set_value("graphics", "render_scale_percent", render_scale_percent)
	SaveManager.set_value("graphics", "shadows", shadows_enabled)
	SaveManager.set_value("graphics", "neons", neon_enabled)
	SaveManager.set_value("graphics", "headlights", headlights_enabled)
	SaveManager.set_value("graphics", "reflections", reflections_enabled)
	SaveManager.set_value("graphics", "effects", effects_enabled)
	SaveManager.set_value("graphics", "fx_glow", glow_enabled)
	SaveManager.set_value("graphics", "fx_ssao", ssao_enabled)
	SaveManager.set_value("graphics", "fx_ssil", ssil_enabled)
	SaveManager.set_value("graphics", "fx_ssr", ssr_enabled)
	SaveManager.set_value("graphics", "fx_sdfgi", sdfgi_enabled)
	SaveManager.set_value("graphics", "fx_volumetric_fog", volumetric_fog_enabled)
	SaveManager.set_value("graphics", "fx_depth_fog", depth_fog_enabled)
	SaveManager.set_value("graphics", "fx_taa", taa_enabled)
	SaveManager.set_value("graphics", "fx_debanding", debanding_enabled)
	SaveManager.set_value("graphics", "fx_roughness_limiter", roughness_limiter_enabled)
	SaveManager.set_value("graphics", "fps_limit", fps_limit)
	SaveManager.set_value("graphics", "show_fps", show_fps)
	SaveManager.set_value("graphics", "object_skin", object_skin)


func _save_controls() -> void:
	SaveManager.set_value("controls", "mode", control_mode)
	SaveManager.set_value("controls", "sensitivity", steering_sensitivity)
	SaveManager.set_value("controls", "gyro_invert", gyro_invert)
	SaveManager.set_value("controls", "gyro_neutral", gyro_neutral)
	SaveManager.set_value("controls", "gyro_max_tilt", gyro_max_tilt)
	SaveManager.set_value("controls", "haptics", haptics_enabled)


func _save_audio() -> void:
	SaveManager.set_value("audio", "master", master_volume)
	SaveManager.set_value("audio", "sfx", sfx_volume)
	SaveManager.set_value("audio", "engine", engine_volume)
	SaveManager.set_value("audio", "ui", ui_volume)


# =========================================================
# GRAFIKA - SETTERY
# =========================================================

## Ustawia poziom jakości i przestawia przełączniki na wartości domyślne
## dla tego poziomu. Gracz może je potem zmienić ręcznie.
func set_quality_preset(value: int, mark_chosen: bool = true) -> void:
	quality = clampi(value, 0, 4)
	render_scale_percent = [45.0, 65.0, 82.0, 100.0, 100.0][quality]
	_dynamic_render_scale = render_scale_percent / 100.0
	if mark_chosen:
		confirm_graphics_quality()

	match quality:
		Quality.VERY_LOW:
			shadows_enabled = false
			reflections_enabled = false
			effects_enabled = false
			neon_enabled = false
			headlights_enabled = false
			glow_enabled = false
			ssao_enabled = false
			ssil_enabled = false
			ssr_enabled = false
			sdfgi_enabled = false
			volumetric_fog_enabled = false
			depth_fog_enabled = false
			taa_enabled = false
		Quality.LOW:
			shadows_enabled = false
			reflections_enabled = false
			effects_enabled = true
			neon_enabled = true
			headlights_enabled = true
		Quality.MEDIUM:
			shadows_enabled = true
			reflections_enabled = false
			effects_enabled = true
			neon_enabled = true
			headlights_enabled = true
		Quality.HIGH:
			shadows_enabled = true
			reflections_enabled = true
			effects_enabled = true
			neon_enabled = true
			headlights_enabled = true
		Quality.ULTRA:
			# ULTRA przywraca pełną jakość obrazu i natywną skalę renderowania 3D.
			shadows_enabled = true
			reflections_enabled = true
			effects_enabled = true
			neon_enabled = true
			headlights_enabled = true
			glow_enabled = true
			ssao_enabled = true
			ssil_enabled = true
			ssr_enabled = true
			sdfgi_enabled = true
			volumetric_fog_enabled = true
			depth_fog_enabled = true
			taa_enabled = true
			debanding_enabled = true
			roughness_limiter_enabled = true
			dynamic_resolution_enabled = false
			_dynamic_render_scale = 1.0

	_graphics_updated()


## Zatwierdza jakość po zakończeniu pierwszej konfiguracji lub testu.
func confirm_graphics_quality() -> void:
	graphics_quality_chosen = true
	SaveManager.set_value("graphics", "quality_prompt_seen", true)
	SaveManager.set_value("graphics", "quality", quality)
	SaveManager.set_value("graphics", "quality_schema", 2)


func set_shadows_enabled(value: bool) -> void:
	shadows_enabled = value
	_graphics_updated()


func set_neon_enabled(value: bool) -> void:
	neon_enabled = value
	_graphics_updated()


func set_headlights_enabled(value: bool) -> void:
	headlights_enabled = value
	_graphics_updated()


func set_reflections_enabled(value: bool) -> void:
	reflections_enabled = value
	_graphics_updated()


func set_effects_enabled(value: bool) -> void:
	effects_enabled = value
	_graphics_updated()


func set_fps_limit(value: int) -> void:
	if not FPS_OPTIONS.has(value):
		return
	fps_limit = value
	_graphics_updated()


func set_object_skin(value: String) -> void:
	var normalized: String = ObjectSkins.normalize(value)
	if normalized == object_skin:
		return
	object_skin = normalized
	_save_graphics()
	graphics_changed.emit()


func set_show_fps(value: bool) -> void:
	show_fps = value
	_graphics_updated()


func _graphics_updated() -> void:
	apply_global_graphics()
	_save_graphics()
	graphics_changed.emit()


# =========================================================
# GRAFIKA - WARTOŚCI POCHODNE (używane przez obiekty sceny)
# =========================================================

## Nazwa aktualnego renderera: "forward_plus", "mobile" lub "gl_compatibility".
func get_renderer() -> String:
	return str(RenderingServer.get_current_rendering_method())


func is_forward_plus() -> bool:
	return get_renderer() == "forward_plus"


func is_compatibility() -> bool:
	return get_renderer() == "gl_compatibility"


func is_mobile_renderer() -> bool:
	return get_renderer() == "mobile"


## Identyfikacja rodziny GPU służy diagnostyce i doborowi ostrożnych presetów.
## Nie jest dowodem obsługi konkretnego efektu — o tym decyduje renderer Godota.
func get_gpu_family() -> String:
	var adapter: String = (RenderingServer.get_video_adapter_name() + " " + RenderingServer.get_video_adapter_vendor()).to_lower()
	if "adreno" in adapter or "qualcomm" in adapter:
		return "Qualcomm Adreno"
	if "mali" in adapter or "arm" in adapter:
		return "ARM Mali"
	if "xclipse" in adapter or "samsung" in adapter:
		return "Samsung Xclipse / Exynos"
	if "powervr" in adapter or "imagination" in adapter:
		return "PowerVR"
	if "apple" in adapter:
		return "Apple GPU"
	if adapter.strip_edges().is_empty():
		return "Nieznany układ graficzny"
	return RenderingServer.get_video_adapter_name()


func get_gpu_adapter_name() -> String:
	var adapter_name: String = RenderingServer.get_video_adapter_name().strip_edges()
	return adapter_name if not adapter_name.is_empty() else "Brak danych sterownika"


func get_render_scale() -> float:
	return clampf(render_scale_percent / 100.0, 0.35, 1.5)


func set_render_scale_percent(value: float) -> void:
	render_scale_percent = clampf(roundf(value / 5.0) * 5.0, 35.0, 150.0)
	_dynamic_render_scale = get_render_scale()
	_save_graphics()
	apply_global_graphics()
	graphics_changed.emit()


func set_dynamic_resolution_enabled(value: bool) -> void:
	dynamic_resolution_enabled = value
	_dynamic_render_scale = 0.0
	_save_graphics()
	apply_global_graphics()
	graphics_changed.emit()


func _process(delta: float) -> void:
	if not dynamic_resolution_enabled:
		return
	_dynamic_resolution_timer += delta
	if _dynamic_resolution_timer < 1.0:
		return
	_dynamic_resolution_timer = 0.0
	var target_fps: float = 30.0 if fps_limit == 30 else 45.0 if fps_limit == 45 else 55.0
	var current_fps: float = float(Engine.get_frames_per_second())
	var upper: float = get_render_scale()
	var lower: float = minf(0.35, upper)
	if _dynamic_render_scale <= 0.0:
		_dynamic_render_scale = upper
	var next_scale: float = _dynamic_render_scale
	if current_fps < target_fps - 3.0:
		next_scale = maxf(lower, _dynamic_render_scale - 0.05)
	elif current_fps > target_fps + 8.0:
		next_scale = minf(upper, _dynamic_render_scale + 0.025)
	if not is_equal_approx(next_scale, _dynamic_render_scale):
		_dynamic_render_scale = next_scale
		var viewport: Viewport = get_viewport()
		if viewport != null:
			viewport.scaling_3d_scale = _dynamic_render_scale


func get_shadow_atlas_size() -> int:
	match quality:
		Quality.VERY_LOW:
			return 512
		Quality.LOW:
			return 512
		Quality.MEDIUM:
			return 2048
	return 4096


func get_shadow_distance() -> float:
	match quality:
		Quality.VERY_LOW:
			return 0.0
		Quality.LOW:
			return 18.0
		Quality.MEDIUM:
			return 35.0
		Quality.HIGH:
			return 50.0
	return 70.0


## Czy robot (gracz lub AI) ma mieć prawdziwe źródło światła neonu.
func neon_light_allowed(is_player: bool) -> bool:
	if not neon_enabled or quality == Quality.VERY_LOW:
		return false
	match quality:
		Quality.LOW:
			return false
		Quality.MEDIUM:
			return is_player
	return true


## Czy robot ma mieć prawdziwe światła reflektorów (SpotLight3D).
func headlights_light_allowed(is_player: bool) -> bool:
	if not headlights_enabled or quality == Quality.VERY_LOW:
		return false
	match quality:
		Quality.LOW, Quality.MEDIUM:
			return is_player
	return true


func headlight_shadows_allowed(is_player: bool) -> bool:
	return headlights_enabled and shadows_enabled and quality == Quality.ULTRA and is_player


## Mnożnik liczby cząsteczek (0 = efekty wyłączone).
func get_particle_scale() -> float:
	if not effects_enabled or quality == Quality.VERY_LOW:
		return 0.0
	match quality:
		Quality.LOW:
			return 0.35
		Quality.MEDIUM:
			return 0.6
	return 1.0


func supports_forward_plus_effects() -> bool:
	return is_forward_plus()


func supports_ssao() -> bool:
	return is_forward_plus() or is_compatibility()


func supports_glow() -> bool:
	return true


## Klasyczna mgła głębiowa/wysokościowa działa także w rendererze Mobile.
func supports_depth_fog() -> bool:
	return true


func supports_debanding() -> bool:
	return not is_compatibility()


func supports_roughness_limiter() -> bool:
	return is_forward_plus() or is_mobile_renderer()


## ReflectionProbe jest obsługiwany także przez renderer Mobile.
func reflection_probe_allowed() -> bool:
	return reflections_enabled and quality >= Quality.HIGH


func glow_allowed() -> bool:
	return effects_enabled and glow_enabled and quality >= Quality.HIGH


func depth_fog_allowed() -> bool:
	return effects_enabled and depth_fog_enabled and quality >= Quality.MEDIUM


func ssao_allowed() -> bool:
	return effects_enabled and ssao_enabled and quality >= Quality.HIGH and supports_ssao()


func ssil_allowed() -> bool:
	return effects_enabled and ssil_enabled and quality >= Quality.HIGH and supports_forward_plus_effects()


func ssr_allowed() -> bool:
	return effects_enabled and ssr_enabled and quality >= Quality.HIGH and supports_forward_plus_effects()


func sdfgi_allowed() -> bool:
	return effects_enabled and sdfgi_enabled and quality == Quality.ULTRA and supports_forward_plus_effects()


func volumetric_fog_allowed() -> bool:
	return effects_enabled and volumetric_fog_enabled and quality >= Quality.HIGH and supports_forward_plus_effects()


func taa_allowed() -> bool:
	return taa_enabled and quality >= Quality.HIGH and supports_forward_plus_effects()


func debanding_allowed() -> bool:
	return debanding_enabled and supports_debanding()


func roughness_limiter_allowed() -> bool:
	return roughness_limiter_enabled and supports_roughness_limiter()


func set_advanced_graphics_option(key: String, value: bool) -> void:
	match key:
		"fx_glow": glow_enabled = value
		"fx_ssao": ssao_enabled = value
		"fx_ssil": ssil_enabled = value
		"fx_ssr": ssr_enabled = value
		"fx_sdfgi": sdfgi_enabled = value
		"fx_volumetric_fog": volumetric_fog_enabled = value
		"fx_depth_fog": depth_fog_enabled = value
		"fx_taa": taa_enabled = value
		"fx_debanding": debanding_enabled = value
		"fx_roughness_limiter": roughness_limiter_enabled = value
		_: return
	_graphics_updated()


## Odległość, po której gasną światła przeciwników (oszczędność GPU).
func light_fade_distance() -> float:
	match quality:
		Quality.VERY_LOW:
			return 0.0
		Quality.LOW:
			return 12.0
		Quality.MEDIUM:
			return 22.0
		Quality.HIGH:
			return 30.0
	return 45.0


# =========================================================
# GRAFIKA - USTAWIENIA GLOBALNE
# =========================================================

func apply_global_graphics() -> void:
	Engine.max_fps = fps_limit

	var viewport: Viewport = get_viewport()
	if viewport == null:
		return

	_dynamic_render_scale = get_render_scale()
	viewport.scaling_3d_scale = _dynamic_render_scale
	viewport.use_taa = taa_allowed()
	viewport.use_debanding = debanding_allowed()
	# Mobile wymaga ustawienia debandingu również po stronie materiałów.
	if not is_compatibility():
		RenderingServer.material_set_use_debanding(debanding_allowed())
	# Roughness limiter istnieje tylko w Forward+ i Mobile.
	if supports_roughness_limiter():
		var roughness_amount: float = float(ProjectSettings.get_setting("rendering/anti_aliasing/screen_space_roughness_limiter/amount", 0.25))
		var roughness_limit: float = float(ProjectSettings.get_setting("rendering/anti_aliasing/screen_space_roughness_limiter/limit", 0.18))
		RenderingServer.screen_space_roughness_limiter_set_active(roughness_limiter_allowed(), roughness_amount, roughness_limit)

	match quality:
		Quality.VERY_LOW, Quality.LOW:
			viewport.msaa_3d = Viewport.MSAA_DISABLED
			viewport.screen_space_aa = Viewport.SCREEN_SPACE_AA_DISABLED
		Quality.MEDIUM:
			viewport.msaa_3d = Viewport.MSAA_DISABLED
			viewport.screen_space_aa = Viewport.SCREEN_SPACE_AA_FXAA if not is_compatibility() else Viewport.SCREEN_SPACE_AA_DISABLED
		Quality.HIGH:
			viewport.msaa_3d = Viewport.MSAA_2X
			viewport.screen_space_aa = Viewport.SCREEN_SPACE_AA_DISABLED
		Quality.ULTRA:
			viewport.msaa_3d = Viewport.MSAA_4X
			viewport.screen_space_aa = Viewport.SCREEN_SPACE_AA_DISABLED

	RenderingServer.directional_shadow_atlas_set_size(get_shadow_atlas_size(), quality >= Quality.HIGH)
	viewport.positional_shadow_atlas_size = 512 if quality == Quality.VERY_LOW else (2048 if quality == Quality.ULTRA else 1024)

	var soft_quality: int = RenderingServer.SHADOW_QUALITY_HARD
	match quality:
		Quality.MEDIUM:
			soft_quality = RenderingServer.SHADOW_QUALITY_SOFT_VERY_LOW
		Quality.HIGH:
			soft_quality = RenderingServer.SHADOW_QUALITY_SOFT_LOW
		Quality.ULTRA:
			soft_quality = RenderingServer.SHADOW_QUALITY_SOFT_MEDIUM
	RenderingServer.directional_soft_shadow_filter_set_quality(soft_quality)
	RenderingServer.positional_soft_shadow_filter_set_quality(soft_quality)


# =========================================================
# STEROWANIE
# =========================================================

func set_control_mode(value: int) -> void:
	control_mode = clampi(value, 0, 2)
	_save_controls()
	controls_changed.emit()


func set_steering_sensitivity(value: float) -> void:
	steering_sensitivity = clampf(value, 0.4, 2.0)
	_save_controls()
	controls_changed.emit()


func set_gyro_invert(value: bool) -> void:
	gyro_invert = value
	_save_controls()
	controls_changed.emit()


func set_gyro_max_tilt(value: float) -> void:
	gyro_max_tilt = clampf(value, 10.0, 45.0)
	_save_controls()
	controls_changed.emit()


func set_haptics_enabled(value: bool) -> void:
	haptics_enabled = value
	_save_controls()
	controls_changed.emit()


## Odczyt przechyłu urządzenia w zakresie -1..1 (bez neutralnej kalibracji).
## Godot na Androidzie przelicza osie czujnika zgodnie z obrotem ekranu, więc
## w orientacji poziomej oś X grawitacji odpowiada przechyłowi "kierownicy".
func read_raw_tilt() -> float:
	var gravity: Vector3 = Input.get_gravity()

	if gravity.length_squared() < 0.01:
		gravity = Input.get_accelerometer()

	if gravity.length_squared() < 0.01:
		return 0.0

	return clampf(gravity.x / 9.81, -1.0, 1.0)


## Kalibracja: aktualne położenie telefonu staje się położeniem neutralnym.
func calibrate_gyro() -> void:
	gyro_neutral = read_raw_tilt()
	_save_controls()
	controls_changed.emit()


func vibrate(duration_ms: int) -> void:
	if haptics_enabled and OS.has_feature("mobile"):
		Input.vibrate_handheld(duration_ms)


# =========================================================
# DŹWIĘK
# =========================================================

func set_volume(channel: String, value: float) -> void:
	value = clampf(value, 0.0, 1.0)
	match channel:
		"master":
			master_volume = value
		"sfx":
			sfx_volume = value
		"engine":
			engine_volume = value
		"ui":
			ui_volume = value
	_save_audio()
	audio_changed.emit()


# =========================================================
# UKŁAD HUD
# =========================================================

## Klucz proporcji ekranu - dla każdej grupy zapisujemy osobny układ HUD.
func get_aspect_bucket(screen_size: Vector2) -> String:
	if screen_size.y <= 0.0:
		return "16:9"
	var ratio: float = screen_size.x / screen_size.y
	if ratio < 1.45:
		return "4:3"
	if ratio < 1.68:
		return "16:10"
	if ratio < 1.86:
		return "16:9"
	if ratio < 2.12:
		return "19.5:9"
	return "21:9"


func get_hud_layout(bucket: String) -> Dictionary:
	var layout: Variant = hud_layouts.get(bucket, {})
	if layout is Dictionary:
		return (layout as Dictionary).duplicate(true)
	return {}


func set_hud_layout(bucket: String, layout: Dictionary) -> void:
	hud_layouts[bucket] = layout.duplicate(true)
	SaveManager.set_value("hud", "layouts", hud_layouts)
	SaveManager.save_now()
	hud_layout_changed.emit()


func reset_hud_layout(bucket: String) -> void:
	hud_layouts.erase(bucket)
	SaveManager.set_value("hud", "layouts", hud_layouts)
	SaveManager.save_now()
	hud_layout_changed.emit()


func set_hud_opacity(value: float) -> void:
	hud_opacity = clampf(value, 0.3, 1.0)
	SaveManager.set_value("hud", "opacity", hud_opacity)
	hud_layout_changed.emit()


func is_simple_play_style() -> bool:
	return play_style == "simple"


func set_play_style(value: String) -> void:
	play_style = "advanced" if value == "advanced" else "simple"
	play_style_chosen = true
	SaveManager.set_value("gameplay", "play_style", play_style)
	SaveManager.set_value("gameplay", "play_style_chosen", true)
	SaveManager.save_now()
