extends Node
## Central language manager. Polish is the source language; each additional
## language lives in its own scripts/translations/Locale_<code>.gd catalog.

signal language_changed(language_code: String)

const LANGUAGE_CATALOGS: Dictionary = {
	"pl": {"name": "Polski", "catalog": null},
	"en": {"name": "English", "catalog": preload("res://translations/Locale_en.gd")}
}

var language_code: String = "pl"
var _translations: Dictionary = {}

func _ready() -> void:
	language_code = str(SaveManager.get_value("language", "code", "pl"))
	if not LANGUAGE_CATALOGS.has(language_code):
		language_code = "pl"
	_load_catalog()

func get_languages() -> Array[String]:
	var result: Array[String] = []
	for code: Variant in LANGUAGE_CATALOGS.keys():
		result.append(str(code))
	return result

func get_language_name(code: String) -> String:
	if not LANGUAGE_CATALOGS.has(code):
		return code
	return str(LANGUAGE_CATALOGS[code].get("name", code))

func set_language(code: String) -> void:
	if not LANGUAGE_CATALOGS.has(code) or code == language_code:
		return
	language_code = code
	_load_catalog()
	SaveManager.set_value("language", "code", language_code)
	SaveManager.save_now()
	language_changed.emit(language_code)

func _load_catalog() -> void:
	_translations.clear()
	var entry: Dictionary = LANGUAGE_CATALOGS.get(language_code, {})
	var catalog: Variant = entry.get("catalog")
	if catalog is Script:
		var constants: Dictionary = catalog.get_script_constant_map()
		var strings: Variant = constants.get("STRINGS", {})
		if strings is Dictionary:
			_translations = strings

func tr_text(source: String) -> String:
	if language_code == "pl" or _translations.is_empty():
		return source
	if _translations.has(source):
		return str(_translations[source])
	var translated := source
	var keys: Array = _translations.keys()
	keys.sort_custom(func(a: Variant, b: Variant) -> bool: return str(a).length() > str(b).length())
	for key: Variant in keys:
		var original: String = str(key)
		if original.length() >= 4 and translated.contains(original):
			translated = translated.replace(original, str(_translations[original]))
	return translated
