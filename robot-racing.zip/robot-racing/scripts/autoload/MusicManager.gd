extends Node
## Odtwarzacz muzyki użytkownika. Kopiuje wybrane pliki do user://music,
## zachowuje playlistę i automatycznie przechodzi do kolejnego utworu.

signal track_changed(title: String, index: int, count: int)

const MUSIC_DIR := "user://music"
const PLAYLIST_PATH := "user://music/playlist.cfg"
var tracks: PackedStringArray = PackedStringArray()
var current_index: int = -1
var _player: AudioStreamPlayer

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(MUSIC_DIR))
	_player = AudioStreamPlayer.new()
	_player.bus = "Master"
	add_child(_player)
	_player.finished.connect(next_track)
	_load_playlist()

func _load_playlist() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(PLAYLIST_PATH) != OK:
		return
	var values: Variant = cfg.get_value("music", "tracks", PackedStringArray())
	if values is PackedStringArray:
		for track_path: String in values:
			if FileAccess.file_exists(track_path):
				tracks.append(track_path)
	elif values is Array:
		for value: Variant in values:
			var array_track_path: String = str(value)
			if FileAccess.file_exists(array_track_path):
				tracks.append(array_track_path)
	current_index = clampi(int(cfg.get_value("music", "index", -1)), -1, tracks.size() - 1)

func _save_playlist() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("music", "tracks", tracks)
	cfg.set_value("music", "index", current_index)
	cfg.save(PLAYLIST_PATH)

func add_files(paths: PackedStringArray) -> int:
	var added := 0
	for source: String in paths:
		var ext := source.get_extension().to_lower()
		if not ["mp3", "ogg", "wav"].has(ext):
			continue
		var base := source.get_file()
		var destination := MUSIC_DIR.path_join(base)
		var suffix := 1
		while FileAccess.file_exists(destination):
			destination = MUSIC_DIR.path_join("%s_%d.%s" % [base.get_basename(), suffix, ext])
			suffix += 1
		if DirAccess.copy_absolute(source, ProjectSettings.globalize_path(destination)) == OK:
			tracks.append(destination)
			added += 1
	if added > 0:
		_save_playlist()
		if current_index < 0: play_index(0)
	return added

func play_index(index: int) -> void:
	if tracks.is_empty():
		return
	current_index = posmod(index, tracks.size())
	var path := tracks[current_index]
	var stream: AudioStream
	match path.get_extension().to_lower():
		"mp3": stream = AudioStreamMP3.load_from_file(path)
		"ogg": stream = AudioStreamOggVorbis.load_from_file(path)
		"wav": stream = AudioStreamWAV.load_from_file(path)
	if stream == null:
		tracks.remove_at(current_index)
		current_index = -1 if tracks.is_empty() else mini(current_index, tracks.size() - 1)
		_save_playlist()
		if not tracks.is_empty(): play_index(current_index)
		return
	_player.stream = stream
	_player.play()
	_save_playlist()
	track_changed.emit(path.get_file(), current_index, tracks.size())

func next_track() -> void:
	if not tracks.is_empty():
		play_index(current_index + 1)


func move_track(index: int, direction: int) -> bool:
	if index < 0 or index >= tracks.size() or direction == 0:
		return false
	var target: int = clampi(index + signi(direction), 0, tracks.size() - 1)
	if target == index:
		return false
	var playing_path: String = tracks[current_index] if current_index >= 0 and current_index < tracks.size() else ""
	var moved_path: String = tracks[index]
	tracks.remove_at(index)
	tracks.insert(target, moved_path)
	if not playing_path.is_empty():
		current_index = tracks.find(playing_path)
	_save_playlist()
	return true


func remove_track(index: int) -> bool:
	if index < 0 or index >= tracks.size():
		return false
	var removed_path: String = tracks[index]
	var was_current: bool = current_index >= 0 and current_index < tracks.size() and tracks[current_index] == removed_path
	var was_playing: bool = _player.playing
	var old_current_path: String = tracks[current_index] if current_index >= 0 and current_index < tracks.size() else ""
	tracks.remove_at(index)
	if tracks.is_empty():
		_player.stop()
		_player.stream = null
		current_index = -1
	elif was_current:
		current_index = mini(index, tracks.size() - 1)
		if was_playing:
			play_index(current_index)
		else:
			_player.stop()
			_save_playlist()
	else:
		current_index = tracks.find(old_current_path) if not old_current_path.is_empty() else -1
	_save_playlist()
	return true


func get_track_title(index: int) -> String:
	if index < 0 or index >= tracks.size():
		return ""
	return tracks[index].get_file()

func toggle_playback() -> void:
	if tracks.is_empty():
		return
	if _player.playing:
		_player.stop()
	elif current_index >= 0:
		play_index(current_index)
	else:
		play_index(0)

func has_tracks() -> bool:
	return not tracks.is_empty()

func get_status() -> String:
	if tracks.is_empty(): return "Brak dodanej muzyki"
	return "%d utworów • %s" % [tracks.size(), tracks[current_index].get_file() if current_index >= 0 else "zatrzymano"]
