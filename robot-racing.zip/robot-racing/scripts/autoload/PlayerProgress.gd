
extends Node
## Postęp gracza i ekonomia: kredyty, odblokowane roboty i skórki,
## ulepszenia, uszkodzenia robotów (naprawa w garażu), wybory, rekordy, statystyki.
##
## Brak jakichkolwiek płatności prawdziwymi pieniędzmi - waluta (CR) jest
## zdobywana wyłącznie w grze.

signal currency_changed(value: int)
signal progress_changed

const CURRENCY_NAME: String = "CR"
const REPAIR_COST_PER_PERCENT: float = 1.5

var currency: int = 0
var unlocked_robots: Array[int] = [0, 1]
var unlocked_skins: Array[int] = [0]
var selected_robot: int = 0
var robot_upgrades: Dictionary = {}
var robot_skins: Dictionary = {}
var robot_neons: Dictionary = {}
var robot_damage: Dictionary = {}
var best_times: Dictionary = {}
var stats: Dictionary = {}
## Dzienne wyzwania działające offline; stan resetuje się według lokalnej daty.
var daily_challenges: Dictionary = {}
## Progres kampanii fabularnej i własne teksty dymków komiksu.
var career_state: Dictionary = {"event_index": 0, "cleared": [], "wins": 0, "attempts": 0}
var career_comic_texts: Dictionary = {}
## Wspólne wyposażenie boostów dla wszystkich robotów.
var boost_loadout: BoostLoadoutSystem

# Ostatnie wybory w menu.
var selected_track_id: String = "apartment"
var last_difficulty: int = 1
var last_laps: int = 3
var last_opponents: int = 4
var ghost_enabled: bool = true


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_load()
	boost_loadout = BoostLoadoutSystem.new()


# =========================================================
# ODCZYT / ZAPIS (z migracją ze starego formatu)
# =========================================================

func _load() -> void:
	if SaveManager.has_value("progress", "currency"):
		currency = SaveManager.get_int("progress", "currency", 0, 0)
	else:
		# Stary zapis: economy/player_points.
		currency = SaveManager.get_int("economy", "player_points", 0, 0)

	unlocked_robots = _to_int_array(
		SaveManager.get_array("progress", "unlocked_robots"),
		[0, 1],
		RobotDatabase.count()
	)

	unlocked_skins = _to_int_array(
		SaveManager.get_array("progress", "unlocked_skins"),
		[0],
		RobotDatabase.SKINS.size()
	)

	if not unlocked_robots.has(0):
		unlocked_robots.append(0)

	if not unlocked_skins.has(0):
		unlocked_skins.append(0)

	selected_robot = SaveManager.get_int(
		"selection",
		"robot",
		0,
		0,
		RobotDatabase.count() - 1
	)

	if not unlocked_robots.has(selected_robot):
		selected_robot = 0

	robot_upgrades = SaveManager.get_dict("progress", "upgrades")
	robot_skins = SaveManager.get_dict("progress", "skins")
	robot_neons = SaveManager.get_dict("progress", "neons")
	robot_damage = SaveManager.get_dict("progress", "damage")
	best_times = SaveManager.get_dict("progress", "best_times")
	stats = SaveManager.get_dict("progress", "stats")
	daily_challenges = SaveManager.get_dict("daily_challenges", "state")
	career_state = SaveManager.get_dict("career", "state")
	career_comic_texts = SaveManager.get_dict("career", "comic_texts")
	if career_state.is_empty():
		career_state = {"event_index": 0, "cleared": [], "wins": 0, "attempts": 0}
	_ensure_daily_challenges()

	if robot_upgrades.is_empty():
		_migrate_old_tuning()

	selected_track_id = SaveManager.get_string(
		"selection",
		"track",
		"apartment"
	)

	if TrackDatabase.find_index(selected_track_id) == 0 \
	and str(TrackDatabase.get_track(0)["id"]) != selected_track_id:
		selected_track_id = str(TrackDatabase.get_track(0)["id"])

	last_difficulty = SaveManager.get_int(
		"selection", "difficulty", 1, 0, 3
	)

	last_laps = SaveManager.get_int(
		"selection", "laps", 3, 1, 10
	)

	last_opponents = SaveManager.get_int(
		"selection", "opponents", 4, 1, 4
	)

	ghost_enabled = SaveManager.get_bool(
		"selection", "ghost", true
	)


func _migrate_old_tuning() -> void:
	# Stary zapis: tuning/robots.
	var old: Array = SaveManager.get_array("tuning", "robots")

	for i: int in range(mini(old.size(), RobotDatabase.count())):
		if not (old[i] is Dictionary):
			continue

		var entry: Dictionary = old[i]

		robot_upgrades[str(i)] = {
			"speed": clampi(
				int(entry.get("engine", 0)),
				0,
				RobotDatabase.UPGRADE_MAX_LEVEL
			),
			"accel": clampi(
				int(entry.get("acceleration", 0)),
				0,
				RobotDatabase.UPGRADE_MAX_LEVEL
			),
			"grip": clampi(
				int(entry.get("grip", 0)),
				0,
				RobotDatabase.UPGRADE_MAX_LEVEL
			),
			"capacity": clampi(
				int(entry.get("container", 0)),
				0,
				RobotDatabase.UPGRADE_MAX_LEVEL
			),
			"boost": clampi(
				int(entry.get("boost", 0)),
				0,
				RobotDatabase.UPGRADE_MAX_LEVEL
			)
		}


func _to_int_array(
	source: Array,
	fallback: Array[int],
	limit: int
) -> Array[int]:
	var result: Array[int] = []

	for value: Variant in source:
		if value is int or value is float:
			var number: int = int(value)

			if number >= 0 and number < limit and not result.has(number):
				result.append(number)

	if result.is_empty():
		return fallback.duplicate()

	return result


func save() -> void:
	SaveManager.set_value("progress", "currency", currency)
	SaveManager.set_value("progress", "unlocked_robots", unlocked_robots)
	SaveManager.set_value("progress", "unlocked_skins", unlocked_skins)
	SaveManager.set_value("progress", "upgrades", robot_upgrades)
	SaveManager.set_value("progress", "skins", robot_skins)
	SaveManager.set_value("progress", "neons", robot_neons)
	SaveManager.set_value("progress", "damage", robot_damage)
	SaveManager.set_value("progress", "best_times", best_times)
	SaveManager.set_value("progress", "stats", stats)
	SaveManager.set_value("daily_challenges", "state", daily_challenges)
	SaveManager.set_value("career", "state", career_state)
	SaveManager.set_value("career", "comic_texts", career_comic_texts)

	SaveManager.set_value("selection", "robot", selected_robot)
	SaveManager.set_value("selection", "track", selected_track_id)
	SaveManager.set_value("selection", "difficulty", last_difficulty)
	SaveManager.set_value("selection", "laps", last_laps)
	SaveManager.set_value("selection", "opponents", last_opponents)
	SaveManager.set_value("selection", "ghost", ghost_enabled)

	# Stary klucz utrzymujemy w zgodności.
	SaveManager.set_value("economy", "player_points", currency)

	progress_changed.emit()


# =========================================================
# WALUTA
# =========================================================

func add_currency(amount: int) -> void:
	if amount <= 0:
		return

	currency += amount
	stats["earned_total"] = int(stats.get("earned_total", 0)) + amount

	save()
	currency_changed.emit(currency)


func can_afford(amount: int) -> bool:
	return amount >= 0 and currency >= amount


func spend(amount: int) -> bool:
	if not can_afford(amount):
		return false

	currency -= amount
	save()
	currency_changed.emit(currency)

	return true


# =========================================================
# ROBOTY, SKÓRKI, NEONY
# =========================================================

func is_robot_unlocked(index: int) -> bool:
	return unlocked_robots.has(index)


func unlock_robot(index: int) -> bool:
	if is_robot_unlocked(index):
		return true

	var cost: int = int(RobotDatabase.get_robot(index)["cost"])

	if not spend(cost):
		return false

	unlocked_robots.append(index)
	save()

	return true


func select_robot(index: int) -> void:
	if is_robot_unlocked(index):
		selected_robot = index
		save()


func is_skin_unlocked(index: int) -> bool:
	return unlocked_skins.has(index)


func unlock_skin(index: int) -> bool:
	if is_skin_unlocked(index):
		return true

	var cost: int = int(RobotDatabase.get_skin(index)["cost"])

	if not spend(cost):
		return false

	unlocked_skins.append(index)
	save()

	return true


func get_skin(robot_index: int) -> int:
	return clampi(
		int(robot_skins.get(str(robot_index), 0)),
		0,
		RobotDatabase.SKINS.size() - 1
	)


func set_skin(robot_index: int, skin_index: int) -> void:
	if is_skin_unlocked(skin_index):
		robot_skins[str(robot_index)] = skin_index
		save()


func get_neon(robot_index: int) -> int:
	return clampi(
		int(robot_neons.get(str(robot_index), 0)),
		0,
		RobotDatabase.NEON_COLORS.size() - 1
	)


func set_neon(robot_index: int, neon_index: int) -> void:
	robot_neons[str(robot_index)] = clampi(
		neon_index,
		0,
		RobotDatabase.NEON_COLORS.size() - 1
	)
	save()


# =========================================================
# ULEPSZENIA
# =========================================================

func get_upgrades(robot_index: int) -> Dictionary:
	var result: Dictionary = RobotDatabase.empty_upgrades()
	var saved: Variant = robot_upgrades.get(str(robot_index), {})

	if saved is Dictionary:
		for key: String in result.keys():
			result[key] = clampi(
				int((saved as Dictionary).get(key, 0)),
				0,
				RobotDatabase.UPGRADE_MAX_LEVEL
			)

	return result


func buy_upgrade(robot_index: int, upgrade_id: String) -> bool:
	var upgrades: Dictionary = get_upgrades(robot_index)

	if not upgrades.has(upgrade_id):
		return false

	var level: int = int(upgrades[upgrade_id])
	var cost: int = RobotDatabase.get_upgrade_cost(level)

	if cost < 0 or not spend(cost):
		return false

	upgrades[upgrade_id] = level + 1
	robot_upgrades[str(robot_index)] = upgrades

	save()

	return true


## Konfiguracja aktualnie wybranego robota gracza do wyścigu.
func get_player_robot_config() -> Dictionary:
	return RobotDatabase.build_config(
		selected_robot,
		get_upgrades(selected_robot),
		get_skin(selected_robot),
		get_neon(selected_robot)
	)


# =========================================================
# USZKODZENIA I NAPRAWA
# =========================================================

func get_damage(robot_index: int) -> float:
	return clampf(
		float(robot_damage.get(str(robot_index), 0.0)),
		0.0,
		100.0
	)


func set_damage(robot_index: int, value: float) -> void:
	robot_damage[str(robot_index)] = snappedf(
		clampf(value, 0.0, 100.0),
		0.1
	)
	save()


func get_repair_cost(robot_index: int) -> int:
	return ceili(get_damage(robot_index) * REPAIR_COST_PER_PERCENT)


## Naprawa: pełna, jeśli gracza stać; w przeciwnym razie częściowa.
## Zwraca liczbę naprawionych procent.
func repair(robot_index: int) -> float:
	var damage: float = get_damage(robot_index)

	if damage <= 0.0:
		return 0.0

	var full_cost: int = get_repair_cost(robot_index)

	if currency >= full_cost:
		spend(full_cost)
		set_damage(robot_index, 0.0)
		return damage

	if currency <= 0:
		return 0.0

	var repaired: float = minf(
		float(currency) / REPAIR_COST_PER_PERCENT,
		damage
	)

	spend(currency)
	set_damage(robot_index, damage - repaired)

	return repaired


# =========================================================
# REKORDY
# =========================================================

func record_key(track_id: String, mode: String, laps: int) -> String:
	return "%s|%s|%d" % [track_id, mode, laps]


func get_best(track_id: String, mode: String, laps: int) -> Dictionary:
	var value: Variant = best_times.get(
		record_key(track_id, mode, laps),
		{}
	)

	if value is Dictionary:
		return value

	return {}


func get_best_lap_any(track_id: String) -> float:
	var best: float = -1.0

	for key: String in best_times.keys():
		if not key.begins_with(track_id + "|"):
			continue

		var entry: Variant = best_times[key]

		if entry is Dictionary:
			var lap: float = float(
				(entry as Dictionary).get("best_lap", -1.0)
			)

			if lap > 0.0 and (best < 0.0 or lap < best):
				best = lap

	return best


## Aktualizuje rekordy; zwraca {"new_total": bool, "new_lap": bool}.
func submit_times(
	track_id: String,
	mode: String,
	laps: int,
	total_time: float,
	best_lap: float
) -> Dictionary:
	var key: String = record_key(track_id, mode, laps)
	var entry: Dictionary = get_best(
		track_id,
		mode,
		laps
	).duplicate()

	var result: Dictionary = {
		"new_total": false,
		"new_lap": false
	}

	if total_time > 0.0:
		var old_total: float = float(entry.get("total", -1.0))

		if old_total <= 0.0 or total_time < old_total:
			entry["total"] = total_time
			result["new_total"] = true

	if best_lap > 0.0:
		var old_lap: float = float(entry.get("best_lap", -1.0))

		if old_lap <= 0.0 or best_lap < old_lap:
			entry["best_lap"] = best_lap
			result["new_lap"] = true

	best_times[key] = entry
	save()

	return result


# =========================================================
# NAGRODY
# =========================================================

## Oblicza nagrody za wyścig.
func compute_rewards(info: Dictionary) -> Dictionary:
	var rewards: Dictionary = {
		"items": [],
		"total": 0
	}

	var mode: String = str(info.get("mode", "race"))
	var laps: int = maxi(int(info.get("laps", 1)), 1)

	var lap_factor: float = clampf(
		0.5 + 0.5 * float(laps) / 3.0,
		0.65,
		2.2
	)

	if mode == "race":
		var position: int = int(info.get("position", 0))
		var finished: bool = bool(info.get("finished", false))
		var base: Array[int] = [150, 100, 70, 45, 30]

		var difficulty: int = clampi(
			int(info.get("difficulty", 1)),
			0,
			3
		)

		var mult: float = AIDifficulty.REWARD_MULTIPLIER[difficulty]

		if finished and position >= 1 and position <= base.size():
			_add_reward(
				rewards,
				"Miejsce %d" % position,
				roundi(base[position - 1] * lap_factor * mult)
			)
		elif not finished:
			_add_reward(
				rewards,
				"Udział w wyścigu",
				roundi(10 * lap_factor)
			)

	elif mode == "time_trial":
		var laps_done: int = int(info.get("laps_done", 0))

		_add_reward(
			rewards,
			"Ukończone okrążenia",
			laps_done * 15
		)

		if bool(info.get("new_total", false)):
			_add_reward(rewards, "Nowy rekord czasu", 60)

		if bool(info.get("new_lap", false)):
			_add_reward(rewards, "Nowe najlepsze okrążenie", 30)

	var dirt: float = float(info.get("dirt_collected", 0.0))

	if dirt > 0.0:
		_add_reward(rewards, "Zebrany brud", floori(dirt))

	if bool(info.get("finished", false)) \
	and float(info.get("damage_taken", 100.0)) < 8.0:
		_add_reward(rewards, "Czysta jazda", 25)

	return rewards


func _add_reward(
	rewards: Dictionary,
	label: String,
	amount: int
) -> void:
	if amount <= 0:
		return

	(rewards["items"] as Array).append({
		"label": label,
		"amount": amount
	})

	rewards["total"] = int(rewards["total"]) + amount


func apply_race_stats(
	mode: String,
	position: int,
	finished: bool,
	dirt: float
) -> void:
	stats["races"] = int(stats.get("races", 0)) + 1
	stats["dirt_total"] = float(stats.get("dirt_total", 0.0)) + dirt

	if mode == "race" and finished:
		if position == 1:
			stats["wins"] = int(stats.get("wins", 0)) + 1

		if position >= 1 and position <= 3:
			stats["podiums"] = int(stats.get("podiums", 0)) + 1

	_update_daily_challenge_progress(mode, position, finished, dirt)
	save()


func _local_date_key() -> String:
	var date: Dictionary = Time.get_date_dict_from_system()
	return "%04d-%02d-%02d" % [int(date.get("year", 2000)), int(date.get("month", 1)), int(date.get("day", 1))]


func _ensure_daily_challenges() -> void:
	var today: String = _local_date_key()
	if str(daily_challenges.get("date", "")) != today:
		daily_challenges = {
			"date": today,
			"completed_races": 0,
			"wins": 0,
			"dirt": 0.0,
			"claimed": []
		}
		SaveManager.set_value("daily_challenges", "state", daily_challenges)


func _update_daily_challenge_progress(mode: String, position: int, finished: bool, dirt: float) -> void:
	_ensure_daily_challenges()
	if finished:
		daily_challenges["completed_races"] = int(daily_challenges.get("completed_races", 0)) + 1
	if mode == "race" and finished and position == 1:
		daily_challenges["wins"] = int(daily_challenges.get("wins", 0)) + 1
	daily_challenges["dirt"] = float(daily_challenges.get("dirt", 0.0)) + maxf(dirt, 0.0)
	SaveManager.set_value("daily_challenges", "state", daily_challenges)


func get_daily_challenges() -> Array[Dictionary]:
	_ensure_daily_challenges()
	var claimed: Array = daily_challenges.get("claimed", [])
	var definitions: Array[Dictionary] = [
		{"id": "daily_races", "title": "DWIE META", "description": "Ukończ 2 wyścigi.", "progress": int(daily_challenges.get("completed_races", 0)), "target": 2, "reward": 90},
		{"id": "daily_dirt", "title": "CODZIENNY PORZĄDEK", "description": "Zbierz 100 jednostek brudu.", "progress": floori(float(daily_challenges.get("dirt", 0.0))), "target": 100, "reward": 110},
		{"id": "daily_win", "title": "PIERWSZE MIEJSCE", "description": "Wygraj 1 wyścig.", "progress": int(daily_challenges.get("wins", 0)), "target": 1, "reward": 160}
	]
	for challenge: Dictionary in definitions:
		challenge["claimed"] = claimed.has(str(challenge["id"]))
	return definitions


func claim_daily_challenge(challenge_id: String) -> bool:
	var definitions: Array[Dictionary] = get_daily_challenges()
	for challenge: Dictionary in definitions:
		if str(challenge["id"]) != challenge_id:
			continue
		if bool(challenge["claimed"]) or int(challenge["progress"]) < int(challenge["target"]):
			return false
		var claimed: Array = daily_challenges.get("claimed", [])
		claimed.append(challenge_id)
		daily_challenges["claimed"] = claimed
		SaveManager.set_value("daily_challenges", "state", daily_challenges)
		add_currency(int(challenge["reward"]))
		return true
	return false


func set_race_preferences(
	track_id: String,
	difficulty: int,
	laps: int,
	opponents: int,
	ghost: bool
) -> void:
	selected_track_id = track_id
	last_difficulty = clampi(difficulty, 0, 3)
	last_laps = clampi(laps, 1, 10)
	last_opponents = clampi(opponents, 1, 4)
	ghost_enabled = ghost

	save()




# =========================================================
# KAMPANIA FABULARNA I KOMIKS
# =========================================================

func get_career_event_index() -> int:
	return clampi(int(career_state.get("event_index", 0)), 0, CareerCampaign.count())


func get_career_event() -> Dictionary:
	return CareerCampaign.get_event(get_career_event_index())


func record_career_result(event_id: String, position: int, finished: bool) -> Dictionary:
	var index: int = get_career_event_index()
	var event: Dictionary = CareerCampaign.get_event(index)
	if event.is_empty() or str(event.get("id", "")) != event_id:
		return {"advanced": false, "bonus": 0, "completed": index >= CareerCampaign.count()}
	career_state["attempts"] = int(career_state.get("attempts", 0)) + 1
	var boss: bool = bool(event.get("boss", false))
	var qualified: bool = false
	if boss:
		qualified = finished and position == 1
	else:
		qualified = finished and position >= 1 and position <= 3
	var result: Dictionary = {"advanced": false, "bonus": 0, "completed": false}
	if qualified:
		var cleared: Array = career_state.get("cleared", [])
		if not cleared.has(event_id):
			cleared.append(event_id)
		career_state["cleared"] = cleared
		career_state["event_index"] = mini(index + 1, CareerCampaign.count())
		career_state["wins"] = int(career_state.get("wins", 0)) + (1 if position == 1 else 0)
		var bonus: int = 250 if boss else 100
		career_state["last_event"] = event_id
		result["advanced"] = true
		result["bonus"] = bonus
	result["completed"] = int(career_state["event_index"]) >= CareerCampaign.count()
	save()
	return result


func get_comic_text(panel_id: String, fallback: String) -> String:
	return str(career_comic_texts.get(panel_id, fallback))


func set_comic_text(panel_id: String, value: String) -> void:
	career_comic_texts[panel_id] = value.substr(0, 500)
	save()

# =========================================================
# RESET CAŁEGO POSTĘPU
# =========================================================

func reset_progress() -> void:
	## Resetuje postęp w pamięci i w pliku zapisu.
	## Ustawienia grafiki, sterowania, dźwięku i HUD pozostają zachowane.

	currency = 0

	unlocked_robots = [0, 1]
	unlocked_skins = [0]
	selected_robot = 0

	robot_upgrades.clear()
	robot_skins.clear()
	robot_neons.clear()
	robot_damage.clear()

	best_times.clear()
	stats.clear()
	daily_challenges.clear()
	career_state = {"event_index": 0, "cleared": [], "wins": 0, "attempts": 0}
	career_comic_texts.clear()

	selected_track_id = "apartment"
	last_difficulty = 1
	last_laps = 3
	last_opponents = 4
	ghost_enabled = true

	# Usuwa sekcje postępu, w tym docking_stations,
	# economy i stare tuning. Ustawienia użytkownika pozostają.
	SaveManager.reset_all()
	_ensure_daily_challenges()
	if boost_loadout != null:
		boost_loadout.reset_to_defaults()

	# Zapisuje wartości początkowe do nowego zapisu.
	save()
	SaveManager.save_now()

	currency_changed.emit(currency)
	progress_changed.emit()

