
extends Node
## Centralny magazyn zapisu gry.
##
## Obsługuje:
## - automatyczny zapis,
## - odczyt danych,
## - eksport postępu do osobnego pliku,
## - import postępu z walidacją,
## - kopię bezpieczeństwa przed importem,
## - selektywne czyszczenie postępu bez usuwania ustawień.

signal saved

const SAVE_PATH: String = "user://robot_racing_save.cfg"
const TEST_SAVE_PATH: String = "user://robot_racing_test_save.cfg"
const BACKUP_PATH: String = "user://robot_racing_before_import.cfg"

const SAVE_VERSION: int = 2
const BACKUP_FORMAT_VERSION: int = 1
const SAVE_DELAY: float = 0.75

## Sekcje zawierające postęp gry.
## Ustawienia graphics, controls, audio i hud pozostają nietknięte.
const PROGRESS_SECTIONS: Array[String] = [
	"progress",
	"achievements",
	"daily_challenges",
	"career",
	"selection",
	"boost_loadout",
	"boost_upgrades",
	"docking_stations",
	"economy",
	"tuning",
	"random_routes",
	"race_preferences"
]

const BACKUP_SECTION: String = "robot_racing_backup"

var _config: ConfigFile = ConfigFile.new()
var _dirty: bool = false
var _timer: float = 0.0
var loaded_version: int = 0

## Testy automatyczne używają osobnego pliku.
var test_mode: bool = false
var save_path: String = SAVE_PATH


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS

	if OS.get_cmdline_user_args().has("--test-save"):
		test_mode = true
		save_path = TEST_SAVE_PATH

		if FileAccess.file_exists(save_path):
			DirAccess.remove_absolute(ProjectSettings.globalize_path(save_path))

	_load_from_disk()
	set_process(false)


# =========================================================
# ODCZYT PLIKU
# =========================================================

func _load_from_disk() -> void:
	if not FileAccess.file_exists(save_path):
		loaded_version = 0
		return

	var error: Error = _config.load(save_path)

	if error != OK:
		push_warning(
			"SaveManager: nie można odczytać zapisu (kod %d). Używam wartości domyślnych."
			% error
		)

		var absolute: String = ProjectSettings.globalize_path(save_path)
		DirAccess.copy_absolute(absolute, absolute + ".broken")

		_config = ConfigFile.new()
		loaded_version = 0
		return

	loaded_version = int(
		_config.get_value("meta", "version", 1)
	) if _config.has_section_key("meta", "version") else 1


# =========================================================
# ODCZYT DANYCH
# =========================================================

func has_value(section: String, key: String) -> bool:
	return _config.has_section_key(section, key)


func get_value(
	section: String,
	key: String,
	default_value: Variant = null
) -> Variant:
	if _config.has_section_key(section, key):
		return _config.get_value(section, key, default_value)

	return default_value


func get_int(
	section: String,
	key: String,
	default_value: int,
	min_value: int = -2147483648,
	max_value: int = 2147483647
) -> int:
	var value: Variant = get_value(section, key, default_value)

	if value is int or value is float:
		return clampi(int(value), min_value, max_value)

	if value is String and (value as String).is_valid_int():
		return clampi((value as String).to_int(), min_value, max_value)

	return default_value


func get_float(
	section: String,
	key: String,
	default_value: float,
	min_value: float = -INF,
	max_value: float = INF
) -> float:
	var value: Variant = get_value(section, key, default_value)

	if value is int or value is float:
		var result: float = float(value)

		if is_nan(result) or is_inf(result):
			return default_value

		return clampf(result, min_value, max_value)

	return default_value


func get_bool(
	section: String,
	key: String,
	default_value: bool
) -> bool:
	var value: Variant = get_value(section, key, default_value)

	if value is bool:
		return value

	if value is int:
		return int(value) != 0

	return default_value


func get_string(
	section: String,
	key: String,
	default_value: String
) -> String:
	var value: Variant = get_value(section, key, default_value)

	if value is String or value is StringName:
		return str(value)

	return default_value


func get_dict(section: String, key: String) -> Dictionary:
	var value: Variant = get_value(section, key, {})

	if value is Dictionary:
		return (value as Dictionary).duplicate(true)

	return {}


func get_array(section: String, key: String) -> Array:
	var value: Variant = get_value(section, key, [])

	if value is Array:
		return (value as Array).duplicate(true)

	return []


# =========================================================
# ZAPIS
# =========================================================

func set_value(section: String, key: String, value: Variant) -> void:
	_config.set_value(section, key, value)
	_mark_dirty()


func erase_key(section: String, key: String) -> void:
	if _config.has_section_key(section, key):
		_config.erase_section_key(section, key)
		_mark_dirty()


func _mark_dirty() -> void:
	_dirty = true
	_timer = SAVE_DELAY
	set_process(true)


func _process(delta: float) -> void:
	_timer -= delta

	if _timer <= 0.0:
		save_now()


## Natychmiastowy zapis na dysk.
func save_now() -> void:
	set_process(false)

	if not _dirty:
		return

	_config.set_value("meta", "version", SAVE_VERSION)

	var error: Error = _config.save(save_path)

	if error != OK:
		push_error("SaveManager: błąd zapisu (kod %d)." % error)
		return

	_dirty = false
	saved.emit()


func _notification(what: int) -> void:
	match what:
		NOTIFICATION_WM_CLOSE_REQUEST, \
		NOTIFICATION_APPLICATION_PAUSED, \
		NOTIFICATION_APPLICATION_FOCUS_OUT, \
		NOTIFICATION_PREDELETE:
			save_now()


# =========================================================
# POMOCNICZE - SEKCJE POSTĘPU
# =========================================================

func clear_progress_sections() -> void:
	## Usuwa wyłącznie dane postępu.
	## Nie usuwa grafiki, sterowania, dźwięku ani HUD.

	for section: String in PROGRESS_SECTIONS:
		if _config.has_section(section):
			_config.erase_section(section)

	_mark_dirty()


func _copy_sections(
	source: ConfigFile,
	destination: ConfigFile,
	sections: Array[String]
) -> void:
	for section: String in sections:
		if not source.has_section(section):
			continue

		for key: String in source.get_section_keys(section):
			var value: Variant = source.get_value(section, key)
			destination.set_value(section, key, value)


# =========================================================
# EKSPORT POSTĘPU
# =========================================================

## Eksportuje postęp do wskazanego pliku.
## Przykładowa ścieżka: user://robot_racing_backup.cfg
## Zwraca true, jeśli eksport się udał.

func export_progress(target_path: String) -> bool:
	if target_path.strip_edges().is_empty():
		push_warning("SaveManager: nie podano ścieżki eksportu.")
		return false

	# Najpierw zapisujemy aktualny stan gry.
	save_now()

	if _dirty:
		push_error("SaveManager: nie udało się zapisać bieżącego postępu.")
		return false

	var export_config: ConfigFile = ConfigFile.new()

	export_config.set_value(
		BACKUP_SECTION,
		"format_version",
		BACKUP_FORMAT_VERSION
	)

	export_config.set_value(
		BACKUP_SECTION,
		"save_version",
		SAVE_VERSION
	)

	export_config.set_value(
		BACKUP_SECTION,
		"created_at",
		Time.get_datetime_string_from_system()
	)

	_copy_sections(_config, export_config, PROGRESS_SECTIONS)

	var error: Error = export_config.save(target_path)

	if error != OK:
		push_error(
			"SaveManager: eksport nie powiódł się (kod %d)." % error
		)
		return false

	return true


# =========================================================
# WALIDACJA PLIKU IMPORTU
# =========================================================

func validate_progress_file(source_path: String) -> bool:
	if source_path.strip_edges().is_empty():
		return false

	if not FileAccess.file_exists(source_path):
		return false

	var imported: ConfigFile = ConfigFile.new()
	var error: Error = imported.load(source_path)

	if error != OK:
		return false

	if not imported.has_section_key(
		BACKUP_SECTION,
		"format_version"
	):
		return false

	var format_version: int = int(
		imported.get_value(BACKUP_SECTION, "format_version", -1)
	)

	if format_version != BACKUP_FORMAT_VERSION:
		return false

	var has_progress: bool = (
		imported.has_section("progress")
		or imported.has_section("economy")
	)

	if not has_progress:
		return false

	# Sprawdzamy, czy plik zawiera przynajmniej jedną
	# rozpoznawaną sekcję postępu.
	var has_known_section: bool = false

	for section: String in PROGRESS_SECTIONS:
		if imported.has_section(section):
			has_known_section = true
			break

	return has_known_section


# =========================================================
# IMPORT POSTĘPU
# =========================================================

## Importuje postęp z pliku.
## Przed importem tworzy kopię aktualnego zapisu.
## Ustawienia grafiki, sterowania, dźwięku i HUD pozostają bez zmian.

func import_progress(source_path: String) -> bool:
	if not validate_progress_file(source_path):
		push_warning(
			"SaveManager: plik importu jest nieprawidłowy lub nieobsługiwany."
		)
		return false

	var imported: ConfigFile = ConfigFile.new()
	var load_error: Error = imported.load(source_path)

	if load_error != OK:
		return false

	# Zapisujemy aktualny stan przed wykonaniem kopii.
	save_now()

	if _dirty:
		push_error(
			"SaveManager: nie udało się zapisać bieżącego stanu przed importem."
		)
		return false

	# Kopia bezpieczeństwa aktualnego zapisu.
	if FileAccess.file_exists(save_path):
		var current_absolute: String = ProjectSettings.globalize_path(save_path)
		var backup_absolute: String = ProjectSettings.globalize_path(BACKUP_PATH)

		if FileAccess.file_exists(BACKUP_PATH):
			DirAccess.remove_absolute(backup_absolute)

		var backup_error: Error = DirAccess.copy_absolute(
			current_absolute,
			backup_absolute
		)

		if backup_error != OK:
			push_error(
				"SaveManager: nie udało się utworzyć kopii bezpieczeństwa."
			)
			return false

	# Usuwamy tylko stare sekcje postępu.
	for section: String in PROGRESS_SECTIONS:
		if _config.has_section(section):
			_config.erase_section(section)

	# Wstawiamy dane z importowanego pliku.
	_copy_sections(_config_source(imported), _config, PROGRESS_SECTIONS)

	_config.set_value("meta", "version", SAVE_VERSION)
	_mark_dirty()
	save_now()

	if _dirty:
		push_error(
			"SaveManager: import nie został zapisany. Kopia bezpieczeństwa pozostaje dostępna."
		)
		return false

	return true


func _config_source(source: ConfigFile) -> ConfigFile:
	return source


# =========================================================
# RESET CAŁEGO POSTĘPU
# =========================================================

## Usuwa wszystkie znane sekcje postępu.
## Ustawienia użytkownika pozostają zapisane.

func reset_all() -> void:
	clear_progress_sections()
	save_now()

