extends Node
## Runtime Style Pack manager. Downloads verified glTF/GLB models and dependencies from Poly Haven.
## All content is stored under user:// and never overwrites project assets.

signal catalog_updated(count: int)
signal status_changed(message: String)
signal download_progress(asset_id: String, downloaded: int, total: int)
signal pack_changed(asset_id: String, installed: bool)
signal download_confirmation_requested(asset_id: String, asset_name: String, package_bytes: int)

const API_ROOT: String = "https://api.polyhaven.com"
const ROOT_DIR: String = "user://content_packs/poly_haven"
const LICENSE_URL: String = "https://polyhaven.com/license"
const API_TERMS_URL: String = "https://polyhaven.com/our-api"
const APP_CREDIT: String = "Powered by Poly Haven"
const MAX_ASSET_CATALOG: int = 2500

var catalog: Array[Dictionary] = []
var _http: HTTPRequest
var _mode: String = "idle"
var _pending_asset: Dictionary = {}
var _download_queue: Array[Dictionary] = []
var _download_index: int = 0
var _asset_directory: String = ""
var _pending_asset_id: String = ""
var _download_path: String = ""
var _last_error: String = ""
var _pending_confirmation_bytes: int = 0
var _pending_model_validation: Dictionary = {}
var _installed: Dictionary = {}
var _loaded_templates: Dictionary = {}
var _kind_map: Dictionary = {}
var _obstacle_map: Dictionary = {}
var _dirt_map: Dictionary = {}
var _animal_map: Dictionary = {}
var _intro_seen: bool = false
var preferred_resolution: String = "1k"
var auto_pack_limit: int = 20
var _auto_pack_active: bool = false
var _auto_pack_queue: Array[String] = []
var _auto_pack_large_queue: Array[String] = []
var _auto_pack_large_phase: bool = false
var _auto_pack_total: int = 0
var _auto_pack_done: int = 0
var use_downloaded_models: bool = true
var downloaded_only_mode: bool = false
var auto_correct_proportions: bool = true
var _settings_path: String = "user://content_packs/style_pack_settings.json"

func _ready() -> void:
	_http = HTTPRequest.new()
	_http.timeout = 90.0
	_http.max_redirects = 10
	# The Poly Haven catalog is a large JSON response. In Godot, -1 means unlimited; 0 rejects any response body.
	_http.body_size_limit = -1
	add_child(_http)
	_http.request_completed.connect(_on_request_completed)
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(ROOT_DIR))
	_recover_staging()
	_load_settings()

func refresh_catalog() -> void:
	if _mode != "idle":
		status_changed.emit("Poczekaj na zakończenie bieżącego żądania.")
		return
	_mode = "catalog"
	_http.download_file = ""
	status_changed.emit("Pobieranie katalogu modeli Poly Haven…")
	var err: Error = _http.request(API_ROOT + "/assets?type=models", _api_headers(), HTTPClient.METHOD_GET)
	if err != OK:
		_fail("Nie udało się połączyć z API Poly Haven: " + error_string(err))

func search_catalog(query: String, limit: int = 100) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	var needle: String = query.strip_edges().to_lower()
	for asset: Dictionary in catalog:
		var haystack: String = (str(asset.get("name", "")) + " " + str(asset.get("id", "")) + " " + str(asset.get("category", "")) + " " + " ".join(PackedStringArray(asset.get("tags", [])))).to_lower()
		if needle.is_empty() or haystack.contains(needle):
			result.append(asset)
			if result.size() >= limit:
				break
	return result

func set_auto_pack_limit(value: int) -> void:
	auto_pack_limit = clampi(value, 1, 200)
	_save_settings()

func set_use_downloaded_models(value: bool) -> void:
	use_downloaded_models = true if downloaded_only_mode else value
	_save_settings()
	status_changed.emit("Generator używa %s." % ("pobranych modeli z możliwością modeli standardowych" if use_downloaded_models else "modeli standardowych"))

func set_downloaded_only_mode(value: bool) -> void:
	downloaded_only_mode = value
	if value:
		use_downloaded_models = true
	_save_settings()
	status_changed.emit("Tryb wyłącznie dodatkowych modeli %s." % ("włączony" if value else "wyłączony"))

func is_downloaded_only_mode() -> bool:
	return downloaded_only_mode

func get_preview_instance(asset_id: String) -> Node3D:
	var template: Node3D = _get_loaded_template(asset_id)
	if template == null:
		return null
	var instance: Node3D = template.duplicate() as Node3D
	if instance == null:
		return null
	instance.name = "StylePackPreview_%s" % asset_id
	_fit_model_to_dimensions(instance, Vector3(1.25, 1.25, 1.25), true)
	return instance

func start_auto_pack(limit: int = 20) -> void:
	if _mode != "idle" or _auto_pack_active:
		status_changed.emit("Poczekaj na zakończenie bieżącego pobierania.")
		return
	if catalog.is_empty():
		status_changed.emit("Najpierw odśwież katalog Poly Haven.")
		return
	auto_pack_limit = clampi(limit, 1, 200)
	_auto_pack_queue.clear()
	_auto_pack_large_queue.clear()
	_auto_pack_large_phase = false
	var candidates: Array[Dictionary] = []
	for asset: Dictionary in catalog:
		if _guess_kind_for_asset(asset).is_empty() and _guess_obstacle_for_asset(asset) < 0 and _guess_dirt_type_for_asset(asset) < 0 and _guess_animal_species(asset).is_empty():
			continue
		candidates.append(asset)
	candidates.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		return int(a.get("download_count", 0)) > int(b.get("download_count", 0))
	)
	for asset: Dictionary in candidates:
		_auto_pack_queue.append(str(asset.get("id", "")))
		if _auto_pack_queue.size() >= auto_pack_limit:
			break
	if _auto_pack_queue.is_empty():
		status_changed.emit("Nie znaleziono wystarczającej liczby pasujących modeli domowych. Możesz pobierać modele ręcznie.")
		return
	_auto_pack_active = true
	_auto_pack_total = _auto_pack_queue.size()
	_auto_pack_done = 0
	status_changed.emit("Pakiet Modern Home: przygotowano %d modeli. Rozpoczynam pobieranie kolejno…" % _auto_pack_total)
	_start_next_auto_pack_asset()

func _start_next_auto_pack_asset() -> void:
	var active_queue: Array[String] = _auto_pack_large_queue if _auto_pack_large_phase else _auto_pack_queue
	if active_queue.is_empty() and not _auto_pack_large_phase and not _auto_pack_large_queue.is_empty():
		_auto_pack_large_phase = true
		status_changed.emit("Wszystkie małe modele zostały obsłużone. Teraz kolejno zapytam o większe pakiety powyżej 10 MB.")
		active_queue = _auto_pack_large_queue
	while not active_queue.is_empty():
		var next_id: String = active_queue.pop_front()
		if _installed.has(next_id):
			_auto_pack_done += 1
			continue
		var asset: Dictionary = _find_asset(next_id)
		if asset.is_empty():
			_auto_pack_done += 1
			continue
		_pending_asset = asset
		_pending_asset_id = next_id
		_mode = "files"
		_http.download_file = ""
		status_changed.emit("Pakiet Modern Home %d/%d: %s" % [_auto_pack_done + 1, _auto_pack_total, str(asset.get("name", next_id))])
		var err: Error = _http.request(API_ROOT + "/v2/files/" + next_id.uri_encode(), _api_headers(), HTTPClient.METHOD_GET)
		if err != OK:
			_fail("Nie udało się rozpocząć pobierania pakietu: " + error_string(err))
		return
	_auto_pack_active = false
	_auto_pack_large_phase = false
	status_changed.emit("Pakiet Modern Home zakończony: obsłużono %d z %d modeli. Większe pakiety można było pominąć." % [_auto_pack_done, _auto_pack_total])

func _asset_search_text(asset: Dictionary) -> String:
	return (str(asset.get("name", "")) + " " + str(asset.get("id", "")) + " " + str(asset.get("category", "")) + " " + " ".join(PackedStringArray(asset.get("tags", [])))).to_lower()

func _guess_obstacle_for_asset(asset: Dictionary) -> int:
	var text: String = _asset_search_text(asset)
	if text.contains("pouf") or text.contains("cushion") or text.contains("bean bag") or text.contains("pillow"):
		return 0
	if text.contains("tin can") or text.contains("soda can") or text.contains("aluminium can") or text.contains("aluminum can") or text.contains("carton") or text.contains("package") or text.contains("bottle"):
		return 1
	if text.contains("toy") or text.contains("block") or text.contains("ball") or text.contains("doll") or text.contains("duck"):
		return 2
	if text.contains("shoe") or text.contains("slipper") or text.contains("sneaker"):
		return 3
	if text.contains("pet bowl") or text.contains("dog bowl") or text.contains("cat bowl") or text.contains("basket") or text.contains("book") or text.contains("box"):
		return 4
	return -1

func _guess_dirt_type_for_asset(asset: Dictionary) -> int:
	var text: String = _asset_search_text(asset)
	if text.contains("dust") or text.contains("dirt pile") or text.contains("dust bunny"):
		return 0
	if text.contains("crumb") or text.contains("food scrap") or text.contains("bread") or text.contains("cereal"):
		return 1
	if text.contains("pet hair") or text.contains("animal hair"):
		return 5
	if text.contains("lint") or text.contains("fluff") or text.contains("fur") or text.contains("hair"):
		return 2
	if text.contains("mud") or text.contains("muddy") or text.contains("soil"):
		return 3
	if text.contains("sand") or text.contains("gravel"):
		return 4
	if text.contains("spill") or text.contains("stain") or text.contains("coffee spill") or text.contains("juice") or text.contains("milk puddle") or text.contains("liquid puddle"):
		return 6
	return -1

func _guess_kind_for_asset(asset: Dictionary) -> String:
	var haystack: String = (str(asset.get("name", "")) + " " + str(asset.get("id", "")) + " " + str(asset.get("category", "")) + " " + " ".join(PackedStringArray(asset.get("tags", [])))).to_lower()
	var rules: Array = [
		["washing_machine", ["washing machine", "washer"]], ["bookshelf", ["bookshelf", "bookcase"]],
		["nightstand", ["nightstand", "bedside table"]], ["coffee_table", ["coffee table"]],
		["kitchen_counter", ["kitchen counter", "countertop"]], ["trash_bin", ["trash bin", "waste bin"]],
		["wardrobe", ["wardrobe", "closet"]], ["sofa", ["sofa", "couch"]], ["chair", ["chair", "armchair"]],
		["table", ["dining table", "table"]], ["cabinet", ["cabinet", "cupboard"]],
		["lamp", ["lamp", "light fixture"]], ["plant", ["plant", "potted plant"]],
		["fridge", ["fridge", "refrigerator"]], ["tv", ["television", "tv screen"]],
		["shoe", ["shoe", "sneaker"]], ["toy", ["toy", "teddy bear", "plush"]],
		["box", ["cardboard box", "storage box"]], ["pillow", ["pillow", "cushion"]],
		["rug", ["rug", "carpet"]], ["sink", ["sink", "washbasin"]],
		["cable", ["cable", "cord", "wire"]], ["mug", ["mug", "cup"]],
		["book", ["book", "books"]], ["remote", ["remote control"]],
		["paper_scrap", ["paper scrap", "crumpled paper", "paper ball"]],
		["food_scraps", ["food scraps", "crumbs", "spilled food", "cereal", "bread crumbs"]],
		["pet_bowl", ["pet bowl", "dog bowl", "cat bowl"]],
		["laundry_basket", ["laundry basket", "clothes basket"]]
	]
	for rule: Array in rules:
		var kind: String = str(rule[0])
		if not FurnitureModels.KINDS.has(kind):
			continue
		for token: String in rule[1]:
			if haystack.contains(token):
				return kind
	return ""

func confirm_pending_download(approved: bool) -> void:
	if _mode != "awaiting_confirmation":
		return
	if not approved:
		if _asset_directory.ends_with(".installing") and DirAccess.dir_exists_absolute(ProjectSettings.globalize_path(_asset_directory)):
			_remove_directory(_asset_directory)
		_mode = "idle"
		_http.download_file = ""
		_download_queue.clear()
		_pending_asset.clear()
		_pending_asset_id = ""
		_pending_model_validation.clear()
		_asset_directory = ""
		_download_path = ""
		_auto_pack_active = false
		_auto_pack_queue.clear()
		_auto_pack_large_queue.clear()
		_auto_pack_large_phase = false
		status_changed.emit("Pobieranie anulowane.")
		return
	_mode = "download"
	status_changed.emit("Rozpoczynam pobieranie zaakceptowanego pakietu…")
	_start_next_download()


func skip_pending_download() -> void:
	if _mode != "awaiting_confirmation":
		return
	var skipped_name: String = str(_pending_asset.get("name", _pending_asset_id))
	if _asset_directory.ends_with(".installing") and DirAccess.dir_exists_absolute(ProjectSettings.globalize_path(_asset_directory)):
		_remove_directory(_asset_directory)
	_mode = "idle"
	_http.download_file = ""
	_download_queue.clear()
	_pending_asset.clear()
	_pending_asset_id = ""
	_asset_directory = ""
	_download_path = ""
	if _auto_pack_active:
		_auto_pack_done += 1
		status_changed.emit("Pominięto duży model: %s. Przechodzę do następnego." % skipped_name)
		_start_next_auto_pack_asset()
	else:
		status_changed.emit("Pominięto pobieranie dużego modelu: %s." % skipped_name)


func download_asset(asset_id: String) -> void:
	if _mode != "idle":
		status_changed.emit("Inne pobieranie jest już aktywne.")
		return
	if not _is_safe_asset_id(asset_id):
		status_changed.emit("Nieprawidłowy identyfikator modelu.")
		return
	var asset: Dictionary = _find_asset(asset_id)
	if asset.is_empty():
		status_changed.emit("Najpierw odśwież katalog i wybierz istniejący model.")
		return
	if _guess_kind_for_asset(asset).is_empty() and _guess_obstacle_for_asset(asset) < 0 and _guess_dirt_type_for_asset(asset) < 0 and _guess_animal_species(asset).is_empty():
		status_changed.emit("Pominięto model przed pobraniem: nie rozpoznaję jego zastosowania ani bezpiecznej skali w Robot Racing.")
		return
	_pending_asset = asset
	_pending_asset_id = asset_id
	_mode = "files"
	_http.download_file = ""
	status_changed.emit("Sprawdzanie dostępnych plików: %s…" % str(asset.get("name", asset_id)))
	var err: Error = _http.request(API_ROOT + "/v2/files/" + asset_id.uri_encode(), _api_headers(), HTTPClient.METHOD_GET)
	if err != OK:
		_fail("Nie udało się pobrać listy plików: " + error_string(err))

func delete_pack(asset_id: String) -> bool:
	if not _is_safe_asset_id(asset_id) or not _installed.has(asset_id):
		return false
	if _mode != "idle":
		return false
	var dir_path: String = ROOT_DIR.path_join(asset_id)
	var absolute_root: String = ProjectSettings.globalize_path(ROOT_DIR).simplify_path()
	var absolute_target: String = ProjectSettings.globalize_path(dir_path).simplify_path()
	if not absolute_target.begins_with(absolute_root + "/") or not DirAccess.dir_exists_absolute(absolute_target):
		return false
	var manifest_path: String = dir_path.path_join("license_manifest.json")
	if not FileAccess.file_exists(manifest_path):
		status_changed.emit("Brak manifestu pakietu — odmowa usunięcia niezweryfikowanego folderu.")
		return false
	var manifest_file := FileAccess.open(manifest_path, FileAccess.READ)
	if manifest_file == null:
		return false
	var manifest: Variant = JSON.parse_string(manifest_file.get_as_text())
	manifest_file.close()
	if not manifest is Dictionary or str(manifest.get("id", "")) != asset_id or not bool(manifest.get("verified", false)):
		status_changed.emit("Manifest pakietu jest nieprawidłowy — odmowa usunięcia.")
		return false
	var err: Error = _remove_directory(dir_path)
	if err != OK:
		status_changed.emit("Nie udało się usunąć pakietu: " + error_string(err))
		return false
	_unassign_asset(asset_id)
	_installed.erase(asset_id)
	_save_settings()
	pack_changed.emit(asset_id, false)
	status_changed.emit("Usunięto pakiet: " + asset_id)
	return true


func delete_all_packs() -> bool:
	if _mode != "idle":
		status_changed.emit("Nie można usuwać pakietów podczas pobierania.")
		return false
	var ids: Array[String] = []
	for key: Variant in _installed.keys():
		ids.append(str(key))
	if ids.is_empty():
		status_changed.emit("Brak pobranych modeli do usunięcia.")
		return true
	var failed: Array[String] = []
	for asset_id: String in ids:
		if not delete_pack(asset_id):
			failed.append(asset_id)
	if failed.is_empty():
		status_changed.emit("Usunięto wszystkie pobrane modele (%d)." % ids.size())
		return true
	status_changed.emit("Nie udało się usunąć %d pakietów: %s" % [failed.size(), ", ".join(failed)])
	return false


func _unassign_asset(asset_id: String) -> void:
	if _loaded_templates.has(asset_id):
		var old_template: Node = _loaded_templates[asset_id]
		if is_instance_valid(old_template): old_template.free()
		_loaded_templates.erase(asset_id)
	for kind: String in _kind_map.keys():
		var mapped: Variant = _kind_map[kind]
		if mapped is Array:
			var kept: Array = []
			for mapped_id: Variant in mapped:
				if str(mapped_id) != asset_id: kept.append(mapped_id)
			if kept.is_empty(): _kind_map.erase(kind)
			else: _kind_map[kind] = kept
		elif str(mapped) == asset_id:
			_kind_map.erase(kind)
	for obstacle_id: String in _obstacle_map.keys():
		if str(_obstacle_map[obstacle_id]) == asset_id: _obstacle_map.erase(obstacle_id)
	for dirt_id: String in _dirt_map.keys():
		if str(_dirt_map[dirt_id]) == asset_id: _dirt_map.erase(dirt_id)
	for animal_id: String in _animal_map.keys():
		if str(_animal_map[animal_id]) == asset_id: _animal_map.erase(animal_id)

func assign_asset_to_kind(asset_id: String, kind: String) -> bool:
	if not _is_geometry_validated(asset_id) or not FurnitureModels.KINDS.has(kind):
		return false
	var previous_map: Dictionary = _kind_map.duplicate(true)
	_kind_map[kind] = asset_id
	if not _save_settings():
		_kind_map = previous_map
		return false
	status_changed.emit("Model %s przypisano do kategorii %s." % [asset_id, kind])
	return true

func has_kind_asset(kind: String) -> bool:
	var mapped: Variant = _kind_map.get(kind, "")
	if mapped is Array:
		for asset_id: Variant in mapped:
			if _installed.has(str(asset_id)):
				return true
		return false
	return _installed.has(str(mapped))

func has_obstacle_asset(obstacle_index: int) -> bool:
	return _installed.has(str(_obstacle_map.get(str(obstacle_index), "")))

func get_asset_for_kind(kind: String) -> String:
	if not use_downloaded_models:
		return ""
	var mapped: Variant = _kind_map.get(kind, "")
	if mapped is Array:
		var choices: Array = mapped
		if choices.is_empty(): return ""
		return str(choices[randi_range(0, choices.size() - 1)])
	return str(mapped)

func instantiate_for_kind(kind: String) -> Node3D:
	var asset_id: String = get_asset_for_kind(kind)
	if not _is_geometry_validated(asset_id): return null
	var template: Node3D = _get_loaded_template(asset_id)
	if template == null: return null
	var instance: Node3D = template.duplicate() as Node3D
	if instance == null: return null
	instance.name = "StylePack_%s" % asset_id
	_fit_model_to_kind(instance, kind)
	return instance

func assign_obstacle_asset(asset_id: String, obstacle_index: int) -> bool:
	if not _is_geometry_validated(asset_id) or obstacle_index < 0 or obstacle_index >= ObstacleModels.KIND_COUNT:
		return false
	var previous_map: Dictionary = _obstacle_map.duplicate(true)
	_obstacle_map[str(obstacle_index)] = asset_id
	if not _save_settings():
		_obstacle_map = previous_map
		return false
	status_changed.emit("Model %s przypisano do przeszkody %d." % [asset_id, obstacle_index + 1])
	return true

func assign_dirt_asset(asset_id: String, dirt_type: int) -> bool:
	if not _is_geometry_validated(asset_id) or dirt_type < 0 or dirt_type >= 7:
		return false
	var previous_map: Dictionary = _dirt_map.duplicate(true)
	_dirt_map[str(dirt_type)] = asset_id
	if not _save_settings():
		_dirt_map = previous_map
		return false
	status_changed.emit("Model %s przypisano do zabrudzenia %d." % [asset_id, dirt_type + 1])
	return true

func instantiate_dirt(dirt_type: int) -> Node3D:
	if not use_downloaded_models and not downloaded_only_mode:
		return null
	var asset_id: String = str(_dirt_map.get(str(dirt_type), ""))
	if not _is_geometry_validated(asset_id): return null
	var template: Node3D = _get_loaded_template(asset_id)
	if template == null:
		return null
	var instance: Node3D = template.duplicate() as Node3D
	if instance == null:
		return null
	instance.name = "StylePack_Dirt_%d" % dirt_type
	_fit_model_to_dimensions(instance, Vector3(0.32, 0.12, 0.32), true)
	return instance

func assign_animal_asset(asset_id: String, species: String) -> bool:
	if not _is_geometry_validated(asset_id) or not AnimalModels.SPECIES.has(species):
		return false
	var template: Node3D = _get_loaded_template(asset_id)
	if template == null:
		status_changed.emit("Nie udało się wczytać modelu zwierzęcia.")
		return false
	var animation_player: AnimationPlayer = _find_animation_player(template)
	if animation_player == null or animation_player.get_animation_list().is_empty():
		status_changed.emit("Ten model nie zawiera animacji. Wybierz animowany model glTF/GLB.")
		return false
	var previous_map: Dictionary = _animal_map.duplicate(true)
	_animal_map[species] = asset_id
	if not _save_settings():
		_animal_map = previous_map
		return false
	status_changed.emit("Animowany model przypisano do zwierzęcia: %s." % species)
	return true


func instantiate_animal(species: String) -> Node3D:
	if not use_downloaded_models:
		return null
	var asset_id: String = str(_animal_map.get(species, ""))
	if not _is_geometry_validated(asset_id): return null
	var template: Node3D = _get_loaded_template(asset_id)
	if template == null:
		return null
	var instance: Node3D = template.duplicate() as Node3D
	if instance == null:
		return null
	instance.name = "StylePack_Animal_%s" % species
	var dimensions: Dictionary = {
		"cat": Vector3(0.95, 1.35, 1.15), "dog": Vector3(1.25, 1.45, 1.65),
		"rabbit": Vector3(0.85, 1.35, 0.95), "bearded_dragon": Vector3(1.15, 0.55, 1.25),
		"parrot": Vector3(0.85, 1.75, 0.85)
	}
	_fit_model_to_dimensions(instance, dimensions.get(species, Vector3.ONE), true)
	var player: AnimationPlayer = _find_animation_player(instance)
	if player != null:
		var animations: PackedStringArray = player.get_animation_list()
		var selected_animation: StringName = &""
		for animation_name: String in animations:
			if animation_name.to_upper() != "RESET":
				selected_animation = StringName(animation_name)
				break
		if selected_animation == &"" and not animations.is_empty():
			selected_animation = StringName(animations[0])
		if selected_animation != &"":
			player.autoplay = selected_animation
			if player.is_inside_tree(): player.play(selected_animation)
	return instance


func _find_animation_player(root: Node) -> AnimationPlayer:
	if root is AnimationPlayer and not (root as AnimationPlayer).get_animation_list().is_empty():
		return root as AnimationPlayer
	for child: Node in root.get_children():
		var found: AnimationPlayer = _find_animation_player(child)
		if found != null:
			return found
	return null


func _is_geometry_validated(asset_id: String) -> bool:
	if not _installed.has(asset_id):
		return false
	return bool(_installed[asset_id].get("geometry_validated", false))


func _guess_animal_species(asset: Dictionary) -> String:
	var text: String = _asset_search_text(asset)
	var species_rules: Array = [
		["cat", ["cat", "kitten"]], ["dog", ["dog", "puppy"]],
		["rabbit", ["rabbit", "bunny"]], ["bearded_dragon", ["bearded dragon"]],
		["parrot", ["parrot"]], ["hamster", ["hamster"]],
		["guinea_pig", ["guinea pig"]], ["turtle", ["turtle"]],
		["hedgehog", ["hedgehog"]], ["ferret", ["ferret"]]
	]
	for rule: Array in species_rules:
		for token: String in rule[1]:
			if text.contains(token): return str(rule[0])
	return ""


func _validate_downloaded_model(document: GLTFDocument, state: GLTFState) -> Dictionary:
	var scene_root: Node = document.generate_scene(state)
	if not scene_root is Node3D:
		if is_instance_valid(scene_root): scene_root.free()
		return {"valid": false, "reason": "plik nie zawiera poprawnego modelu 3D."}
	var bounds: AABB = _collect_bounds(scene_root as Node3D, scene_root)
	scene_root.free()
	var dimensions: Vector3 = bounds.size
	if dimensions.x <= 0.0001 or dimensions.y <= 0.0001 or dimensions.z <= 0.0001:
		return {"valid": false, "reason": "nie można wiarygodnie ustalić wszystkich wymiarów modelu."}
	if dimensions.x > 20.0 or dimensions.y > 20.0 or dimensions.z > 20.0:
		return {"valid": false, "reason": "model ma ponad 20 m w co najmniej jednym wymiarze; prawdopodobnie ma błędną skalę."}
	var smallest: float = minf(dimensions.x, minf(dimensions.y, dimensions.z))
	var largest: float = maxf(dimensions.x, maxf(dimensions.y, dimensions.z))
	if largest / smallest > 500.0:
		return {"valid": false, "reason": "proporcje modelu są skrajne; nie da się bezpiecznie dobrać jego skali."}
	var kind: String = _guess_kind_for_asset(_pending_asset)
	var obstacle: int = _guess_obstacle_for_asset(_pending_asset)
	var dirt: int = _guess_dirt_type_for_asset(_pending_asset)
	var animal_species: String = _guess_animal_species(_pending_asset)
	if kind.is_empty() and obstacle < 0 and dirt < 0 and animal_species.is_empty():
		return {"valid": false, "reason": "nie można rozpoznać przeznaczenia modelu, więc nie przypiszę mu przypadkowej skali."}
	return {"valid": true, "dimensions": [snappedf(dimensions.x, 0.001), snappedf(dimensions.y, 0.001), snappedf(dimensions.z, 0.001)], "note": "Wymiary odczytane z geometrii glTF; model będzie skalowany proporcjonalnie i oparty dolną krawędzią na powierzchni."}


func get_installed_asset_info(asset_id: String) -> Dictionary:
	return _installed.get(asset_id, {}).duplicate(true)

func get_dirt_asset_id(dirt_type: int) -> String:
	return str(_dirt_map.get(str(dirt_type), ""))

func instantiate_obstacle(obstacle_index: int, radius: float, height: float) -> Node3D:
	if not use_downloaded_models and not downloaded_only_mode:
		return null
	var asset_id: String = str(_obstacle_map.get(str(obstacle_index), ""))
	if not _is_geometry_validated(asset_id): return null
	var template: Node3D = _get_loaded_template(asset_id)
	if template == null: return null
	var instance: Node3D = template.duplicate() as Node3D
	if instance == null: return null
	instance.name = "StylePack_Obstacle_%d" % obstacle_index
	_fit_model_to_dimensions(instance, Vector3(radius * 2.0, height * 1.35, radius * 2.0), true)
	return instance

func _get_loaded_template(asset_id: String) -> Node3D:
	if asset_id.is_empty() or not _installed.has(asset_id): return null
	var model_path: String = str(_installed[asset_id].get("model_path", ""))
	if not FileAccess.file_exists(model_path): return null
	var template: Node3D = _loaded_templates.get(asset_id) as Node3D
	if is_instance_valid(template): return template
	var document := GLTFDocument.new()
	var state := GLTFState.new()
	var load_error: Error = document.append_from_file(model_path, state)
	if load_error != OK:
		push_warning("StylePack: nie można wczytać %s: %s" % [asset_id, error_string(load_error)])
		return null
	var loaded_root: Node = document.generate_scene(state)
	if not loaded_root is Node3D:
		if is_instance_valid(loaded_root): loaded_root.free()
		return null
	template = loaded_root as Node3D
	_loaded_templates[asset_id] = template
	return template


func get_installed_assets() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for asset_id: String in _installed.keys():
		var entry: Dictionary = _installed[asset_id].duplicate(true)
		entry["id"] = asset_id
		result.append(entry)
	return result

func get_status_text() -> String:
	return "%d modeli w katalogu • %d pobranych" % [catalog.size(), _installed.size()]

func should_show_intro() -> bool:
	return not _intro_seen

func mark_intro_seen() -> void:
	_intro_seen = true
	_save_settings()

func set_auto_correct_proportions(value: bool) -> void:
	auto_correct_proportions = value
	_save_settings()
	status_changed.emit("Automatyczna korekta proporcji %s." % ("włączona" if value else "wyłączona"))

func set_preferred_resolution(value: String) -> void:
	var previous_resolution: String = preferred_resolution
	preferred_resolution = "2k" if value.to_lower() == "2k" else "1k"
	if not _save_settings(): preferred_resolution = previous_resolution

func _on_request_completed(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300:
		var response_text: String = body.get_string_from_utf8().strip_edges()
		if response_text.length() > 240: response_text = response_text.substr(0, 240)
		_fail("Błąd sieci/API (HTTP %d, kod %d)%s. Sprawdź połączenie i spróbuj ponownie." % [response_code, result, ": " + response_text if not response_text.is_empty() else ""])
		return
	match _mode:
		"catalog":
			var parsed: Variant = JSON.parse_string(body.get_string_from_utf8())
			if not parsed is Dictionary:
				_fail("API zwróciło nieprawidłowy katalog modeli.")
				return
			catalog.clear()
			for id: Variant in parsed.keys():
				var item: Dictionary = parsed[id]
				if int(item.get("type", 2)) != 2: continue
				item = item.duplicate(true)
				item["id"] = str(id)
				catalog.append(item)
				if catalog.size() >= MAX_ASSET_CATALOG: break
			catalog.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
				return int(a.get("download_count", 0)) > int(b.get("download_count", 0))
			)
			_mode = "idle"
			status_changed.emit("Katalog Poly Haven gotowy. " + get_status_text())
			catalog_updated.emit(catalog.size())
		"files":
			var parsed_files: Variant = JSON.parse_string(body.get_string_from_utf8())
			if parsed_files is Dictionary and parsed_files.has("data") and parsed_files["data"] is Dictionary:
				parsed_files = parsed_files["data"]
			if not parsed_files is Dictionary:
				_fail("Nieprawidłowa odpowiedź z listą plików modelu.")
				return
			var model_file: Dictionary = _find_model_file(parsed_files)
			if model_file.is_empty():
				_fail("API v2 nie zwróciło pliku glTF/GLB dla modelu %s. Sprawdź, czy wybrany zasób udostępnia format glTF." % _pending_asset_id)
				return
			_asset_directory = ROOT_DIR.path_join(_pending_asset_id + ".installing")
			if DirAccess.dir_exists_absolute(ProjectSettings.globalize_path(_asset_directory)):
				_remove_directory(_asset_directory)
			DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(_asset_directory))
			_download_queue.clear()
			_download_index = 0
			var main_url: String = str(model_file.get("url", ""))
			var main_name: String = _safe_relative_path(_url_basename(main_url))
			if main_name.is_empty() or main_name.contains("/") or not _is_trusted_download_url(main_url):
				_fail("API zwróciło plik bez poprawnej nazwy.")
				return
			_download_path = _asset_directory.path_join(main_name)
			_download_queue.append({"url": main_url, "size": int(model_file.get("size", 0)), "md5": str(model_file.get("md5", "")), "rel_path": main_name, "_api_path": str(model_file.get("_api_path", ""))})
			var includes: Variant = model_file.get("include", {})
			if includes is Dictionary:
				for rel_path: Variant in includes.keys():
					var dependency: Variant = includes[rel_path]
					if not dependency is Dictionary: continue
					var safe_rel_path: String = _safe_relative_path(str(rel_path))
					if safe_rel_path.is_empty() or not _is_trusted_download_url(str(dependency.get("url", ""))):
						_fail("API zwróciło niebezpieczną ścieżkę zależności. Pobieranie przerwane.")
						return
					_download_queue.append({"url": str(dependency.get("url", "")), "size": int(dependency.get("size", 0)), "md5": str(dependency.get("md5", "")), "rel_path": safe_rel_path})
			if _download_queue.is_empty():
				_fail("Brak plików do pobrania.")
				return
			var package_bytes: int = 0
			for queued_file: Dictionary in _download_queue: package_bytes += int(queued_file.get("size", 0))	
			if package_bytes > 10 * 1024 * 1024:
				if _auto_pack_active and not _auto_pack_large_phase:
					# Najpierw pobierz wszystkie małe modele; duże zostaw na osobną kolejkę decyzji.
					_auto_pack_large_queue.append(_pending_asset_id)
					if _asset_directory.ends_with(".installing") and DirAccess.dir_exists_absolute(ProjectSettings.globalize_path(_asset_directory)):
						_remove_directory(_asset_directory)
					_mode = "idle"
					_http.download_file = ""
					_download_queue.clear()
					_pending_asset.clear()
					_pending_asset_id = ""
					_asset_directory = ""
					_download_path = ""
					_start_next_auto_pack_asset()
					return
				_pending_confirmation_bytes = package_bytes
				_mode = "awaiting_confirmation"
				download_confirmation_requested.emit(_pending_asset_id, str(_pending_asset.get("name", _pending_asset_id)), package_bytes)
				status_changed.emit("Pakiet przekracza 10 MB — wybierz pobranie albo pominięcie.")
				return
			_mode = "download"
			status_changed.emit("Pobieranie %s: %d plików, %s (model + zależności)…" % [str(_pending_asset.get("name", _pending_asset_id)), _download_queue.size(), _format_bytes(package_bytes)])
			_start_next_download()
		"download":
			var current: Dictionary = _download_queue[_download_index]
			var temp_path: String = _asset_directory.path_join(str(current["rel_path"])) + ".part"
			var final_path: String = _asset_directory.path_join(str(current["rel_path"]))
			var expected_size: int = int(current.get("size", 0))
			var actual_size: int = 0
			if FileAccess.file_exists(temp_path):
				var size_file := FileAccess.open(temp_path, FileAccess.READ)
				if size_file != null:
					actual_size = size_file.get_length()
					size_file.close()
			if expected_size <= 0 or actual_size != expected_size:
				_fail("Plik %s ma nieprawidłowy rozmiar. Pakiet odrzucono." % str(current["rel_path"]))
				return
			var expected_md5: String = str(current.get("md5", "")).to_lower()
			var actual_md5: String = FileAccess.get_md5(temp_path).to_lower()
			if expected_md5.length() != 32 or actual_md5 != expected_md5:
				_fail("Suma kontrolna pliku %s nie pasuje. Pakiet odrzucono." % str(current["rel_path"]))
				return
			var rename_error: Error = DirAccess.rename_absolute(ProjectSettings.globalize_path(temp_path), ProjectSettings.globalize_path(final_path))
			if rename_error != OK:
				_fail("Nie udało się zapisać pliku %s: %s" % [str(current["rel_path"]), error_string(rename_error)])
				return
			_download_index += 1
			if _download_index < _download_queue.size():
				_start_next_download()
				return
			var gltf_check := GLTFDocument.new()
			var gltf_state := GLTFState.new()
			gltf_state.base_path = ProjectSettings.globalize_path(_asset_directory)
			var gltf_error: Error = gltf_check.append_from_file(ProjectSettings.globalize_path(_download_path), gltf_state)
			if gltf_error != OK:
				_fail("Pobrany zestaw nie jest poprawnym modelem glTF: " + error_string(gltf_error))
				return
			# Model musi przejść kontrolę geometrii przed instalacją i przypisaniem do gry.
			var validation: Dictionary = _validate_downloaded_model(gltf_check, gltf_state)
			if not bool(validation.get("valid", false)):
				_fail("Model odrzucony przed instalacją: " + str(validation.get("reason", "nieznane wymiary lub geometria")))
				return
			_pending_model_validation = validation
			var total_size: int = 0
			var combined_hashes: PackedStringArray = PackedStringArray()
			for file_entry: Dictionary in _download_queue:
				total_size += int(file_entry.get("size", 0))
				combined_hashes.append(str(file_entry.get("md5", "")))
			var final_directory: String = ROOT_DIR.path_join(_pending_asset_id)
			var backup_directory: String = ROOT_DIR.path_join(_pending_asset_id + ".backup")
			if DirAccess.dir_exists_absolute(ProjectSettings.globalize_path(backup_directory)):
				_remove_directory(backup_directory)
			var had_previous: bool = DirAccess.dir_exists_absolute(ProjectSettings.globalize_path(final_directory))
			if had_previous:
				var backup_error: Error = DirAccess.rename_absolute(ProjectSettings.globalize_path(final_directory), ProjectSettings.globalize_path(backup_directory))
				if backup_error != OK:
					_fail("Nie udało się zabezpieczyć poprzedniej wersji modelu: " + error_string(backup_error))
					return
			var commit_error: Error = DirAccess.rename_absolute(ProjectSettings.globalize_path(_asset_directory), ProjectSettings.globalize_path(final_directory))
			if commit_error != OK:
				if had_previous:
					DirAccess.rename_absolute(ProjectSettings.globalize_path(backup_directory), ProjectSettings.globalize_path(final_directory))
				_fail("Nie udało się zainstalować pakietu: " + error_string(commit_error))
				return
			_asset_directory = final_directory
			_download_path = _asset_directory.path_join(_url_basename(str(_download_queue[0].get("url", ""))))
			if not _install_manifest(total_size, ",".join(combined_hashes)):
				_remove_directory(final_directory)
				if had_previous:
					DirAccess.rename_absolute(ProjectSettings.globalize_path(backup_directory), ProjectSettings.globalize_path(final_directory))
				_fail("Nie udało się zapisać manifestu licencji. Poprzednia wersja została przywrócona.")
				return
			if _loaded_templates.has(_pending_asset_id):
				var previous_template: Node = _loaded_templates[_pending_asset_id]
				if is_instance_valid(previous_template): previous_template.free()
				_loaded_templates.erase(_pending_asset_id)
			if had_previous and DirAccess.dir_exists_absolute(ProjectSettings.globalize_path(backup_directory)):
				_remove_directory(backup_directory)
			var installed_id: String = _pending_asset_id
			var installed_name: String = str(_pending_asset.get("name", installed_id))
			var guessed_kind: String = _guess_kind_for_asset(_pending_asset)
			if _auto_pack_active:
				if not guessed_kind.is_empty():
					var mapped_models: Array = []
					var previous_mapping: Variant = _kind_map.get(guessed_kind, [])
					if previous_mapping is Array: mapped_models = previous_mapping.duplicate()
					elif not str(previous_mapping).is_empty(): mapped_models.append(str(previous_mapping))
					if not mapped_models.has(installed_id): mapped_models.append(installed_id)
					_kind_map[guessed_kind] = mapped_models
				var obstacle_guess: int = _guess_obstacle_for_asset(_pending_asset)
				if obstacle_guess >= 0 and not _obstacle_map.has(str(obstacle_guess)):
					_obstacle_map[str(obstacle_guess)] = installed_id
				var dirt_guess: int = _guess_dirt_type_for_asset(_pending_asset)
				if dirt_guess >= 0 and not _dirt_map.has(str(dirt_guess)):
					_dirt_map[str(dirt_guess)] = installed_id
				_save_settings()
			_mode = "idle"
			_http.download_file = ""
			status_changed.emit("Zainstalowano %s (%d plików)%s." % [installed_name, _download_queue.size(), " i przypisano do: " + guessed_kind if not guessed_kind.is_empty() and _auto_pack_active else ""])
			pack_changed.emit(installed_id, true)
			_pending_asset.clear()
			_pending_asset_id = ""
			_pending_model_validation.clear()
			_download_path = ""
			_asset_directory = ""
			_download_queue.clear()
			_http.download_file = ""
			if _auto_pack_active:
				_auto_pack_done += 1
				_start_next_auto_pack_asset()
		_:
			_mode = "idle"

func _process(_delta: float) -> void:
	if _mode == "download" and _http != null and _download_index < _download_queue.size():
		var current: Dictionary = _download_queue[_download_index]
		var total: int = int(current.get("size", 0))
		var completed: int = 0
		for i: int in range(_download_index): completed += int(_download_queue[i].get("size", 0))
		var all_total: int = 0
		for entry: Dictionary in _download_queue: all_total += int(entry.get("size", 0))
		download_progress.emit(_pending_asset_id, completed + _http.get_downloaded_bytes(), all_total if all_total > 0 else total)

func _format_bytes(value: int) -> String:
	if value < 1024: return "%d B" % value
	if value < 1048576: return "%.1f KB" % (float(value) / 1024.0)
	return "%.2f MB" % (float(value) / 1048576.0)

func _api_headers() -> PackedStringArray:
	return PackedStringArray(["User-Agent: RobotRacing/0.3 (StylePackManager)", "Accept: application/json"])


func _start_next_download() -> void:
	if _download_index >= _download_queue.size(): return
	var current: Dictionary = _download_queue[_download_index]
	var final_path: String = _asset_directory.path_join(str(current["rel_path"]))
	var temp_path: String = final_path + ".part"
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(final_path.get_base_dir()))
	if FileAccess.file_exists(temp_path): DirAccess.remove_absolute(ProjectSettings.globalize_path(temp_path))
	_http.download_file = ProjectSettings.globalize_path(temp_path)
	var download_url: String = str(current.get("url", ""))
	if not _is_trusted_download_url(download_url):
		_fail("Odrzucono niezatwierdzony adres pobierania.")
		return
	var err: Error = _http.request(download_url, PackedStringArray(["User-Agent: RobotRacing/0.3 (StylePackManager)"]))
	if err != OK: _fail("Nie udało się rozpocząć pobierania %s: %s" % [str(current["rel_path"]), error_string(err)])

func _find_model_file(value: Variant) -> Dictionary:
	var found: Array[Dictionary] = []
	_collect_model_files(value, "", found)
	if found.is_empty(): return {}
	found.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		var a_path: String = str(a.get("_api_path", "")).to_lower()
		var b_path: String = str(b.get("_api_path", "")).to_lower()
		var a_preferred: bool = a_path.contains(preferred_resolution)
		var b_preferred: bool = b_path.contains(preferred_resolution)
		if a_preferred != b_preferred: return a_preferred
		var a_1k: bool = a_path.contains("1k")
		var b_1k: bool = b_path.contains("1k")
		if a_1k != b_1k: return a_1k
		var a_glb: bool = str(a.get("url", "")).to_lower().split("?")[0].ends_with(".glb")
		var b_glb: bool = str(b.get("url", "")).to_lower().split("?")[0].ends_with(".glb")
		if a_glb != b_glb: return a_glb
		return int(a.get("size", 0)) < int(b.get("size", 0))
	)
	return found[0]

func _collect_model_files(value: Variant, api_path: String, found: Array[Dictionary]) -> void:
	if value is Dictionary:
		var url: String = str(value.get("url", ""))
		var clean_url: String = url.to_lower().split("?")[0].split("#")[0]
		var lower_api_path: String = api_path.to_lower()
		var is_gltf_path: bool = clean_url.ends_with(".glb") or clean_url.ends_with(".gltf") or lower_api_path.contains("/gltf/")
		if is_gltf_path and (clean_url.ends_with(".glb") or clean_url.ends_with(".gltf")) and value.has("size") and value.has("md5"):
			var entry: Dictionary = value.duplicate(true)
			entry["_api_path"] = api_path
			found.append(entry)
		for key: Variant in value.keys():
			if key == "include": continue
			_collect_model_files(value[key], api_path + "/" + str(key), found)
	elif value is Array:
		for child: Variant in value: _collect_model_files(child, api_path, found)

func _is_trusted_download_url(url: String) -> bool:
	var parsed: String = url.to_lower()
	return parsed.begins_with("https://dl.polyhaven.org/") or parsed.begins_with("https://cdn.polyhaven.com/") or parsed.begins_with("https://assets.polyhaven.com/")

func _url_basename(url: String) -> String:
	var clean: String = url.split("?")[0]
	return clean.get_file().uri_decode()

func _safe_relative_path(path: String) -> String:
	var normalized: String = path.replace("\\", "/")
	if normalized.begins_with("/") or normalized.contains(":"): return ""
	for segment: String in normalized.split("/"):
		if segment == ".." or segment == "." or segment.is_empty(): return ""
	return normalized

func _get_selected_resolution_label() -> String:
	var api_path: String = str(_download_queue[0].get("_api_path", "")).to_lower() if not _download_queue.is_empty() else ""
	if api_path.contains("2k"): return "2K"
	if api_path.contains("1k"): return "1K"
	return "najmniejszy dostępny wariant API"

func _install_manifest(file_size: int, md5: String) -> bool:
	var authors: Dictionary = _pending_asset.get("authors", {})
	var author_names: PackedStringArray = PackedStringArray()
	for author: Variant in authors.keys(): author_names.append(str(author))
	var asset_id: String = _pending_asset_id
	var manifest: Dictionary = {
		"id": asset_id,
		"name": str(_pending_asset.get("name", asset_id)),
		"source": "Poly Haven",
		"source_url": "https://polyhaven.com/a/" + asset_id,
		"author": ", ".join(author_names),
		"license": "CC0 1.0 Universal",
		"license_url": LICENSE_URL,
		"cc0_legal_text_url": "https://creativecommons.org/publicdomain/zero/1.0/",
		"api_terms_url": API_TERMS_URL,
		"api_implementation_license": "AGPL-3.0 (API server code; not bundled with the game)",
		"attribution": APP_CREDIT,
		"asset_category": str(_pending_asset.get("category", "")),
		"asset_description": str(_pending_asset.get("description", "")),
		"asset_tags": _pending_asset.get("tags", []),
		"style_pack": "Modern Home (user-curated)",
		"texture_resolution": _get_selected_resolution_label(),
		"file": _download_path,
		"files": _download_queue.duplicate(true),
		"size_bytes": file_size,
		"md5_list": md5,
		"verified": true,
		"geometry_validated": bool(_pending_model_validation.get("valid", false)),
		"model_dimensions_m": _pending_model_validation.get("dimensions", [0.0, 0.0, 0.0]),
		"model_grounded_on_import": true,
		"model_validation_note": str(_pending_model_validation.get("note", "")),
		"downloaded_at_utc": Time.get_datetime_string_from_system(true, true)
	}
	var json_text: String = JSON.stringify(manifest, "  ")
	var f := FileAccess.open(ROOT_DIR.path_join(asset_id).path_join("license_manifest.json"), FileAccess.WRITE)
	if f == null:
		return false
	f.store_string(json_text)
	f.close()
	var previous_installed: Dictionary = _installed.duplicate(true)
	_installed[asset_id] = {"name": manifest["name"], "model_path": _download_path, "model_base_path": ProjectSettings.globalize_path(_asset_directory), "size_bytes": file_size, "license": manifest["license"], "author": manifest["author"], "source_url": manifest["source_url"], "resolution": manifest["texture_resolution"], "geometry_validated": bool(manifest["geometry_validated"]), "model_dimensions_m": manifest["model_dimensions_m"], "model_grounded_on_import": true}
	if not _save_settings():
		_installed = previous_installed
		return false
	return true

func _is_safe_asset_id(asset_id: String) -> bool:
	if asset_id.is_empty() or asset_id.length() > 100: return false
	for character: String in asset_id:
		var code: int = character.unicode_at(0)
		var allowed: bool = (code >= 48 and code <= 57) or (code >= 65 and code <= 90) or (code >= 97 and code <= 122) or code == 45 or code == 95
		if not allowed: return false
	return true

func _find_asset(asset_id: String) -> Dictionary:
	for item: Dictionary in catalog:
		if str(item.get("id", "")) == asset_id: return item
	return {}

func _recover_staging() -> void:
	var root_absolute: String = ProjectSettings.globalize_path(ROOT_DIR)
	var dir := DirAccess.open(root_absolute)
	if dir == null: return
	var entries: Array[String] = []
	dir.list_dir_begin()
	var item: String = dir.get_next()
	while not item.is_empty():
		if dir.current_is_dir() and item != "." and item != "..": entries.append(item)
		item = dir.get_next()
	dir.list_dir_end()
	for entry: String in entries:
		if entry.ends_with(".installing"):
			_remove_directory(ROOT_DIR.path_join(entry))
		elif entry.ends_with(".backup"):
			var asset_id: String = entry.trim_suffix(".backup")
			var backup_path: String = ROOT_DIR.path_join(entry)
			var final_path: String = ROOT_DIR.path_join(asset_id)
			if not DirAccess.dir_exists_absolute(ProjectSettings.globalize_path(final_path)):
				DirAccess.rename_absolute(ProjectSettings.globalize_path(backup_path), ProjectSettings.globalize_path(final_path))
			elif not FileAccess.file_exists(final_path.path_join("license_manifest.json")):
				_remove_directory(final_path)
				DirAccess.rename_absolute(ProjectSettings.globalize_path(backup_path), ProjectSettings.globalize_path(final_path))
			else:
				_remove_directory(backup_path)

func _load_settings() -> void:
	if FileAccess.file_exists(_settings_path):
		var f := FileAccess.open(_settings_path, FileAccess.READ)
		if f != null:
			var data: Variant = JSON.parse_string(f.get_as_text())
			f.close()
			if data is Dictionary:
				_installed = data.get("installed", {})
				_kind_map = data.get("kind_map", {})
				_obstacle_map = data.get("obstacle_map", {})
				_dirt_map = data.get("dirt_map", {})
				_animal_map = data.get("animal_map", {})
				_intro_seen = bool(data.get("intro_seen", false))
				preferred_resolution = "2k" if str(data.get("preferred_resolution", "1k")).to_lower() == "2k" else "1k"
				auto_pack_limit = clampi(int(data.get("auto_pack_limit", 20)), 1, 200)
				use_downloaded_models = bool(data.get("use_downloaded_models", true))
				downloaded_only_mode = bool(data.get("downloaded_only_mode", false))
				auto_correct_proportions = bool(data.get("auto_correct_proportions", true))
				if downloaded_only_mode:
					use_downloaded_models = true
				for id: String in _installed.keys():
					var model_path: String = str(_installed[id].get("model_path", ""))
					if not FileAccess.file_exists(model_path): _installed.erase(id)
	_rebuild_installed_from_manifests()

func _rebuild_installed_from_manifests() -> void:
	var root_absolute: String = ProjectSettings.globalize_path(ROOT_DIR)
	var dir := DirAccess.open(root_absolute)
	if dir == null: return
	var folders: Array[String] = []
	dir.list_dir_begin()
	var item: String = dir.get_next()
	while not item.is_empty():
		if dir.current_is_dir() and item != "." and item != ".." and not item.ends_with(".backup") and not item.ends_with(".installing"):
			folders.append(item)
		item = dir.get_next()
	dir.list_dir_end()
	var changed: bool = false
	for asset_id: String in folders:
		if not _is_safe_asset_id(asset_id): continue
		var manifest_path: String = ROOT_DIR.path_join(asset_id).path_join("license_manifest.json")
		if not FileAccess.file_exists(manifest_path): continue
		var manifest_file := FileAccess.open(manifest_path, FileAccess.READ)
		if manifest_file == null: continue
		var manifest: Variant = JSON.parse_string(manifest_file.get_as_text())
		manifest_file.close()
		if not manifest is Dictionary or not bool(manifest.get("verified", false)): continue
		var model_path: String = str(manifest.get("file", ""))
		if model_path.is_empty() or not FileAccess.file_exists(model_path): continue
		if not _installed.has(asset_id):
			_installed[asset_id] = {"name": str(manifest.get("name", asset_id)), "model_path": model_path, "model_base_path": ProjectSettings.globalize_path(ROOT_DIR.path_join(asset_id)), "size_bytes": int(manifest.get("size_bytes", 0)), "license": str(manifest.get("license", "")), "author": str(manifest.get("author", "")), "source_url": str(manifest.get("source_url", "")), "resolution": str(manifest.get("texture_resolution", "")), "geometry_validated": bool(manifest.get("geometry_validated", false)), "model_dimensions_m": manifest.get("model_dimensions_m", [0.0, 0.0, 0.0]), "model_grounded_on_import": bool(manifest.get("model_grounded_on_import", false))}
			changed = true
	if changed: _save_settings()

func _save_settings() -> bool:
	var dir: String = _settings_path.get_base_dir()
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(dir))
	var f := FileAccess.open(_settings_path, FileAccess.WRITE)
	if f == null:
		push_warning("StylePack: nie można zapisać ustawień pakietów.")
		return false
	f.store_string(JSON.stringify({"installed": _installed, "kind_map": _kind_map, "obstacle_map": _obstacle_map, "dirt_map": _dirt_map, "animal_map": _animal_map, "intro_seen": _intro_seen, "preferred_resolution": preferred_resolution, "auto_pack_limit": auto_pack_limit, "use_downloaded_models": use_downloaded_models, "downloaded_only_mode": downloaded_only_mode, "auto_correct_proportions": auto_correct_proportions}, "  "))
	f.close()
	return true

func _remove_directory(path: String) -> Error:
	var absolute: String = ProjectSettings.globalize_path(path)
	var dir := DirAccess.open(absolute)
	if dir == null: return ERR_CANT_OPEN
	dir.list_dir_begin()
	var item: String = dir.get_next()
	while not item.is_empty():
		if item != "." and item != "..":
			var child: String = absolute.path_join(item)
			var err: Error = DirAccess.remove_absolute(child) if not DirAccess.dir_exists_absolute(child) else _remove_directory(child)
			if err != OK:
				dir.list_dir_end()
				return err
		item = dir.get_next()
	dir.list_dir_end()
	return DirAccess.remove_absolute(absolute)

func _fit_model_to_kind(model: Node3D, kind: String) -> void:
	var targets: Dictionary = {
		"sofa": Vector3(2.05, 1.05, 0.95), "bed": Vector3(2.1, 0.8, 1.8),
		"wardrobe": Vector3(1.3, 2.0, 0.65), "bookshelf": Vector3(1.1, 1.8, 0.42),
		"chair": Vector3(0.72, 1.05, 0.72), "table": Vector3(1.7, 0.85, 1.1),
		"coffee_table": Vector3(1.25, 0.55, 0.85), "cabinet": Vector3(1.1, 1.1, 0.55),
		"lamp": Vector3(0.55, 1.55, 0.55), "plant": Vector3(0.8, 1.5, 0.8),
		"fridge": Vector3(0.85, 1.9, 0.78), "bathtub": Vector3(1.8, 0.72, 0.9),
		"sink": Vector3(0.85, 0.95, 0.68), "kitchen_counter": Vector3(1.6, 0.95, 0.7),
		"nightstand": Vector3(0.65, 0.72, 0.55), "toilet": Vector3(0.72, 0.92, 0.78),
		"shower": Vector3(0.95, 2.0, 0.95), "washing_machine": Vector3(0.78, 0.95, 0.72),
		"tv": Vector3(1.25, 0.85, 0.2), "tv_wall": Vector3(1.5, 1.1, 0.25),
		"shoe_rack": Vector3(1.0, 0.8, 0.4), "trash_bin": Vector3(0.5, 0.9, 0.5),
		"floor_fan": Vector3(0.8, 1.5, 0.45), "shoe": Vector3(0.35, 0.22, 0.5),
		"sock": Vector3(0.2, 0.12, 0.35), "toy_car": Vector3(0.55, 0.35, 0.35),
		"toy": Vector3(0.45, 0.55, 0.4), "box": Vector3(0.6, 0.5, 0.6),
		"pillow": Vector3(0.6, 0.25, 0.6), "rug": Vector3(1.3, 0.04, 1.0)
	}
	# Wymiary planowania pomieszczeń są wspólnym źródłem prawdy dla skali
	# modeli pobranych. Dzięki temu ich obrys odpowiada przestrzeni zarezerwowanej
	# przez RoomFurnisher i meble nie powinny wchodzić w ściany.
	var planned_dimensions: Vector3 = targets.get(kind, Vector3(0.8, 0.8, 0.8))
	_fit_model_to_dimensions(model, planned_dimensions, false)

func _fit_model_to_dimensions(model: Node3D, target: Vector3, center_model: bool) -> void:
	var bounds: AABB = _collect_bounds(model, model)
	if bounds.size.length() <= 0.001: return
	var axis_ratio: Vector3 = Vector3(
		target.x / maxf(bounds.size.x, 0.001),
		target.y / maxf(bounds.size.y, 0.001),
		target.z / maxf(bounds.size.z, 0.001)
	)
	# Jedna skala dla wszystkich osi: zachowuje naturalne proporcje modelu.
	# Przełącznik korekty włącza dopasowanie do obrysu; wyłączenie zachowuje
	# bazową wielkość importu, ale nadal nigdy nie rozciąga pojedynczych osi.
	var uniform_ratio: float = minf(axis_ratio.x, minf(axis_ratio.y, axis_ratio.z))
	var applied_ratio: float = uniform_ratio if auto_correct_proportions else minf(uniform_ratio, 1.0)
	var applied_scale: Vector3 = Vector3.ONE * applied_ratio
	model.scale = applied_scale
	var horizontal_center: Vector3 = bounds.get_center() if center_model else Vector3(bounds.get_center().x, 0.0, bounds.get_center().z)
	model.position = Vector3(-horizontal_center.x * applied_scale.x, -bounds.position.y * applied_scale.y, -horizontal_center.z * applied_scale.z)

func _collect_bounds(_root: Node3D, current: Node) -> AABB:
	# get_aabb() zwraca obrys w lokalnej przestrzeni MeshInstance3D.
	# Każdy transform potomka musi zostać uwzględniony, inaczej modele z glTF,
	# które mają przesunięte węzły-mesh, są błędnie centrowane (często w lewym
	# dolnym rogu podglądu).
	return _collect_bounds_recursive(current, Transform3D.IDENTITY, true)

func _collect_bounds_recursive(current: Node, parent_transform: Transform3D, is_root: bool = false) -> AABB:
	var result := AABB()
	var has_bounds: bool = false
	var node_transform: Transform3D = Transform3D.IDENTITY
	if not is_root and current is Node3D:
		node_transform = (current as Node3D).transform
	var current_transform: Transform3D = parent_transform * node_transform
	if current is MeshInstance3D and (current as MeshInstance3D).mesh != null:
		result = (current as MeshInstance3D).get_aabb() * current_transform
		has_bounds = true
	for child: Node in current.get_children():
		if child is Node3D:
			var child_box: AABB = _collect_bounds_recursive(child, current_transform)
			if child_box.size.length() > 0.0:
				result = result.merge(child_box) if has_bounds else child_box
				has_bounds = true
	return result if has_bounds else AABB()

func _fail(message: String) -> void:
	_last_error = message
	_pending_model_validation.clear()
	_mode = "idle"
	_http.download_file = ""
	for entry: Dictionary in _download_queue:
		var partial: String = _asset_directory.path_join(str(entry.get("rel_path", ""))) + ".part"
		if FileAccess.file_exists(partial): DirAccess.remove_absolute(ProjectSettings.globalize_path(partial))
	if _asset_directory.ends_with(".installing") and DirAccess.dir_exists_absolute(ProjectSettings.globalize_path(_asset_directory)):
		_remove_directory(_asset_directory)
	_auto_pack_active = false
	_auto_pack_queue.clear()
	status_changed.emit(message)
	_pending_asset.clear()
	_pending_asset_id = ""
	_download_path = ""
	_download_queue.clear()
	_download_index = 0
	_asset_directory = ""
