extends Node
## Ustawia wspólny motyw interfejsu (UITheme) dla całego drzewa okien gry.


func _ready() -> void:
	get_tree().root.theme = UITheme.build()
