class_name BoostCatalog
extends RefCounted
## Centralny katalog 10 boostów. Dane są oddzielone od mechaniki i prezentacji.
## Wartości bazowe wynikają z ustaleń Robot Racing v0.3; parametry bez decyzji
## projektowej są jawnie oznaczone jako wartości domyślne.

const IDS: Array[String] = [
	"turbo", "electric_pulse", "slippery_trail", "shockwave", "shield",
	"magnet", "emergency_repair", "energy_regenerator", "overdrive", "hologram"
]

const RARITIES: Array[String] = ["common", "rare", "unique", "legendary"]
const RARITY_COLORS: Dictionary = {
	"common": Color("#d7dce2"), "rare": Color("#3298ff"),
	"unique": Color("#a65cff"), "legendary": Color("#ffc533")
}

static func get_definition(boost_id: String) -> Dictionary:
	var all := get_all()
	return (all.get(boost_id, {}) as Dictionary).duplicate(true)

static func get_all() -> Dictionary:
	return {
		"turbo": {"name":"Turbo", "duration":3.0, "cooldown":12.0, "energy_cost":30.0, "radius":0.0, "accel_pct":30.0, "speed_pct":35.0, "handling_pct":-35.0, "post_accel_pct":-20.0, "post_duration":3.0, "rarity_duration":[3.0,3.5,4.0,5.0], "rarity_energy_cost":[30.0,27.0,24.0,20.0], "rarity_cooldown":[12.0,11.0,10.0,8.0]},
		"electric_pulse": {"name":"Impuls elektryczny", "duration":2.0, "cooldown":14.0, "energy_cost":25.0, "radius":8.0, "speed_pct":-35.0, "accel_pct":-40.0, "blocks_boosts":true, "extra_shock_duration":2.0},
		"slippery_trail": {"name":"Śliski ślad", "duration":8.0, "cooldown":12.0, "energy_cost":20.0, "trail_length":6.0, "target_duration":2.0, "handling_pct":-45.0},
		"shockwave": {"name":"Fala uderzeniowa", "duration":1.0, "cooldown":16.0, "energy_cost":30.0, "radius":6.0, "knockback":true, "knockback_strength":8.0, "destabilize_duration":1.0, "blocked_by_shield":true},
		"shield": {"name":"Tarcza", "duration":5.0, "cooldown":15.0, "energy_cost":20.0, "blocked_hits":1},
		"magnet": {"name":"Magnes", "duration":5.0, "cooldown":12.0, "energy_cost":20.0, "radius":6.0, "attracts":["dirt", "track_pickups"], "attracts_robots":false, "attraction_speed":5.0},
		"emergency_repair": {"name":"Naprawa awaryjna", "duration":0.0, "cooldown":25.0, "energy_cost":25.0, "repair_damage_pct":30.0, "requires_damage":true},
		"energy_regenerator": {"name":"Regenerator energii", "duration":3.0, "cooldown":20.0, "energy_cost":0.0, "restore_energy_pct":35.0, "gradual":true},
		"overdrive": {"name":"Overdrive", "duration":3.0, "cooldown":18.0, "energy_cost":35.0, "handling_pct":30.0, "collision_resistance_pct":35.0, "stability_field":true},
		"hologram": {"name":"Hologram / wabik", "duration":5.0, "cooldown":18.0, "energy_cost":20.0, "physical_collision":false, "collects_items":false, "imitates_player_motion":true, "decoy_strength":0.5}
	}

static func is_valid_id(boost_id: String) -> bool:
	return IDS.has(boost_id)

static func get_rarity_index(rarity: String) -> int:
	return maxi(RARITIES.find(rarity), 0)
