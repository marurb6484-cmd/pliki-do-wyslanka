class_name BoostLoadoutSystem
extends RefCounted
## Globalne wyposażenie boostów. Dane są trwałe i niezależne od robota.
## System nie aktywuje jeszcze efektów w wyścigu - odpowiada za konfigurację.

signal loadout_changed
signal equip_rejected(reason: String)

const STARTING_SLOTS: int = 2
const MAX_SLOTS: int = 10
const SAVE_SECTION: String = "boost_loadout"

var unlocked_slots: int = STARTING_SLOTS
var presets: Dictionary = {"Domyślny": ["turbo", "electric_pulse"]}
var active_preset: String = "Domyślny"


func _init() -> void:
	load_from_save()


## Zwraca sloty z zachowaniem pustych miejsc - indeks zawsze odpowiada slotowi.
func get_equipped() -> Array[String]:
	var raw: Variant = presets.get(active_preset, [])
	var result: Array[String] = []
	for slot_index: int in range(unlocked_slots):
		var boost_id: String = ""
		if raw is Array and slot_index < (raw as Array).size():
			var candidate: String = str((raw as Array)[slot_index])
			if BoostCatalog.is_valid_id(candidate):
				boost_id = candidate
		result.append(boost_id)
	return result


func equip(boost_id: String, slot_index: int) -> bool:
	if not BoostCatalog.is_valid_id(boost_id):
		equip_rejected.emit("NIEZNANY BOOST")
		return false
	if slot_index < 0 or slot_index >= unlocked_slots:
		equip_rejected.emit("SLOT NIEODBLOCKOWANY")
		return false
	var equipped: Array[String] = get_equipped()
	for i: int in range(equipped.size()):
		if i != slot_index and equipped[i] == boost_id:
			equip_rejected.emit("NIE MOŻNA WYPOSAŻYĆ DWÓCH IDENTYCZNYCH BOOSTÓW")
			return false
	equipped[slot_index] = boost_id
	presets[active_preset] = equipped
	_commit()
	return true


func clear_slot(slot_index: int) -> void:
	if slot_index < 0 or slot_index >= unlocked_slots:
		return
	var equipped: Array[String] = get_equipped()
	if equipped[slot_index].is_empty():
		return
	equipped[slot_index] = ""
	presets[active_preset] = equipped
	_commit()


func create_preset(preset_name: String) -> bool:
	var clean: String = preset_name.strip_edges()
	if clean.is_empty() or presets.has(clean):
		return false
	var empty_slots: Array[String] = []
	for _i: int in range(unlocked_slots):
		empty_slots.append("")
	presets[clean] = empty_slots
	active_preset = clean
	_commit()
	return true


func select_preset(preset_name: String) -> bool:
	if not presets.has(preset_name):
		return false
	active_preset = preset_name
	_commit()
	return true


func unlock_slot(new_count: int) -> void:
	var next_count: int = clampi(new_count, STARTING_SLOTS, MAX_SLOTS)
	if next_count == unlocked_slots:
		return
	unlocked_slots = next_count
	for preset_name: String in presets.keys():
		var slots: Array[String] = _sanitize_slots(presets[preset_name], unlocked_slots)
		presets[preset_name] = slots
	_commit()


func get_preset_names() -> Array[String]:
	var result: Array[String] = []
	for key: Variant in presets.keys():
		result.append(str(key))
	result.sort()
	return result


func reset_to_defaults() -> void:
	unlocked_slots = STARTING_SLOTS
	presets = {"Domyślny": ["turbo", "electric_pulse"]}
	active_preset = "Domyślny"
	_save()
	loadout_changed.emit()


func load_from_save() -> void:
	unlocked_slots = clampi(
		SaveManager.get_int(SAVE_SECTION, "unlocked_slots", STARTING_SLOTS),
		STARTING_SLOTS,
		MAX_SLOTS
	)
	var saved_presets: Dictionary = SaveManager.get_dict(SAVE_SECTION, "presets")
	var clean_presets: Dictionary = {}
	for key: Variant in saved_presets.keys():
		var preset_name: String = str(key).strip_edges()
		if preset_name.is_empty():
			continue
		clean_presets[preset_name] = _sanitize_slots(saved_presets[key], unlocked_slots)
	if clean_presets.is_empty():
		clean_presets = {"Domyślny": ["turbo", "electric_pulse"]}
	presets = clean_presets
	active_preset = SaveManager.get_string(SAVE_SECTION, "active_preset", "Domyślny")
	if not presets.has(active_preset):
		active_preset = str(presets.keys()[0])
	# Zapisuje migrację/normalizację bez utraty innych sekcji zapisu.
	_save()


func _sanitize_slots(raw: Variant, count: int) -> Array[String]:
	var result: Array[String] = []
	var source: Array = raw if raw is Array else []
	for i: int in range(count):
		var boost_id: String = str(source[i]) if i < source.size() else ""
		if not BoostCatalog.is_valid_id(boost_id):
			boost_id = ""
		# Duplikaty w starym/uszkodzonym zapisie są czyszczone, nie kopiowane.
		if not boost_id.is_empty() and result.has(boost_id):
			boost_id = ""
		result.append(boost_id)
	return result


func _commit() -> void:
	_save()
	loadout_changed.emit()


func _save() -> void:
	SaveManager.set_value(SAVE_SECTION, "unlocked_slots", unlocked_slots)
	SaveManager.set_value(SAVE_SECTION, "presets", presets)
	SaveManager.set_value(SAVE_SECTION, "active_preset", active_preset)
