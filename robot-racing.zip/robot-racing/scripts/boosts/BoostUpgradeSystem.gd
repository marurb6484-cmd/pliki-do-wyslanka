class_name BoostUpgradeSystem
extends RefCounted
## Trwałe, niezależne ulepszenia parametrów boostów dla każdej rzadkości.
## Poziomy 0-20; koszt rośnie progresywnie. Wszystkie wartości bazowe pochodzą
## z katalogu, a przyrosty są parametrami balansu możliwymi do późniejszej korekty.

const SAVE_SECTION: String = "boost_upgrades"
const MAX_LEVEL: int = 20
const RARITY_COST: Dictionary = {"common": 1.0, "rare": 1.5, "unique": 2.2, "legendary": 3.2}

const PARAMS: Dictionary = {
	"turbo": [
		{"id":"duration","label":"Czas działania","field":"duration","step":0.10,"min":3.0,"max":9.0,"unit":"s"},
		{"id":"accel_pct","label":"Przyspieszenie","field":"accel_pct","step":1.5,"min":30.0,"max":85.0,"unit":"%"},
		{"id":"speed_pct","label":"Prędkość maksymalna","field":"speed_pct","step":1.5,"min":35.0,"max":90.0,"unit":"%"},
		{"id":"handling_pct","label":"Kontrola prowadzenia","field":"handling_pct","step":0.5,"min":-35.0,"max":0.0,"unit":"%"},
		{"id":"energy_cost","label":"Koszt energii","field":"energy_cost","step":0.45,"min":10.0,"max":30.0,"unit":"%","reverse":true},
		{"id":"cooldown","label":"Odnowienie","field":"cooldown","step":0.18,"min":3.0,"max":12.0,"unit":"s","reverse":true}
	],
	"electric_pulse": [
		{"id":"radius","label":"Promień impulsu","field":"radius","step":0.15,"min":8.0,"max":12.0,"unit":"m"},
		{"id":"duration","label":"Czas porażenia","field":"duration","step":0.05,"min":2.0,"max":4.0,"unit":"s"},
		{"id":"speed_pct","label":"Osłabienie prędkości","field":"speed_pct","step":0.75,"min":-55.0,"max":-35.0,"unit":"%","reverse":true},
		{"id":"accel_pct","label":"Osłabienie przyspieszenia","field":"accel_pct","step":0.75,"min":-60.0,"max":-40.0,"unit":"%","reverse":true},
		{"id":"energy_cost","label":"Koszt energii","field":"energy_cost","step":0.5,"min":10.0,"max":25.0,"unit":"%","reverse":true},
		{"id":"cooldown","label":"Odnowienie","field":"cooldown","step":0.3,"min":5.0,"max":14.0,"unit":"s","reverse":true}
	],
	"slippery_trail": [
		{"id":"trail_length","label":"Długość śladu","field":"trail_length","step":0.2,"min":6.0,"max":10.0,"unit":"m"},
		{"id":"duration","label":"Czas działania śladu","field":"duration","step":0.15,"min":8.0,"max":11.0,"unit":"s"},
		{"id":"handling_pct","label":"Siła poślizgu","field":"handling_pct","step":0.75,"min":-60.0,"max":-45.0,"unit":"%","reverse":true},
		{"id":"energy_cost","label":"Koszt energii","field":"energy_cost","step":0.4,"min":8.0,"max":20.0,"unit":"%","reverse":true},
		{"id":"cooldown","label":"Odnowienie","field":"cooldown","step":0.3,"min":4.0,"max":12.0,"unit":"s","reverse":true}
	],
	"shockwave": [
		{"id":"radius","label":"Promień fali","field":"radius","step":0.15,"min":6.0,"max":10.0,"unit":"m"},
		{"id":"knockback_strength","label":"Siła odrzutu","field":"knockback_strength","step":0.25,"min":8.0,"max":13.0,"unit":""},
		{"id":"destabilize_duration","label":"Czas destabilizacji","field":"destabilize_duration","step":0.05,"min":1.0,"max":2.0,"unit":"s"},
		{"id":"energy_cost","label":"Koszt energii","field":"energy_cost","step":0.5,"min":10.0,"max":30.0,"unit":"%","reverse":true},
		{"id":"cooldown","label":"Odnowienie","field":"cooldown","step":0.3,"min":6.0,"max":16.0,"unit":"s","reverse":true}
	],
	"shield": [
		{"id":"duration","label":"Czas działania","field":"duration","step":0.15,"min":5.0,"max":8.0,"unit":"s"},
		{"id":"blocked_hits","label":"Blokowane trafienia","field":"blocked_hits","step":0.05,"min":1.0,"max":2.0,"unit":""},
		{"id":"energy_cost","label":"Koszt energii","field":"energy_cost","step":0.4,"min":8.0,"max":20.0,"unit":"%","reverse":true},
		{"id":"cooldown","label":"Odnowienie","field":"cooldown","step":0.3,"min":5.0,"max":15.0,"unit":"s","reverse":true}
	],
	"magnet": [
		{"id":"radius","label":"Promień magnesu","field":"radius","step":0.15,"min":6.0,"max":10.0,"unit":"m"},
		{"id":"duration","label":"Czas działania","field":"duration","step":0.1,"min":5.0,"max":8.0,"unit":"s"},
		{"id":"attraction_speed","label":"Siła przyciągania","field":"attraction_speed","step":0.3,"min":5.0,"max":11.0,"unit":""},
		{"id":"energy_cost","label":"Koszt energii","field":"energy_cost","step":0.4,"min":8.0,"max":20.0,"unit":"%","reverse":true},
		{"id":"cooldown","label":"Odnowienie","field":"cooldown","step":0.3,"min":4.0,"max":12.0,"unit":"s","reverse":true}
	],
	"emergency_repair": [
		{"id":"repair_damage_pct","label":"Naprawiane uszkodzenia","field":"repair_damage_pct","step":1.5,"min":30.0,"max":60.0,"unit":"%"},
		{"id":"energy_cost","label":"Koszt energii","field":"energy_cost","step":0.5,"min":10.0,"max":25.0,"unit":"%","reverse":true},
		{"id":"cooldown","label":"Odnowienie","field":"cooldown","step":0.5,"min":8.0,"max":25.0,"unit":"s","reverse":true}
	],
	"energy_regenerator": [
		{"id":"restore_energy_pct","label":"Odnawiana energia","field":"restore_energy_pct","step":1.5,"min":35.0,"max":65.0,"unit":"%"},
		{"id":"duration","label":"Czas regeneracji","field":"duration","step":-0.05,"min":2.0,"max":3.0,"unit":"s"},
		{"id":"cooldown","label":"Odnowienie","field":"cooldown","step":0.4,"min":6.0,"max":20.0,"unit":"s","reverse":true}
	],
	"overdrive": [
		{"id":"handling_pct","label":"Stabilność prowadzenia","field":"handling_pct","step":1.0,"min":30.0,"max":50.0,"unit":"%"},
		{"id":"collision_resistance_pct","label":"Odporność na odrzut","field":"collision_resistance_pct","step":1.0,"min":35.0,"max":60.0,"unit":"%"},
		{"id":"duration","label":"Czas działania","field":"duration","step":0.1,"min":3.0,"max":5.0,"unit":"s"},
		{"id":"energy_cost","label":"Koszt energii","field":"energy_cost","step":0.5,"min":20.0,"max":35.0,"unit":"%","reverse":true},
		{"id":"cooldown","label":"Odnowienie","field":"cooldown","step":0.3,"min":6.0,"max":18.0,"unit":"s","reverse":true}
	],
	"hologram": [
		{"id":"duration","label":"Czas działania","field":"duration","step":0.15,"min":5.0,"max":8.0,"unit":"s"},
		{"id":"decoy_strength","label":"Skuteczność wabika","field":"decoy_strength","step":0.03,"min":0.5,"max":1.1,"unit":""},
		{"id":"energy_cost","label":"Koszt energii","field":"energy_cost","step":0.4,"min":8.0,"max":20.0,"unit":"%","reverse":true},
		{"id":"cooldown","label":"Odnowienie","field":"cooldown","step":0.3,"min":6.0,"max":18.0,"unit":"s","reverse":true}
	]
}

static func get_parameters(boost_id: String) -> Array:
	return (PARAMS.get(boost_id, []) as Array).duplicate(true)

static func get_level(boost_id: String, rarity: String, parameter_id: String) -> int:
	var all: Dictionary = SaveManager.get_dict(SAVE_SECTION, "levels")
	var key: String = "%s|%s|%s" % [boost_id, rarity, parameter_id]
	# Migracja poprzedniej nazwy rangi „epic” do ustalonej nazwy „unique”.
	if rarity == "unique" and not all.has(key):
		var legacy_key: String = "%s|epic|%s" % [boost_id, parameter_id]
		if all.has(legacy_key):
			all[key] = all[legacy_key]
			all.erase(legacy_key)
			SaveManager.set_value(SAVE_SECTION, "levels", all)
			SaveManager.save_now()
	return clampi(int(all.get(key, 0)), 0, MAX_LEVEL)

static func get_cost(boost_id: String, rarity: String, parameter_id: String) -> int:
	var level: int = get_level(boost_id, rarity, parameter_id)
	if level >= MAX_LEVEL:
		return -1
	var rarity_factor: float = float(RARITY_COST.get(rarity, 1.0))
	return maxi(1, roundi(55.0 * rarity_factor * pow(float(level + 1), 1.42)))

static func purchase_level(boost_id: String, rarity: String, parameter_id: String) -> bool:
	if not BoostCatalog.is_valid_id(boost_id) or not BoostCatalog.RARITIES.has(rarity):
		return false
	var valid: bool = false
	for parameter: Dictionary in get_parameters(boost_id):
		if str(parameter.get("id", "")) == parameter_id:
			valid = true
			break
	if not valid:
		return false
	var cost: int = get_cost(boost_id, rarity, parameter_id)
	if cost < 0 or not PlayerProgress.spend(cost):
		return false
	var all: Dictionary = SaveManager.get_dict(SAVE_SECTION, "levels")
	var key: String = "%s|%s|%s" % [boost_id, rarity, parameter_id]
	all[key] = get_level(boost_id, rarity, parameter_id) + 1
	SaveManager.set_value(SAVE_SECTION, "levels", all)
	SaveManager.save_now()
	return true

static func get_full_upgrade_cost(boost_id: String, rarity: String = "common") -> int:
	var parameters: Array = get_parameters(boost_id)
	if parameters.is_empty():
		return -1
	var total: int = 0
	for parameter: Dictionary in parameters:
		var cost: int = get_cost(boost_id, rarity, str(parameter.get("id", "")))
		if cost < 0:
			continue
		total += cost
	return total if total > 0 else -1


static func purchase_full_upgrade(boost_id: String, rarity: String = "common") -> bool:
	if not BoostCatalog.is_valid_id(boost_id) or not BoostCatalog.RARITIES.has(rarity):
		return false
	var parameters: Array = get_parameters(boost_id)
	if parameters.is_empty():
		return false
	var total_cost: int = get_full_upgrade_cost(boost_id, rarity)
	if total_cost < 0 or not PlayerProgress.spend(total_cost):
		return false
	var all: Dictionary = SaveManager.get_dict(SAVE_SECTION, "levels")
	for parameter: Dictionary in parameters:
		var parameter_id: String = str(parameter.get("id", ""))
		var key: String = "%s|%s|%s" % [boost_id, rarity, parameter_id]
		var current_level: int = clampi(int(all.get(key, 0)), 0, MAX_LEVEL)
		all[key] = mini(current_level + 1, MAX_LEVEL)
	SaveManager.set_value(SAVE_SECTION, "levels", all)
	SaveManager.save_now()
	return true


static func apply_to_definition(boost_id: String, rarity: String = "common") -> Dictionary:
	var result: Dictionary = BoostCatalog.get_definition(boost_id)
	var saved_levels: Dictionary = SaveManager.get_dict(SAVE_SECTION, "levels")
	for parameter: Dictionary in get_parameters(boost_id):
		var parameter_id: String = str(parameter.get("id", ""))
		var field: String = str(parameter.get("field", parameter_id))
		var level_key: String = "%s|%s|%s" % [boost_id, rarity, parameter_id]
		var level: int = clampi(int(saved_levels.get(level_key, 0)), 0, MAX_LEVEL)
		var base: float = float(result.get(field, 0.0))
		var step: float = float(parameter.get("step", 0.0))
		var value: float = base + step * float(level)
		if bool(parameter.get("reverse", false)):
			value = base - step * float(level)
		value = clampf(value, float(parameter.get("min", -INF)), float(parameter.get("max", INF)))
		if field == "blocked_hits":
			result[field] = maxi(1, roundi(value))
		else:
			result[field] = value
	return result

static func reset_all() -> void:
	SaveManager.erase_key(SAVE_SECTION, "levels")
	SaveManager.save_now()
