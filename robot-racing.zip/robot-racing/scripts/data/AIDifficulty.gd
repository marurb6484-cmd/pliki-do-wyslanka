class_name AIDifficulty
extends RefCounted
## Profile trudności i style jazdy przeciwników AI.
##
## AI korzysta z tej samej fizyki co gracz. Trudność zmienia wyłącznie
## "umiejętności kierowcy" (tor jazdy, hamowanie, reakcję, błędy, użycie boosta)
## oraz poziom ulepszeń robota - żadnego teleportowania ani ukrytego przyspieszania.

enum Level { EASY, NORMAL, HARD, EXPERT }
enum Style { BALANCED, AGGRESSIVE, CAREFUL, COLLECTOR }

const NAMES: Array[String] = ["ŁATWY", "NORMALNY", "TRUDNY", "EKSPERT"]
const STYLE_NAMES: Array[String] = ["zrównoważony", "agresywny", "ostrożny", "zbieracz"]

## speed_factor     - jaki ułamek prędkości maksymalnej robota kierowca wykorzystuje
## corner_margin    - jaki ułamek limitu przyczepności wykorzystuje w zakrętach
## line_quality     - jak dobrze ścina zakręty (0 = środek toru, 1 = idealna linia)
## steer_noise      - drgania kierownicy
## mistake_rate     - średnia liczba błędów na sekundę
## reaction         - czas reakcji (s)
## boost_skill      - jak mądrze używa boosta (0 = losowo, 1 = tylko na prostych)
## dirt_skill       - jak chętnie zbiera brud
## avoid_skill      - jak dobrze omija przeszkody i rywali
## upgrade_level    - poziom ulepszeń robota przeciwnika (jak u gracza, max 5)
const PROFILES: Array[Dictionary] = [
	{"speed_factor": 0.8, "corner_margin": 0.66, "line_quality": 0.2, "steer_noise": 0.16, "mistake_rate": 0.12, "reaction": 0.30, "boost_skill": 0.25, "dirt_skill": 0.35, "avoid_skill": 0.55, "upgrade_level": 0},
	{"speed_factor": 0.93, "corner_margin": 0.82, "line_quality": 0.55, "steer_noise": 0.07, "mistake_rate": 0.04, "reaction": 0.18, "boost_skill": 0.6, "dirt_skill": 0.6, "avoid_skill": 0.75, "upgrade_level": 1},
	{"speed_factor": 0.97, "corner_margin": 0.89, "line_quality": 0.75, "steer_noise": 0.03, "mistake_rate": 0.012, "reaction": 0.11, "boost_skill": 0.85, "dirt_skill": 0.8, "avoid_skill": 0.9, "upgrade_level": 2},
	{"speed_factor": 1.0, "corner_margin": 0.95, "line_quality": 0.9, "steer_noise": 0.01, "mistake_rate": 0.0, "reaction": 0.07, "boost_skill": 1.0, "dirt_skill": 0.95, "avoid_skill": 1.0, "upgrade_level": 3}
]

## Mnożnik nagród za wyścig zależnie od trudności.
const REWARD_MULTIPLIER: Array[float] = [0.7, 1.0, 1.35, 1.75]


static func get_profile(level: int, style: int) -> Dictionary:
	var profile: Dictionary = PROFILES[clampi(level, 0, PROFILES.size() - 1)].duplicate()
	profile["level"] = clampi(level, 0, PROFILES.size() - 1)
	profile["style"] = style

	match style:
		Style.AGGRESSIVE:
			profile["corner_margin"] = minf(float(profile["corner_margin"]) + 0.03, 1.0)
			profile["boost_skill"] = float(profile["boost_skill"]) * 0.85
			profile["avoid_skill"] = float(profile["avoid_skill"]) * 0.8
			profile["aggression"] = 1.0
		Style.CAREFUL:
			profile["corner_margin"] = float(profile["corner_margin"]) - 0.05
			profile["avoid_skill"] = minf(float(profile["avoid_skill"]) + 0.15, 1.0)
			profile["aggression"] = 0.0
		Style.COLLECTOR:
			profile["dirt_skill"] = minf(float(profile["dirt_skill"]) + 0.3, 1.0)
			profile["aggression"] = 0.3
		_:
			profile["aggression"] = 0.5

	return profile


static func get_upgrades_for(level: int) -> Dictionary:
	var lvl: int = int(PROFILES[clampi(level, 0, PROFILES.size() - 1)]["upgrade_level"])
	return {"speed": lvl, "accel": lvl, "grip": lvl, "capacity": lvl, "boost": lvl}
