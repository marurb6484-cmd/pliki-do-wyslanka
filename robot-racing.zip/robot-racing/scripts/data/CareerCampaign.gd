class_name CareerCampaign
extends RefCounted
## Dane kampanii fabularnej. Każde wydarzenie jest generowane deterministycznie.

const EVENTS: Array[Dictionary] = [
	{"id":"s01_first_night","chapter":0,"chapter_name":"DNO HARMONOGRAMU","title":"Kawa na panelach","location":"Kawalerka studenta","time_of_day":"day","theme":"apartment","size":0,"complexity":1,"obstacles":0,"furniture":1,"laps":2,"difficulty":0,"opponents":3,"boss":false,"goal":"Zajmij miejsce na podium i pokaż, że tani robot też potrafi jechać."},
	{"id":"s01_under_sofa","chapter":0,"chapter_name":"DNO HARMONOGRAMU","title":"Pod kanapą nie ma litości","location":"Zagracony salon","time_of_day":"evening","theme":"apartment","size":1,"complexity":2,"obstacles":2,"furniture":2,"laps":1,"route_type":"segment","difficulty":1,"opponents":4,"boss":false,"goal":"Przetrwaj wieczorny chaos i unikaj kabli, kapci oraz zabawek."},
	{"id":"s01_hall_boss","chapter":0,"chapter_name":"DNO HARMONOGRAMU","title":"Król przedpokoju","location":"Przedpokój i korytarz","time_of_day":"night","theme":"apartment","size":1,"complexity":3,"obstacles":2,"furniture":2,"laps":3,"difficulty":2,"opponents":4,"boss":true,"boss_name":"SZCZOTMISTRZ","goal":"Pokonaj lokalnego rewiranta. Boss wymaga zwycięstwa."},
	{"id":"office_first_shift","chapter":1,"chapter_name":"KORPORACYJNY WYŚCIG SZCZURÓW","title":"Open space po godzinach","location":"Piętro biurowca","time_of_day":"day","theme":"office","size":2,"complexity":2,"obstacles":1,"furniture":1,"laps":3,"difficulty":1,"opponents":4,"boss":false,"goal":"Zdobądź miejsce w czołówce korporacyjnej ligi."},
	{"id":"office_rush","chapter":1,"chapter_name":"KORPORACYJNY WYŚCIG SZCZURÓW","title":"Godzina nadgodzin","location":"Śliski korytarz biurowy","time_of_day":"evening","theme":"office","size":2,"complexity":3,"obstacles":2,"furniture":2,"laps":1,"route_type":"segment","difficulty":2,"opponents":4,"boss":false,"goal":"Utrzymaj tempo między przeszkodami i nie trać kontroli."},
	{"id":"office_director","chapter":1,"chapter_name":"KORPORACYJNY WYŚCIG SZCZURÓW","title":"Dyrektor floty","location":"Piętro zarządu","time_of_day":"night","theme":"office","size":3,"complexity":4,"obstacles":2,"furniture":1,"laps":4,"difficulty":3,"opponents":4,"boss":true,"boss_name":"DYREKTOR DUSTCORP","goal":"Pokonaj korporacyjnego bossa i zdobądź przepustkę do Pro League."},
	{"id":"pro_qualifier","chapter":2,"chapter_name":"PRO LEAGUE","title":"Kwalifikacje mistrzostw","location":"Oficjalny tor kwalifikacyjny","time_of_day":"day","theme":"pro_league","size":3,"complexity":3,"obstacles":1,"furniture":1,"laps":3,"difficulty":2,"opponents":4,"boss":false,"goal":"Zakwalifikuj się do półfinału oficjalnych mistrzostw."},
	{"id":"pro_semifinal","chapter":2,"chapter_name":"PRO LEAGUE","title":"Półfinał mistrzostw","location":"Arena Pro League","time_of_day":"evening","theme":"pro_league","size":4,"complexity":4,"obstacles":2,"furniture":1,"laps":4,"difficulty":3,"opponents":4,"boss":false,"goal":"Wywalcz miejsce w wielkim finale."},
	{"id":"pro_final","chapter":2,"chapter_name":"PRO LEAGUE","title":"Król Paneli","location":"Wielki finał Pro League","time_of_day":"night","theme":"pro_league","size":4,"complexity":5,"obstacles":3,"furniture":1,"laps":5,"difficulty":3,"opponents":4,"boss":true,"boss_name":"APEX-9000","goal":"Wygraj finał i udowodnij, że S-01 może zostać Królem Paneli."}
]

static func count() -> int:
	return EVENTS.size()

static func get_event(index: int) -> Dictionary:
	if index < 0 or index >= EVENTS.size():
		return {}
	return EVENTS[index].duplicate(true)

static func chapter_for(index: int) -> int:
	if index >= EVENTS.size():
		return 3
	return int(EVENTS[maxi(index, 0)].get("chapter", 0))

static func reward_multiplier(time_of_day: String) -> float:
	match time_of_day:
		"evening": return 1.5
		"night": return 2.0
		_: return 1.0
