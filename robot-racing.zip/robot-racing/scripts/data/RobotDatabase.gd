class_name RobotDatabase
extends RefCounted
## Dane wszystkich robotów, skórek, kolorów neonów i ulepszeń.
##
## Jedno źródło prawdy dla garażu, wyścigu, AI i HUD. Statystyki bazowe
## pochodzą z poprzedniej wersji GameManager.robots_data (zachowany balans),
## uzupełnione o pojemność zbiornika brudu (wcześniej zapisaną w BoostHUD).

const ROBOTS: Array[Dictionary] = [
	{
		"id": "dustmower",
		"name": "S-01 Szoromir",
		"speed": 2.59,
		"acceleration": 2.52,
		"grip": 7.5,
		"boost_power": 1.8,
		"capacity": 10.0,
		"battery_capacity": 100.0,
		"color": Color(0.91, 0.92, 0.94),
		"shape": "disc",
		"cost": 0,
		"description": "Tani pracownik nocnej zmiany. Niepozorny, ale bardzo chce awansować."
	},
	{
		"id": "turbosweep",
		"name": "TurboKapeć GT",
		"speed": 2.96,
		"acceleration": 2.14,
		"grip": 6.0,
		"boost_power": 2.1,
		"capacity": 15.0,
		"battery_capacity": 88.0,
		"color": Color(0.15, 0.16, 0.18),
		"shape": "wedge",
		"cost": 0,
		"description": "Król korytarza. Na prostej pędzi, a zakręty traktuje jak sugestię."
	},
	{
		"id": "cleanbot",
		"name": "Mopson na Etacie",
		"speed": 2.34,
		"acceleration": 3.15,
		"grip": 9.0,
		"boost_power": 1.5,
		"capacity": 20.0,
		"battery_capacity": 115.0,
		"color": Color(0.66, 0.69, 0.72),
		"shape": "square",
		"cost": 450,
		"description": "Złota rączka korporacji. Przykleja się do podłogi i rusza jak po kawie."
	},
	{
		"id": "vortex",
		"name": "Pan Odkurzacz 3000",
		"speed": 2.71,
		"acceleration": 1.89,
		"grip": 9.5,
		"boost_power": 1.9,
		"capacity": 25.0,
		"battery_capacity": 140.0,
		"color": Color(0.10, 0.105, 0.115),
		"shape": "heavy",
		"cost": 800,
		"description": "Ochroniarz piętra. Powolny, uparty i z ogromnym zbiornikiem na zapasy."
	},
	{
		"id": "nanovac",
		"name": "Błyskawica z Promocji",
		"speed": 3.20,
		"acceleration": 2.27,
		"grip": 5.0,
		"boost_power": 2.4,
		"capacity": 30.0,
		"battery_capacity": 82.0,
		"color": Color(0.80, 0.73, 0.62),
		"shape": "hex",
		"cost": 1300,
		"description": "Stażyści go nie doganiają. Szybki jak plotka o darmowym urlopie."
	},
	{
		"id": "dreame_x60",
		"name": "Szoromir X-60",
		"speed": 2.59, "acceleration": 2.52, "grip": 7.5,
		"boost_power": 1.8, "capacity": 10.0, "battery_capacity": 100.0,
		"color": Color(0.10, 0.12, 0.15), "shape": "model_dreame",
		"cost": 1600,
		"description": "Elegancki zawodnik z chowającym się radarem i wysuwanymi szczotkami. Udaje, że nie słyszy poleceń."
	},
	{
		"id": "saros_z70",
		"name": "Łapcio Z-5",
		"speed": 2.96, "acceleration": 2.14, "grip": 6.0,
		"boost_power": 2.1, "capacity": 15.0, "battery_capacity": 88.0,
		"color": Color(0.15, 0.16, 0.18), "shape": "model_saros",
		"cost": 1900,
		"description": "Niski jak naleśnik. Ma mechaniczne ramię do podnoszenia cudzych problemów."
	},
	{
		"id": "roomba_combo",
		"name": "Mopson Kombinator",
		"speed": 2.34, "acceleration": 3.15, "grip": 9.0,
		"boost_power": 1.5, "capacity": 20.0, "battery_capacity": 115.0,
		"color": Color(0.66, 0.69, 0.72), "shape": "model_roomba",
		"cost": 2200,
		"description": "Nie wie, czy jest mopem, czy bolidem. Na szczęście szybko jeździ."
	},
	{
		"id": "xiaomi_x20",
		"name": "Bąbeltron 20",
		"speed": 2.71, "acceleration": 1.89, "grip": 9.5,
		"boost_power": 1.9, "capacity": 25.0, "battery_capacity": 140.0,
		"color": Color(0.10, 0.105, 0.115), "shape": "model_xiaomi",
		"cost": 2500,
		"description": "Ma radar na czubku i ambicje większe niż własna stacja dokująca."
	},
	{
		"id": "narwal_freo",
		"name": "Glutowóz Z",
		"speed": 3.20, "acceleration": 2.27, "grip": 5.0,
		"boost_power": 2.4, "capacity": 30.0, "battery_capacity": 82.0,
		"color": Color(0.80, 0.73, 0.62), "shape": "model_narwal",
		"cost": 2800,
		"description": "Dwie oczy, dwa wirujące pady i absolutny brak poczucia kierunku."
	},
	# Nowa piątka inspirowana kolejnymi konstrukcjami odkurzaczy.
	# Dopisujemy na końcu, ponieważ indeksy robotów są zapisywane w postępie.
	{
		"id": "pajaczek",
		"name": "Pan Pajączek Turbo",
		"speed": 2.84, "acceleration": 2.72, "grip": 8.5,
		"boost_power": 2.0, "capacity": 18.0, "battery_capacity": 120.0,
		"color": Color(0.06, 0.065, 0.075), "shape": "spider",
		"cost": 1700,
		"description": "Wysuwa boczną szczotkę jak pajęcze odnóże i trzyma się podłogi jak pająk ściany. Czarny, szybki i trochę złowrogi."
	},
	{
		"id": "skarpeciarz",
		"name": "Skarpeciarz",
		"speed": 3.09, "acceleration": 2.47, "grip": 7.0,
		"boost_power": 1.7, "capacity": 28.0, "battery_capacity": 100.0,
		"color": Color(0.86, 0.87, 0.89), "shape": "slimarm",
		"cost": 2100,
		"description": "Ultra płaski, z mechanicznym ramieniem na grzbiecie. Wjedzie pod każdą szafę i przy okazji zgarnie samotną skarpetkę."
	},
	{
		"id": "zenek",
		"name": "Zenek Okrągły",
		"speed": 2.47, "acceleration": 2.35, "grip": 8.5,
		"boost_power": 1.6, "capacity": 22.0, "battery_capacity": 130.0,
		"color": Color(0.22, 0.23, 0.25), "shape": "roomba",
		"cost": 900,
		"description": "Klasyk bez ozdób: matowy, spokojny i niezawodny jak stary sąsiad Zenek. Nigdy nie narzeka."
	},
	{
		"id": "wacek",
		"name": "Wacek Peryskop",
		"speed": 2.72, "acceleration": 1.98, "grip": 9.0,
		"boost_power": 2.0, "capacity": 26.0, "battery_capacity": 135.0,
		"color": Color(0.07, 0.07, 0.08), "shape": "periscope",
		"cost": 1500,
		"description": "Wieżyczka na środku widzi wszystko dookoła, nawet kapcie za rogiem. Z tyłu wysuwa pad mopujący."
	},
	{
		"id": "walenty",
		"name": "Walenty Wieloryb",
		"speed": 2.91, "acceleration": 2.22, "grip": 7.5,
		"boost_power": 2.3, "capacity": 24.0, "battery_capacity": 118.0,
		"color": Color(0.72, 0.74, 0.76), "shape": "whale",
		"cost": 2600,
		"description": "Obła, opływowa bryła i dwoje oczu z AI. Płynie po panelach jak wieloryb po oceanie, tylko ciszej."
	}
]

## Skórki są pogrupowane w TE SAME kategorie stylu co skórki obiektów
## (ObjectSkins): fabryczna, realistyczna, kreskówkowa, neonowa i pastelowa.
## primary = null oznacza kolor fabryczny danego robota (realistyczny).
## Indeksy 0..N są zapisywane w postępie gracza, więc nowe skórki dopisujemy na końcu.
const SKIN_CATEGORIES: Array[Dictionary] = [
	{"id": "factory", "name": "FABRYCZNA"},
	{"id": "realistic", "name": "REALISTYCZNA"},
	{"id": "cartoon", "name": "KREŚKÓWKOWA"},
	{"id": "neon", "name": "NEONOWA"},
	{"id": "pastel", "name": "PASTELOWA"}
]

const SKINS: Array[Dictionary] = [
	{"name": "Fabryczna", "category": "factory", "primary": null, "secondary": Color(0.11, 0.12, 0.14), "metallic": 0.12, "roughness": 0.42, "cost": 0},
	# --- Realistyczna: kolory spotykane w prawdziwych robotach sprzątających ---
	{"name": "Biały perłowy", "category": "realistic", "primary": Color(0.91, 0.92, 0.94), "secondary": Color(0.15, 0.16, 0.18), "metallic": 0.08, "roughness": 0.40, "cost": 40},
	{"name": "Grafit", "category": "realistic", "primary": Color(0.14, 0.15, 0.17), "secondary": Color(0.72, 0.74, 0.78), "metallic": 0.25, "roughness": 0.38, "cost": 40},
	{"name": "Srebrny", "category": "realistic", "primary": Color(0.66, 0.69, 0.72), "secondary": Color(0.10, 0.11, 0.13), "metallic": 0.45, "roughness": 0.34, "cost": 60},
	{"name": "Szampański", "category": "realistic", "primary": Color(0.80, 0.73, 0.62), "secondary": Color(0.20, 0.17, 0.14), "metallic": 0.40, "roughness": 0.36, "cost": 60},
	# --- Kreskówkowa: nasycone, połyskliwe kolory ---
	{"name": "Lawa", "category": "cartoon", "primary": Color(1.0, 0.42, 0.05), "secondary": Color(0.10, 0.07, 0.06), "metallic": 0.10, "roughness": 0.30, "cost": 80},
	{"name": "Toksyczna", "category": "cartoon", "primary": Color(0.55, 0.95, 0.10), "secondary": Color(0.08, 0.10, 0.06), "metallic": 0.10, "roughness": 0.30, "cost": 80},
	{"name": "Królewska", "category": "cartoon", "primary": Color(0.10, 0.36, 0.95), "secondary": Color(0.95, 0.80, 0.25), "metallic": 0.15, "roughness": 0.28, "cost": 90},
	{"name": "Wisienka", "category": "cartoon", "primary": Color(0.90, 0.10, 0.20), "secondary": Color(0.97, 0.97, 0.97), "metallic": 0.10, "roughness": 0.28, "cost": 90},
	# --- Neonowa: ciemne bryły ze świecącymi akcentami ---
	{"name": "Cyber", "category": "neon", "primary": Color(0.04, 0.05, 0.09), "secondary": Color(0.0, 0.9, 1.0), "metallic": 0.55, "roughness": 0.30, "cost": 130},
	{"name": "Magenta noc", "category": "neon", "primary": Color(0.09, 0.03, 0.11), "secondary": Color(1.0, 0.15, 0.85), "metallic": 0.55, "roughness": 0.30, "cost": 130},
	{"name": "Kwas", "category": "neon", "primary": Color(0.04, 0.07, 0.04), "secondary": Color(0.55, 1.0, 0.10), "metallic": 0.5, "roughness": 0.32, "cost": 140},
	{"name": "Zachód", "category": "neon", "primary": Color(0.10, 0.04, 0.04), "secondary": Color(1.0, 0.45, 0.05), "metallic": 0.5, "roughness": 0.32, "cost": 140},
	# --- Pastelowa: jasne, matowe, miękkie kolory ---
	{"name": "Mięta", "category": "pastel", "primary": Color(0.72, 0.90, 0.82), "secondary": Color(0.95, 0.97, 0.95), "metallic": 0.0, "roughness": 0.72, "cost": 70},
	{"name": "Brzoskwinia", "category": "pastel", "primary": Color(0.97, 0.78, 0.70), "secondary": Color(0.98, 0.95, 0.92), "metallic": 0.0, "roughness": 0.72, "cost": 70},
	{"name": "Lawenda", "category": "pastel", "primary": Color(0.80, 0.74, 0.93), "secondary": Color(0.97, 0.96, 0.99), "metallic": 0.0, "roughness": 0.72, "cost": 70},
	{"name": "Niebo", "category": "pastel", "primary": Color(0.72, 0.84, 0.95), "secondary": Color(0.97, 0.98, 1.0), "metallic": 0.0, "roughness": 0.72, "cost": 70}
]

const NEON_COLORS: Array[Dictionary] = [
	{"name": "Cyjan", "color": Color(0.0, 0.9, 1.0)},
	{"name": "Magenta", "color": Color(1.0, 0.15, 0.85)},
	{"name": "Zielony", "color": Color(0.2, 1.0, 0.35)},
	{"name": "Pomarańcz", "color": Color(1.0, 0.5, 0.05)},
	{"name": "Czerwony", "color": Color(1.0, 0.1, 0.1)},
	{"name": "Fiolet", "color": Color(0.55, 0.2, 1.0)},
	{"name": "Złoty", "color": Color(1.0, 0.85, 0.2)},
	{"name": "Biały", "color": Color(0.95, 0.95, 1.0)}
]

## Ulepszenia: 5 poziomów, rozsądne limity, żeby nie zaburzyć balansu.
const UPGRADE_MAX_LEVEL: int = 5
const UPGRADE_COSTS: Array[int] = [100, 180, 300, 450, 650]

const UPGRADES: Array[Dictionary] = [
	{"id": "speed", "name": "Prędkość maks.", "per_level": 0.03, "unit": "%", "description": "+3% prędkości maksymalnej na poziom"},
	{"id": "accel", "name": "Przyspieszenie", "per_level": 0.05, "unit": "%", "description": "+5% przyspieszenia na poziom"},
	{"id": "grip", "name": "Przyczepność", "per_level": 0.05, "unit": "%", "description": "+5% przyczepności bocznej na poziom"},
	{"id": "capacity", "name": "Zbiornik brudu", "per_level": 3.0, "unit": "", "description": "+3 jednostki pojemności na poziom"},
	{"id": "battery", "name": "Pojemność baterii", "per_level": 0.08, "unit": "%", "description": "+8% pojemności baterii na poziom"},
	{"id": "bumper", "name": "Pancerny zderzak", "per_level": 0.06, "unit": "%", "description": "−6% uszkodzeń od kolizji na poziom"},
	{"id": "boost", "name": "Moc boosta", "per_level": 0.04, "unit": "%", "description": "+4% mocy i -0.25 s odnowienia na poziom"}
]

## Wspólne parametry boosta (koszt w brudzie, czas działania, odnowienie).
const BOOST_DIRT_COST: float = 5.0
const BOOST_DURATION: float = 2.0
const BOOST_COOLDOWN: float = 3.5


static func count() -> int:
	return ROBOTS.size()


static func get_robot(index: int) -> Dictionary:
	return ROBOTS[clampi(index, 0, ROBOTS.size() - 1)]


static func get_skin(index: int) -> Dictionary:
	return SKINS[clampi(index, 0, SKINS.size() - 1)]


static func get_neon_color(index: int) -> Color:
	return NEON_COLORS[clampi(index, 0, NEON_COLORS.size() - 1)]["color"]


static func get_upgrade_cost(current_level: int) -> int:
	if current_level < 0 or current_level >= UPGRADE_MAX_LEVEL:
		return -1
	return UPGRADE_COSTS[current_level]


static func empty_upgrades() -> Dictionary:
	return {"speed": 0, "accel": 0, "grip": 0, "capacity": 0, "battery": 0, "bumper": 0, "boost": 0}


## Pełna konfiguracja robota do wyścigu (statystyki po ulepszeniach + wygląd).
static func build_config(robot_index: int, upgrades: Dictionary, skin_index: int, neon_index: int) -> Dictionary:
	var data: Dictionary = get_robot(robot_index)
	var skin: Dictionary = get_skin(skin_index)

	var up_speed: int = clampi(int(upgrades.get("speed", 0)), 0, UPGRADE_MAX_LEVEL)
	var up_accel: int = clampi(int(upgrades.get("accel", 0)), 0, UPGRADE_MAX_LEVEL)
	var up_grip: int = clampi(int(upgrades.get("grip", 0)), 0, UPGRADE_MAX_LEVEL)
	var up_capacity: int = clampi(int(upgrades.get("capacity", 0)), 0, UPGRADE_MAX_LEVEL)
	var up_battery: int = clampi(int(upgrades.get("battery", 0)), 0, UPGRADE_MAX_LEVEL)
	var up_bumper: int = clampi(int(upgrades.get("bumper", 0)), 0, UPGRADE_MAX_LEVEL)
	var up_boost: int = clampi(int(upgrades.get("boost", 0)), 0, UPGRADE_MAX_LEVEL)

	var primary: Color = data["color"]
	if skin["primary"] != null:
		primary = skin["primary"]

	# Moc boosta z danych (1.5-2.4) przeliczamy na rozsądny mnożnik prędkości
	# (1.18-1.49), aby boost był wyraźny, ale nie wyrzucał robotów z trasy.
	var boost_power: float = float(data["boost_power"]) * (1.0 + up_boost * 0.04)

	var config: Dictionary = {
		"robot_index": clampi(robot_index, 0, ROBOTS.size() - 1),
		"name": data["name"],
		"shape": data["shape"],
		"max_speed": float(data["speed"]) * (1.0 + up_speed * 0.03),
		"acceleration": float(data["acceleration"]) * (1.0 + up_accel * 0.05),
		"grip": float(data["grip"]) * (1.0 + up_grip * 0.05),
		"capacity": float(data["capacity"]) + up_capacity * 3.0,
		"battery_capacity": float(data.get("battery_capacity", 100.0)) * (1.0 + up_battery * 0.08),
		"damage_resistance_multiplier": 1.0 - up_bumper * 0.06,
		"boost_speed_multiplier": 1.0 + (boost_power - 1.0) * 0.35,
		"boost_duration": BOOST_DURATION,
		"boost_cooldown": maxf(BOOST_COOLDOWN - up_boost * 0.25, 1.5),
		"boost_cost": BOOST_DIRT_COST,
		"primary_color": primary,
		"secondary_color": skin["secondary"],
		"metallic": float(skin["metallic"]),
		"roughness": float(skin["roughness"]),
		"skin_category": str(skin.get("category", "factory")),
		"upgrade_levels": {"speed": up_speed, "accel": up_accel, "grip": up_grip, "capacity": up_capacity, "battery": up_battery, "bumper": up_bumper, "boost": up_boost},
		"neon_color": get_neon_color(neon_index),
		"skin_index": skin_index,
		"neon_index": neon_index
	}
	config["ovr"] = calculate_ovr(config)
	return config


## Ocena ogólna 1..100: średnia z sześciu głównych parametrów.
## Normalizacja korzysta z tych samych zakresów co paski statystyk w garażu.
static func calculate_ovr(config: Dictionary) -> int:
	var stats: Array[String] = [
		"max_speed",
		"acceleration",
		"grip",
		"capacity",
		"battery_capacity",
		"boost_speed_multiplier"
	]
	var total: float = 0.0
	for stat: String in stats:
		total += clampf(normalized_stat(stat, float(config.get(stat, 0.0))), 0.0, 1.0)
	return clampi(roundi((total / float(stats.size())) * 100.0), 1, 100)


## Zwraca wartość statystyki znormalizowaną 0..1 do pasków w garażu.
static func normalized_stat(stat: String, value: float) -> float:
	match stat:
		"max_speed":
			return inverse_lerp(2.2, 4.2, value)
		"acceleration":
			return inverse_lerp(1.5, 4.0, value)
		"grip":
			return inverse_lerp(4.0, 12.0, value)
		"capacity":
			return inverse_lerp(5.0, 45.0, value)
		"battery_capacity":
			return inverse_lerp(70.0, 200.0, value)
		"boost_speed_multiplier":
			return inverse_lerp(1.15, 1.85, value)
	return 0.5
