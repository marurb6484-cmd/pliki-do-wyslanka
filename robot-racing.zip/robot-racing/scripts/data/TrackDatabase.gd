class_name TrackDatabase
extends RefCounted

const TrackGeneratorScript = preload("res://scripts/tracks/TrackGenerator.gd")
## Rejestr tras. Aby dodać nową trasę:
##  1. Utwórz scenę trasy, której korzeń używa skryptu dziedziczącego po TrackBase
##     (waypointy jako Marker3D w węźle "Waypoints", własna geometria, światło itd.).
##  2. Dopisz wpis poniżej.
## Wszystkie systemy (wyścig, AI, brud, nawigacja, rekordy) odczytają trasę same.

static var _default_track_cache: Dictionary = {}

const TRACKS: Array[Dictionary] = [
	{
		"id": "apartment",
		"name": "MIESZKANIE",
		"scene": "res://scenes/TrackApartment.tscn",
		"description": "Mieszkanie z pokojami 5–20 m² i trasą dopasowaną do odkurzacza 30–35 cm.",
		"default_laps": 3
	}
]


static func count() -> int:
	return TRACKS.size()


static func get_track(index: int) -> Dictionary:
	var safe_index: int = clampi(index, 0, TRACKS.size() - 1)
	if safe_index == 0:
		if _default_track_cache.is_empty():
			var generated: Dictionary = TrackGeneratorScript.generate(20261117, 1, 2, 1, "apartment", "MIESZKANIE", 5, 2, 1, "lap")
			generated["id"] = "apartment"
			generated["track_id"] = "apartment"
			generated["name"] = "MIESZKANIE"
			generated["display_name"] = "MIESZKANIE"
			generated["description"] = "Mieszkanie z pokojami 5–20 m² i trasą dopasowaną do odkurzacza 30–35 cm."
			generated["scene"] = str(TRACKS[0]["scene"])
			_default_track_cache = generated
		return _default_track_cache.duplicate(true)
	return TRACKS[safe_index].duplicate(true)


static func find_index(track_id: String) -> int:
	for i: int in range(TRACKS.size()):
		if str(TRACKS[i]["id"]) == track_id:
			return i
	return 0


static func find_index_by_scene(scene_path: String) -> int:
	for i: int in range(TRACKS.size()):
		if str(TRACKS[i]["scene"]) == scene_path:
			return i
	return -1
