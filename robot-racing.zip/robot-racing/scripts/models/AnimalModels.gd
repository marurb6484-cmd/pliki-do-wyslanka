class_name AnimalModels
extends RefCounted
## Modele 3D dziesięciu gatunków zwierząt domowych i małych zwierząt.
##
## Każde zwierzę ma własną sylwetkę i jest złożone z nazwanych części
## (Body, Head, Tail, LegFL/FR/BL/BR lub Wing…) z pivotami — gotowe do animacji.
## Zwierzę stoi na y = 0 i patrzy w stronę -Z. Materiały są zwykłymi
## StandardMaterial3D, więc skórki (ObjectSkins) działają bez zmian.
## Logika ruchu i wpływu na wyścig jest w TrackAnimal.gd i nie została ruszona.

const SPECIES: Array[String] = ["cat", "dog", "rabbit", "bearded_dragon", "parrot", "hamster", "guinea_pig", "turtle", "hedgehog", "ferret"]

const FUR_COLORS: Dictionary = {
	"cat": ["#d58b4e", "#6e7884", "#f0e7d8", "#35343a"],
	"dog": ["#c98a54", "#e6d7bd", "#51443d", "#8d694f"],
	"rabbit": ["#eee3d3", "#a9aeb5", "#c99a78", "#6e625e"],
	"bearded_dragon": ["#c7a66b", "#a9a16a", "#d18a55", "#8d795a"],
	"parrot": ["#20b96b", "#e64c3c", "#168bd1", "#e8c83e"],
	"hamster": ["#d7a66d", "#b8a18a", "#e5c8a0", "#8d765f"],
	"guinea_pig": ["#c98f62", "#e7dfd0", "#766b62", "#b9a17d"],
	"turtle": ["#668b4f", "#9b8054", "#547a70", "#b48a52"],
	"hedgehog": ["#9b7654", "#b18b63", "#75614e", "#d0b18a"],
	"ferret": ["#e7d7b5", "#9c8b79", "#f0e6d2", "#6c5c50"],
}

const COL_EYE: Color = Color("#171b20")
const COL_GLINT: Color = Color("#ffffff")
const COL_PINK: Color = Color("#e8a0a6")
const COL_CREAM: Color = Color("#f4e8d6")


static func build(parent: Node3D, species: String, variant: int) -> void:
	var palette: Array = FUR_COLORS.get(species, FUR_COLORS["cat"])
	var fur: Color = Color(str(palette[posmod(variant, palette.size())]))
	var b := ModelBuilder.new()
	match species:
		"cat":
			_cat(b, fur, variant)
		"dog":
			_dog(b, fur, variant)
		"rabbit":
			_rabbit(b, fur, variant)
		"bearded_dragon":
			_dragon(b, fur, variant)
		"parrot":
			_parrot(b, fur, variant)
		"hamster":
			_small_mammal(b, fur, variant, "hamster")
		"guinea_pig":
			_small_mammal(b, fur, variant, "guinea_pig")
		"turtle":
			_turtle(b, fur, variant)
		"hedgehog":
			_small_mammal(b, fur, variant, "hedgehog")
		"ferret":
			_small_mammal(b, fur, variant, "ferret")
		_:
			_cat(b, fur, variant)
	b.build(parent)


static func _small_mammal(b: ModelBuilder, fur: Color, variant: int, species: String) -> void:
	var dark: Color = fur.darkened(0.30)
	var body_len: float = 0.43 if species == "hamster" else 0.58 if species == "ferret" else 0.48
	var body_w: float = 0.31 if species != "ferret" else 0.25
	b.part("Body", Vector3(0.0, 0.34, 0.08))
	b.ellipsoid(Vector3(0.0, 0.35, 0.08), Vector3(body_w, 0.29, body_len), fur, Vector3.ZERO, 2.5)
	if species == "hedgehog":
		for i: int in range(7):
			for side: float in [-1.0, 1.0]:
				b.cone(Vector3(side * (0.08 + float(i) * 0.025), 0.62, -0.12 + float(i) * 0.055), 0.035, 0.24, dark, Vector3(0.35, 0.0, side * 0.35))
	if species == "guinea_pig":
		b.ellipsoid(Vector3(0.0, 0.39, -0.25), Vector3(0.25, 0.20, 0.18), fur.lightened(0.25))
	if species == "ferret":
		b.ellipsoid(Vector3(0.0, 0.31, 0.43), Vector3(0.07, 0.07, 0.22), fur)
	b.part("Head", Vector3(0.0, 0.57, -0.30))
	b.ellipsoid(Vector3(0.0, 0.59, -0.34), Vector3(0.23, 0.20, 0.22), fur.lightened(0.08), Vector3.ZERO, 2.4)
	for side: float in [-1.0, 1.0]:
		b.ellipsoid(Vector3(side * 0.18, 0.69, -0.32), Vector3(0.09, 0.10, 0.08), fur)
		_eye(b, side, Vector3(0.11, 0.62, -0.50), 0.045, Color("#4c3428"))
	b.ellipsoid(Vector3(0.0, 0.51, -0.54), Vector3(0.07, 0.05, 0.07), COL_PINK)
	b.part("Tail", Vector3(0.0, 0.34, 0.46))
	for side: float in [-1.0, 1.0]:
		for front: bool in [true, false]:
			var z: float = -0.20 if front else 0.30
			var x: float = side * 0.18
			var tag: String = "F" if front else "B"
			b.part("Leg%s%s" % [tag, "L" if side < 0.0 else "R"], Vector3(x, 0.28, z))
			b.cylinder(Vector3(x, 0.13, z), 0.055, 0.05, 0.25, fur)


static func _turtle(b: ModelBuilder, shell: Color, variant: int) -> void:
	var skin: Color = shell.lightened(0.25)
	b.part("Body", Vector3(0.0, 0.34, 0.08))
	b.ellipsoid(Vector3(0.0, 0.34, 0.08), Vector3(0.38, 0.16, 0.48), skin)
	b.ellipsoid(Vector3(0.0, 0.57, 0.08), Vector3(0.39, 0.27, 0.48), shell.darkened(0.12), Vector3.ZERO, 2.2)
	b.ellipsoid(Vector3(0.0, 0.58, 0.08), Vector3(0.31, 0.23, 0.40), shell, Vector3.ZERO, 2.2)
	b.part("Head", Vector3(0.0, 0.46, -0.48))
	b.ellipsoid(Vector3(0.0, 0.48, -0.52), Vector3(0.19, 0.17, 0.25), skin)
	for side: float in [-1.0, 1.0]:
		_eye(b, side, Vector3(0.11, 0.53, -0.68), 0.035, Color("#3d4c2f"))
		for front: bool in [true, false]:
			var z: float = -0.24 if front else 0.34
			var x: float = side * 0.31
			var tag: String = "F" if front else "B"
			b.part("Leg%s%s" % [tag, "L" if side < 0.0 else "R"], Vector3(x, 0.28, z))
			b.ellipsoid(Vector3(x, 0.15, z), Vector3(0.13, 0.13, 0.16), skin)
	b.part("Tail", Vector3(0.0, 0.29, 0.49))
	b.cone(Vector3(0.0, 0.26, 0.61), 0.10, 0.20, skin, Vector3(PI * 0.5, 0.0, 0.0))


static func _eye(b: ModelBuilder, side: float, pos: Vector3, size: float, iris: Color) -> void:
	b.ellipsoid(Vector3(side * pos.x, pos.y, pos.z), Vector3(size, size * 1.15, size * 0.55), iris, Vector3.ZERO, 2.0, 0.25)
	b.ellipsoid(Vector3(side * pos.x, pos.y, pos.z - size * 0.35), Vector3(size * 0.62, size * 0.85, size * 0.3), COL_EYE, Vector3.ZERO, 2.0, 0.2)
	b.ellipsoid(Vector3(side * (pos.x + size * 0.25), pos.y + size * 0.45, pos.z - size * 0.6), Vector3(size * 0.2, size * 0.24, size * 0.12), COL_GLINT, Vector3.ZERO, 2.0, 0.1)


static func _cat(b: ModelBuilder, fur: Color, variant: int) -> void:
	var dark: Color = fur.darkened(0.28)
	b.part("Body", Vector3(0.0, 0.45, 0.1))
	b.ellipsoid(Vector3(0.0, 0.47, 0.14), Vector3(0.30, 0.30, 0.50), fur, Vector3.ZERO, 2.6)
	b.ellipsoid(Vector3(0.0, 0.50, -0.26), Vector3(0.28, 0.30, 0.27), fur.lightened(0.04), Vector3.ZERO, 2.4)
	b.ellipsoid(Vector3(0.0, 0.40, -0.40), Vector3(0.16, 0.20, 0.13), COL_CREAM)
	for side: float in [-1.0, 1.0]:
		b.ellipsoid(Vector3(side * 0.22, 0.38, 0.40), Vector3(0.17, 0.24, 0.26), fur, Vector3.ZERO, 2.4)
	if variant < 2:
		for k: int in range(4):
			b.ellipsoid(Vector3(0.0, 0.74 - absf(float(k) - 1.5) * 0.02, -0.08 + float(k) * 0.17), Vector3(0.20, 0.035, 0.05), dark)
	b.part("Head", Vector3(0.0, 0.84, -0.46))
	b.ellipsoid(Vector3(0.0, 0.86, -0.52), Vector3(0.28, 0.25, 0.24), fur, Vector3.ZERO, 2.4)
	b.ellipsoid(Vector3(0.0, 0.77, -0.72), Vector3(0.12, 0.09, 0.09), COL_CREAM)
	b.ellipsoid(Vector3(0.0, 0.81, -0.80), Vector3(0.035, 0.025, 0.025), COL_PINK, Vector3.ZERO, 2.0, 0.4)
	for side: float in [-1.0, 1.0]:
		b.ellipsoid(Vector3(side * 0.17, 0.77, -0.64), Vector3(0.10, 0.07, 0.09), COL_CREAM)
		b.cone(Vector3(side * 0.17, 1.12, -0.50), 0.12, 0.26, fur, Vector3(0.0, 0.0, -side * 0.18))
		b.cone(Vector3(side * 0.17, 1.10, -0.54), 0.075, 0.18, COL_PINK, Vector3(0.0, 0.0, -side * 0.18))
		_eye(b, side, Vector3(0.115, 0.90, -0.735), 0.055, Color("#8fd16a"))
		for k: int in range(3):
			b.cylinder(Vector3(side * 0.22, 0.78 - float(k) * 0.03, -0.76), 0.006, 0.006, 0.30, COL_CREAM, Vector3(0.0, 0.0, PI * 0.5 + side * (float(k) - 1.0) * 0.18))
	b.part("Tail", Vector3(0.0, 0.52, 0.62))
	for k: int in range(7):
		var t: float = float(k) / 6.0
		var tail_color: Color = dark if k >= 5 else fur
		b.ellipsoid(Vector3(0.0, 0.55 + t * 0.58, 0.64 + 0.20 * sin(t * 2.3)), Vector3(0.062, 0.12, 0.062), tail_color, Vector3(0.45 * t, 0.0, 0.0))
	for side: float in [-1.0, 1.0]:
		b.part("LegF%s" % ("L" if side < 0.0 else "R"), Vector3(side * 0.17, 0.42, -0.28))
		b.cylinder(Vector3(side * 0.17, 0.22, -0.28), 0.075, 0.06, 0.40, fur)
		b.ellipsoid(Vector3(side * 0.17, 0.05, -0.31), Vector3(0.085, 0.05, 0.11), COL_CREAM)
		b.part("LegB%s" % ("L" if side < 0.0 else "R"), Vector3(side * 0.2, 0.40, 0.42))
		b.cylinder(Vector3(side * 0.2, 0.16, 0.44), 0.07, 0.05, 0.30, fur)
		b.ellipsoid(Vector3(side * 0.2, 0.045, 0.40), Vector3(0.085, 0.05, 0.12), COL_CREAM)


static func _dog(b: ModelBuilder, fur: Color, variant: int) -> void:
	var dark: Color = fur.darkened(0.28)
	var snout_color: Color = fur.lightened(0.28)
	b.part("Body", Vector3(0.0, 0.52, 0.1))
	b.ellipsoid(Vector3(0.0, 0.54, 0.12), Vector3(0.34, 0.34, 0.60), fur, Vector3.ZERO, 2.5)
	b.ellipsoid(Vector3(0.0, 0.52, -0.36), Vector3(0.32, 0.34, 0.30), fur.lightened(0.05), Vector3.ZERO, 2.4)
	b.ellipsoid(Vector3(0.0, 0.40, -0.14), Vector3(0.24, 0.12, 0.40), snout_color)
	if variant >= 2:
		b.ellipsoid(Vector3(0.22, 0.66, 0.12), Vector3(0.14, 0.14, 0.22), dark, Vector3(0.0, 0.0, -0.4))
	b.part("Head", Vector3(0.0, 0.86, -0.50))
	b.ellipsoid(Vector3(0.0, 0.92, -0.58), Vector3(0.30, 0.27, 0.28), fur.lightened(0.03), Vector3.ZERO, 2.3)
	b.ellipsoid(Vector3(0.0, 0.81, -0.88), Vector3(0.16, 0.12, 0.20), snout_color, Vector3.ZERO, 2.4)
	b.ellipsoid(Vector3(0.0, 0.88, -1.06), Vector3(0.065, 0.05, 0.05), Color("#2b2523"), Vector3.ZERO, 2.0, 0.3)
	if variant % 2 == 1:
		b.ellipsoid(Vector3(0.0, 0.70, -0.95), Vector3(0.06, 0.018, 0.10), COL_PINK, Vector3(-0.2, 0.0, 0.0))
	for side: float in [-1.0, 1.0]:
		_eye(b, side, Vector3(0.14, 0.99, -0.83), 0.058, Color("#5a3b26"))
		b.ellipsoid(Vector3(side * 0.31, 0.88, -0.52), Vector3(0.075, 0.21, 0.15), dark, Vector3(0.0, 0.0, side * 0.35))
		b.ellipsoid(Vector3(side * 0.15, 1.08, -0.80), Vector3(0.09, 0.025, 0.04), dark, Vector3(0.0, 0.0, side * 0.3))
	b.torus(Vector3(0.0, 0.70, -0.42), 0.19, 0.26, Color("#cf3e48"), Vector3(PI * 0.5 - 0.3, 0.0, 0.0))
	b.ellipsoid(Vector3(0.0, 0.52, -0.62), Vector3(0.05, 0.065, 0.025), Color("#e8c65a"), Vector3.ZERO, 2.0, 0.3, 0.6)
	b.part("Tail", Vector3(0.0, 0.70, 0.72))
	for k: int in range(6):
		var t: float = float(k) / 5.0
		b.ellipsoid(Vector3(0.0, 0.72 + t * 0.46, 0.74 + t * 0.26), Vector3(0.06 - t * 0.012, 0.12, 0.06 - t * 0.012), fur.lightened(0.1) if k == 5 else fur, Vector3(0.5, 0.0, 0.0))
	for side: float in [-1.0, 1.0]:
		var tag: String = "L" if side < 0.0 else "R"
		b.part("LegF" + tag, Vector3(side * 0.2, 0.56, -0.32))
		b.cylinder(Vector3(side * 0.2, 0.28, -0.32), 0.10, 0.08, 0.56, fur)
		b.ellipsoid(Vector3(side * 0.2, 0.05, -0.36), Vector3(0.10, 0.055, 0.14), snout_color)
		b.part("LegB" + tag, Vector3(side * 0.26, 0.56, 0.42))
		b.ellipsoid(Vector3(side * 0.27, 0.42, 0.42), Vector3(0.17, 0.26, 0.28), fur, Vector3.ZERO, 2.4)
		b.cylinder(Vector3(side * 0.24, 0.17, 0.46), 0.08, 0.07, 0.34, fur)
		b.ellipsoid(Vector3(side * 0.24, 0.05, 0.42), Vector3(0.10, 0.055, 0.14), snout_color)


static func _rabbit(b: ModelBuilder, fur: Color, variant: int) -> void:
	var light: Color = fur.lightened(0.22)
	b.part("Body", Vector3(0.0, 0.40, 0.1))
	b.ellipsoid(Vector3(0.0, 0.42, 0.10), Vector3(0.34, 0.36, 0.46), fur, Vector3.ZERO, 2.2)
	b.ellipsoid(Vector3(0.0, 0.34, -0.22), Vector3(0.22, 0.22, 0.16), light)
	for side: float in [-1.0, 1.0]:
		b.ellipsoid(Vector3(side * 0.26, 0.36, 0.30), Vector3(0.20, 0.28, 0.30), fur, Vector3.ZERO, 2.3)
	if variant == 2:
		b.ellipsoid(Vector3(-0.2, 0.62, 0.08), Vector3(0.18, 0.12, 0.22), fur.darkened(0.25), Vector3(0.0, 0.0, 0.5))
	b.part("Head", Vector3(0.0, 0.70, -0.38))
	b.ellipsoid(Vector3(0.0, 0.74, -0.40), Vector3(0.25, 0.23, 0.25), fur.lightened(0.03), Vector3.ZERO, 2.3)
	b.ellipsoid(Vector3(0.0, 0.67, -0.60), Vector3(0.13, 0.10, 0.10), light)
	b.ellipsoid(Vector3(0.0, 0.71, -0.68), Vector3(0.035, 0.028, 0.025), COL_PINK, Vector3.ZERO, 2.0, 0.4)
	b.ellipsoid(Vector3(0.0, 0.60, -0.67), Vector3(0.05, 0.05, 0.02), Color("#fff9ed"))
	for side: float in [-1.0, 1.0]:
		b.ellipsoid(Vector3(side * 0.13, 0.66, -0.55), Vector3(0.12, 0.10, 0.11), light)
		_eye(b, side, Vector3(0.15, 0.80, -0.58), 0.05, Color("#3a2a24"))
		b.ellipsoid(Vector3(side * 0.13, 1.20, -0.34), Vector3(0.075, 0.34, 0.045), fur, Vector3(0.0, 0.0, -side * 0.12))
		b.ellipsoid(Vector3(side * 0.13, 1.19, -0.37), Vector3(0.042, 0.26, 0.02), COL_PINK, Vector3(0.0, 0.0, -side * 0.12))
		for k: int in range(2):
			b.cylinder(Vector3(side * 0.20, 0.66 - float(k) * 0.04, -0.66), 0.005, 0.005, 0.24, COL_CREAM, Vector3(0.0, 0.0, PI * 0.5 + side * (float(k) - 0.5) * 0.3))
	b.part("Tail", Vector3(0.0, 0.44, 0.52))
	b.ellipsoid(Vector3(0.0, 0.44, 0.58), Vector3(0.12, 0.12, 0.12), Color("#fff6ea"))
	for side: float in [-1.0, 1.0]:
		var tag: String = "L" if side < 0.0 else "R"
		b.part("LegF" + tag, Vector3(side * 0.14, 0.28, -0.22))
		b.cylinder(Vector3(side * 0.14, 0.14, -0.22), 0.055, 0.045, 0.28, fur)
		b.ellipsoid(Vector3(side * 0.14, 0.04, -0.26), Vector3(0.06, 0.04, 0.09), light)
		b.part("LegB" + tag, Vector3(side * 0.27, 0.20, 0.30))
		b.ellipsoid(Vector3(side * 0.27, 0.05, 0.20), Vector3(0.09, 0.045, 0.23), light)


static func _dragon(b: ModelBuilder, fur: Color, variant: int) -> void:
	var belly: Color = fur.lightened(0.28)
	var beard: Color = fur.darkened(0.30)
	var band: Color = fur.darkened(0.22)
	b.part("Body", Vector3(0.0, 0.28, 0.05))
	b.ellipsoid(Vector3(0.0, 0.28, 0.05), Vector3(0.42, 0.17, 0.62), fur, Vector3.ZERO, 2.4, 0.9)
	b.ellipsoid(Vector3(0.0, 0.20, 0.05), Vector3(0.34, 0.10, 0.55), belly, Vector3.ZERO, 2.2, 0.9)
	for k: int in range(4):
		b.ellipsoid(Vector3(0.0, 0.43, -0.25 + float(k) * 0.2), Vector3(0.30, 0.03, 0.05), band, Vector3.ZERO, 2.0, 0.9)
	for side: float in [-1.0, 1.0]:
		for k: int in range(7):
			b.cone(Vector3(side * 0.40, 0.30, -0.35 + float(k) * 0.14), 0.03, 0.12, beard, Vector3(0.0, 0.0, -side * 1.35), 0.9)
	b.part("Head", Vector3(0.0, 0.34, -0.55))
	b.ellipsoid(Vector3(0.0, 0.34, -0.66), Vector3(0.26, 0.14, 0.30), fur.lightened(0.04), Vector3.ZERO, 2.4, 0.9)
	b.ellipsoid(Vector3(0.0, 0.31, -0.92), Vector3(0.13, 0.08, 0.14), fur, Vector3.ZERO, 2.4, 0.9)
	b.ellipsoid(Vector3(0.0, 0.22, -0.76), Vector3(0.20, 0.09, 0.17), beard, Vector3.ZERO, 2.2, 0.9)
	for k: int in range(7):
		var angle: float = -1.3 + float(k) * (2.6 / 6.0)
		b.cone(Vector3(sin(angle) * 0.21, 0.20 - cos(angle) * 0.02, -0.76 - cos(angle) * 0.14), 0.035, 0.13, beard, Vector3(-0.9, 0.0, -angle * 0.9), 0.9)
	b.ellipsoid(Vector3(0.0, 0.26, -1.0), Vector3(0.07, 0.012, 0.02), COL_EYE)
	for side: float in [-1.0, 1.0]:
		b.ellipsoid(Vector3(side * 0.17, 0.44, -0.72), Vector3(0.07, 0.065, 0.07), fur.lightened(0.08), Vector3.ZERO, 2.0, 0.9)
		b.ellipsoid(Vector3(side * 0.20, 0.45, -0.74), Vector3(0.045, 0.05, 0.045), Color("#d9a441") if variant != 3 else Color("#b8b8b8"), Vector3.ZERO, 2.0, 0.3)
		b.ellipsoid(Vector3(side * 0.225, 0.455, -0.755), Vector3(0.022, 0.034, 0.022), COL_EYE, Vector3.ZERO, 2.0, 0.2)
	b.part("Tail", Vector3(0.0, 0.22, 0.62))
	for k: int in range(9):
		var t: float = float(k) / 8.0
		b.ellipsoid(Vector3(sin(t * 2.2) * 0.2, 0.21 - t * 0.09, 0.64 + t * 0.95), Vector3(0.15 * (1.0 - t) + 0.025, 0.11 * (1.0 - t) + 0.02, 0.17), band if k % 2 == 1 else fur, Vector3(0.0, -cos(t * 2.2) * 0.3, 0.0), 2.2, 0.9)
	for side: float in [-1.0, 1.0]:
		var tag: String = "L" if side < 0.0 else "R"
		for front: bool in [true, false]:
			var leg_z: float = -0.38 if front else 0.42
			b.part(("LegF" if front else "LegB") + tag, Vector3(side * 0.36, 0.22, leg_z))
			b.ellipsoid(Vector3(side * 0.44, 0.20, leg_z), Vector3(0.15, 0.065, 0.09), fur, Vector3(0.0, 0.0, side * 0.25), 2.2, 0.9)
			b.ellipsoid(Vector3(side * 0.56, 0.10, leg_z - 0.04), Vector3(0.06, 0.12, 0.07), fur, Vector3(0.0, 0.0, side * -0.2), 2.2, 0.9)
			for toe: int in range(3):
				b.ellipsoid(Vector3(side * 0.60, 0.035, leg_z - 0.10 + float(toe) * 0.06), Vector3(0.07, 0.03, 0.03), belly, Vector3.ZERO, 2.0, 0.9)


static func _parrot(b: ModelBuilder, fur: Color, variant: int) -> void:
	var wood: Color = Color("#9a7049")
	var belly: Color = Color("#f2d16b") if variant != 3 else Color("#f6ecc0")
	var wing: Color = fur.darkened(0.16)
	var wing_tip: Color = Color("#168bd1") if variant != 2 else Color("#e8c83e")
	b.part("Stand", Vector3.ZERO)
	b.cylinder(Vector3(0.0, 0.05, 0.0), 0.30, 0.34, 0.10, wood.darkened(0.12), Vector3.ZERO, 0.7)
	b.cylinder(Vector3(0.0, 0.26, 0.0), 0.03, 0.04, 0.42, wood)
	b.cylinder(Vector3(0.0, 0.46, 0.0), 0.035, 0.035, 0.62, wood, Vector3(0.0, 0.0, PI * 0.5))
	b.part("Body", Vector3(0.0, 0.85, 0.05))
	b.ellipsoid(Vector3(0.0, 0.88, 0.05), Vector3(0.30, 0.40, 0.28), fur, Vector3(0.18, 0.0, 0.0), 2.3)
	b.ellipsoid(Vector3(0.0, 0.84, -0.11), Vector3(0.24, 0.33, 0.17), belly, Vector3(0.18, 0.0, 0.0), 2.3)
	for side: float in [-1.0, 1.0]:
		var tag: String = "L" if side < 0.0 else "R"
		b.part("Wing" + tag, Vector3(side * 0.26, 1.10, 0.10))
		b.ellipsoid(Vector3(side * 0.28, 0.88, 0.12), Vector3(0.09, 0.34, 0.20), wing, Vector3(0.12, 0.0, -side * 0.10), 2.2)
		b.ellipsoid(Vector3(side * 0.30, 0.62, 0.18), Vector3(0.075, 0.20, 0.14), wing_tip, Vector3(0.12, 0.0, -side * 0.10), 2.2)
		b.ellipsoid(Vector3(side * 0.33, 0.92, 0.02), Vector3(0.05, 0.16, 0.12), Color("#f0c43b"), Vector3(0.12, 0.0, -side * 0.10), 2.2)
	b.part("Head", Vector3(0.0, 1.24, -0.10))
	b.ellipsoid(Vector3(0.0, 1.30, -0.12), Vector3(0.24, 0.23, 0.23), fur.lightened(0.08), Vector3.ZERO, 2.2)
	b.ellipsoid(Vector3(0.0, 1.23, -0.36), Vector3(0.09, 0.11, 0.12), Color("#f4a52d"), Vector3(-0.5, 0.0, 0.0), 2.2, 0.35)
	b.ellipsoid(Vector3(0.0, 1.13, -0.44), Vector3(0.05, 0.075, 0.05), Color("#c9731c"), Vector3(-0.5, 0.0, 0.0), 2.2, 0.35)
	b.ellipsoid(Vector3(0.0, 1.14, -0.34), Vector3(0.065, 0.04, 0.07), Color("#d87922"), Vector3.ZERO, 2.2, 0.35)
	for side: float in [-1.0, 1.0]:
		b.ellipsoid(Vector3(side * 0.17, 1.33, -0.28), Vector3(0.085, 0.09, 0.03), Color("#f5ead2"), Vector3.ZERO, 2.0, 0.6)
		b.ellipsoid(Vector3(side * 0.18, 1.33, -0.305), Vector3(0.05, 0.055, 0.025), COL_EYE, Vector3.ZERO, 2.0, 0.2)
		b.ellipsoid(Vector3(side * 0.19, 1.355, -0.325), Vector3(0.015, 0.018, 0.01), COL_GLINT, Vector3.ZERO, 2.0, 0.1)
	for k: int in range(3):
		b.cone(Vector3((float(k) - 1.0) * 0.07, 1.55, -0.06 + float(k % 2) * 0.03), 0.04, 0.20, fur.lightened(0.18), Vector3(0.3, 0.0, (float(k) - 1.0) * -0.35))
	b.part("Tail", Vector3(0.0, 0.62, 0.30))
	var tail_colors: Array[Color] = [Color("#e64c3c"), Color("#f0c43b"), Color("#168bd1"), fur]
	for k: int in range(4):
		b.ellipsoid(Vector3(-0.1 + float(k) * 0.067, 0.34, 0.40 + float(k % 2) * 0.03), Vector3(0.05, 0.30, 0.035), tail_colors[k], Vector3(0.35, 0.0, (float(k) - 1.5) * 0.06))
	for side: float in [-1.0, 1.0]:
		b.part("Foot" + ("L" if side < 0.0 else "R"), Vector3(side * 0.1, 0.50, 0.0))
		b.cylinder(Vector3(side * 0.1, 0.56, 0.0), 0.03, 0.03, 0.12, Color("#d69a38"))
		for toe: int in range(3):
			b.ellipsoid(Vector3(side * 0.1 + (float(toe) - 1.0) * 0.03, 0.51, -0.05 + float(toe % 2) * 0.1), Vector3(0.022, 0.022, 0.06), Color("#d69a38"))
