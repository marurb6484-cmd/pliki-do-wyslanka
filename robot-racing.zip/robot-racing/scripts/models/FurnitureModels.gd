class_name FurnitureModels
extends RefCounted
## Modele 3D mebli, przedmiotów domowych, zabawek i dekoracji (rozszerzana biblioteka).
##
## Wymiary odpowiadają dotychczasowym śladom obiektów (hitboxy w ProceduralTrack
## pozostają bez zmian). Model stoi na y = 0, front zwrócony w stronę -Z.
## Bryły są scalane per materiał (ModelBuilder), a materiały to zwykłe
## StandardMaterial3D, więc skórki (ObjectSkins) działają bez żadnych zmian.

const UPHOLSTERY: Array[Color] = [Color("#bd795d"), Color("#527f98"), Color("#78956a"), Color("#9a7aa9")]
const WOODS: Array[Color] = [Color("#8c5a3c"), Color("#b07b4d"), Color("#6e4935"), Color("#c29a69")]
const METAL: Color = Color("#68727d")
const BOOK_COLORS: Array[Color] = [Color("#c0504d"), Color("#4f81bd"), Color("#9bbb59"), Color("#f2b84b"), Color("#8064a2"), Color("#d9d2c0")]

const KINDS: Array[String] = ["plant", "sofa", "table", "lamp", "toy", "fish_tank", "bookshelf", "box", "pillow", "chair", "bed", "cabinet", "pet_bowl", "robot_toy", "rug", "tv", "tv_wall", "scratching_post", "pet_bed", "shoe", "sock", "mug", "book", "remote", "tennis_ball", "yarn", "paper_scrap", "food_scraps", "cable", "backpack", "fridge", "bathtub", "sink", "kitchen_counter", "nightstand", "wardrobe", "coffee_table", "side_table", "shoe_rack", "ottoman", "laundry_basket", "floor_mirror", "trash_bin", "floor_fan", "wall_clock", "speaker", "game_console", "laptop", "monitor", "microwave", "toaster", "kettle", "fruit_bowl", "dish_rack", "washing_machine", "toilet", "shower", "radiator", "coat_rack", "umbrella_stand", "suitcase", "toy_car", "pet_tunnel", "water_dispenser", "vase", "candle", "towel_rack", "hanging_plant"]


static func build(parent: Node3D, kind: String, variant: int) -> void:
	var color: Color = UPHOLSTERY[posmod(variant, UPHOLSTERY.size())]
	var wood: Color = WOODS[posmod(variant, WOODS.size())]
	var b := ModelBuilder.new()
	b.part("Body", Vector3.ZERO)
	match kind:
		"plant": _plant(b, variant)
		"sofa": _sofa(b, color, wood)
		"table": _table(b, color, wood)
		"lamp": _lamp(b, variant)
		"toy": _teddy(b, color)
		"fish_tank": _fish_tank(b, wood)
		"bookshelf": _bookshelf(b, wood)
		"box": _box(b, variant)
		"pillow": _pillow(b, color)
		"chair": _chair(b, color, wood)
		"bed": _bed(b, color, wood)
		"cabinet": _cabinet(b, wood)
		"pet_bowl": _pet_bowl(b, color)
		"robot_toy": _robot_toy(b, color)
		"rug": _rug(b, color)
		"tv": _tv(b, wood)
		"tv_wall": _tv_wall(b)
		"scratching_post": _scratching_post(b)
		"pet_bed": _pet_bed(b, color)
		"shoe": _shoe(b, color)
		"sock": _sock(b, color)
		"mug": _mug(b, color)
		"book": _book(b, color)
		"remote": _remote(b)
		"tennis_ball": _tennis_ball(b)
		"yarn": _yarn(b, color)
		"paper_scrap": _paper_scrap(b)
		"food_scraps": _food_scraps(b)
		"cable": _cable(b, variant)
		"backpack": _backpack(b, color)
		"fridge": _fridge(b, variant)
		"bathtub": _bathtub(b)
		"sink": _sink(b)
		"kitchen_counter": _kitchen_counter(b, wood)
		"nightstand": _nightstand(b, wood)
		"wardrobe": _wardrobe(b, wood, variant)
		"coffee_table": _coffee_table(b, wood, color)
		"side_table": _side_table(b, wood)
		"shoe_rack": _shoe_rack(b, wood)
		"ottoman": _ottoman(b, color)
		"laundry_basket": _laundry_basket(b, color)
		"floor_mirror": _floor_mirror(b, wood)
		"trash_bin", "floor_fan", "wall_clock", "speaker", "game_console", "laptop", "monitor", "microwave", "toaster", "kettle", "fruit_bowl", "dish_rack", "washing_machine", "toilet", "shower", "radiator", "coat_rack", "umbrella_stand", "suitcase", "toy_car", "pet_tunnel", "water_dispenser", "vase", "candle", "towel_rack", "hanging_plant": _new_household_prop(b, kind, color, wood, variant)
		_:
			b.ellipsoid(Vector3(0.0, 0.35, 0.0), Vector3(0.42, 0.35, 0.42), color)
	b.build(parent)


static func _new_household_prop(b: ModelBuilder, kind: String, color: Color, wood: Color, variant: int) -> void:
	var metal: Color = Color("#77838d")
	var dark: Color = Color("#26313b")
	match kind:
		"trash_bin":
			b.cylinder(Vector3(0, 0.40, 0), 0.25, 0.30, 0.80, Color("#657783"))
			b.torus(Vector3(0, 0.81, 0), 0.25, 0.31, dark)
			b.soft_box(Vector3(0, 0.85, 0), Vector3(0.48, 0.06, 0.48), Color("#9aa8ae"))
		"floor_fan":
			b.cylinder(Vector3(0, 0.08, 0), 0.28, 0.34, 0.16, metal)
			b.cylinder(Vector3(0, 0.72, 0), 0.055, 0.07, 1.15, metal)
			b.torus(Vector3(0, 1.30, 0), 0.38, 0.44, metal, Vector3(PI * 0.5, 0, 0))
			for i: int in range(3):
				var a: float = TAU * float(i) / 3.0
				b.ellipsoid(Vector3(cos(a) * 0.18, 1.30 + sin(a) * 0.18, 0), Vector3(0.20, 0.07, 0.045), color, Vector3(0, 0, a))
			b.ellipsoid(Vector3(0, 1.30, -0.03), Vector3(0.09, 0.09, 0.09), dark)
		"wall_clock":
			b.cylinder(Vector3(0, 0.30, 0), 0.28, 0.28, 0.10, wood, Vector3(PI * 0.5, 0, 0))
			b.cylinder(Vector3(0, 0.30, -0.06), 0.23, 0.23, 0.025, Color("#f4ead2"), Vector3(PI * 0.5, 0, 0))
			b.box(Vector3(0, 0.40, -0.08), Vector3(0.018, 0.17, 0.018), dark)
			b.box(Vector3(0.06, 0.30, -0.08), Vector3(0.13, 0.018, 0.018), dark)
		"speaker":
			b.soft_box(Vector3(0, 0.42, 0), Vector3(0.46, 0.84, 0.40), dark)
			b.cylinder(Vector3(0, 0.48, -0.21), 0.13, 0.13, 0.04, metal, Vector3(PI * 0.5, 0, 0))
			b.cylinder(Vector3(0, 0.48, -0.24), 0.075, 0.075, 0.025, color, Vector3(PI * 0.5, 0, 0))
			b.cylinder(Vector3(0, 0.18, -0.21), 0.055, 0.055, 0.03, metal, Vector3(PI * 0.5, 0, 0))
		"game_console":
			b.soft_box(Vector3(0, 0.09, 0), Vector3(0.62, 0.18, 0.42), dark)
			b.soft_box(Vector3(0, 0.19, 0), Vector3(0.44, 0.025, 0.28), metal)
			b.ellipsoid(Vector3(0.23, 0.20, -0.08), Vector3(0.025, 0.018, 0.025), Color("#4de2d0"))
		"laptop":
			b.soft_box(Vector3(0, 0.035, 0.12), Vector3(0.56, 0.05, 0.38), metal)
			b.soft_box(Vector3(0, 0.22, -0.07), Vector3(0.54, 0.36, 0.035), dark, Vector3(-0.12, 0, 0))
			b.soft_box(Vector3(0, 0.22, -0.095), Vector3(0.47, 0.29, 0.012), Color("#55a9c9"), Vector3(-0.12, 0, 0))
		"monitor":
			b.soft_box(Vector3(0, 0.46, 0), Vector3(0.72, 0.52, 0.10), dark)
			b.soft_box(Vector3(0, 0.47, -0.06), Vector3(0.64, 0.42, 0.018), Color("#4a9fbd"))
			b.cylinder(Vector3(0, 0.13, 0), 0.035, 0.035, 0.26, metal)
			b.soft_box(Vector3(0, 0.025, 0), Vector3(0.34, 0.04, 0.20), metal)
		"microwave":
			b.soft_box(Vector3(0, 0.21, 0), Vector3(0.64, 0.42, 0.42), metal)
			b.soft_box(Vector3(-0.08, 0.22, -0.215), Vector3(0.42, 0.30, 0.018), dark)
			b.soft_box(Vector3(0.23, 0.22, -0.22), Vector3(0.09, 0.23, 0.025), color)
		"toaster":
			b.soft_box(Vector3(0, 0.16, 0), Vector3(0.40, 0.30, 0.30), color, Vector3.ZERO, 5.0)
			for x: float in [-0.10, 0.10]: b.box(Vector3(x, 0.315, 0), Vector3(0.055, 0.018, 0.19), dark)
		"kettle":
			b.ellipsoid(Vector3(0, 0.22, 0), Vector3(0.17, 0.21, 0.16), metal)
			b.cone(Vector3(0, 0.48, 0), 0.13, 0.18, dark)
			b.torus(Vector3(0.19, 0.28, 0), 0.08, 0.11, dark, Vector3(PI * 0.5, 0, 0))
		"fruit_bowl":
			b.cylinder(Vector3(0, 0.08, 0), 0.27, 0.34, 0.16, color)
			for i: int in range(5):
				var a: float = TAU * float(i) / 5.0
				b.ellipsoid(Vector3(cos(a) * 0.13, 0.22 + float(i % 2) * 0.05, sin(a) * 0.13), Vector3(0.12, 0.10, 0.10), [Color("#d84d3f"), Color("#e6b943"), Color("#68a957")][i % 3])
		"dish_rack":
			b.box(Vector3(0, 0.04, 0), Vector3(0.72, 0.08, 0.38), metal)
			for i: int in range(5):
				b.box(Vector3(-0.27 + float(i) * 0.135, 0.25, 0), Vector3(0.025, 0.40, 0.30), metal)
		"washing_machine":
			b.soft_box(Vector3(0, 0.45, 0), Vector3(0.72, 0.90, 0.68), Color("#d9e1e4"))
			b.cylinder(Vector3(0, 0.42, -0.35), 0.25, 0.25, 0.045, dark, Vector3(PI * 0.5, 0, 0))
			b.cylinder(Vector3(0, 0.42, -0.38), 0.19, 0.19, 0.025, Color("#76a9bb"), Vector3(PI * 0.5, 0, 0))
			b.ellipsoid(Vector3(0.22, 0.78, -0.35), Vector3(0.055, 0.055, 0.025), color)
		"toilet":
			b.soft_box(Vector3(0, 0.58, 0.12), Vector3(0.48, 0.34, 0.28), Color("#e7ecec"))
			b.cylinder(Vector3(0, 0.24, -0.03), 0.25, 0.25, 0.38, Color("#e7ecec"))
			b.torus(Vector3(0, 0.43, -0.12), 0.18, 0.23, Color("#c6d2d5"))
		"shower":
			b.box(Vector3(0, 0.04, 0), Vector3(0.90, 0.08, 0.90), Color("#b7dce6"))
			for x: float in [-0.42, 0.42]: b.box(Vector3(x, 0.98, 0), Vector3(0.035, 1.90, 0.035), metal)
			b.box(Vector3(0, 1.92, 0), Vector3(0.88, 0.035, 0.035), metal)
			b.cylinder(Vector3(0.28, 1.72, 0.05), 0.11, 0.11, 0.05, metal)
		"radiator":
			b.soft_box(Vector3(0, 0.36, 0), Vector3(1.25, 0.72, 0.16), Color("#e6e9e7"))
			for i: int in range(7): b.box(Vector3(-0.52 + float(i) * 0.17, 0.36, -0.09), Vector3(0.045, 0.58, 0.025), metal)
		"coat_rack":
			b.cylinder(Vector3(0, 0.82, 0), 0.035, 0.05, 1.60, wood)
			b.cylinder(Vector3(0, 0.06, 0), 0.30, 0.30, 0.12, metal)
			for i: int in range(4):
				var a: float = TAU * float(i) / 4.0
				b.cylinder(Vector3(cos(a) * 0.18, 1.55, sin(a) * 0.18), 0.018, 0.025, 0.28, wood, Vector3(sin(a) * 0.7, 0, -cos(a) * 0.7))
		"umbrella_stand":
			b.cylinder(Vector3(0, 0.28, 0), 0.18, 0.22, 0.56, dark)
			for i: int in range(3): b.cylinder(Vector3(-0.10 + float(i) * 0.10, 0.78, 0), 0.012, 0.02, 0.92, color, Vector3(0, 0, -0.08 + float(i) * 0.08))
		"suitcase":
			b.soft_box(Vector3(0, 0.29, 0), Vector3(0.70, 0.58, 0.32), color)
			b.box(Vector3(0, 0.63, 0), Vector3(0.22, 0.08, 0.04), metal)
			for x: float in [-0.22, 0.22]: b.cylinder(Vector3(x, 0.06, 0.12), 0.045, 0.045, 0.08, dark)
		"toy_car":
			b.soft_box(Vector3(0, 0.13, 0), Vector3(0.52, 0.16, 0.28), color)
			b.soft_box(Vector3(0, 0.25, 0.015), Vector3(0.25, 0.16, 0.23), Color("#9ed2e5"))
			for x: float in [-0.18, 0.18]:
				for z: float in [-0.12, 0.12]: b.cylinder(Vector3(x, 0.06, z), 0.055, 0.055, 0.045, dark, Vector3(PI * 0.5, 0, 0))
		"pet_tunnel":
			b.torus(Vector3(0, 0.34, 0), 0.34, 0.43, color, Vector3(PI * 0.5, 0, 0))
			b.cylinder(Vector3(0, 0.34, 0), 0.32, 0.32, 0.86, Color("#d7a46a"), Vector3(PI * 0.5, 0, 0))
		"water_dispenser":
			b.soft_box(Vector3(0, 0.40, 0), Vector3(0.42, 0.80, 0.42), Color("#e4e8e9"))
			b.cylinder(Vector3(0, 0.94, 0), 0.16, 0.18, 0.34, Color("#76b9d8"))
			b.box(Vector3(0, 0.23, -0.22), Vector3(0.22, 0.10, 0.025), dark)
		"vase":
			b.ellipsoid(Vector3(0, 0.25, 0), Vector3(0.19, 0.25, 0.18), color)
			b.cylinder(Vector3(0, 0.56, 0), 0.09, 0.13, 0.28, color)
			b.torus(Vector3(0, 0.70, 0), 0.075, 0.10, wood)
		"candle":
			b.cylinder(Vector3(0, 0.12, 0), 0.085, 0.085, 0.24, Color("#f0dfb5"))
			b.cone(Vector3(0, 0.29, 0), 0.045, 0.12, Color("#ffb84c"))
		"towel_rack":
			b.cylinder(Vector3(-0.36, 0.55, 0), 0.025, 0.025, 1.0, metal, Vector3(0, 0, PI * 0.5))
			b.cylinder(Vector3(0.36, 0.55, 0), 0.025, 0.025, 1.0, metal, Vector3(0, 0, PI * 0.5))
			b.box(Vector3(0, 0.56, 0), Vector3(0.72, 0.56, 0.045), color)
		"hanging_plant":
			b.cylinder(Vector3(0, 0.55, 0), 0.22, 0.28, 0.42, Color("#b8754f"))
			for i: int in range(5):
				var a: float = TAU * float(i) / 5.0
				b.ellipsoid(Vector3(cos(a) * 0.18, 0.25 - float(i % 2) * 0.08, sin(a) * 0.18), Vector3(0.12, 0.28, 0.12), Color("#55a66a"))


static func _leg(b: ModelBuilder, x: float, z: float, height: float, radius: float, color: Color) -> void:
	b.cylinder(Vector3(x, height * 0.5, z), radius * 0.75, radius, height, color, Vector3.ZERO, 0.6)


static func _plant(b: ModelBuilder, variant: int) -> void:
	var terracotta: Color = Color("#b96f4d")
	b.cylinder(Vector3(0.0, 0.27, 0.0), 0.31, 0.22, 0.54, terracotta, Vector3.ZERO, 0.85)
	b.torus(Vector3(0.0, 0.56, 0.0), 0.27, 0.37, terracotta.lightened(0.12), Vector3.ZERO, 0.8)
	b.cylinder(Vector3(0.0, 0.55, 0.0), 0.28, 0.28, 0.04, Color("#49372a"), Vector3.ZERO, 1.0)
	var greens: Array[Color] = [Color("#3e9958"), Color("#58ad68"), Color("#2f7d49")]
	match variant % 4:
		0:
			for k: int in range(8):
				var angle: float = TAU * float(k) / 8.0
				var lift: float = 0.95 + float(k % 3) * 0.13
				b.cylinder(Vector3(cos(angle) * 0.10, 0.82, sin(angle) * 0.10), 0.014, 0.018, 0.56, greens[2], Vector3(sin(angle) * 0.35, 0.0, -cos(angle) * 0.35))
				b.ellipsoid(Vector3(cos(angle) * 0.30, lift, sin(angle) * 0.30), Vector3(0.20, 0.035, 0.27), greens[k % 3], Vector3(sin(angle) * 0.4, -angle, -cos(angle) * 0.4), 2.2)
		1:
			for k: int in range(10):
				var angle: float = TAU * float(k) / 10.0
				b.ellipsoid(Vector3(cos(angle) * 0.22, 0.98, sin(angle) * 0.22), Vector3(0.05, 0.40, 0.025), greens[k % 3], Vector3(sin(angle) * 0.55, -angle + PI * 0.5, -cos(angle) * 0.55))
		2:
			for k: int in range(7):
				var angle: float = TAU * float(k) / 7.0
				b.ellipsoid(Vector3(cos(angle) * 0.10, 0.98 + float(k % 3) * 0.12, sin(angle) * 0.10), Vector3(0.075, 0.46, 0.025), greens[(k + 1) % 3], Vector3(sin(angle) * 0.18, angle, -cos(angle) * 0.18))
		_:
			for k: int in range(9):
				var angle: float = TAU * float(k) / 9.0
				b.ellipsoid(Vector3(cos(angle) * 0.17, 0.72, sin(angle) * 0.17), Vector3(0.085, 0.07, 0.19), greens[k % 3].lightened(0.1), Vector3(sin(angle) * 0.9, -angle + PI * 0.5, -cos(angle) * 0.9))
			b.ellipsoid(Vector3(0.0, 0.76, 0.0), Vector3(0.12, 0.09, 0.12), Color("#e8738c"))


static func _sofa(b: ModelBuilder, color: Color, wood: Color) -> void:
	for x_sign: float in [-1.0, 1.0]:
		for z_sign: float in [-1.0, 1.0]:
			_leg(b, x_sign * 0.90, z_sign * 0.36, 0.12, 0.05, wood)
	b.soft_box(Vector3(0.0, 0.30, 0.0), Vector3(2.05, 0.36, 0.92), color.darkened(0.12), Vector3.ZERO, 5.0, 0.9)
	b.soft_box(Vector3(0.0, 0.78, 0.37), Vector3(2.05, 0.74, 0.20), color.darkened(0.05), Vector3.ZERO, 4.0, 0.9)
	for x_sign: float in [-1.0, 1.0]:
		b.soft_box(Vector3(x_sign * 0.95, 0.60, 0.0), Vector3(0.20, 0.54, 0.92), color.darkened(0.08), Vector3.ZERO, 4.0, 0.9)
	for k: int in range(3):
		var x_pos: float = (float(k) - 1.0) * 0.62
		b.soft_box(Vector3(x_pos, 0.57, -0.02), Vector3(0.60, 0.24, 0.70), color, Vector3.ZERO, 3.2, 0.92)
		b.soft_box(Vector3(x_pos, 0.88, 0.30), Vector3(0.60, 0.46, 0.20), color.lightened(0.04), Vector3(-0.14, 0.0, 0.0), 3.2, 0.92)
	b.soft_box(Vector3(0.66, 0.78, 0.02), Vector3(0.34, 0.34, 0.12), Color("#f0d9a8"), Vector3(-0.3, -0.4, 0.3), 2.8, 0.95)


static func _table(b: ModelBuilder, color: Color, wood: Color) -> void:
	b.soft_box(Vector3(0.0, 0.74, 0.0), Vector3(1.68, 0.10, 1.05), wood, Vector3.ZERO, 6.0, 0.55)
	b.soft_box(Vector3(0.0, 0.66, 0.0), Vector3(1.50, 0.07, 0.88), wood.darkened(0.2), Vector3.ZERO, 4.0, 0.7)
	for x_sign: float in [-1.0, 1.0]:
		for z_sign: float in [-1.0, 1.0]:
			b.cylinder(Vector3(x_sign * 0.70, 0.32, z_sign * 0.40), 0.045, 0.065, 0.64, wood.darkened(0.12), Vector3.ZERO, 0.6)
	b.soft_box(Vector3(0.0, 0.795, 0.0), Vector3(0.46, 0.012, 0.96), color, Vector3.ZERO, 4.0, 0.9)
	b.cylinder(Vector3(0.38, 0.84, 0.12), 0.17, 0.10, 0.10, Color("#f2efe8"), Vector3.ZERO, 0.35)
	for k: int in range(3):
		var fruit_colors: Array[Color] = [Color("#d9443a"), Color("#f2b53b"), Color("#7fb04a")]
		b.ellipsoid(Vector3(0.38 + (float(k) - 1.0) * 0.07, 0.92 + float(k % 2) * 0.02, 0.12 + float(k % 2) * 0.04), Vector3(0.065, 0.06, 0.065), fruit_colors[k], Vector3.ZERO, 2.0, 0.45)


static func _lamp(b: ModelBuilder, variant: int) -> void:
	var shade: Color = [Color("#f5deb3"), Color("#f2c4c4"), Color("#c9e0f0"), Color("#e6e0a8")][variant % 4]
	b.cylinder(Vector3(0.0, 0.04, 0.0), 0.22, 0.24, 0.08, METAL.darkened(0.3), Vector3.ZERO, 0.35, 0.6)
	b.cylinder(Vector3(0.0, 0.76, 0.0), 0.02, 0.025, 1.40, METAL, Vector3.ZERO, 0.3, 0.7)
	b.ellipsoid(Vector3(0.0, 1.38, 0.0), Vector3(0.07, 0.07, 0.07), Color("#fff3c4"), Vector3.ZERO, 2.0, 0.3)
	b.cylinder(Vector3(0.0, 1.50, 0.0), 0.17, 0.32, 0.40, shade, Vector3.ZERO, 0.95)
	b.torus(Vector3(0.0, 1.30, 0.0), 0.28, 0.34, shade.darkened(0.15), Vector3.ZERO, 0.7)


static func _teddy(b: ModelBuilder, color: Color) -> void:
	var cream: Color = color.lightened(0.35)
	b.ellipsoid(Vector3(0.0, 0.34, 0.0), Vector3(0.30, 0.34, 0.26), color, Vector3.ZERO, 2.2, 0.95)
	b.ellipsoid(Vector3(0.0, 0.32, -0.15), Vector3(0.20, 0.22, 0.12), cream, Vector3.ZERO, 2.2, 0.95)
	b.ellipsoid(Vector3(0.0, 0.78, 0.0), Vector3(0.25, 0.23, 0.23), color, Vector3.ZERO, 2.2, 0.95)
	b.ellipsoid(Vector3(0.0, 0.71, -0.20), Vector3(0.11, 0.085, 0.07), cream, Vector3.ZERO, 2.2, 0.95)
	b.ellipsoid(Vector3(0.0, 0.74, -0.26), Vector3(0.04, 0.03, 0.025), Color("#2b2523"), Vector3.ZERO, 2.0, 0.3)
	for side: float in [-1.0, 1.0]:
		b.ellipsoid(Vector3(side * 0.19, 0.97, 0.0), Vector3(0.09, 0.09, 0.05), color, Vector3.ZERO, 2.2, 0.95)
		b.ellipsoid(Vector3(side * 0.19, 0.97, -0.03), Vector3(0.05, 0.05, 0.03), cream, Vector3.ZERO, 2.2, 0.95)
		b.ellipsoid(Vector3(side * 0.10, 0.82, -0.20), Vector3(0.035, 0.04, 0.02), Color("#171b20"), Vector3.ZERO, 2.0, 0.2)
		b.ellipsoid(Vector3(side * 0.34, 0.42, -0.04), Vector3(0.10, 0.20, 0.10), color, Vector3(0.0, 0.0, -side * 0.5), 2.2, 0.95)
		b.ellipsoid(Vector3(side * 0.16, 0.10, -0.14), Vector3(0.12, 0.10, 0.17), color, Vector3.ZERO, 2.2, 0.95)
		b.ellipsoid(Vector3(side * 0.16, 0.10, -0.24), Vector3(0.07, 0.06, 0.05), cream, Vector3.ZERO, 2.2, 0.95)
	b.ellipsoid(Vector3(0.0, 0.58, -0.14), Vector3(0.14, 0.04, 0.05), Color("#d9443a"), Vector3(0.0, 0.0, 0.0), 2.4, 0.8)
	b.ellipsoid(Vector3(0.0, 0.54, -0.17), Vector3(0.05, 0.07, 0.04), Color("#d9443a"), Vector3.ZERO, 2.4, 0.8)


static func _fish_tank(b: ModelBuilder, wood: Color) -> void:
	b.soft_box(Vector3(0.0, 0.28, 0.0), Vector3(1.34, 0.56, 0.82), wood, Vector3.ZERO, 6.0, 0.6)
	b.soft_box(Vector3(0.0, 0.58, 0.0), Vector3(1.38, 0.05, 0.86), wood.darkened(0.25), Vector3.ZERO, 6.0, 0.5)
	b.soft_box(Vector3(0.0, 0.63, 0.0), Vector3(1.28, 0.06, 0.74), Color("#d9c28f"), Vector3.ZERO, 4.0, 0.95)
	b.soft_box(Vector3(0.0, 1.03, 0.0), Vector3(1.30, 0.78, 0.76), Color(0.55, 0.82, 0.95, 0.30), Vector3.ZERO, 8.0, 0.1)
	b.soft_box(Vector3(0.0, 0.98, 0.0), Vector3(1.24, 0.66, 0.70), Color(0.30, 0.65, 0.85, 0.35), Vector3.ZERO, 6.0, 0.1)
	b.soft_box(Vector3(0.0, 1.45, 0.0), Vector3(1.36, 0.06, 0.80), Color("#2c3138"), Vector3.ZERO, 6.0, 0.4)
	b.soft_box(Vector3(0.0, 1.41, 0.0), Vector3(1.0, 0.03, 0.2), Color("#f5f1d8"), Vector3.ZERO, 3.0, 0.4)
	for k: int in range(3):
		b.ellipsoid(Vector3(-0.45 + float(k) * 0.12, 0.88 + float(k) * 0.05, 0.18), Vector3(0.04, 0.26 + float(k) * 0.05, 0.02), Color("#3ea04e"), Vector3(0.0, 0.0, 0.15 * float(k - 1)), 2.0, 0.7)
	b.ellipsoid(Vector3(0.40, 0.70, 0.12), Vector3(0.12, 0.08, 0.10), Color("#8a8f96"), Vector3.ZERO, 2.4, 0.9)
	b.ellipsoid(Vector3(0.18, 1.0, -0.05), Vector3(0.12, 0.07, 0.04), Color("#f08a2b"), Vector3.ZERO, 2.2, 0.35)
	b.cone(Vector3(0.31, 1.0, -0.05), 0.07, 0.12, Color("#f08a2b"), Vector3(0.0, 0.0, PI * 0.5))
	b.ellipsoid(Vector3(-0.2, 1.1, 0.05), Vector3(0.10, 0.06, 0.035), Color("#f2d34a"), Vector3.ZERO, 2.2, 0.35)


static func _bookshelf(b: ModelBuilder, wood: Color) -> void:
	for x_sign: float in [-1.0, 1.0]:
		b.soft_box(Vector3(x_sign * 0.62, 0.86, 0.0), Vector3(0.06, 1.72, 0.46), wood, Vector3.ZERO, 5.0, 0.65)
	b.soft_box(Vector3(0.0, 1.73, 0.0), Vector3(1.32, 0.08, 0.50), wood.darkened(0.12), Vector3.ZERO, 5.0, 0.6)
	b.soft_box(Vector3(0.0, 0.05, 0.0), Vector3(1.32, 0.10, 0.50), wood.darkened(0.2), Vector3.ZERO, 5.0, 0.6)
	b.box(Vector3(0.0, 0.86, 0.21), Vector3(1.20, 1.64, 0.03), wood.darkened(0.3), Vector3.ZERO, 0.8)
	for level: int in range(5):
		var shelf_y: float = 0.10 + float(level) * 0.40
		if level > 0:
			b.soft_box(Vector3(0.0, shelf_y, 0.0), Vector3(1.20, 0.05, 0.44), wood.lightened(0.05), Vector3.ZERO, 5.0, 0.6)
		if level == 4:
			continue
		var x_pos: float = -0.52
		var k: int = 0
		while x_pos < 0.48:
			var width: float = 0.07 + 0.03 * absf(sin(float(k) * 2.3 + float(level)))
			var book_height: float = 0.24 + 0.09 * absf(sin(float(k) * 1.7 + float(level) * 2.0))
			if (k + level) % 7 == 6:
				x_pos += 0.09
			else:
				b.soft_box(Vector3(x_pos + width * 0.5, shelf_y + 0.025 + book_height * 0.5, -0.02), Vector3(width, book_height, 0.30), BOOK_COLORS[(k * 3 + level) % BOOK_COLORS.size()], Vector3.ZERO, 5.0, 0.7)
				x_pos += width + 0.005
			k += 1
	b.ellipsoid(Vector3(0.38, 1.62, 0.0), Vector3(0.10, 0.10, 0.10), Color("#d9443a"), Vector3.ZERO, 2.0, 0.4)


static func _box(b: ModelBuilder, variant: int) -> void:
	var kraft: Color = [Color("#c19a6b"), Color("#b58a5a"), Color("#d2ad7e"), Color("#a9825a")][variant % 4]
	b.soft_box(Vector3(0.0, 0.34, 0.0), Vector3(0.92, 0.68, 0.82), kraft, Vector3.ZERO, 8.0, 0.95)
	b.box(Vector3(0.0, 0.685, 0.0), Vector3(0.12, 0.012, 0.82), Color("#e6d3a8"), Vector3.ZERO, 0.5)
	b.box(Vector3(0.0, 0.688, -0.205), Vector3(0.92, 0.006, 0.012), kraft.darkened(0.2), Vector3.ZERO, 0.9)
	b.box(Vector3(-0.23, 0.69, 0.0), Vector3(0.40, 0.014, 0.80), kraft.lightened(0.05), Vector3(0.0, 0.0, 0.06), 0.9)
	b.box(Vector3(0.0, 0.40, -0.416), Vector3(0.34, 0.24, 0.006), Color("#f3efe4"), Vector3.ZERO, 0.8)
	b.box(Vector3(0.0, 0.47, -0.422), Vector3(0.24, 0.025, 0.004), Color("#3a4350"), Vector3.ZERO, 0.8)
	b.box(Vector3(0.0, 0.40, -0.422), Vector3(0.24, 0.018, 0.004), Color("#6a727c"), Vector3.ZERO, 0.8)


static func _pillow(b: ModelBuilder, color: Color) -> void:
	b.soft_box(Vector3(0.0, 0.17, 0.0), Vector3(0.96, 0.30, 0.78), color, Vector3.ZERO, 2.6, 0.95)
	b.ellipsoid(Vector3(0.0, 0.31, 0.0), Vector3(0.05, 0.025, 0.05), color.darkened(0.3), Vector3.ZERO, 2.0, 0.8)
	for x_sign: float in [-1.0, 1.0]:
		for z_sign: float in [-1.0, 1.0]:
			b.ellipsoid(Vector3(x_sign * 0.46, 0.16, z_sign * 0.36), Vector3(0.05, 0.05, 0.05), color.darkened(0.12), Vector3.ZERO, 2.0, 0.95)
	b.ellipsoid(Vector3(0.0, 0.17, 0.0), Vector3(0.48, 0.152, 0.39), color.lightened(0.18), Vector3.ZERO, 6.0, 0.95)


static func _chair(b: ModelBuilder, color: Color, wood: Color) -> void:
	for x_sign: float in [-1.0, 1.0]:
		for z_sign: float in [-1.0, 1.0]:
			_leg(b, x_sign * 0.36, z_sign * 0.34, 0.48, 0.04, wood)
	b.soft_box(Vector3(0.0, 0.50, 0.0), Vector3(0.88, 0.07, 0.82), wood.darkened(0.12), Vector3.ZERO, 5.0, 0.6)
	b.soft_box(Vector3(0.0, 0.58, -0.01), Vector3(0.80, 0.12, 0.74), color, Vector3.ZERO, 3.2, 0.92)
	for x_sign: float in [-1.0, 1.0]:
		b.cylinder(Vector3(x_sign * 0.36, 0.85, 0.34), 0.035, 0.04, 0.70, wood, Vector3.ZERO, 0.6)
	b.soft_box(Vector3(0.0, 1.12, 0.36), Vector3(0.82, 0.14, 0.07), wood, Vector3.ZERO, 4.0, 0.6)
	b.soft_box(Vector3(0.0, 0.92, 0.35), Vector3(0.70, 0.34, 0.09), color, Vector3.ZERO, 3.2, 0.92)
	b.cylinder(Vector3(0.0, 0.22, 0.0), 0.02, 0.02, 0.72, wood.darkened(0.2), Vector3(0.0, 0.0, PI * 0.5), 0.6)


static func _bed(b: ModelBuilder, color: Color, wood: Color) -> void:
	for x_sign: float in [-1.0, 1.0]:
		for z_sign: float in [-1.0, 1.0]:
			_leg(b, x_sign * 0.92, z_sign * 0.60, 0.14, 0.06, wood.darkened(0.2))
	b.soft_box(Vector3(0.0, 0.28, 0.0), Vector3(2.0, 0.28, 1.38), wood, Vector3.ZERO, 6.0, 0.6)
	b.soft_box(Vector3(0.0, 0.52, 0.02), Vector3(1.92, 0.26, 1.30), Color("#f2eee6"), Vector3.ZERO, 4.0, 0.95)
	b.soft_box(Vector3(0.0, 0.82, 0.69), Vector3(2.04, 0.92, 0.09), wood.darkened(0.1), Vector3.ZERO, 5.0, 0.55)
	b.soft_box(Vector3(0.0, 0.50, -0.70), Vector3(2.0, 0.32, 0.07), wood.darkened(0.1), Vector3.ZERO, 5.0, 0.55)
	b.soft_box(Vector3(0.0, 0.66, -0.20), Vector3(1.96, 0.16, 0.92), color, Vector3.ZERO, 3.4, 0.95)
	b.soft_box(Vector3(0.0, 0.67, -0.52), Vector3(1.98, 0.17, 0.12), color.lightened(0.25), Vector3.ZERO, 3.4, 0.95)
	for x_sign: float in [-1.0, 1.0]:
		b.soft_box(Vector3(x_sign * 0.45, 0.72, 0.43), Vector3(0.66, 0.17, 0.38), Color("#fbf8f1"), Vector3(-0.12, x_sign * 0.06, 0.0), 2.8, 0.95)


static func _cabinet(b: ModelBuilder, wood: Color) -> void:
	b.soft_box(Vector3(0.0, 0.06, 0.0), Vector3(1.34, 0.12, 0.70), wood.darkened(0.35), Vector3.ZERO, 5.0, 0.6)
	b.soft_box(Vector3(0.0, 0.78, 0.0), Vector3(1.42, 1.34, 0.76), wood, Vector3.ZERO, 7.0, 0.6)
	b.soft_box(Vector3(0.0, 1.50, 0.0), Vector3(1.52, 0.09, 0.84), wood.darkened(0.15), Vector3.ZERO, 6.0, 0.5)
	for x_sign: float in [-1.0, 1.0]:
		b.soft_box(Vector3(x_sign * 0.345, 0.80, -0.385), Vector3(0.64, 1.18, 0.04), wood.lightened(0.10), Vector3.ZERO, 7.0, 0.55)
		b.soft_box(Vector3(x_sign * 0.345, 0.80, -0.41), Vector3(0.50, 1.02, 0.015), wood.lightened(0.02), Vector3.ZERO, 7.0, 0.6)
		b.cylinder(Vector3(x_sign * 0.07, 0.82, -0.43), 0.02, 0.02, 0.26, METAL.lightened(0.2), Vector3.ZERO, 0.25, 0.8)
		b.ellipsoid(Vector3(x_sign * 0.07, 0.95, -0.43), Vector3(0.03, 0.03, 0.03), METAL.lightened(0.2), Vector3.ZERO, 2.0, 0.25, 0.8)
		b.ellipsoid(Vector3(x_sign * 0.07, 0.69, -0.43), Vector3(0.03, 0.03, 0.03), METAL.lightened(0.2), Vector3.ZERO, 2.0, 0.25, 0.8)


static func _pet_bowl(b: ModelBuilder, color: Color) -> void:
	b.cylinder(Vector3(0.0, 0.10, 0.0), 0.30, 0.20, 0.20, color, Vector3.ZERO, 0.4)
	b.torus(Vector3(0.0, 0.20, 0.0), 0.26, 0.34, color.lightened(0.15), Vector3.ZERO, 0.4)
	b.cylinder(Vector3(0.0, 0.185, 0.0), 0.28, 0.28, 0.03, color.darkened(0.35), Vector3.ZERO, 0.8)
	b.ellipsoid(Vector3(0.0, 0.215, 0.0), Vector3(0.22, 0.07, 0.22), Color("#8a5a35"), Vector3.ZERO, 2.4, 0.95)
	for k: int in range(5):
		var angle: float = TAU * float(k) / 5.0
		b.ellipsoid(Vector3(cos(angle) * 0.12, 0.27, sin(angle) * 0.12), Vector3(0.035, 0.03, 0.035), Color("#6e4527"), Vector3.ZERO, 2.0, 0.95)
	b.ellipsoid(Vector3(0.0, 0.10, -0.285), Vector3(0.07, 0.045, 0.012), Color("#f4f1e8"), Vector3.ZERO, 2.4, 0.5)


static func _robot_toy(b: ModelBuilder, color: Color) -> void:
	var steel: Color = Color("#aeb8c2")
	b.soft_box(Vector3(0.0, 0.50, 0.0), Vector3(0.50, 0.56, 0.40), steel, Vector3.ZERO, 5.0, 0.35, 0.5)
	b.soft_box(Vector3(0.0, 0.52, -0.205), Vector3(0.32, 0.26, 0.02), color, Vector3.ZERO, 4.0, 0.45)
	for k: int in range(3):
		b.ellipsoid(Vector3((float(k) - 1.0) * 0.09, 0.52, -0.222), Vector3(0.028, 0.028, 0.012), Color("#f2e04a"), Vector3.ZERO, 2.0, 0.3)
	b.soft_box(Vector3(0.0, 0.98, 0.0), Vector3(0.42, 0.32, 0.36), steel.lightened(0.08), Vector3.ZERO, 5.0, 0.35, 0.5)
	b.cylinder(Vector3(0.0, 0.80, 0.0), 0.07, 0.09, 0.08, METAL, Vector3.ZERO, 0.4, 0.6)
	b.cylinder(Vector3(0.0, 1.22, 0.0), 0.012, 0.012, 0.18, METAL, Vector3.ZERO, 0.4, 0.6)
	b.ellipsoid(Vector3(0.0, 1.33, 0.0), Vector3(0.05, 0.05, 0.05), Color("#d9443a"), Vector3.ZERO, 2.0, 0.3)
	b.soft_box(Vector3(0.0, 0.98, -0.185), Vector3(0.32, 0.12, 0.02), Color("#1c2530"), Vector3.ZERO, 4.0, 0.2)
	for side: float in [-1.0, 1.0]:
		b.ellipsoid(Vector3(side * 0.08, 0.98, -0.20), Vector3(0.045, 0.035, 0.012), Color("#5cd7ff"), Vector3.ZERO, 2.0, 0.2)
		b.cylinder(Vector3(side * 0.34, 0.52, 0.0), 0.05, 0.05, 0.46, steel.darkened(0.15), Vector3(0.0, 0.0, side * 0.12), 0.35, 0.5)
		b.ellipsoid(Vector3(side * 0.37, 0.28, 0.0), Vector3(0.075, 0.075, 0.075), color, Vector3.ZERO, 2.0, 0.4)
		b.soft_box(Vector3(side * 0.13, 0.12, 0.0), Vector3(0.17, 0.24, 0.24), color.darkened(0.1), Vector3.ZERO, 4.0, 0.45)


static func _rug(b: ModelBuilder, color: Color) -> void:
	b.soft_box(Vector3(0.0, 0.045, 0.0), Vector3(2.2, 0.09, 1.5), color, Vector3.ZERO, 7.0, 0.98)
	b.soft_box(Vector3(0.0, 0.09, 0.0), Vector3(2.0, 0.025, 1.3), color.lightened(0.22), Vector3.ZERO, 6.0, 0.98)
	b.soft_box(Vector3(0.0, 0.10, 0.0), Vector3(1.7, 0.025, 1.0), color.darkened(0.12), Vector3.ZERO, 6.0, 0.98)
	b.ellipsoid(Vector3(0.0, 0.105, 0.0), Vector3(0.50, 0.02, 0.32), color.lightened(0.30), Vector3.ZERO, 2.4, 0.98)
	for end_sign: float in [-1.0, 1.0]:
		for k: int in range(13):
			b.box(Vector3(end_sign * 1.14, 0.02, -0.66 + float(k) * 0.11), Vector3(0.12, 0.03, 0.025), Color("#efe4cc"), Vector3.ZERO, 0.95)


static func _tv(b: ModelBuilder, wood: Color) -> void:
	for x_sign: float in [-1.0, 1.0]:
		_leg(b, x_sign * 0.66, 0.0, 0.10, 0.045, wood.darkened(0.3))
	b.soft_box(Vector3(0.0, 0.30, 0.0), Vector3(1.52, 0.40, 0.62), wood, Vector3.ZERO, 6.0, 0.6)
	b.box(Vector3(0.0, 0.30, -0.315), Vector3(1.3, 0.28, 0.01), wood.darkened(0.25), Vector3.ZERO, 0.7)
	b.cylinder(Vector3(0.0, 0.54, 0.05), 0.20, 0.26, 0.04, Color("#1c1f24"), Vector3.ZERO, 0.4)
	b.cylinder(Vector3(0.0, 0.66, 0.08), 0.04, 0.05, 0.22, Color("#1c1f24"), Vector3.ZERO, 0.4)
	b.soft_box(Vector3(0.0, 1.10, 0.08), Vector3(1.56, 0.88, 0.08), Color("#15181c"), Vector3.ZERO, 6.0, 0.35)
	b.box(Vector3(0.0, 1.10, 0.035), Vector3(1.44, 0.76, 0.012), Color("#1e3a5f"), Vector3.ZERO, 0.12, 0.3)
	b.box(Vector3(-0.26, 1.18, 0.028), Vector3(0.62, 0.30, 0.004), Color("#3f78b5"), Vector3(0.0, 0.0, 0.1), 0.12, 0.3)
	b.ellipsoid(Vector3(0.55, 0.92, 0.028), Vector3(0.10, 0.08, 0.004), Color("#e8c65a"), Vector3.ZERO, 2.0, 0.12, 0.3)
	b.ellipsoid(Vector3(0.0, 0.66, -0.0), Vector3(0.012, 0.012, 0.012), Color("#4cff7a"), Vector3.ZERO, 2.0, 0.3)


## Nowy, osobny model telewizora ściennego. Istniejący model „tv” pozostaje bez zmian.
static func _tv_wall(b: ModelBuilder) -> void:
	b.soft_box(Vector3(0.0, 1.10, 0.0), Vector3(1.82, 1.14, 0.12), Color("#10151b"), Vector3.ZERO, 6.0, 0.32)
	b.box(Vector3(0.0, 1.10, -0.066), Vector3(1.68, 1.00, 0.012), Color("#17334a"), Vector3.ZERO, 0.12)
	b.soft_box(Vector3(0.0, 0.49, 0.055), Vector3(0.52, 0.08, 0.06), Color("#313b45"), Vector3.ZERO, 4.0, 0.5)


static func _scratching_post(b: ModelBuilder) -> void:
	var carpet: Color = Color("#c9b48a")
	var sisal: Color = Color("#c9ad7c")
	b.soft_box(Vector3(0.0, 0.06, 0.0), Vector3(0.80, 0.12, 0.80), carpet, Vector3.ZERO, 5.0, 0.98)
	b.cylinder(Vector3(0.0, 0.76, 0.0), 0.12, 0.12, 1.30, sisal, Vector3.ZERO, 0.98)
	for k: int in range(9):
		b.torus(Vector3(0.0, 0.18 + float(k) * 0.14, 0.0), 0.11, 0.135, sisal.darkened(0.12), Vector3.ZERO, 0.98)
	b.soft_box(Vector3(0.0, 1.44, 0.0), Vector3(0.64, 0.09, 0.64), carpet, Vector3.ZERO, 5.0, 0.98)
	b.ellipsoid(Vector3(0.0, 1.32, 0.0), Vector3(0.18, 0.05, 0.18), carpet.darkened(0.2), Vector3.ZERO, 2.4, 0.98)
	b.cylinder(Vector3(0.22, 1.15, 0.0), 0.006, 0.006, 0.26, Color("#e8e0d0"))
	b.ellipsoid(Vector3(0.22, 1.0, 0.0), Vector3(0.07, 0.07, 0.07), Color("#e8738c"), Vector3.ZERO, 2.0, 0.9)


static func _pet_bed(b: ModelBuilder, color: Color) -> void:
	b.torus(Vector3(0.0, 0.17, 0.0), 0.40, 0.76, color, Vector3.ZERO, 0.95)
	b.cylinder(Vector3(0.0, 0.10, 0.0), 0.50, 0.52, 0.16, color.lightened(0.28), Vector3.ZERO, 0.97)
	b.ellipsoid(Vector3(0.0, 0.17, 0.0), Vector3(0.46, 0.06, 0.46), color.lightened(0.35), Vector3.ZERO, 3.0, 0.97)
	b.ellipsoid(Vector3(0.0, 0.18, -0.64), Vector3(0.10, 0.04, 0.03), Color("#f4f1e8"), Vector3.ZERO, 2.4, 0.9)
	b.ellipsoid(Vector3(0.0, 0.205, 0.05), Vector3(0.06, 0.02, 0.05), color.darkened(0.3), Vector3.ZERO, 2.4, 0.9)
	for k: int in range(4):
		b.ellipsoid(Vector3((float(k) - 1.5) * 0.085, 0.215, -0.04 + float(k % 2) * 0.06), Vector3(0.028, 0.015, 0.032), color.darkened(0.3), Vector3.ZERO, 2.0, 0.9)


static func _shoe(b: ModelBuilder, color: Color) -> void:
	var white: Color = Color("#f4f1e8")
	b.soft_box(Vector3(0.0, 0.07, 0.08), Vector3(0.50, 0.12, 1.12), white, Vector3.ZERO, 5.0, 0.5)
	b.ellipsoid(Vector3(0.0, 0.22, 0.20), Vector3(0.24, 0.17, 0.42), color, Vector3.ZERO, 2.4, 0.7)
	b.ellipsoid(Vector3(0.0, 0.17, -0.32), Vector3(0.22, 0.13, 0.26), white, Vector3.ZERO, 2.4, 0.55)
	b.ellipsoid(Vector3(0.0, 0.31, 0.46), Vector3(0.26, 0.10, 0.12), color.darkened(0.2), Vector3.ZERO, 2.4, 0.8)
	b.ellipsoid(Vector3(0.0, 0.36, 0.0), Vector3(0.14, 0.12, 0.20), color.lightened(0.1), Vector3(0.5, 0.0, 0.0), 2.4, 0.8)
	for k: int in range(4):
		b.box(Vector3(0.0, 0.34 - float(k) * 0.015, -0.12 + float(k) * 0.085), Vector3(0.20, 0.016, 0.022), white, Vector3(-0.35, 0.0, 0.0), 0.8)
	for side: float in [-1.0, 1.0]:
		b.ellipsoid(Vector3(side * 0.20, 0.22, 0.08), Vector3(0.025, 0.07, 0.22), white, Vector3(0.0, 0.0, side * 0.18), 2.2, 0.55)


static func _sock(b: ModelBuilder, color: Color) -> void:
	var stripe: Color = color.lightened(0.45)
	b.ellipsoid(Vector3(0.0, 0.11, -0.15), Vector3(0.16, 0.10, 0.34), color, Vector3.ZERO, 2.6, 0.97)
	b.ellipsoid(Vector3(0.0, 0.10, -0.40), Vector3(0.15, 0.085, 0.14), stripe, Vector3.ZERO, 2.4, 0.97)
	b.cylinder(Vector3(0.0, 0.13, 0.26), 0.14, 0.14, 0.52, color, Vector3(PI * 0.5, 0.0, 0.0), 0.97)
	b.ellipsoid(Vector3(0.0, 0.10, 0.02), Vector3(0.15, 0.10, 0.14), color.darkened(0.12), Vector3.ZERO, 2.4, 0.97)
	for k: int in range(3):
		b.torus(Vector3(0.0, 0.13, 0.12 + float(k) * 0.12), 0.115, 0.165, stripe if k % 2 == 0 else color.darkened(0.15), Vector3(PI * 0.5, 0.0, 0.0), 0.97)
	b.torus(Vector3(0.0, 0.13, 0.52), 0.10, 0.17, stripe, Vector3(PI * 0.5, 0.0, 0.0), 0.97)


static func _mug(b: ModelBuilder, color: Color) -> void:
	b.cylinder(Vector3(0.0, 0.015, 0.0), 0.28, 0.28, 0.03, Color("#f2efe8"), Vector3.ZERO, 0.35)
	b.cylinder(Vector3(0.0, 0.30, 0.0), 0.20, 0.19, 0.54, color, Vector3.ZERO, 0.3)
	b.torus(Vector3(0.0, 0.57, 0.0), 0.17, 0.23, color.lightened(0.12), Vector3.ZERO, 0.3)
	b.cylinder(Vector3(0.0, 0.555, 0.0), 0.185, 0.185, 0.02, Color("#4a2c1a"), Vector3.ZERO, 0.2)
	b.torus(Vector3(0.24, 0.32, 0.0), 0.07, 0.17, color, Vector3(PI * 0.5, 0.0, 0.0), 0.3)
	b.ellipsoid(Vector3(0.0, 0.30, -0.195), Vector3(0.08, 0.08, 0.01), Color("#f4f1e8"), Vector3.ZERO, 2.0, 0.4)


static func _book(b: ModelBuilder, color: Color) -> void:
	b.soft_box(Vector3(0.0, 0.10, 0.0), Vector3(0.88, 0.18, 1.12), color, Vector3.ZERO, 7.0, 0.6)
	b.box(Vector3(0.03, 0.10, 0.0), Vector3(0.84, 0.13, 1.08), Color("#f3ead2"), Vector3.ZERO, 0.9)
	b.soft_box(Vector3(0.0, 0.195, 0.0), Vector3(0.88, 0.03, 1.12), color.lightened(0.06), Vector3.ZERO, 7.0, 0.55)
	b.soft_box(Vector3(-0.43, 0.10, 0.0), Vector3(0.05, 0.19, 1.12), color.darkened(0.25), Vector3.ZERO, 4.0, 0.6)
	b.soft_box(Vector3(0.04, 0.215, -0.22), Vector3(0.52, 0.01, 0.30), Color("#f3e2b0"), Vector3.ZERO, 5.0, 0.5)
	b.box(Vector3(0.04, 0.222, 0.12), Vector3(0.40, 0.006, 0.05), Color("#f3e2b0"), Vector3.ZERO, 0.5)
	b.box(Vector3(0.28, 0.215, 0.58), Vector3(0.03, 0.012, 0.16), Color("#d9443a"), Vector3.ZERO, 0.6)


static func _remote(b: ModelBuilder) -> void:
	b.soft_box(Vector3(0.0, 0.09, 0.0), Vector3(0.34, 0.16, 1.10), Color("#2a2d33"), Vector3.ZERO, 5.0, 0.45)
	b.ellipsoid(Vector3(0.0, 0.17, -0.42), Vector3(0.07, 0.03, 0.07), Color("#d9443a"), Vector3.ZERO, 2.0, 0.35)
	b.soft_box(Vector3(0.0, 0.172, -0.20), Vector3(0.20, 0.02, 0.10), Color("#3a6b4a"), Vector3.ZERO, 4.0, 0.3)
	for row: int in range(4):
		for col: int in range(2):
			var button_color: Color = Color("#8c939c") if (row + col) % 2 == 0 else Color("#aeb5bd")
			b.cylinder(Vector3((float(col) - 0.5) * 0.12, 0.17, -0.02 + float(row) * 0.14), 0.045, 0.05, 0.03, button_color, Vector3.ZERO, 0.5)
	b.ellipsoid(Vector3(0.0, 0.10, -0.55), Vector3(0.06, 0.04, 0.025), Color("#5a1f1f"), Vector3.ZERO, 2.0, 0.3)


static func _tennis_ball(b: ModelBuilder) -> void:
	b.ellipsoid(Vector3(0.0, 0.27, 0.0), Vector3(0.265, 0.265, 0.265), Color("#c9e03a"), Vector3.ZERO, 2.0, 0.95)
	b.torus(Vector3(0.0, 0.27, 0.0), 0.255, 0.285, Color("#f7f7f0"), Vector3(PI * 0.5, 0.0, 0.0), 0.9)
	b.torus(Vector3(0.0, 0.27, 0.0), 0.255, 0.285, Color("#f7f7f0"), Vector3(0.6, 0.0, PI * 0.5), 0.9)


static func _yarn(b: ModelBuilder, color: Color) -> void:
	b.ellipsoid(Vector3(0.0, 0.27, 0.0), Vector3(0.27, 0.25, 0.27), color, Vector3.ZERO, 2.0, 0.98)
	for k: int in range(7):
		var tilt: float = float(k) * 0.55
		b.torus(Vector3(0.0, 0.27, 0.0), 0.255, 0.30, color.darkened(0.12) if k % 2 == 0 else color.lightened(0.14), Vector3(tilt, float(k) * 0.9, 0.3 * float(k)), 0.98)
	for k: int in range(9):
		var t: float = float(k) / 8.0
		b.ellipsoid(Vector3(0.24 + t * 0.55, 0.03, 0.10 + sin(t * 5.0) * 0.14), Vector3(0.05, 0.022, 0.022), color, Vector3(0.0, -cos(t * 5.0) * 0.5, 0.0), 2.0, 0.98)


static func _paper_scrap(b: ModelBuilder) -> void:
	var paper: Color = Color("#f4f1e8")
	b.ellipsoid(Vector3(0.0, 0.17, 0.0), Vector3(0.22, 0.17, 0.20), paper, Vector3(0.2, 0.4, 0.1), 2.3, 0.95)
	b.ellipsoid(Vector3(0.14, 0.14, 0.08), Vector3(0.14, 0.12, 0.13), paper.darkened(0.06), Vector3(0.5, 0.1, 0.3), 2.4, 0.95)
	b.ellipsoid(Vector3(-0.13, 0.13, -0.08), Vector3(0.12, 0.11, 0.12), paper.darkened(0.03), Vector3(0.1, 0.7, 0.4), 2.4, 0.95)
	b.box(Vector3(0.0, 0.012, 0.28), Vector3(0.46, 0.012, 0.32), paper.darkened(0.08), Vector3(0.0, 0.35, 0.0), 0.95)
	b.box(Vector3(0.0, 0.016, 0.28), Vector3(0.34, 0.004, 0.012), Color("#9fb4d6"), Vector3(0.0, 0.35, 0.0), 0.95)


static func _food_scraps(b: ModelBuilder) -> void:
	b.ellipsoid(Vector3(-0.20, 0.12, 0.0), Vector3(0.13, 0.10, 0.12), Color("#e0c27a"), Vector3(0.0, 0.5, 0.2), 2.3, 0.9)
	b.ellipsoid(Vector3(-0.20, 0.17, 0.0), Vector3(0.10, 0.04, 0.10), Color("#c9482d"), Vector3(0.0, 0.5, 0.2), 2.4, 0.7)
	b.ellipsoid(Vector3(0.20, 0.10, 0.10), Vector3(0.11, 0.09, 0.11), Color("#d95f4a"), Vector3.ZERO, 2.1, 0.5)
	b.ellipsoid(Vector3(0.20, 0.10, 0.10), Vector3(0.075, 0.095, 0.075), Color("#efe5b6"), Vector3.ZERO, 2.1, 0.7)
	b.cylinder(Vector3(0.20, 0.21, 0.10), 0.008, 0.008, 0.08, Color("#4a2c1a"))
	for k: int in range(9):
		var angle: float = float(k) * 2.4
		b.ellipsoid(Vector3(cos(angle) * 0.34, 0.025, sin(angle) * 0.30), Vector3(0.03, 0.02, 0.028), Color("#d9b46a"), Vector3(0.0, angle, 0.0), 2.0, 0.95)


static func _cable(b: ModelBuilder, variant: int) -> void:
	var cord: Color = [Color("#f2efe8"), Color("#23262b"), Color("#e8c65a"), Color("#4a78b8")][variant % 4]
	var segments: int = 16
	for k: int in range(segments):
		var t0: float = float(k) / float(segments)
		var t1: float = float(k + 1) / float(segments)
		var p0 := Vector3(-0.62 + t0 * 1.24, 0.04, 0.24 * sin(t0 * 7.0))
		var p1 := Vector3(-0.62 + t1 * 1.24, 0.04, 0.24 * sin(t1 * 7.0))
		var mid: Vector3 = (p0 + p1) * 0.5
		var length: float = p0.distance_to(p1)
		b.ellipsoid(mid, Vector3(length * 0.62, 0.04, 0.04), cord, Vector3(0.0, -atan2(p1.z - p0.z, p1.x - p0.x), 0.0), 2.0, 0.5)
	for end_sign: float in [-1.0, 1.0]:
		var plug_z: float = 0.24 * sin(0.0 if end_sign < 0.0 else 7.0)
		b.soft_box(Vector3(end_sign * 0.70, 0.08, plug_z), Vector3(0.16, 0.14, 0.16), Color("#23262b"), Vector3.ZERO, 4.0, 0.5)
		for prong: float in [-1.0, 1.0]:
			b.box(Vector3(end_sign * 0.80, 0.08, plug_z + prong * 0.04), Vector3(0.08, 0.018, 0.02), Color("#c9ced3"), Vector3.ZERO, 0.25, 0.8)


static func _backpack(b: ModelBuilder, color: Color) -> void:
	b.soft_box(Vector3(0.0, 0.55, 0.0), Vector3(0.92, 1.00, 0.58), color, Vector3.ZERO, 4.0, 0.88)
	b.soft_box(Vector3(0.0, 0.32, -0.34), Vector3(0.70, 0.50, 0.16), color.darkened(0.12), Vector3.ZERO, 4.0, 0.88)
	b.box(Vector3(0.0, 0.46, -0.42), Vector3(0.62, 0.012, 0.01), Color("#c9ced3"), Vector3.ZERO, 0.3, 0.7)
	b.ellipsoid(Vector3(0.28, 0.43, -0.43), Vector3(0.03, 0.05, 0.015), Color("#f2b84b"), Vector3.ZERO, 2.0, 0.4)
	b.soft_box(Vector3(0.0, 0.88, -0.27), Vector3(0.78, 0.40, 0.14), color.lightened(0.05), Vector3.ZERO, 4.0, 0.88)
	b.box(Vector3(0.0, 0.84, -0.345), Vector3(0.55, 0.012, 0.01), Color("#c9ced3"), Vector3.ZERO, 0.3, 0.7)
	for side: float in [-1.0, 1.0]:
		b.soft_box(Vector3(side * 0.28, 0.55, 0.31), Vector3(0.13, 0.90, 0.05), color.darkened(0.3), Vector3.ZERO, 4.0, 0.9)
		b.cylinder(Vector3(side * 0.50, 0.30, -0.02), 0.09, 0.09, 0.42, color.darkened(0.18), Vector3.ZERO, 0.88)
	b.torus(Vector3(0.0, 1.07, 0.0), 0.07, 0.15, color.darkened(0.3), Vector3(0.0, 0.0, PI * 0.0), 0.9)


static func _fridge(b: ModelBuilder, variant: int) -> void:
	var shell: Color = [Color("#dce3e8"), Color("#c8d2d9"), Color("#e7e0d2"), Color("#4f5964")][variant % 4]
	b.soft_box(Vector3(0.0, 1.05, 0.0), Vector3(1.08, 2.05, 0.82), shell, Vector3.ZERO, 7.0, 0.32, 0.35)
	b.soft_box(Vector3(0.0, 1.55, -0.425), Vector3(1.00, 0.98, 0.035), shell.lightened(0.05), Vector3.ZERO, 5.0, 0.28, 0.3)
	b.soft_box(Vector3(0.0, 0.54, -0.425), Vector3(1.00, 0.94, 0.035), shell.darkened(0.04), Vector3.ZERO, 5.0, 0.28, 0.3)
	b.box(Vector3(0.0, 1.03, -0.45), Vector3(1.02, 0.025, 0.018), Color("#68727d"), Vector3.ZERO, 0.35, 0.55)
	for y_value: float in [1.52, 0.52]:
		b.soft_box(Vector3(0.39, y_value, -0.47), Vector3(0.045, 0.34, 0.045), Color("#7d8992"), Vector3.ZERO, 4.0, 0.25, 0.7)
	b.soft_box(Vector3(0.0, 0.035, 0.0), Vector3(1.12, 0.07, 0.86), Color("#68727d"), Vector3.ZERO, 4.0, 0.35, 0.5)


static func _bathtub(b: ModelBuilder) -> void:
	var ceramic: Color = Color("#e8edf0")
	b.soft_box(Vector3(0.0, 0.36, 0.0), Vector3(1.72, 0.62, 0.88), ceramic, Vector3.ZERO, 6.0, 0.24, 0.12)
	b.soft_box(Vector3(0.0, 0.48, -0.015), Vector3(1.48, 0.43, 0.68), Color("#b8d5df"), Vector3.ZERO, 7.0, 0.18, 0.05)
	b.soft_box(Vector3(0.0, 0.66, 0.0), Vector3(1.82, 0.10, 0.98), ceramic, Vector3.ZERO, 7.0, 0.2, 0.15)
	b.cylinder(Vector3(0.0, 0.12, 0.0), 0.035, 0.035, 0.20, Color("#8b969e"), Vector3.ZERO, 0.25, 0.65)
	b.torus(Vector3(0.0, 0.70, 0.0), 0.045, 0.075, Color("#aeb8c0"), Vector3.ZERO, 0.25, 0.7)


static func _sink(b: ModelBuilder) -> void:
	var ceramic: Color = Color("#e8edf0")
	b.cylinder(Vector3(0.0, 0.46, 0.0), 0.18, 0.28, 0.88, ceramic, Vector3.ZERO, 0.25)
	b.ellipsoid(Vector3(0.0, 0.94, 0.0), Vector3(0.66, 0.20, 0.48), ceramic, Vector3.ZERO, 3.5, 0.22)
	b.ellipsoid(Vector3(0.0, 0.99, -0.015), Vector3(0.48, 0.09, 0.32), Color("#b8d5df"), Vector3.ZERO, 3.0, 0.18)
	b.cylinder(Vector3(0.0, 1.18, 0.22), 0.035, 0.035, 0.30, Color("#9daab2"), Vector3.ZERO, 0.25, 0.75)
	b.torus(Vector3(0.0, 1.31, 0.22), 0.10, 0.13, Color("#b7c2c9"), Vector3.ZERO, 0.25, 0.75)


static func _kitchen_counter(b: ModelBuilder, wood: Color) -> void:
	b.soft_box(Vector3(0.0, 0.62, 0.0), Vector3(1.70, 1.18, 0.78), wood, Vector3.ZERO, 6.0, 0.55)
	b.soft_box(Vector3(0.0, 1.25, 0.0), Vector3(1.82, 0.12, 0.88), Color("#d6d0c4"), Vector3.ZERO, 5.0, 0.32, 0.18)
	for x_sign: float in [-1.0, 1.0]:
		b.soft_box(Vector3(x_sign * 0.42, 0.68, -0.405), Vector3(0.72, 0.88, 0.035), wood.lightened(0.08), Vector3.ZERO, 5.0, 0.5)
		b.ellipsoid(Vector3(x_sign * 0.42, 0.72, -0.44), Vector3(0.035, 0.035, 0.025), Color("#87939b"), Vector3.ZERO, 2.0, 0.25, 0.7)


static func _nightstand(b: ModelBuilder, wood: Color) -> void:
	b.soft_box(Vector3(0.0, 0.48, 0.0), Vector3(0.72, 0.86, 0.62), wood, Vector3.ZERO, 5.0, 0.65)
	b.soft_box(Vector3(0.0, 0.91, -0.02), Vector3(0.78, 0.08, 0.68), wood.lightened(0.12), Vector3.ZERO, 4.0, 0.55)
	for y: float in [0.30, 0.62]:
		b.soft_box(Vector3(0.0, y, -0.318), Vector3(0.62, 0.22, 0.025), wood.lightened(0.08), Vector3.ZERO, 3.0, 0.6)
		b.ellipsoid(Vector3(0.0, y, -0.345), Vector3(0.045, 0.035, 0.025), Color("#d6c49b"), Vector3.ZERO, 2.0, 0.45)

static func _wardrobe(b: ModelBuilder, wood: Color, variant: int) -> void:
	b.soft_box(Vector3(0.0, 1.12, 0.0), Vector3(1.55, 2.24, 0.68), wood, Vector3.ZERO, 5.0, 0.65)
	for x: float in [-0.39, 0.39]:
		b.soft_box(Vector3(x, 1.12, -0.355), Vector3(0.75, 2.12, 0.035), wood.lightened(0.10 if variant % 2 == 0 else 0.02), Vector3.ZERO, 3.0, 0.55)
		b.ellipsoid(Vector3(x + (0.30 if x < 0.0 else -0.30), 1.12, -0.39), Vector3(0.035, 0.11, 0.035), Color("#b9a27a"), Vector3.ZERO, 2.0, 0.35)

static func _coffee_table(b: ModelBuilder, wood: Color, accent: Color) -> void:
	b.soft_box(Vector3(0.0, 0.34, 0.0), Vector3(1.25, 0.10, 0.72), wood, Vector3.ZERO, 5.0, 0.55)
	for x: float in [-0.52, 0.52]:
		for z: float in [-0.27, 0.27]:
			b.cylinder(Vector3(x, 0.16, z), 0.035, 0.045, 0.32, wood.darkened(0.18), Vector3.ZERO, 0.5)
	b.ellipsoid(Vector3(0.0, 0.43, 0.0), Vector3(0.18, 0.035, 0.14), accent.lightened(0.2), Vector3.ZERO, 2.0, 0.8)

static func _side_table(b: ModelBuilder, wood: Color) -> void:
	b.soft_box(Vector3(0.0, 0.56, 0.0), Vector3(0.68, 0.09, 0.58), wood, Vector3.ZERO, 5.0, 0.6)
	for x: float in [-0.26, 0.26]:
		for z: float in [-0.20, 0.20]:
			b.cylinder(Vector3(x, 0.28, z), 0.025, 0.03, 0.54, wood.darkened(0.16), Vector3.ZERO, 0.5)

static func _shoe_rack(b: ModelBuilder, wood: Color) -> void:
	for y: float in [0.20, 0.58, 0.96]:
		b.soft_box(Vector3(0.0, y, 0.0), Vector3(1.05, 0.055, 0.38), wood, Vector3.ZERO, 3.0, 0.7)
	for x: float in [-0.48, 0.48]:
		b.cylinder(Vector3(x, 0.52, 0.0), 0.025, 0.03, 1.02, wood.darkened(0.18), Vector3.ZERO, 0.5)
	for level: int in range(2):
		for side: int in range(2):
			var shoe_color: Color = [Color("#39485a"), Color("#8b5844"), Color("#e3e0d8"), Color("#547b68")][(level * 2 + side) % 4]
			b.soft_box(Vector3(-0.24 + float(side) * 0.48, 0.30 + float(level) * 0.38, -0.02), Vector3(0.36, 0.13, 0.25), shoe_color, Vector3(0.0, 0.0, -0.04), 3.0, 0.8)

static func _ottoman(b: ModelBuilder, color: Color) -> void:
	b.cylinder(Vector3(0.0, 0.27, 0.0), 0.48, 0.48, 0.52, color, Vector3.ZERO, 0.9)
	b.cylinder(Vector3(0.0, 0.54, 0.0), 0.49, 0.49, 0.08, color.lightened(0.12), Vector3.ZERO, 0.95)

static func _laundry_basket(b: ModelBuilder, color: Color) -> void:
	b.cylinder(Vector3(0.0, 0.36, 0.0), 0.34, 0.42, 0.72, color, Vector3.ZERO, 0.95)
	b.torus(Vector3(0.0, 0.73, 0.0), 0.39, 0.44, color.darkened(0.15), Vector3.ZERO, 0.85)
	for i: int in range(8):
		var angle: float = TAU * float(i) / 8.0
		b.box(Vector3(cos(angle) * 0.37, 0.38, sin(angle) * 0.37), Vector3(0.035, 0.52, 0.035), color.darkened(0.12), Vector3(0.0, -angle, 0.0), 0.7)

static func _floor_mirror(b: ModelBuilder, wood: Color) -> void:
	b.soft_box(Vector3(0.0, 1.0, 0.0), Vector3(0.82, 1.92, 0.10), wood, Vector3.ZERO, 4.0, 0.55)
	b.soft_box(Vector3(0.0, 1.0, -0.06), Vector3(0.68, 1.72, 0.025), Color("#9fc4d0"), Vector3.ZERO, 3.0, 0.12)
	b.cylinder(Vector3(0.0, 0.06, 0.05), 0.30, 0.34, 0.10, wood.darkened(0.2), Vector3.ZERO, 0.55)
