class_name ObstacleModels
extends RefCounted
## Modele okrągłych przeszkód na trasie (5 rodzajów). Kolizja (walec o promieniu
## `radius` i wysokości `height`) pozostaje w ProceduralTrack — tu powstaje tylko
## wygląd. Początek układu to środek kolizji, dół przeszkody leży na y = -height/2.

const KIND_COUNT: int = 5


static func build(parent: Node3D, index: int, radius: float, height: float, base_color: Color) -> void:
	var b := ModelBuilder.new()
	var bottom: float = -height * 0.5
	b.part("Obstacle", Vector3.ZERO)
	match index % KIND_COUNT:
		0:
			_pouf(b, radius, height, bottom, base_color.lightened(0.12))
		1:
			_tin_can(b, radius, height, bottom)
		2:
			_toy_block(b, radius, height, bottom, base_color.darkened(0.05))
		3:
			_traffic_cone(b, radius, height, bottom)
		_:
			_drum(b, radius, height, bottom)
	b.build(parent)


## Miękki puf z szwem, guzikiem i podstawką.
static func _pouf(b: ModelBuilder, radius: float, height: float, bottom: float, color: Color) -> void:
	b.ellipsoid(Vector3(0.0, bottom + height * 0.62, 0.0), Vector3(radius * 0.98, height * 0.62, radius * 0.98), color, Vector3.ZERO, 2.5, 0.88)
	b.cylinder(Vector3(0.0, bottom + height * 0.07, 0.0), radius * 0.78, radius * 0.82, height * 0.14, color.darkened(0.35), Vector3.ZERO, 0.8)
	b.torus(Vector3(0.0, bottom + height * 0.62, 0.0), radius * 0.96, radius * 1.0, color.darkened(0.18), Vector3.ZERO, 0.9)
	b.ellipsoid(Vector3(0.0, bottom + height * 1.18, 0.0), Vector3(radius * 0.09, radius * 0.05, radius * 0.09), color.darkened(0.3), Vector3.ZERO, 2.0, 0.6)


## Puszka z etykietą, metalowymi obręczami i wieczkiem z zawleczką.
static func _tin_can(b: ModelBuilder, radius: float, height: float, bottom: float) -> void:
	var metal: Color = Color("#c3ccd2")
	var label: Color = Color("#c9593f")
	b.cylinder(Vector3(0.0, bottom + height * 0.5, 0.0), radius * 0.92, radius * 0.92, height, metal, Vector3.ZERO, 0.3, 0.7)
	b.cylinder(Vector3(0.0, bottom + height * 0.5, 0.0), radius * 0.945, radius * 0.945, height * 0.56, label, Vector3.ZERO, 0.6, 0.0)
	b.cylinder(Vector3(0.0, bottom + height * 0.5, 0.0), radius * 0.95, radius * 0.95, height * 0.12, Color("#f2e6c8"), Vector3.ZERO, 0.6, 0.0)
	for y_value: float in [bottom + height * 0.03, bottom + height * 0.97]:
		b.torus(Vector3(0.0, y_value, 0.0), radius * 0.86, radius * 0.96, Color("#e2e8eb"), Vector3.ZERO, 0.25, 0.8)
	b.torus(Vector3(radius * 0.25, bottom + height * 1.0, 0.0), radius * 0.10, radius * 0.22, Color("#aab4ba"), Vector3(PI * 0.5, 0.0, 0.0), 0.3, 0.8)


## Zabawkowy klocek z zaokrąglonymi krawędziami i czterema wypustkami.
static func _toy_block(b: ModelBuilder, radius: float, height: float, bottom: float, color: Color) -> void:
	b.soft_box(Vector3(0.0, bottom + height * 0.5, 0.0), Vector3(radius * 1.8, height, radius * 1.8), color, Vector3.ZERO, 5.0, 0.55)
	for x_sign: float in [-1.0, 1.0]:
		for z_sign: float in [-1.0, 1.0]:
			b.cylinder(Vector3(x_sign * radius * 0.42, bottom + height + radius * 0.06, z_sign * radius * 0.42), radius * 0.26, radius * 0.28, radius * 0.16, color.lightened(0.1), Vector3.ZERO, 0.55)
	b.soft_box(Vector3(0.0, bottom + height * 0.5, radius * 0.9), Vector3(radius * 0.9, height * 0.5, radius * 0.06), Color("#f5e7c4"), Vector3.ZERO, 3.0, 0.6)


## Pachołek drogowy z dwoma odblaskowymi pasami i kwadratową podstawą.
static func _traffic_cone(b: ModelBuilder, radius: float, height: float, bottom: float) -> void:
	var orange: Color = Color("#e8662d")
	var cone_height: float = height * 1.35
	b.soft_box(Vector3(0.0, bottom + height * 0.04, 0.0), Vector3(radius * 2.0, height * 0.08, radius * 2.0), Color("#2c2f36"), Vector3.ZERO, 6.0, 0.6)
	b.cylinder(Vector3(0.0, bottom + height * 0.08 + cone_height * 0.5, 0.0), radius * 0.10, radius * 0.78, cone_height, orange, Vector3.ZERO, 0.55)
	b.cylinder(Vector3(0.0, bottom + height * 0.08 + cone_height * 0.36, 0.0), radius * 0.45, radius * 0.56, cone_height * 0.16, Color("#f4f1e8"), Vector3.ZERO, 0.4)
	b.cylinder(Vector3(0.0, bottom + height * 0.08 + cone_height * 0.62, 0.0), radius * 0.30, radius * 0.38, cone_height * 0.12, Color("#f4f1e8"), Vector3.ZERO, 0.4)
	b.ellipsoid(Vector3(0.0, bottom + height * 0.08 + cone_height, 0.0), Vector3(radius * 0.12, radius * 0.07, radius * 0.12), orange.darkened(0.15), Vector3.ZERO, 2.0, 0.5)


## Bęben z obręczami, pokrywą i dwiema pałeczkami.
static func _drum(b: ModelBuilder, radius: float, height: float, bottom: float) -> void:
	var shell: Color = Color("#568b9d")
	b.cylinder(Vector3(0.0, bottom + height * 0.5, 0.0), radius * 0.82, radius, height, shell, Vector3.ZERO, 0.45)
	b.cylinder(Vector3(0.0, bottom + height * 1.0, 0.0), radius * 0.80, radius * 0.80, height * 0.04, Color("#f1ecd8"), Vector3.ZERO, 0.5)
	for y_value: float in [bottom + height * 0.04, bottom + height * 0.96]:
		b.torus(Vector3(0.0, y_value, 0.0), radius * 0.74, radius * 0.88, Color("#cfd6da"), Vector3.ZERO, 0.3, 0.7)
	for k: int in range(8):
		var angle: float = TAU * float(k) / 8.0
		b.box(Vector3(cos(angle) * radius * 0.90, bottom + height * 0.5, sin(angle) * radius * 0.90), Vector3(radius * 0.05, height * 0.82, radius * 0.05), Color("#cfd6da"), Vector3(0.0, -angle, 0.0), 0.3, 0.7)
	for side: float in [-1.0, 1.0]:
		b.cylinder(Vector3(side * radius * 0.28, bottom + height * 1.04, 0.0), 0.02, 0.02, radius * 0.9, Color("#b9895a"), Vector3(PI * 0.5, side * 0.35, 0.0), 0.7)
