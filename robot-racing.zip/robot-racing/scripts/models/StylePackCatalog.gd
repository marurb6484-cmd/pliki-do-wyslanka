class_name StylePackCatalog
extends RefCounted
## Rejestr pakietów stylistycznych dla wyposażenia wnętrz.
## Ścieżki wskazują na zaimportowane sceny glTF/GLB; brak pliku oznacza
## bezpieczny powrót do dotychczasowego modelu proceduralnego.

const DEFAULT_PACK_ID: String = "procedural"
const PACKS: Dictionary = {
	"procedural": {
		"name": "Modele proceduralne",
		"source": "Robot Racing",
		"license": "Internal",
		"model_scenes": {},
	},
	"modern_home": {
		"name": "Modern Home – pilot",
		"description": "Jasne, współczesne wnętrza z drewnem, tkaniną i prostymi formami.",
		"source": "Poly Haven",
		"source_url": "https://polyhaven.com/models/furniture",
		"license": "CC0 1.0",
		"license_url": "https://polyhaven.com/license",
		"attribution": "Modele 3D: Poly Haven (CC0).",
		# Wypełniane dopiero po pobraniu i sprawdzeniu konkretnego pliku.
		"model_scenes": {},
		"model_sources": {
			"sofa": "Sofa 03",
			"chair": "Vibrant Nordic Modern Arm Chair 01",
			"coffee_table": "Amin Modern Coffee Table 01",
			"cabinet": "Modern Wooden Cabinet",
			"bookshelf": "Wooden Display Shelves 01",
			"lamp": "Modern Ceiling Lamp 01",
			"nightstand": "Modern Wooden Cabinet",
		},
	},
}


static func has_pack(pack_id: String) -> bool:
	return PACKS.has(pack_id)


static func get_pack(pack_id: String) -> Dictionary:
	return PACKS.get(pack_id, PACKS[DEFAULT_PACK_ID]).duplicate(true)


static func get_pack_ids() -> Array[String]:
	var ids: Array[String] = []
	for key: Variant in PACKS.keys():
		ids.append(str(key))
	return ids


static func get_model_path(pack_id: String, kind: String) -> String:
	var pack: Dictionary = PACKS.get(pack_id, {})
	var scenes: Dictionary = pack.get("model_scenes", {})
	return str(scenes.get(kind, ""))


static func instantiate_model(pack_id: String, kind: String, variant: int = 0) -> Node3D:
	if pack_id == DEFAULT_PACK_ID or not PACKS.has(pack_id):
		return null
	var scene_path: String = get_model_path(pack_id, kind)
	if scene_path.is_empty() or not ResourceLoader.exists(scene_path):
		return null
	var packed: PackedScene = load(scene_path) as PackedScene
	if packed == null:
		return null
	var instance: Node = packed.instantiate()
	if not instance is Node3D:
		instance.queue_free()
		return null
	var model: Node3D = instance as Node3D
	model.name = "StylePack_%s_%s_%d" % [pack_id, kind, posmod(variant, 4)]
	return model
