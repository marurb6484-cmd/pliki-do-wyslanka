class_name TrackModelLibrary
extends RefCounted
## Wspólna biblioteka modeli 3D używanych przez trasy i edytor.
## Geometria danego rodzaju/wariantu jest budowana tylko raz na sesję,
## a kolejne wystąpienia korzystają z kopii węzłów współdzielących zasoby Mesh.

static var _templates: Dictionary = {}


static func make_furniture(kind: String, variant: int) -> Node3D:
	# Opcjonalny model zainstalowany przez StylePackManager. Roboty i stacje
	# nie korzystają z tej ścieżki; ich sceny pozostają nietknięte.
	if StylePackManager != null:
		var downloaded_model: Node3D = StylePackManager.instantiate_for_kind(kind)
		if downloaded_model != null:
			return downloaded_model
	if StylePackManager != null and StylePackManager.is_downloaded_only_mode():
		var empty_model := Node3D.new()
		empty_model.name = "MissingDownloadedFurniture_%s" % kind
		return empty_model
	var safe_variant: int = posmod(variant, 4)
	var key: String = "furniture|%s|%d" % [kind, safe_variant]
	return _get_or_build(key, func(root: Node3D) -> void:
		FurnitureModels.build(root, kind, safe_variant)
	)


static func make_animal(species: String, variant: int) -> Node3D:
	if StylePackManager != null:
		var downloaded_animal: Node3D = StylePackManager.instantiate_animal(species)
		if downloaded_animal != null:
			return downloaded_animal
	var safe_variant: int = posmod(variant, 4)
	var key: String = "animal|%s|%d" % [species, safe_variant]
	return _get_or_build(key, func(root: Node3D) -> void:
		AnimalModels.build(root, species, safe_variant)
	)


static func make_obstacle(index: int, radius: float, height: float, base_color: Color) -> Node3D:
	var safe_index: int = posmod(index, ObstacleModels.KIND_COUNT)
	var downloaded_model: Node3D = StylePackManager.instantiate_obstacle(safe_index, radius, height)
	if downloaded_model != null:
		return downloaded_model
	if StylePackManager != null and StylePackManager.is_downloaded_only_mode():
		var empty_model := Node3D.new()
		empty_model.name = "MissingDownloadedObstacle_%d" % safe_index
		return empty_model
	var key: String = "obstacle|%d|%.3f|%.3f|%s" % [safe_index, radius, height, base_color.to_html(true)]
	return _get_or_build(key, func(root: Node3D) -> void:
		ObstacleModels.build(root, safe_index, radius, height, base_color)
	)


static func clear_cache() -> void:
	_templates.clear()


static func _get_or_build(key: String, builder: Callable) -> Node3D:
	if not _templates.has(key) or not is_instance_valid(_templates[key]):
		var template := Node3D.new()
		template.name = "ModelTemplate"
		builder.call(template)
		_templates[key] = template
	var instance: Node3D = (_templates[key] as Node3D).duplicate() as Node3D
	instance.name = "Model3D"
	return instance
