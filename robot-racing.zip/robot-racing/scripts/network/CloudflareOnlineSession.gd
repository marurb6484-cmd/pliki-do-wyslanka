extends Node
## Internet transport for Robot Racing. Separate from LanNetworkSession (ENet).

signal status_changed(message: String)
signal connected_to_room(room_code: String, player_id: String)
signal players_changed(players: Array)
signal packet_received(packet: Dictionary)
signal disconnected_from_room(reason: String)
signal lobby_changed(players: Array, host_id: String)
signal race_starting(start_at: int, ai_count: int)
signal race_state_received(player_id: String, state: Dictionary)
signal ai_states_received(states: Array)
signal rooms_received(rooms: Array)

var room_code: String = ""
var player_id: String = ""
var player_name: String = "Robot"
var robot_name: String = "Robot"
var robot_ovr: int = 1
var endpoint: String = ""
var connected: bool = false
var _socket: WebSocketPeer
var _http: HTTPRequest
var _rooms_http: HTTPRequest
var _pending_create: bool = false
var _sequence: int = 0
var _players: Array = []
var host_id: String = ""
var _last_remote_sequence: Dictionary = {}
var _last_state_send_ms: int = 0
var server_time_offset_ms: int = 0

func get_players() -> Array:
	return _players.duplicate(true)


func get_server_time_ms() -> int:
	return int(Time.get_unix_time_from_system() * 1000.0) + server_time_offset_ms


func _ready() -> void:
	_http = HTTPRequest.new()
	_http.timeout = 15.0
	add_child(_http)
	_http.request_completed.connect(_on_create_completed)
	_rooms_http = HTTPRequest.new()
	_rooms_http.timeout = 15.0
	add_child(_rooms_http)
	_rooms_http.request_completed.connect(_on_rooms_completed)

func list_rooms(worker_url: String) -> Error:
	var base := _normalize_http_url(worker_url)
	if base.is_empty():
		status_changed.emit("Wpisz poprawny adres HTTPS serwera Cloudflare.")
		return ERR_INVALID_PARAMETER
	endpoint = base
	status_changed.emit("Pobieranie listy pokoi…")
	var result := _rooms_http.request(endpoint + "/api/rooms")
	if result != OK:
		status_changed.emit("Nie udało się pobrać listy pokoi: %s" % error_string(result))
	return result

func _on_rooms_completed(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300:
		status_changed.emit("Nie udało się pobrać pokoi (HTTP %d)." % response_code)
		rooms_received.emit([])
		return
	var parsed: Variant = JSON.parse_string(body.get_string_from_utf8())
	if not parsed is Dictionary or not bool(parsed.get("ok", false)):
		status_changed.emit("Serwer zwrócił nieprawidłową listę pokoi.")
		rooms_received.emit([])
		return
	var rooms: Variant = parsed.get("rooms", [])
	rooms_received.emit(rooms if rooms is Array else [])
	status_changed.emit("Znalezione pokoje: %d." % (rooms.size() if rooms is Array else 0))

func create_room(worker_url: String, display_name: String = "Robot") -> Error:
	if _http == null:
		return ERR_UNCONFIGURED
	endpoint = _normalize_http_url(worker_url)
	player_name = _clean_player_name(display_name)
	_update_local_robot_identity()
	if endpoint.is_empty():
		status_changed.emit("Wpisz poprawny adres HTTPS serwera Cloudflare.")
		return ERR_INVALID_PARAMETER
	disconnect_room(false)
	_pending_create = true
	status_changed.emit("Tworzenie pokoju…")
	var headers := PackedStringArray(["Content-Type: application/json"])
	var payload := JSON.stringify({"game": "robot-racing", "protocol": 1})
	var result := _http.request(endpoint + "/api/rooms", headers, HTTPClient.METHOD_POST, payload)
	if result != OK:
		_pending_create = false
		status_changed.emit("Nie udało się wysłać żądania: %s" % error_string(result))
	return result

func join_room(worker_url: String, code: String, display_name: String = "Robot") -> Error:
	endpoint = _normalize_http_url(worker_url)
	room_code = code.strip_edges().to_upper()
	player_name = _clean_player_name(display_name)
	_update_local_robot_identity()
	if endpoint.is_empty() or not _valid_room_code(room_code):
		status_changed.emit("Sprawdź adres serwera i 8-znakowy kod pokoju.")
		return ERR_INVALID_PARAMETER
	return _open_socket()

func _on_create_completed(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	_pending_create = false
	if result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300:
		status_changed.emit("Tworzenie pokoju nie powiodło się (HTTP %d)." % response_code)
		return
	var parsed: Variant = JSON.parse_string(body.get_string_from_utf8())
	if not parsed is Dictionary or not bool(parsed.get("ok", false)):
		status_changed.emit("Serwer zwrócił nieprawidłową odpowiedź.")
		return
	room_code = str(parsed.get("room_code", "")).to_upper()
	if not _valid_room_code(room_code):
		status_changed.emit("Serwer zwrócił nieprawidłowy kod pokoju.")
		return
	status_changed.emit("Pokój %s utworzony. Łączenie…" % room_code)
	_open_socket()


func _update_local_robot_identity() -> void:
	if not is_instance_valid(PlayerProgress):
		robot_name = "Robot"
		robot_ovr = 1
		return
	var config: Dictionary = PlayerProgress.get_player_robot_config()
	robot_name = str(config.get("name", "Robot")).substr(0, 28)
	robot_ovr = clampi(int(config.get("ovr", 1)), 1, 100)

func _open_socket() -> Error:
	if _socket != null:
		_socket.close()
	_socket = WebSocketPeer.new()
	var ws_url := endpoint.replace("https://", "wss://").replace("http://", "ws://")
	ws_url += "/ws?room=%s&player=%s&robot=%s&ovr=%d" % [room_code.uri_encode(), player_name.uri_encode(), robot_name.uri_encode(), robot_ovr]
	var result := _socket.connect_to_url(ws_url)
	if result != OK:
		status_changed.emit("Nie udało się rozpocząć połączenia WSS: %s" % error_string(result))
		return result
	connected = false
	set_process(true)
	status_changed.emit("Łączenie z pokojem %s…" % room_code)
	return OK

func _process(_delta: float) -> void:
	if _socket == null:
		set_process(false)
		return
	_socket.poll()
	var state := _socket.get_ready_state()
	if state == WebSocketPeer.STATE_OPEN:
		while _socket.get_available_packet_count() > 0:
			var raw := _socket.get_packet().get_string_from_utf8()
			var parsed: Variant = JSON.parse_string(raw)
			if parsed is Dictionary:
				_handle_packet(parsed)
	elif state == WebSocketPeer.STATE_CLOSED:
		var reason := _socket.get_close_reason()
		var code := _socket.get_close_code()
		if connected or not room_code.is_empty():
			connected = false
			status_changed.emit("Połączenie zamknięte (%d): %s" % [code, reason])
			disconnected_from_room.emit(reason)
		set_process(false)

func _handle_packet(data: Dictionary) -> void:
	var kind := str(data.get("type", ""))
	match kind:
		"welcome":
			connected = true
			var welcome_server_time: int = int(data.get("server_time", 0))
			if welcome_server_time > 0:
				server_time_offset_ms = welcome_server_time - int(Time.get_unix_time_from_system() * 1000.0)
			player_id = str(data.get("player_id", ""))
			_players = data.get("players", []) if data.get("players", []) is Array else []
			host_id = str(data.get("host_id", ""))
			players_changed.emit(_players.duplicate(true))
			lobby_changed.emit(_players.duplicate(true), host_id)
			connected_to_room.emit(room_code, player_id)
			status_changed.emit("Połączono z pokojem %s. Gracze: %d/6." % [room_code, _players.size()])
		"player_joined", "player_left":
			var changed_id := str(data.get("player_id", ""))
			if kind == "player_left":
				var remaining: Array = []
				for item: Variant in _players:
					if not item is Dictionary or str(item.get("player_id", "")) != changed_id:
						remaining.append(item)
				_players = remaining
			else:
				_players.append({"player_id": changed_id, "player_name": str(data.get("player_name", "Robot"))})
			players_changed.emit(_players.duplicate(true))
			status_changed.emit("Gracze w pokoju: %d/6." % _players.size())
		"lobby_update":
			_players = data.get("players", []) if data.get("players", []) is Array else []
			host_id = str(data.get("host_id", ""))
			players_changed.emit(_players.duplicate(true))
			lobby_changed.emit(_players.duplicate(true), host_id)
		"race_starting":
			race_starting.emit(int(data.get("start_at", 0)), clampi(int(data.get("ai_count", 0)), 0, 3))
			status_changed.emit("Start wyścigu za około 5 sekund…")
		"ai_state":
			var ai_states: Variant = data.get("states", [])
			if ai_states is Array:
				ai_states_received.emit(ai_states.duplicate(true))
		"race_state":
			var packet_server_time: int = int(data.get("server_time", 0))
			if packet_server_time > 0:
				var observed_offset: int = packet_server_time - int(Time.get_unix_time_from_system() * 1000.0)
				server_time_offset_ms = observed_offset if server_time_offset_ms == 0 else roundi(lerpf(float(server_time_offset_ms), float(observed_offset), 0.1))
			var remote_id := str(data.get("player_id", ""))
			var remote_seq := int(data.get("seq", 0))
			if remote_id.is_empty() or remote_id == player_id or remote_seq <= int(_last_remote_sequence.get(remote_id, -1)):
				return
			_last_remote_sequence[remote_id] = remote_seq
			race_state_received.emit(remote_id, data.duplicate(true))
		"error":
			status_changed.emit("Błąd serwera: %s" % str(data.get("code", "UNKNOWN")))
		_:
			packet_received.emit(data)

func send_input(position: Vector2, rotation: float, throttle: float, steer: float, brake: bool) -> Error:
	if not connected or _socket == null or _socket.get_ready_state() != WebSocketPeer.STATE_OPEN:
		return ERR_UNAVAILABLE
	_sequence += 1
	var packet := {
		"type": "input", "seq": _sequence,
		"x": position.x, "y": position.y, "rotation": rotation,
		"throttle": throttle, "steer": steer, "brake": brake
	}
	return _socket.send_text(JSON.stringify(packet))


## Wysyła snapshot stanu lokalnego robota. Limit klienta: 10 Hz.
func send_race_state(position: Vector3, yaw: float, velocity: Vector3) -> Error:
	if not connected or _socket == null or _socket.get_ready_state() != WebSocketPeer.STATE_OPEN:
		return ERR_UNAVAILABLE
	var now := Time.get_ticks_msec()
	if now - _last_state_send_ms < 100:
		return ERR_BUSY
	_last_state_send_ms = now
	_sequence += 1
	var packet := {
		"type": "race_state", "seq": _sequence,
		"x": position.x, "y": position.y, "z": position.z,
		"yaw": yaw, "vx": velocity.x, "vz": velocity.z
	}
	return _socket.send_text(JSON.stringify(packet))


func send_ai_states(states: Array) -> Error:
	if not connected or _socket == null or _socket.get_ready_state() != WebSocketPeer.STATE_OPEN:
		return ERR_UNAVAILABLE
	return _socket.send_text(JSON.stringify({"type": "ai_state", "states": states.slice(0, 3)}))


func set_ready(is_ready: bool) -> Error:
	return _send_control_message({"type": "ready", "ready": is_ready})

func request_race_start(ai_count: int = 0) -> Error:
	return _send_control_message({"type": "start_race", "ai_count": clampi(ai_count, 0, 3)})

func _send_control_message(message: Dictionary) -> Error:
	if not connected or _socket == null or _socket.get_ready_state() != WebSocketPeer.STATE_OPEN:
		return ERR_UNAVAILABLE
	return _socket.send_text(JSON.stringify(message))

func send_ping() -> Error:
	if not connected or _socket == null:
		return ERR_UNAVAILABLE
	return _socket.send_text(JSON.stringify({"type": "ping", "seq": Time.get_ticks_msec()}))

func disconnect_room(update_status: bool = true) -> void:
	_pending_create = false
	connected = false
	_players.clear()
	_last_remote_sequence.clear()
	_last_state_send_ms = 0
	server_time_offset_ms = 0
	player_id = ""
	host_id = ""
	if _socket != null:
		_socket.close(1000, "Client left room")
		_socket = null
	set_process(false)
	if update_status:
		status_changed.emit("Rozłączono z pokojem internetowym.")

func _normalize_http_url(value: String) -> String:
	var clean := value.strip_edges().trim_suffix("/")
	if clean.begins_with("https://"):
		return clean
	return ""  # HTTPS only: do not send game traffic without TLS.

func _clean_player_name(value: String) -> String:
	var clean := value.strip_edges().substr(0, 20)
	return clean if not clean.is_empty() else "Robot"

func _valid_room_code(value: String) -> bool:
	return value.length() == 8 and value.is_valid_hex_number(false)
