extends Node
## Wspólny transport ENet dla LAN/Wi-Fi oraz bezpośrednich połączeń internetowych.
## Tryb internetowy wymaga publicznego adresu IP i dostępnego portu UDP.

signal status_changed(message: String)
signal peer_joined(peer_id: int)
signal peer_left(peer_id: int)
signal room_info_received(room: Dictionary)

const DEFAULT_PORT: int = 27840
const MAX_CLIENTS: int = 1
var is_host: bool = false
var connected: bool = false
var room_name: String = "Robot Racing"
var active_port: int = DEFAULT_PORT
var active_max_clients: int = MAX_CLIENTS
var _last_room_info: Dictionary = {}

func host_room(name: String = "Robot Racing", port: int = DEFAULT_PORT, max_clients: int = MAX_CLIENTS) -> Error:
	disconnect_room()
	var peer := ENetMultiplayerPeer.new()
	var result := peer.create_server(port, clampi(max_clients, 1, 32))
	if result != OK:
		status_changed.emit("Nie udało się uruchomić pokoju LAN: %s" % error_string(result))
		return result
	multiplayer.multiplayer_peer = peer
	is_host = true
	connected = true
	room_name = name.strip_edges() if not name.strip_edges().is_empty() else "Robot Racing"
	active_port = port
	active_max_clients = clampi(max_clients, 1, 32)
	if not multiplayer.peer_connected.is_connected(_on_peer_connected):
		multiplayer.peer_connected.connect(_on_peer_connected)
	if not multiplayer.peer_disconnected.is_connected(_on_peer_disconnected):
		multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	status_changed.emit("Serwer uruchomiony. Klient może dołączyć pod podanym adresem i portem.")
	return OK

func join_room(address: String, port: int = DEFAULT_PORT) -> Error:
	disconnect_room()
	var clean_address := address.strip_edges()
	if clean_address.is_empty():
		status_changed.emit("Wpisz adres IP lub domenę hosta.")
		return ERR_INVALID_PARAMETER
	var peer := ENetMultiplayerPeer.new()
	var result := peer.create_client(clean_address, port)
	if result != OK:
		status_changed.emit("Nie udało się połączyć: %s" % error_string(result))
		return result
	multiplayer.multiplayer_peer = peer
	is_host = false
	connected = false
	if not multiplayer.connected_to_server.is_connected(_on_connected_to_server):
		multiplayer.connected_to_server.connect(_on_connected_to_server)
	if not multiplayer.connection_failed.is_connected(_on_connection_failed):
		multiplayer.connection_failed.connect(_on_connection_failed)
	if not multiplayer.server_disconnected.is_connected(_on_server_disconnected):
		multiplayer.server_disconnected.connect(_on_server_disconnected)
	status_changed.emit("Łączenie z %s:%d…" % [clean_address, port])
	return OK

func disconnect_room() -> void:
	if multiplayer.multiplayer_peer != null:
		multiplayer.multiplayer_peer.close()
		multiplayer.multiplayer_peer = null
	is_host = false
	connected = false
	_last_room_info.clear()
	active_port = DEFAULT_PORT
	active_max_clients = MAX_CLIENTS

func get_local_ip_hint() -> String:
	var addresses: PackedStringArray = IP.get_local_addresses()
	var ipv4: Array[String] = []
	for address: String in addresses:
		if address.contains(".") and not address.begins_with("127.") and not address.begins_with("169.254."):
			ipv4.append(address)
	if ipv4.is_empty():
		return "Nie udało się odczytać IP. Sprawdź adres IPv4 telefonu w ustawieniach Wi-Fi."
	return "Adres hosta do wpisania w drugim telefonie: %s" % ", ".join(ipv4)

func _on_connected_to_server() -> void:
	connected = true
	status_changed.emit("Połączono z hostem. Pobieranie informacji o pokoju…")
	request_room_info.rpc_id(1)

func _on_connection_failed() -> void:
	connected = false
	status_changed.emit("Połączenie nieudane. Sprawdź adres, port i dostępność hosta.")

func _on_server_disconnected() -> void:
	connected = false
	status_changed.emit("Host zakończył połączenie.")

func _on_peer_connected(peer_id: int) -> void:
	peer_joined.emit(peer_id)
	status_changed.emit("Nowy gracz dołączył do pokoju.")

func _on_peer_disconnected(peer_id: int) -> void:
	peer_left.emit(peer_id)
	status_changed.emit("Drugi telefon opuścił pokój.")

@rpc("any_peer", "call_remote", "reliable")
func request_room_info() -> void:
	if not multiplayer.is_server():
		return
	var sender := multiplayer.get_remote_sender_id()
	send_room_info.rpc_id(sender, {"name": room_name, "host_id": 1, "port": active_port, "protocol": 1, "max_clients": active_max_clients})

@rpc("authority", "call_remote", "reliable")
func send_room_info(room: Dictionary) -> void:
	_last_room_info = room.duplicate(true)
	room_info_received.emit(_last_room_info)
	status_changed.emit("Dołączono do pokoju: %s. Transport ENet działa." % str(room.get("name", "Robot Racing")))
