extends RefCounted
class_name RemoteRaceStateBuffer
## Bufor snapshotów zdalnego robota. Renderowanie powinno odtwarzać stan z
## niewielkim opóźnieniem, aby wygładzić nieregularne pakiety sieciowe.

const MAX_SNAPSHOTS: int = 8
const INTERPOLATION_DELAY_MS: int = 120
var snapshots: Array[Dictionary] = []

func push_snapshot(packet: Dictionary) -> void:
	var snapshot := {
		"time": int(packet.get("server_time", Time.get_ticks_msec())),
		"position": Vector3(float(packet.get("x", 0.0)), float(packet.get("y", 0.0)), float(packet.get("z", 0.0))),
		"yaw": float(packet.get("yaw", 0.0)),
		"velocity": Vector3(float(packet.get("vx", 0.0)), 0.0, float(packet.get("vz", 0.0)))
	}
	snapshots.append(snapshot)
	while snapshots.size() > MAX_SNAPSHOTS:
		snapshots.pop_front()

func sample(now_server_ms: int) -> Dictionary:
	if snapshots.is_empty():
		return {}
	if snapshots.size() == 1:
		return snapshots[0].duplicate(true)
	var target_time := now_server_ms - INTERPOLATION_DELAY_MS
	while snapshots.size() > 2 and int(snapshots[1]["time"]) <= target_time:
		snapshots.pop_front()
	var a: Dictionary = snapshots[0]
	var b: Dictionary = snapshots[1]
	var span := maxi(int(b["time"]) - int(a["time"]), 1)
	var t := clampf(float(target_time - int(a["time"])) / float(span), 0.0, 1.0)
	return {
		"position": Vector3(a["position"]).lerp(Vector3(b["position"]), t),
		"yaw": lerp_angle(float(a["yaw"]), float(b["yaw"]), t),
		"velocity": Vector3(a["velocity"]).lerp(Vector3(b["velocity"]), t),
		"time": target_time
	}

func clear() -> void:
	snapshots.clear()
