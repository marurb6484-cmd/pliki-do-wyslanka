class_name CameraFollow
extends Node3D
## Kamera za robotem gracza.
##
## - Interpolacja fizyki (płynny obraz przy 90 FPS / bez limitu i fizyce 60 Hz),
## - kamera nie wchodzi w ściany (promień co kilka klatek),
## - FOV zależny od prędkości i boosta, lekkie wstrząsy przy uderzeniach.
## Poprzednie obracanie kamery przeciąganiem palca zostało usunięte, bo
## kolidowało z przyciskami gazu/boosta po prawej stronie ekranu.

@export var distance: float = 1.35
@export var height: float = 0.82
@export var look_height: float = 0.30
@export var look_ahead: float = 0.52
@export var position_smoothing: float = 9.0
@export var yaw_smoothing: float = 4.5
@export var base_fov: float = 64.0
@export var speed_fov: float = 4.0
@export var boost_fov: float = 6.0

var target: Robot
var camera: Camera3D
var camera_mode: int = 0
const CAMERA_MODE_NAMES: Array[String] = ["STANDARD", "NAD ROBOTEM", "KAMERA PRZEDNIA", "Z GÓRY"]

var _yaw: float = 0.0
var _initialized: bool = false
var _fov: float = 64.0
var _shake: float = 0.0
var _wall_check_timer: int = 0
var _wall_limit: float = INF
var _boost_pull: float = 0.0
var _ray_query: PhysicsRayQueryParameters3D


func _ready() -> void:
	physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
	camera = get_node_or_null("Camera3D") as Camera3D
	if camera == null:
		camera = Camera3D.new()
		camera.name = "Camera3D"
		add_child(camera)
	camera.physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
	camera.current = true
	camera.fov = base_fov
	camera.near = 0.1
	camera.far = 160.0
	_ray_query = PhysicsRayQueryParameters3D.new()
	_ray_query.collision_mask = Robot.LAYER_WORLD


func set_target(robot: Robot) -> void:
	if target != null and is_instance_valid(target) and target.collided.is_connected(_on_target_collided):
		target.collided.disconnect(_on_target_collided)
	target = robot
	_initialized = false
	if target != null:
		target.collided.connect(_on_target_collided)


func snap() -> void:
	_initialized = false


func set_camera_mode(mode: int) -> void:
	camera_mode = posmod(mode, CAMERA_MODE_NAMES.size())
	_wall_limit = INF
	_wall_check_timer = 0
	_initialized = false
	_set_overhead_ceiling_visibility(camera_mode != 3)


func _set_overhead_ceiling_visibility(visible_value: bool) -> void:
	for ceiling: Node in get_tree().get_nodes_in_group("race_room_ceiling"):
		if is_instance_valid(ceiling):
			ceiling.visible = visible_value


func get_camera_mode_name() -> String:
	return CAMERA_MODE_NAMES[camera_mode]


func _on_target_collided(strength: float, _position: Vector3, _with_robot: bool, damage_amount: float) -> void:
	if damage_amount > 0.0:
		_shake = maxf(_shake, strength * 0.35)


func _process(delta: float) -> void:
	if target == null or not is_instance_valid(target):
		return

	var target_transform: Transform3D = target.get_global_transform_interpolated()
	var position_target: Vector3 = target_transform.origin
	var forward: Vector3 = -target_transform.basis.z
	forward.y = 0.0
	if forward.length_squared() < 0.001:
		forward = Vector3.FORWARD
	forward = forward.normalized()

	var target_yaw: float = atan2(-forward.x, -forward.z)
	if not _initialized:
		_yaw = target_yaw
	else:
		_yaw = lerp_angle(_yaw, target_yaw, 1.0 - exp(-yaw_smoothing * delta))

	var turbo: bool = target.boost.is_turbo_active() and GameSettings.effects_enabled
	_boost_pull = lerpf(_boost_pull, 0.28 if turbo else 0.0, 1.0 - exp(-3.0 * delta))
	if turbo and camera_mode == 0:
		_shake = maxf(_shake, 0.12)
	var offset: Vector3
	var desired: Vector3
	match camera_mode:
		1: # Kamera tuż za robotem, minimalnie nad obudową, patrzy prosto wzdłuż trasy.
			offset = (-forward * 0.78) + Vector3.UP * 0.38
			desired = position_target + offset
		2: # Kamera na wysokości przedniego sensora, poza obudową; bez widoku wnętrza.
			offset = forward * 0.82 + Vector3.UP * 0.24
			desired = position_target + offset
		3: # Ścisły widok z góry jak w GTA 1: kamera dokładnie nad robotem.
			desired = position_target + Vector3.UP * 6.0
		_:
			var chase_offset: Vector3 = Vector3(0.0, 0.0, distance + _boost_pull).rotated(Vector3.UP, _yaw)
			desired = position_target + chase_offset + Vector3.UP * height

	# Ochrona przed wchodzeniem w ściany (sprawdzana co 3 klatki).
	_wall_check_timer -= 1
	if camera_mode == 0 and _wall_check_timer <= 0:
		_wall_check_timer = 3
		var from: Vector3 = position_target + Vector3.UP * 1.0
		_ray_query.from = from
		_ray_query.to = desired
		var hit: Dictionary = get_world_3d().direct_space_state.intersect_ray(_ray_query)
		_wall_limit = INF if hit.is_empty() else maxf(from.distance_to(hit["position"]) - 0.25, 0.82)

	if camera_mode == 0 and _wall_limit < INF:
		var from_point: Vector3 = position_target + Vector3.UP * 1.0
		var direction: Vector3 = desired - from_point
		if direction.length() > _wall_limit:
			desired = from_point + direction.normalized() * _wall_limit + Vector3.UP * 0.6

	if not _initialized:
		camera.global_position = desired
		_initialized = true
	else:
		camera.global_position = camera.global_position.lerp(desired, 1.0 - exp(-position_smoothing * delta))

	if _shake > 0.0:
		_shake = maxf(_shake - delta * 1.5, 0.0)
		camera.global_position += Vector3(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * _shake * 0.3

	# W trybie GTA kamera patrzy pionowo w dół. Nie ma przesunięcia celu ani
	# obracania kadru za robotem, dzięki czemu obraz pozostaje prawdziwym top-down.	
	if camera_mode == 3:
		camera.projection = Camera3D.PROJECTION_ORTHOGONAL
		camera.size = 6.25
		camera.global_position = position_target + Vector3.UP * 6.0
		camera.look_at(position_target, Vector3.FORWARD)
		camera.fov = 70.0
		return
	else:
		camera.projection = Camera3D.PROJECTION_PERSPECTIVE

	var look_point: Vector3
	match camera_mode:
		1:
			look_point = position_target + Vector3.UP * 0.34 + forward * 10.0
		2:
			look_point = position_target + Vector3.UP * 0.24 + forward * 12.0
		_:
			look_point = position_target + Vector3.UP * look_height + forward * look_ahead
	if camera.global_position.distance_squared_to(look_point) > 0.001:
		camera.look_at(look_point, Vector3.UP)

	var speed_ratio: float = clampf(absf(target.forward_speed) / maxf(target.max_speed, 0.1), 0.0, 1.5)
	var wanted_fov: float = base_fov + speed_ratio * speed_fov + (boost_fov if target.boost.is_active() else 0.0) + (boost_fov * 0.6 if turbo and camera_mode == 0 else 0.0)
	if camera_mode == 1:
		wanted_fov = 74.0
	elif camera_mode == 2:
		wanted_fov = 84.0
	_fov = lerpf(_fov, wanted_fov, 1.0 - exp(-4.0 * delta))
	camera.fov = _fov
