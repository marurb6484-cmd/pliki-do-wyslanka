class_name DirtManager
extends Node3D
## Brud do zebrania. Każdy rodzaj ma własną, wieloelementową bryłę 3D,
## zamiast pojedynczej, gładkiej kuli. Modele są lekkie i tworzone raz.

signal dirt_collected(robot: Robot, amount: float)

const DIRT_TYPES: Array[Dictionary] = [
	{"name": "Kurz", "value": 1.0, "size": 0.12},
	{"name": "Okruchy", "value": 2.0, "size": 0.14},
	{"name": "Kłąb kłaczków", "value": 3.0, "size": 0.16},
	{"name": "Grudka błota", "value": 5.0, "size": 0.18},
	{"name": "Piasek", "value": 1.0, "size": 0.12},
	{"name": "Sierść", "value": 3.0, "size": 0.15},
	{"name": "Plama / rozlany płyn", "value": 4.0, "size": 0.18}
]

var track: TrackBase
var respawn_time: float = 9.0
var pickups: Array[Dictionary] = []
var _shape: SphereShape3D
var _robot_previous_positions: Dictionary = {}


func setup(race_track: TrackBase) -> void:
	track = race_track
	respawn_time = track.dirt_respawn_time
	_shape = SphereShape3D.new()
	_shape.radius = 0.16
	var points: Array[Vector3] = _make_random_spawn_points(maxi(track.dirt_pickup_count, 0))
	for i: int in range(points.size()):
		_create_pickup(i, points[i], i % DIRT_TYPES.size())
	set_process(false)
	set_physics_process(true)
	_robot_previous_positions.clear()


func _make_random_spawn_points(count: int) -> Array[Vector3]:
	var result: Array[Vector3] = []
	if track == null or track.route_length <= 0.1:
		return result
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	var min_distance: float = minf(3.0, track.route_length * 0.12)
	var max_distance: float = maxf(min_distance + 0.5, track.route_length - 2.0)
	var minimum_gap: float = maxf(0.8, track.route_length / float(maxi(count, 1)) * 0.38)
	for index: int in range(count):
		var candidate: Vector3 = Vector3.ZERO
		var accepted: bool = false
		for attempt: int in range(48):
			var distance: float = rng.randf_range(min_distance, max_distance)
			var lateral: float = rng.randf_range(-track.track_width * 0.34, track.track_width * 0.34)
			candidate = track.get_point_at(distance) + track.get_side_at(distance) * lateral
			var clear: bool = true
			for existing: Vector3 in result:
				if Vector2(candidate.x - existing.x, candidate.z - existing.z).length() < minimum_gap:
					clear = false
					break
			if not clear:
				continue
			for obstacle: Dictionary in track.obstacles:
				var obstacle_position: Vector3 = obstacle.get("position", Vector3.ZERO)
				if Vector2(candidate.x - obstacle_position.x, candidate.z - obstacle_position.z).length() < float(obstacle.get("radius", 0.5)) + 0.22:
					clear = false
					break
			if clear:
				accepted = true
				break
		if not accepted:
			var distance_fallback: float = lerpf(min_distance, max_distance, float(index + 1) / float(count + 1))
			candidate = track.get_point_at(distance_fallback) + track.get_side_at(distance_fallback) * rng.randf_range(-track.track_width * 0.25, track.track_width * 0.25)
		candidate.y = 0.08
		result.append(candidate)
	return result


func _random_respawn_position(exclude_index: int) -> Vector3:
	if track == null or track.route_length <= 0.1:
		return Vector3.ZERO
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	var min_distance: float = minf(3.0, track.route_length * 0.12)
	var max_distance: float = maxf(min_distance + 0.5, track.route_length - 2.0)
	for attempt: int in range(64):
		var distance: float = rng.randf_range(min_distance, max_distance)
		var lateral: float = rng.randf_range(-track.track_width * 0.34, track.track_width * 0.34)
		var candidate: Vector3 = track.get_point_at(distance) + track.get_side_at(distance) * lateral
		candidate.y = 0.08
		var clear: bool = true
		for index: int in range(pickups.size()):
			if index == exclude_index:
				continue
			var other: Dictionary = pickups[index]
			var other_position: Vector3 = other.get("position", Vector3.ZERO)
			if bool(other.get("active", false)) and Vector2(candidate.x - other_position.x, candidate.z - other_position.z).length() < 0.85:
				clear = false
				break
		if clear:
			for obstacle: Dictionary in track.obstacles:
				var obstacle_position: Vector3 = obstacle.get("position", Vector3.ZERO)
				if Vector2(candidate.x - obstacle_position.x, candidate.z - obstacle_position.z).length() < float(obstacle.get("radius", 0.5)) + 0.22:
					clear = false
					break
		if clear:
			return candidate
	var fallback_distance: float = rng.randf_range(min_distance, max_distance)
	var fallback_lateral: float = rng.randf_range(-track.track_width * 0.25, track.track_width * 0.25)
	var fallback_position: Vector3 = track.get_point_at(fallback_distance) + track.get_side_at(fallback_distance) * fallback_lateral
	fallback_position.y = 0.08
	return fallback_position


func _physics_process(_delta: float) -> void:
	_sweep_fast_robot_pickups()


## Area3D.body_entered pozostaje podstawową metodą zbierania. Dodatkowy test
## odcinka ruchu zabezpiecza przed przeskoczeniem małego Area przy dużej prędkości.
func _sweep_fast_robot_pickups() -> void:
	var robots: Array[Node] = get_tree().get_nodes_in_group("racers")
	for node: Node in robots:
		var robot: Robot = node as Robot
		if robot == null or not is_instance_valid(robot):
			continue
		var instance_key: int = robot.get_instance_id()
		var current: Vector3 = robot.global_position
		var previous: Vector3 = _robot_previous_positions.get(instance_key, current)
		_robot_previous_positions[instance_key] = current
		if robot.pit_controlled or robot.is_queued_for_deletion():
			continue
		# Po teleporcie/resetowaniu nie sprawdzamy całego odcinka między starą i nową
		# pozycją — zapobiega to zbieraniu punktów przez pół mapy.
		if previous.distance_to(current) > 4.0:
			previous = current
		for index: int in range(pickups.size()):
			var pickup: Dictionary = pickups[index]
			if not bool(pickup["active"]):
				continue
			var pickup_position: Vector3 = pickup["position"]
			var closest: Vector3 = Geometry3D.get_closest_point_to_segment(pickup_position, previous, current)
			var horizontal_distance_sq: float = Vector2(closest.x - pickup_position.x, closest.z - pickup_position.z).length_squared()
			var vertical_distance: float = absf(closest.y - pickup_position.y)
			if vertical_distance <= 0.30 and horizontal_distance_sq <= 0.40 * 0.40:
				_on_body_entered(robot, index)


func _create_pickup(index: int, world_position: Vector3, type_index: int) -> void:
	var area := Area3D.new()
	area.name = "Dirt_%d" % index
	area.add_to_group("dirt_pickups")
	area.collision_layer = 0
	area.collision_mask = Robot.LAYER_ROBOTS
	area.monitorable = false
	area.monitoring = true
	area.position = world_position
	var collision := CollisionShape3D.new()
	collision.shape = _shape
	area.add_child(collision)
	# Bez czarnych, płaskich okręgów/śladów na podłodze — pozostaje sam model brudu.
	# Pusty węzeł zachowuje zgodność z logiką ukrywania i odradzania pickupów.
	var floor_marks: Node3D = Node3D.new()
	floor_marks.name = "BrakCzarnychSladow"
	area.add_child(floor_marks)
	var visual: Node3D = StylePackManager.instantiate_dirt(type_index)
	var has_downloaded_visual: bool = visual != null
	if visual == null and not StylePackManager.is_downloaded_only_mode():
		visual = _build_dirt_visual(type_index, index)
	if visual == null:
		visual = Node3D.new()
	if StylePackManager.is_downloaded_only_mode() and not has_downloaded_visual:
		area.collision_mask = 0
	visual.name = "CzytelnyModelBrudu"
	visual.scale *= 0.72
	visual.position.y = -0.06
	area.add_child(visual)
	# Mały znacznik identyfikujący zabrudzenie: jasny wykrzyknik
	# z wyraźnym złotym obramowaniem, bez dużej poświaty.
	var dirt_marker := Label3D.new()
	dirt_marker.name = "ZnacznikBrudu"
	dirt_marker.text = "!"
	dirt_marker.font_size = 22
	dirt_marker.pixel_size = 0.003
	dirt_marker.modulate = Color("#fff8df")
	dirt_marker.outline_size = 6
	dirt_marker.outline_modulate = Color("#d6a52b")
	dirt_marker.position = Vector3(0.0, 0.22, 0.0)
	dirt_marker.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	area.add_child(dirt_marker)
	add_child(area)
	area.body_entered.connect(_on_body_entered.bind(index))
	var projection: Dictionary = track.project_point(world_position)
	pickups.append({
		"id": index,
		"area": area,
		"visual": visual,
		"floor_marks": floor_marks,
		"marker": dirt_marker,
		"active": not StylePackManager.is_downloaded_only_mode() or has_downloaded_visual,
		"respawn_left": 0.0,
		"value": float(DIRT_TYPES[type_index]["value"]),
		"name": str(DIRT_TYPES[type_index]["name"]),
		"distance": float(projection["distance"]),
		"lateral": float(projection["lateral"]),
		"position": world_position
	})


func _build_dirt_visual(type_index: int, pickup_index: int = 0) -> Node3D:
	var root := Node3D.new()
	var rng := RandomNumberGenerator.new()
	rng.seed = int((pickup_index + 1) * 7919 + (type_index + 1) * 104729)
	match type_index:
		0: # Kurz: drobny, matowy pył i kilka widocznych drobinek.
			for i: int in range(10):
				var angle: float = rng.randf_range(0.0, TAU)
				var radius: float = rng.randf_range(0.04, 0.30)
				var size: float = rng.randf_range(0.035, 0.095)
				var color: Color = [Color("#b9ad91"), Color("#8e8778"), Color("#d0c4a9"), Color("#716d63")][i % 4]
				_add_dirt_piece(root, SphereMesh.new(), Vector3(cos(angle) * radius, 0.015 + size * 0.25, sin(angle) * radius), Vector3(size * 1.8, size * 0.45, size), color, rng.randf_range(0.0, TAU))
		1: # Okruchy: nieregularne kawałki pieczywa i ciemniejsze skórki.
			for i: int in range(6):
				var angle: float = rng.randf_range(0.0, TAU)
				var radius: float = rng.randf_range(0.02, 0.27)
				var size: Vector3 = Vector3(rng.randf_range(0.09, 0.18), rng.randf_range(0.055, 0.12), rng.randf_range(0.07, 0.16))
				var crumb: PrimitiveMesh = BoxMesh.new() if i % 2 == 0 else SphereMesh.new()
				_add_dirt_piece(root, crumb, Vector3(cos(angle) * radius, size.y * 0.45, sin(angle) * radius), size, Color("#c98b45") if i % 3 else Color("#8c552d"), rng.randf_range(0.0, TAU))
			for i: int in range(4):
				var fleck_size: float = rng.randf_range(0.025, 0.045)
				_add_dirt_piece(root, SphereMesh.new(), Vector3(rng.randf_range(-0.34, 0.34), 0.025, rng.randf_range(-0.34, 0.34)), Vector3.ONE * fleck_size, Color("#e1b875"), 0.0)
		2: # Kłaczki: miękkie, połączone włókna zamiast zwartej kuli.
			for i: int in range(8):
				var angle: float = TAU * float(i) / 8.0
				var radius: float = rng.randf_range(0.06, 0.20)
				var size: Vector3 = Vector3(rng.randf_range(0.11, 0.19), rng.randf_range(0.08, 0.14), rng.randf_range(0.10, 0.18))
				_add_dirt_piece(root, SphereMesh.new(), Vector3(cos(angle) * radius, size.y * 0.65, sin(angle) * radius), size, [Color("#9a8877"), Color("#c2b5a3"), Color("#75695f")][i % 3], angle)
			var fiber := _add_dirt_piece(root, CapsuleMesh.new(), Vector3(0.0, 0.10, 0.0), Vector3(0.055, 0.20, 0.055), Color("#b4a38e"), 0.0)
			fiber.rotation.z = 0.8
		3: # Błoto: ciężkie, nieregularne grudki z wilgotniejszymi refleksami.
			for i: int in range(5):
				var angle: float = TAU * float(i) / 5.0
				var radius: float = rng.randf_range(0.02, 0.18)
				var size: Vector3 = Vector3(rng.randf_range(0.13, 0.23), rng.randf_range(0.10, 0.17), rng.randf_range(0.12, 0.22))
				_add_dirt_piece(root, SphereMesh.new(), Vector3(cos(angle) * radius, size.y * 0.55, sin(angle) * radius), size, [Color("#493020"), Color("#62412b"), Color("#38271f")][i % 3], rng.randf_range(0.0, TAU))
			_add_dirt_piece(root, SphereMesh.new(), Vector3(-0.04, 0.20, -0.08), Vector3(0.07, 0.035, 0.045), Color("#98704d"), 0.0)
		4: # Piasek: małe ziarenka w rozproszonej kupce.
			for i: int in range(18):
				var angle: float = rng.randf_range(0.0, TAU)
				var radius: float = sqrt(rng.randf()) * 0.34
				var size: float = rng.randf_range(0.025, 0.055)
				_add_dirt_piece(root, SphereMesh.new(), Vector3(cos(angle) * radius, size * 0.55, sin(angle) * radius), Vector3(size * 1.3, size * 0.7, size), [Color("#c5a36a"), Color("#e0c48a"), Color("#a88754")][i % 3], 0.0)
		5: # Sierść: kilka cienkich, skręconych pasm w naturalnych odcieniach.
			for i: int in range(9):
				var angle: float = TAU * float(i) / 9.0
				var radius: float = rng.randf_range(0.04, 0.19)
				var strand := _add_dirt_piece(root, CapsuleMesh.new(), Vector3(cos(angle) * radius, 0.07, sin(angle) * radius), Vector3(0.035, rng.randf_range(0.16, 0.26), 0.035), [Color("#6b5547"), Color("#b69a7b"), Color("#d1c2aa")][i % 3], angle)
				strand.rotation.z = rng.randf_range(-0.55, 0.55)
		6: # Plama rozlanego płynu.
			var puddle := SphereMesh.new()
			puddle.radial_segments = 16
			puddle.rings = 5
			_add_dirt_piece(root, puddle, Vector3(0.0, 0.012, 0.0), Vector3(0.52, 0.025, 0.34), Color("#80634c"), rng.randf_range(0.0, TAU))
	root.scale = Vector3.ONE * 0.5
	return root


func _add_dirt_piece(parent: Node3D, mesh: PrimitiveMesh, local_position: Vector3, piece_scale: Vector3, color: Color, yaw: float) -> MeshInstance3D:
	if mesh is SphereMesh:
		(mesh as SphereMesh).radial_segments = 8
		(mesh as SphereMesh).rings = 4
	var piece := MeshInstance3D.new()
	piece.mesh = mesh
	piece.position = local_position
	piece.scale = piece_scale
	piece.rotation.y = yaw
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.97
	material.metallic = 0.0
	material.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
	piece.material_override = material
	piece.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(piece)
	return piece


func _on_body_entered(body: Node3D, index: int) -> void:
	if index < 0 or index >= pickups.size():
		return
	var pickup: Dictionary = pickups[index]
	if not bool(pickup["active"]):
		return

	var robot: Robot = body as Robot
	if robot == null:
		return
	var dirt_value: float = float(pickup["value"])
	if robot.boost.is_turbo_active():
		dirt_value *= 0.70
	if not robot.collect_dirt(dirt_value):
		return    # pełny zbiornik - brud zostaje dla innych

	pickup["active"] = false
	pickup["respawn_left"] = respawn_time
	(pickup["visual"] as Node3D).visible = false
	(pickup["floor_marks"] as Node3D).visible = false
	(pickup["marker"] as Label3D).visible = false
	var pickup_area: Area3D = pickup["area"] as Area3D
	pickup_area.set_deferred("monitoring", false)
	pickup_area.visible = false
	set_process(true)
	dirt_collected.emit(robot, dirt_value)


func _process(delta: float) -> void:
	var waiting: bool = false
	for index: int in range(pickups.size()):
		var pickup: Dictionary = pickups[index]
		if bool(pickup["active"]):
			continue
		var left: float = float(pickup["respawn_left"]) - delta
		pickup["respawn_left"] = left
		if left <= 0.0:
			pickup["respawn_left"] = 0.0
			var new_position: Vector3 = _random_respawn_position(index)
			pickup["position"] = new_position
			var projection: Dictionary = track.project_point(new_position)
			pickup["distance"] = float(projection.get("distance", 0.0))
			pickup["lateral"] = float(projection.get("lateral", 0.0))
			(pickup["area"] as Area3D).position = new_position
			pickup["active"] = true
			(pickup["visual"] as Node3D).visible = true
			(pickup["floor_marks"] as Node3D).visible = true
			(pickup["marker"] as Label3D).visible = true
			var respawned_area: Area3D = pickup["area"] as Area3D
			respawned_area.visible = true
			respawned_area.set_deferred("monitoring", true)
		else:
			waiting = true
		pickups[index] = pickup
	if not waiting:
		set_process(false)


## Najbliższy aktywny brud przed podaną pozycją na trasie (dla AI).
func find_pickup_ahead(route_distance: float, min_ahead: float, max_ahead: float) -> Dictionary:
	var best: Dictionary = {}
	var best_ahead: float = INF
	for pickup: Dictionary in pickups:
		if not bool(pickup["active"]):
			continue
		var ahead: float = (track.wrap_distance(float(pickup["distance"]) - route_distance) if track.route_closed else float(pickup["distance"]) - route_distance)
		if ahead < min_ahead or ahead > max_ahead or ahead >= best_ahead:
			continue
		best_ahead = ahead
		best = {"id": pickup["id"], "lateral": pickup["lateral"], "ahead": ahead, "position": pickup["position"]}
	return best


func get_active_count() -> int:
	var count: int = 0
	for pickup: Dictionary in pickups:
		if bool(pickup["active"]):
			count += 1
	return count
