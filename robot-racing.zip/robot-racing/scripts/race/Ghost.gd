class_name Ghost
extends Node3D
## Duch najlepszego okrążenia (tryb Jazda na czas).
##
## Nagrywanie: 10 próbek/s (x, z, kąt) dla każdego okrążenia gracza.
## Najlepsze okrążenie zapisywane jest w user://ghosts/<trasa>.ghost.
## Odtwarzanie: półprzezroczysty robot bez kolizji, startujący razem
## z każdym nowym okrążeniem gracza.

const SAMPLE_INTERVAL: float = 0.1
const GHOST_DIR: String = "user://ghosts/"

var track_id: String = ""
var race_manager: RaceManager
var player: Robot

var best_samples: PackedFloat32Array = PackedFloat32Array()
var best_time: float = -1.0
var _recording: PackedFloat32Array = PackedFloat32Array()
var _sample_timer: float = 0.0
var _visuals: RobotVisuals
var _player_racer: Dictionary = {}


func setup(id: String, manager: RaceManager, player_robot: Robot, show_ghost: bool) -> void:
	track_id = id
	race_manager = manager
	player = player_robot
	_player_racer = manager.player_state
	_load()

	_visuals = RobotVisuals.new()
	_visuals.name = "GhostVisuals"
	add_child(_visuals)
	var config: Dictionary = player_robot.config.duplicate()
	_visuals.build(config, false, true)
	visible = false
	set_process(show_ghost)

	manager.lap_completed.connect(_on_lap_completed)
	manager.race_started.connect(_on_race_started)


func _on_race_started() -> void:
	_recording.clear()
	_sample_timer = 0.0


func _physics_process(delta: float) -> void:
	if race_manager == null or not race_manager.is_running() or player == null:
		return
	if bool(_player_racer.get("finished", false)):
		return
	_sample_timer -= delta
	if _sample_timer <= 0.0:
		_sample_timer += SAMPLE_INTERVAL
		var forward: Vector3 = player.get_forward()
		_recording.append(player.global_position.x)
		_recording.append(player.global_position.z)
		_recording.append(atan2(-forward.x, -forward.z))


func _on_lap_completed(racer: Dictionary, _lap: int, lap_time: float) -> void:
	if not bool(racer["is_player"]):
		return
	if best_time < 0.0 or lap_time < best_time:
		best_time = lap_time
		best_samples = _recording.duplicate()
		_save()
	_recording.clear()
	_sample_timer = 0.0


func _process(_delta: float) -> void:
	if best_samples.size() < 6 or race_manager == null or not race_manager.is_running():
		visible = false
		return

	var lap_time: float = race_manager.get_current_lap_time(_player_racer)
	var exact: float = lap_time / SAMPLE_INTERVAL
	var index: int = int(exact)
	var count: int = best_samples.size() / 3
	if index >= count - 1:
		visible = false
		return

	var t: float = exact - index
	var a: int = index * 3
	var b: int = (index + 1) * 3
	var x: float = lerpf(best_samples[a], best_samples[b], t)
	var z: float = lerpf(best_samples[a + 1], best_samples[b + 1], t)
	var yaw: float = lerp_angle(best_samples[a + 2], best_samples[b + 2], t)
	global_position = Vector3(x, 0.02, z)
	rotation = Vector3(0.0, yaw, 0.0)
	visible = true


func _path() -> String:
	return GHOST_DIR + track_id.validate_filename() + ".ghost"


func _load() -> void:
	if SaveManager.test_mode or not FileAccess.file_exists(_path()):
		return
	var file: FileAccess = FileAccess.open(_path(), FileAccess.READ)
	if file == null:
		return
	var data: Variant = file.get_var()
	if data is Dictionary:
		var dictionary: Dictionary = data
		var samples: Variant = dictionary.get("samples", PackedFloat32Array())
		if samples is PackedFloat32Array and (samples as PackedFloat32Array).size() % 3 == 0:
			best_samples = samples
			best_time = float(dictionary.get("time", -1.0))


func _save() -> void:
	if SaveManager.test_mode:
		return
	DirAccess.make_dir_recursive_absolute(GHOST_DIR)
	var file: FileAccess = FileAccess.open(_path(), FileAccess.WRITE)
	if file == null:
		push_warning("Ghost: nie można zapisać ducha.")
		return
	file.store_var({"version": 1, "time": best_time, "samples": best_samples})
