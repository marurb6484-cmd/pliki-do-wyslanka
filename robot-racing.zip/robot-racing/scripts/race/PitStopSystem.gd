class_name PitStopSystem
extends Node3D
## Pit stop: stacja z garażu, zielona strefa, cofanie, naprawa i ładowanie.
## 100% uszkodzeń wymusza powrót na początek bieżącego okrążenia; gaz
## przerywa naprawę natychmiast, także przed osiągnięciem 0% uszkodzeń.

signal status_changed(message: String)

enum State { IDLE, RETURNING_TO_LAP_START, LANE_ENTRY, APPROACHING, DOCKING, SERVICING, EXITING }

const SERVICE_SPEED: float = 10.0
const REPAIR_SPEED: float = 7.0
const AUTO_RETURN_SPEED: float = 5.5
const APPROACH_SPEED: float = 5.0
const DOCK_SPEED: float = 3.8
const EXIT_SPEED: float = 5.0

var track: TrackBase
var player: Robot
var race_manager: RaceManager
var state: int = State.IDLE
var state_label: String = "BATERIA"
var is_emergency: bool = false
## Osobny tryb awaryjny po osiągnięciu 100% uszkodzeń.
var is_damage_emergency: bool = false
var station_data: Dictionary = {}
var station_root: Node3D
var station_forward: Vector3 = Vector3.FORWARD
var approach_position: Vector3 = Vector3.ZERO
var lane_entry_position: Vector3 = Vector3.ZERO
var dock_position: Vector3 = Vector3.ZERO
var exit_position: Vector3 = Vector3.ZERO
var _return_distance: float = 0.0
var _service_charge_rate: float = SERVICE_SPEED
var _service_repair_rate: float = REPAIR_SPEED
var _trigger: Area3D
var _service_gas_armed: bool = false
var _station_offset: float = 0.0
var _station_distance: float = 0.0
var _ai_auto_service: bool = false
var _show_green_zone: bool = true
var statistics: RaceStatistics
var _damage_before_service: float = 0.0
var _pending_initial_damage_emergency: bool = false


func setup(
	race_track: TrackBase,
	race_player: Robot,
	manager: RaceManager,
	station_offset: float = 0.0,
	ai_auto_service: bool = false,
	show_green_zone: bool = true,
	race_statistics: RaceStatistics = null,
	station_distance: float = 0.0,
	listen_for_emergencies: bool = true
) -> void:
	track = race_track
	player = race_player
	race_manager = manager
	_station_offset = station_offset
	_station_distance = clampf(station_distance, 0.0, race_track.route_length) if race_track != null else 0.0
	_ai_auto_service = ai_auto_service
	_show_green_zone = show_green_zone
	statistics = race_statistics
	if player == null or track == null:
		return
	_build_station()
	if listen_for_emergencies:
		if not player.energy.depleted.is_connected(_on_battery_depleted):
			player.energy.depleted.connect(_on_battery_depleted)
		if not player.damage.damage_changed.is_connected(_on_damage_changed):
			player.damage.damage_changed.connect(_on_damage_changed)
	# Zapis z 100% uszkodzeń obsłużymy dopiero po starcie odliczania,
	# aby robot nie ruszył do stacji przed rozpoczęciem wyścigu.
	_pending_initial_damage_emergency = listen_for_emergencies and player.damage.damage >= 99.99


func _build_station() -> void:
	var start: Vector3 = track.get_point_at(_station_distance)
	var tangent: Vector3 = track.get_tangent_at(_station_distance)
	var side: Vector3 = track.get_side_at(_station_distance)
	var robot_index: int = int(player.config.get("robot_index", 0))
	var robot_data: Dictionary = RobotDatabase.get_robot(robot_index)
	station_data = SaveManager.get_dict("docking_stations", str(robot_index))
	station_data = StationConfig.normalize(station_data, robot_data.get("color", Color.WHITE))

	# Stacja stoi poza prawą bandą z zapasem na całą obudowę. Front
	# i zatoka serwisowa są skierowane ku torowi; linia jazdy nie przecina tyłu.
	var station_position: Vector3 = start + side * (track.track_width * 0.5 + 1.05) + tangent * (0.85 + _station_offset)
	station_forward = -side
	var station_basis: Basis = Basis.looking_at(station_forward, Vector3.UP)
	station_root = Node3D.new()
	station_root.name = "PitStop_Station"
	station_root.global_transform = Transform3D(station_basis, station_position)
	add_child(station_root)
	var station_visuals := StationVisuals.new()
	station_visuals.build(station_root, station_data)
	station_root.scale = Vector3.ONE * 0.30
	if _show_green_zone:
		_add_player_station_marker()
	if _ai_auto_service:
		station_root.set_meta("is_ai_docking_station", true)
		var ai_label := Label3D.new()
		ai_label.name = "OznaczenieStacjiAI"
		ai_label.text = "AI"
		ai_label.font_size = 64
		ai_label.outline_size = 10
		ai_label.modulate = Color("#e8d9ff")
		ai_label.position = Vector3(0.0, 1.35, 0.0)
		ai_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		ai_label.no_depth_test = true
		station_root.add_child(ai_label)
	_build_station_collision()
	_build_pit_lane(station_basis, station_position)

	lane_entry_position = start + tangent * (0.85 + _station_offset)
	lane_entry_position.y = 0.16
	# Strefa serwisowa zaczyna się tuż za linią krawędzi toru; robot musi
	# podjechać blisko stacji, zamiast uruchamiać naprawę z daleka.
	approach_position = station_position + station_forward * 0.72
	approach_position.y = 0.16
	dock_position = station_position + station_forward * 0.30
	dock_position.y = 0.16
	exit_position = approach_position + station_forward * 1.4
	exit_position.y = 0.16
	if _show_green_zone:
		_build_green_zone(station_basis)
	_calculate_service_rates()


## Gracz ma czytelny zielony znacznik bezpośrednio na swojej właściwej stacji.
## Stacje AI zachowują własny podpis AI i nie dostają tego znacznika.
func _add_player_station_marker() -> void:
	var marker_material := StandardMaterial3D.new()
	marker_material.albedo_color = Color("#42ff78")
	marker_material.emission_enabled = true
	marker_material.emission = Color("#18e85a")
	marker_material.emission_energy_multiplier = 1.35
	marker_material.roughness = 0.32
	var marker := MeshInstance3D.new()
	marker.name = "ZielonyZnacznikStacjiGracza"
	var ring := TorusMesh.new()
	ring.inner_radius = 1.12
	ring.outer_radius = 1.28
	ring.rings = 18
	ring.ring_segments = 8
	marker.mesh = ring
	marker.material_override = marker_material
	marker.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	marker.position.y = 0.10
	station_root.add_child(marker)


## Kolizje są osobną warstwą fizyczną: nie zmieniają zatwierdzonego modelu.
## Pozostawiają otwarty przód zatoki, aby robot wjeżdżał tylko właściwym wejściem.
func _build_station_collision() -> void:
	var level: int = clampi(int(station_data.get("level", 1)), 1, 5)
	var profile: Dictionary = StationStructure.get_profile(level)
	var body: StaticBody3D = StaticBody3D.new()
	body.name = "StationCollisionOnly"
	body.collision_layer = Robot.LAYER_WORLD
	body.collision_mask = 0
	station_root.add_child(body)
	_add_station_box_collider(body, Vector3(float(profile["w"]), float(profile["h"]), float(profile["d"])), Vector3(0.0, 0.03 + float(profile["h"]) * 0.5, float(profile["body_cz"])))
	var pw: float = float(profile["pw"])
	var pd: float = float(profile["pd"])
	var gh: float = float(profile["gh"])
	var gx: float = pw * 0.5 + 0.28
	var gw: float = 0.12 if level == 1 else 0.16
	var gz: float = float(profile["plat_cz"]) - 0.03
	for side_sign: float in [-1.0, 1.0]:
		_add_station_box_collider(body, Vector3(gw, gh, pd - 0.35), Vector3(side_sign * gx, 0.08 + gh * 0.5, gz))


func _add_station_box_collider(parent: StaticBody3D, dimensions: Vector3, local_position: Vector3) -> void:
	var collision: CollisionShape3D = CollisionShape3D.new()
	var shape: BoxShape3D = BoxShape3D.new()
	shape.size = dimensions
	collision.shape = shape
	collision.position = local_position
	parent.add_child(collision)


func _build_pit_lane(basis: Basis, station_position: Vector3) -> void:
	# Każde stanowisko ma własną krótką zatokę serwisową, oddzieloną od sąsiednich.
	var lane := MeshInstance3D.new()
	lane.name = "DedicatedPitLane"
	var mesh := BoxMesh.new()
	mesh.size = Vector3(1.10, 0.025, 1.25)
	lane.mesh = mesh
	var lane_origin: Vector3 = station_position + station_forward * 0.625
	lane_origin.y = 0.018
	lane.global_transform = Transform3D(basis, lane_origin)
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(0.19, 0.21, 0.23)
	material.roughness = 0.9
	lane.material_override = material
	lane.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(lane)
	for side_sign: float in [-1.0, 1.0]:
		var line := MeshInstance3D.new()
		line.name = "PitLaneEdge"
		var line_mesh := BoxMesh.new()
		line_mesh.size = Vector3(0.025, 0.02, 1.25)
		line.mesh = line_mesh
		line.transform = Transform3D(Basis.IDENTITY, Vector3(side_sign * 0.52, 0.014, 0.0))
		var line_material := StandardMaterial3D.new()
		line_material.albedo_color = Color(0.72, 0.76, 0.78)
		line_material.emission_enabled = true
		line_material.emission = Color(0.22, 0.27, 0.3)
		line.material_override = line_material
		lane.add_child(line)


func _build_green_zone(basis: Basis) -> void:
	_trigger = Area3D.new()
	_trigger.name = "PitStop_GreenZone"
	_trigger.collision_layer = 0
	_trigger.collision_mask = 2
	_trigger.monitoring = true
	_trigger.monitorable = false
	_trigger.global_transform = Transform3D(basis, approach_position)
	add_child(_trigger)
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(1.1, 0.55, 1.1)
	shape.shape = box
	_trigger.add_child(shape)
	var pad := MeshInstance3D.new()
	pad.name = "GreenApproachPad"
	var mesh := BoxMesh.new()
	mesh.size = Vector3(1.1, 0.018, 1.1)
	pad.mesh = mesh
	pad.position.y = -0.14
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(0.18, 1.0, 0.36, 0.24)
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.emission_enabled = true
	material.emission = Color(0.08, 1.0, 0.24)
	material.emission_energy_multiplier = 0.28
	pad.material_override = material
	_trigger.add_child(pad)
	_trigger.body_entered.connect(_on_zone_body_entered)


func _calculate_service_rates() -> void:
	var rates: Dictionary = StationUpgradeSystem.get_service_rates(station_data)
	_service_charge_rate = float(rates.get("charge_rate", SERVICE_SPEED))
	_service_repair_rate = float(rates.get("repair_rate", REPAIR_SPEED))

func _on_zone_body_entered(body: Node3D) -> void:
	if body != player or state != State.IDLE:
		return
	if player.energy.is_empty():
		return
	_begin_manual_pit_stop()


func _begin_manual_pit_stop() -> void:
	is_emergency = false
	_start_pit_control()
	state = State.DOCKING
	_damage_before_service = player.damage.damage
	if statistics != null:
		statistics.begin_pit_stop()
	state_label = "WJAZD DO PIT STOPU"
	status_changed.emit(state_label)


func _on_battery_depleted() -> void:
	if state != State.IDLE or player == null or not is_instance_valid(player):
		return
	_begin_automatic_return(false)


func _on_damage_changed(value: float, _stage: int) -> void:
	if value < 99.99 or state != State.IDLE:
		return
	_begin_damage_return()


func _begin_damage_return() -> void:
	if state != State.IDLE or player == null or not is_instance_valid(player):
		return
	_begin_automatic_return(true)


func _begin_automatic_return(damage_emergency: bool = false) -> void:
	if state != State.IDLE or player == null or not is_instance_valid(player):
		return
	is_emergency = true
	is_damage_emergency = damage_emergency
	_start_pit_control()
	# Awaria jest natychmiastowa: robot zostaje przeniesiony bez jazdy
	# przez trasę, bez zmiany okrążenia i bez resetowania czasu wyścigu.
	var service_basis: Basis = Basis.looking_at(station_forward, Vector3.UP)
	player.global_transform = Transform3D(service_basis, dock_position)
	player.velocity = Vector3.ZERO
	player.forward_speed = 0.0
	player.lateral_speed = 0.0
	state = State.SERVICING
	_service_gas_armed = false
	_damage_before_service = player.damage.damage
	if statistics != null:
		statistics.begin_pit_stop()
	if damage_emergency:
		state_label = "100% USZKODZEŃ — AWARYJNY PIT STOP"
	elif _ai_auto_service:
		state_label = "AI — AWARYJNY PIT STOP"
	else:
		state_label = "ROZŁADOWANA BATERIA — AWARYJNY PIT STOP"
	status_changed.emit(state_label)


func _start_pit_control() -> void:
	player.pit_controlled = true
	player.can_drive = true
	player.velocity = Vector3.ZERO
	player.boost.cancel()
	player.input_throttle = 0.0
	player.input_brake = 0.0


func _physics_process(delta: float) -> void:
	if player == null or not is_instance_valid(player):
		return
	if _pending_initial_damage_emergency and race_manager != null \
	and race_manager.state == RaceManager.State.RUNNING and state == State.IDLE:
		_pending_initial_damage_emergency = false
		_begin_damage_return()
	# Przeciwnicy AI korzystają z własnych, rozstawionych wzdłuż trasy stacji
	# automatycznie, zanim bateria spadnie do zera.
	if _ai_auto_service and state == State.IDLE and player.can_drive:
		if PitStrategySystem.should_ai_enter_pit(player.energy):
			_begin_automatic_return()
	if statistics != null and state != State.IDLE:
		statistics.add_service_time(delta)
	match state:
		State.IDLE:
			return
		State.RETURNING_TO_LAP_START:
			_process_return(delta)
		State.LANE_ENTRY:
			_move_to(lane_entry_position, APPROACH_SPEED, delta, false)
			if player.global_position.distance_to(lane_entry_position) < 0.25:
				state = State.APPROACHING
				state_label = "WJAZD NA WŁASNY PAS PIT STOPU"
				status_changed.emit(state_label)
		State.APPROACHING:
			_move_to(approach_position, APPROACH_SPEED, delta, false)
			if player.global_position.distance_to(approach_position) < 0.25:
				state = State.DOCKING
				state_label = "COFANIE DO STACJI"
				status_changed.emit(state_label)
		State.DOCKING:
			_move_to(dock_position, DOCK_SPEED, delta, true)
			if player.global_position.distance_to(dock_position) < 0.22:
				player.global_position = dock_position
				player.velocity = Vector3.ZERO
				state = State.SERVICING
				_service_gas_armed = false
				state_label = "ŁADOWANIE I NAPRAWA"
				status_changed.emit(state_label)
		State.SERVICING:
			_process_service(delta)
		State.EXITING:
			_process_exit(delta)


func _process_return(delta: float) -> void:
	_return_distance = maxf(_return_distance - AUTO_RETURN_SPEED * delta, _station_distance)
	var point: Vector3 = track.get_point_at(_return_distance)
	point.y = 0.16
	var tangent: Vector3 = track.get_tangent_at(_return_distance)
	player.global_transform = Transform3D(Basis.looking_at(tangent, Vector3.UP), point)
	player.velocity = -tangent * AUTO_RETURN_SPEED
	if _return_distance <= _station_distance + 0.01:
		player.velocity = Vector3.ZERO
		state = State.LANE_ENTRY
		state_label = "DOJAZD DO WŁASNEGO PASA PIT STOPU"
		status_changed.emit(state_label)


func _move_to(target: Vector3, speed: float, delta: float, reverse_into_dock: bool) -> void:
	var direction: Vector3 = station_forward
	if not reverse_into_dock:
		direction = target - player.global_position
		direction.y = 0.0
		if direction.length_squared() > 0.001:
			direction = direction.normalized()
			player.global_basis = Basis.looking_at(direction, Vector3.UP)
	else:
		player.global_basis = Basis.looking_at(station_forward, Vector3.UP)
	player.global_position = player.global_position.move_toward(target, speed * delta)
	player.velocity = Vector3.ZERO


func _process_service(delta: float) -> void:
	# Gaz trzymany podczas wjazdu nie może natychmiast anulować pit stopu.
	# Gracz najpierw puszcza gaz, a ponowne naciśnięcie uruchamia wyjazd.
	if not _ai_auto_service:
		if player.input_throttle <= 0.1:
			_service_gas_armed = true
		elif _service_gas_armed:
			var minimum_departure: float = maxf(player.energy.capacity * 0.05, 1.0)
			# Przy 100% uszkodzeń gaz natychmiast przerywa naprawę, nawet
			# jeśli naprawa jest niepełna. Awaria baterii zachowuje dotychczasową
			# ochronę przed wyjazdem z całkowicie pustym akumulatorem.
			if is_damage_emergency or not is_emergency or player.energy.current >= minimum_departure:
				_begin_exit()
				return
	player.energy.charge(_service_charge_rate * delta)
	player.damage.repair(_service_repair_rate * delta)
	if statistics != null:
		statistics.record_repair(maxf(_damage_before_service - player.damage.damage, 0.0))
		_damage_before_service = player.damage.damage
	var charge_target: float = PitStrategySystem.get_ai_service_target() if _ai_auto_service else 0.98
	if is_damage_emergency and player.damage.damage <= 0.05:
		_begin_exit()
	elif is_emergency and player.energy.get_ratio() >= charge_target and player.damage.damage <= 0.05:
		_begin_exit()


func _begin_exit() -> void:
	state = State.EXITING
	state_label = "WYJAZD Z PIT STOPU"
	status_changed.emit(state_label)


func _process_exit(delta: float) -> void:
	player.global_basis = Basis.looking_at(station_forward, Vector3.UP)
	player.global_position = player.global_position.move_toward(exit_position, EXIT_SPEED * delta)
	if player.global_position.distance_to(exit_position) < 0.25:
		player.pit_controlled = false
		if statistics != null:
			statistics.end_pit_stop()
		player.can_drive = true
		player.velocity = station_forward * 0.8
		player.forward_speed = 0.8
		state = State.IDLE
		state_label = "BATERIA"
		is_emergency = false
		is_damage_emergency = false
		_service_gas_armed = false
		status_changed.emit("")


func get_status_text() -> String:
	return state_label


func is_in_pit() -> bool:
	return state != State.IDLE
