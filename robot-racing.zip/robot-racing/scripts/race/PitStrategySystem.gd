class_name PitStrategySystem
extends RefCounted
## Wspólna logika strategii pit stopów. Nie steruje robotem ani HUD-em.

const FIRST_LAP_WARNING_RATIO: float = 0.30
const SAFETY_RESERVE_RATIO: float = 0.12
const LAP_MARGIN: float = 1.15
const AI_MINIMUM_RATIO: float = 0.18
const AI_SERVICE_TARGET: float = 0.92


static func get_warning_energy(energy: EnergySystem) -> float:
	if energy == null:
		return 0.0
	var reserve: float = energy.capacity * SAFETY_RESERVE_RATIO
	if energy.last_lap_consumed > 0.01:
		return minf(energy.capacity, energy.last_lap_consumed * LAP_MARGIN + reserve)
	return energy.capacity * FIRST_LAP_WARNING_RATIO


static func should_warn_player(energy: EnergySystem) -> bool:
	return energy != null and energy.current <= get_warning_energy(energy)


static func should_ai_enter_pit(energy: EnergySystem) -> bool:
	if energy == null:
		return false
	var strategic_threshold: float = get_warning_energy(energy)
	var emergency_threshold: float = energy.capacity * AI_MINIMUM_RATIO
	return energy.current <= maxf(strategic_threshold, emergency_threshold)


static func get_ai_service_target() -> float:
	return AI_SERVICE_TARGET
