class_name RaceManager
extends Node
## Logika wyścigu: odliczanie, postęp wzdłuż trasy, okrążenia, pozycje, meta, wyniki.
##
## Zastępuje dwa poprzednie, konkurencyjne systemy (TrackManager z checkpointami
## oraz RaceController z linią mety). Postęp liczony jest w sposób ciągły przez
## rzutowanie pozycji na linię trasy, więc szeroki tor jazdy nie powoduje
## "zgubienia" checkpointu, a jazda pod prąd nie nalicza okrążeń.
##
## Inne systemy (HUD, dźwięk, RaceScene) reagują na sygnały - RaceManager
## nie zna interfejsu.

signal countdown_changed(seconds_left: int)
signal race_started
signal lap_completed(racer: Dictionary, lap: int, lap_time: float)
signal checkpoint_passed(racer: Dictionary, checkpoint_index: int, split_time: float, elapsed_time: float)
signal racer_finished(racer: Dictionary)
signal positions_updated
signal race_finished(results: Array)
signal wrong_way_changed(is_wrong: bool)
signal reset_lock_changed(seconds_left: int)

enum State { IDLE, COUNTDOWN, RUNNING, FINISHING, FINISHED }

## Ile sekund po mecie gracza czekamy na pozostałych zawodników.
const POST_FINISH_WAIT: float = 10.0
const RESET_DRIVE_LOCK_SECONDS: float = 3.0

var track: TrackBase
var mode: String = "race"
var total_laps: int = 3        # 0 = jazda bez końca (test grafiki)
var countdown_time: float = 5.0

var racers: Array[Dictionary] = []
var player_state: Dictionary = {}
var local_player_robots: Array[Robot] = []
var state: int = State.IDLE
var race_time: float = 0.0

var _countdown_left: float = 0.0
var _last_countdown: int = -1
var _position_timer: float = 0.0
var _finish_wait: float = 0.0
var _finished_count: int = 0
var _reset_lock_remaining: float = 0.0
var _reset_lock_last_second: int = -1


func setup(race_track: TrackBase, robots: Array, player: Robot, race_mode: String, laps: int, countdown: float, extra_local_players: Array[Robot] = []) -> void:
	track = race_track
	mode = race_mode
	total_laps = 1 if not race_track.route_closed else maxi(laps, 0)
	countdown_time = countdown
	local_player_robots = [player]
	for local_robot: Robot in extra_local_players:
		if local_robot != null and not local_player_robots.has(local_robot):
			local_player_robots.append(local_robot)
	racers.clear()

	for i: int in range(robots.size()):
		var robot: Robot = robots[i] as Robot
		var projection: Dictionary = track.project_point(robot.global_position)
		var distance: float = float(projection["distance"])
		var signed_distance: float = distance if not track.route_closed or distance < track.route_length * 0.5 else distance - track.route_length

		var racer: Dictionary = {
			"robot": robot,
			"name": robot.display_name,
			"is_player": robot == player,
			"is_local_player": local_player_robots.has(robot),
			"index": i,
			"hint": int(projection["index"]),
			"last_distance": distance,
			"total": signed_distance,
			"laps_done": 0,
			"next_checkpoint": 0,
			"checkpoint_times": [],
			"last_checkpoint_time": 0.0,
			"lap_start": 0.0,
			"lap_times": [],
			"best_lap": -1.0,
			"finished": false,
			"finish_time": -1.0,
			"finish_order": 0,
			"position": i + 1,
			"backwards_time": 0.0,
			"wrong_way": false
		}
		racers.append(racer)
		if robot == player:
			player_state = racer

	_update_positions()


func start_countdown() -> void:
	state = State.COUNTDOWN
	_countdown_left = countdown_time
	_last_countdown = -1
	race_time = 0.0
	GameManager.is_racing = false
	for racer: Dictionary in racers:
		(racer["robot"] as Robot).can_drive = false


func _physics_process(delta: float) -> void:
	if _reset_lock_remaining > 0.0:
		_reset_lock_remaining = maxf(_reset_lock_remaining - delta, 0.0)
		var seconds_left: int = ceili(_reset_lock_remaining)
		if seconds_left != _reset_lock_last_second:
			_reset_lock_last_second = seconds_left
			reset_lock_changed.emit(seconds_left)
		if _reset_lock_remaining <= 0.0:
			var locked_robot: Robot = player_state.get("robot") as Robot
			if is_instance_valid(locked_robot):
				locked_robot.drive_locked = false
			_reset_lock_last_second = -1
	match state:
		State.COUNTDOWN:
			_process_countdown(delta)
		State.RUNNING, State.FINISHING:
			_process_race(delta)


func _process_countdown(delta: float) -> void:
	_countdown_left -= delta
	var seconds: int = ceili(_countdown_left)
	if seconds != _last_countdown and seconds > 0:
		_last_countdown = seconds
		countdown_changed.emit(seconds)
	if _countdown_left <= 0.0:
		state = State.RUNNING
		race_time = 0.0
		GameManager.is_racing = true
		for racer: Dictionary in racers:
			(racer["robot"] as Robot).can_drive = true
		countdown_changed.emit(0)
		race_started.emit()


func _process_race(delta: float) -> void:
	race_time += delta
	GameManager.race_time = race_time

	for racer: Dictionary in racers:
		_update_racer(racer, delta)
		if state == State.FINISHED:
			return

	_position_timer -= delta
	if _position_timer <= 0.0:
		_position_timer = 0.15
		_update_positions()

	if state == State.FINISHING:
		_finish_wait += delta
		if _finish_wait >= POST_FINISH_WAIT:
			_end_race()


func _update_racer(racer: Dictionary, delta: float) -> void:
	var robot: Robot = racer["robot"]
	if not is_instance_valid(robot):
		return

	# Watchdog pozycji: ratowanie zanim robot zniknie pod podłogą.
	# Po teleportacji synchronizujemy licznik dystansu, aby reset nie doliczył
	# przypadkowego skoku do przodu lub do tyłu.
	if robot.global_position.y < -1.25:
		_reset_to_track(racer)
		var rescued_projection: Dictionary = track.project_point(robot.global_position)
		racer["hint"] = int(rescued_projection.get("index", 0))
		racer["last_distance"] = float(rescued_projection.get("distance", 0.0))
		return

	var projection: Dictionary = track.project_point(robot.global_position, int(racer["hint"]))
	racer["hint"] = int(projection["index"])
	var distance: float = float(projection["distance"])
	var step: float = distance - float(racer["last_distance"])
	if track.route_closed:
		var half: float = track.route_length * 0.5
		if step > half:
			step -= track.route_length
		elif step < -half:
			step += track.route_length
		racer["total"] = float(racer["total"]) + step
	else:
		# Na odcinku postęp jest bezwzględną odległością od startu; nie zawija się.
		racer["total"] = distance
	racer["last_distance"] = distance
	_apply_checkpoint_gate(racer, distance, float(projection.get("lateral", 0.0)), robot)

	# Jazda pod prąd.
	if not bool(racer["finished"]) and not robot.pit_controlled:
		var tangent: Vector3 = track.get_tangent_at(distance)
		var backwards: bool = robot.get_forward().dot(tangent) < -0.3 and absf(robot.forward_speed) > 1.0
		racer["backwards_time"] = float(racer["backwards_time"]) + delta if backwards else maxf(float(racer["backwards_time"]) - delta * 2.0, 0.0)
		var wrong: bool = float(racer["backwards_time"]) > 1.2
		if wrong != bool(racer["wrong_way"]):
			racer["wrong_way"] = wrong
			if bool(racer["is_player"]):
				wrong_way_changed.emit(wrong)

	# Okrążenia.
	if bool(racer["finished"]):
		return
	while int(racer.get("next_checkpoint", 0)) >= 4 and float(racer["total"]) >= float(int(racer["laps_done"]) + 1) * track.route_length:
		racer["laps_done"] = int(racer["laps_done"]) + 1
		racer["next_checkpoint"] = 0
		(racer["checkpoint_times"] as Array).clear()
		racer["last_checkpoint_time"] = 0.0
		var lap_time: float = race_time - float(racer["lap_start"])
		racer["lap_start"] = race_time
		(racer["lap_times"] as Array).append(lap_time)
		if float(racer["best_lap"]) < 0.0 or lap_time < float(racer["best_lap"]):
			racer["best_lap"] = lap_time
		lap_completed.emit(racer, int(racer["laps_done"]), lap_time)

		if total_laps > 0 and int(racer["laps_done"]) >= total_laps:
			_finish_racer(racer)
			break


## Wymaga przejechania przez kolejne bramki w kolejności. Samo rzutowanie
## pozycji na dalszy fragment trasy nie zalicza pominiętego checkpointu.
func _apply_checkpoint_gate(racer: Dictionary, distance: float, lateral: float, robot: Robot) -> void:
	var checkpoint_index: int = int(racer.get("next_checkpoint", 0))
	if checkpoint_index >= 4 or track.route_length <= 0.0:
		return
	var fractions: Array[float] = [0.25, 0.5, 0.75, 1.0]
	var fraction: float = fractions[checkpoint_index]
	var target_distance: float = track.route_length * fraction
	var near_gate: bool = false
	if checkpoint_index == 3 and track.route_closed:
		near_gate = distance <= 1.0 or track.route_length - distance <= 1.0
	else:
		near_gate = absf(distance - target_distance) <= 1.0
	var tangent: Vector3 = track.get_tangent_at(distance)
	var facing_forward: bool = robot.get_forward().dot(tangent) > 0.15
	var inside_gate: bool = absf(lateral) <= track.track_width * 0.5 + 0.18
	if near_gate and facing_forward and inside_gate:
		var elapsed_time: float = race_time - float(racer.get("lap_start", 0.0)) if track.route_closed else race_time
		var previous_checkpoint_time: float = float(racer.get("last_checkpoint_time", 0.0))
		var split_time: float = maxf(elapsed_time - previous_checkpoint_time, 0.0)
		racer["last_checkpoint_time"] = elapsed_time
		(racer["checkpoint_times"] as Array).append(elapsed_time)
		racer["next_checkpoint"] = checkpoint_index + 1
		checkpoint_passed.emit(racer, checkpoint_index + 1, split_time, elapsed_time)
		return
	# Zatrzymujemy naliczanie postępu przed kolejną bramką. Gracz musi
	# zawrócić i przejechać przez widoczny checkpoint, zamiast ścinać trasę.
	var lap_base: float = 0.0 if not track.route_closed else float(int(racer.get("laps_done", 0))) * track.route_length
	var gate_limit: float = lap_base + target_distance - 1.2
	if float(racer.get("total", 0.0)) > gate_limit:
		racer["total"] = maxf(gate_limit, lap_base)


func _finish_racer(racer: Dictionary) -> void:
	racer["finished"] = true
	racer["finish_time"] = race_time
	_finished_count += 1
	racer["finish_order"] = _finished_count
	racer["wrong_way"] = false
	_update_positions()
	racer_finished.emit(racer)

	var all_done: bool = true
	for other: Dictionary in racers:
		if not bool(other["finished"]):
			all_done = false
			break

	if all_done:
		_end_race()
	elif bool(racer.get("is_local_player", racer["is_player"])) and state == State.RUNNING:
		state = State.FINISHING
		_finish_wait = 0.0


func _reset_to_track(racer: Dictionary) -> void:
	var robot: Robot = racer["robot"]
	var distance: float = track.wrap_distance(float(racer["total"]))
	var point: Vector3 = track.get_point_at(distance)
	point.y = 0.2
	robot.reset_to(Transform3D(Basis.looking_at(track.get_tangent_at(distance), Vector3.UP), point))


## Powrót na najbliższy bezpieczny punkt linii trasy. Nie zmienia postępu,
## okrążenia, czasu, uszkodzeń, energii ani cooldownów boostów.
func reset_player_to_track() -> bool:
	if player_state.is_empty() or state != State.RUNNING:
		return false
	var robot: Robot = player_state["robot"] as Robot
	if robot == null or not is_instance_valid(robot) or robot.pit_controlled:
		return false
	var projection: Dictionary = track.project_point(robot.global_position)
	var projected_distance: float = float(projection.get("distance", 0.0))
	var safe_distance: float = _find_nearest_safe_distance(projected_distance)
	var point: Vector3 = track.get_point_at(safe_distance)
	point.y = 0.35
	var tangent: Vector3 = track.get_tangent_at(safe_distance)
	if tangent.length_squared() < 0.001:
		tangent = Vector3.FORWARD
	robot.reset_to(Transform3D(Basis.looking_at(tangent, Vector3.UP), point), false)
	robot.drive_locked = true
	_reset_lock_remaining = RESET_DRIVE_LOCK_SECONDS
	_reset_lock_last_second = 3
	reset_lock_changed.emit(3)
	# RaceManager nie może potraktować teleportu jako przejechania odcinka.
	var safe_projection: Dictionary = track.project_point(point)
	player_state["hint"] = int(safe_projection.get("index", 0))
	player_state["last_distance"] = safe_distance
	return true


func _find_nearest_safe_distance(origin_distance: float) -> float:
	var candidates: Array[float] = [0.0]
	for step: int in range(1, 9):
		candidates.append(float(step) * 1.5)
		candidates.append(-float(step) * 1.5)
	for offset: float in candidates:
		var raw_distance: float = origin_distance + offset
		if raw_distance < 0.0 or raw_distance >= track.route_length:
			continue
		var candidate_distance: float = raw_distance
		var candidate: Vector3 = track.get_point_at(candidate_distance)
		var safe: bool = true
		for obstacle: Dictionary in track.obstacles:
			var obstacle_position: Vector3 = obstacle.get("position", Vector3.ZERO)
			var required_clearance: float = float(obstacle.get("radius", 0.0)) + 1.35
			var distance_2d: float = Vector2(candidate.x - obstacle_position.x, candidate.z - obstacle_position.z).length()
			if distance_2d < required_clearance:
				safe = false
				break
		if safe:
			return candidate_distance
	return clampf(origin_distance, 0.0, maxf(track.route_length - 0.001, 0.0))


func _update_positions() -> void:
	var ordered: Array[Dictionary] = racers.duplicate()
	ordered.sort_custom(_compare_racers)
	for i: int in range(ordered.size()):
		ordered[i]["position"] = i + 1
	positions_updated.emit()


func _compare_racers(a: Dictionary, b: Dictionary) -> bool:
	var a_finished: bool = bool(a["finished"])
	var b_finished: bool = bool(b["finished"])
	if a_finished != b_finished:
		return a_finished
	if a_finished and b_finished:
		return int(a["finish_order"]) < int(b["finish_order"])
	return float(a["total"]) > float(b["total"])


## Zakończenie wyścigu: wyniki dla wszystkich (niedokończeni - czas szacowany).
func _end_race() -> void:
	if state == State.FINISHED:
		return
	state = State.FINISHED
	_update_positions()

	var results: Array = []
	for racer: Dictionary in racers:
		var robot: Robot = racer["robot"]
		var finished: bool = bool(racer["finished"])
		var time: float = float(racer["finish_time"])
		var estimated: bool = false

		if not finished and total_laps > 0:
			var remaining: float = maxf(float(total_laps) * track.route_length - float(racer["total"]), 0.0)
			var average_speed: float = maxf(float(racer["total"]) / maxf(race_time, 0.1), 2.0)
			time = race_time + remaining / average_speed
			estimated = true

		results.append({
			"position": int(racer["position"]),
			"name": str(racer["name"]),
			"is_player": bool(racer["is_player"]),
			"is_local_player": bool(racer.get("is_local_player", racer["is_player"])),
			"finished": finished,
			"time": time,
			"estimated": estimated,
			"best_lap": float(racer["best_lap"]),
			"laps": int(racer["laps_done"]),
			"lap_times": (racer["lap_times"] as Array).duplicate(),
			"dirt": robot.tank.total_collected if is_instance_valid(robot) else 0.0,
			"damage_taken": robot.damage.damage_taken_this_race if is_instance_valid(robot) else 0.0
		})

	results.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return int(a["position"]) < int(b["position"]))

	GameManager.race_results = results
	GameManager.finish_race()
	race_finished.emit(results)


## Zakończenie na żądanie (np. "Zakończ test" lub wyjście z wyścigu).
func force_end() -> void:
	if state == State.RUNNING or state == State.FINISHING:
		_end_race()


# =========================================================
# ODCZYT DLA HUD
# =========================================================

func is_running() -> bool:
	return state == State.RUNNING or state == State.FINISHING


func get_racer_count() -> int:
	return racers.size()


func get_player_position() -> int:
	return int(player_state.get("position", 1))


func get_player_lap() -> int:
	if player_state.is_empty():
		return 1
	var lap: int = int(player_state["laps_done"]) + 1
	return mini(lap, total_laps) if total_laps > 0 else lap


func get_current_lap_time(racer: Dictionary) -> float:
	if racer.is_empty() or state == State.COUNTDOWN or state == State.IDLE:
		return 0.0
	if bool(racer["finished"]):
		return 0.0
	return race_time - float(racer["lap_start"])


func get_racer_for(robot: Robot) -> Dictionary:
	for racer: Dictionary in racers:
		if racer["robot"] == robot:
			return racer
	return {}


func get_lap_progress(racer: Dictionary) -> float:
	if racer.is_empty() or track.route_length <= 0.0:
		return 0.0
	var progress: float = fposmod(float(racer["total"]), track.route_length) / track.route_length if track.route_closed else float(racer["total"]) / track.route_length
	return clampf(progress, 0.0, 1.0)


## Odstęp (w sekundach, szacunkowo) do zawodnika przed i za graczem.
func get_player_gaps() -> Dictionary:
	var result: Dictionary = {"ahead": -1.0, "behind": -1.0, "ahead_name": "", "behind_name": ""}
	if player_state.is_empty():
		return result
	var position: int = int(player_state["position"])
	var player_robot: Robot = player_state["robot"]
	var speed: float = maxf(absf(player_robot.forward_speed), 0.8)
	for racer: Dictionary in racers:
		var difference: float = absf(float(racer["total"]) - float(player_state["total"])) / speed
		if int(racer["position"]) == position - 1:
			result["ahead"] = difference
			result["ahead_name"] = racer["name"]
		elif int(racer["position"]) == position + 1:
			result["behind"] = difference
			result["behind_name"] = racer["name"]
	return result
