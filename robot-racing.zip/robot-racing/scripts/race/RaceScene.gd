extends Node3D
## Scena wyścigu - "korzeń kompozycji".
##
## Na podstawie konfiguracji z GameManager tworzy: trasę, roboty (gracz + AI
## z losowymi, niepowtarzalnymi skórkami), brud, logikę wyścigu, kamerę, HUD
## i ducha (jazda na czas). Następnie łączy systemy sygnałami i rozlicza
## wynik (nagrody, rekordy, uszkodzenia) - z wyjątkiem trybu testu grafiki,
## który niczego nie zapisuje.

const ROBOT_SCENE: PackedScene = preload("res://scenes/robots/Robot.tscn")
const HUD_SCENE: PackedScene = preload("res://ui/hud/RaceHUD.tscn")

const AI_NAMES: Array[String] = ["Szczotex", "Kurzołap", "Mop-3000", "Ścierka", "Turbo Zbyszek", "Odkurzacz Max", "Pyłożer", "Zmiotka"]

var track: TrackBase
var race_manager: RaceManager
var dirt_manager: DirtManager
var camera_rig: CameraFollow
var hud: Node
var ghost: Ghost
var pit_stop: PitStopSystem
var pit_stops: Array[PitStopSystem] = []
var race_statistics: RaceStatistics

var player: Robot
var local_player_two: Robot
var local_players: Array[Robot] = []
var robots: Array[Robot] = []
var mode: String = "race"
var _vehicles: Node3D
var _online_active: bool = false
var _online_send_accum: float = 0.0
var _online_remote_robots: Dictionary = {}
var _online_remote_buffers: Dictionary = {}
var _online_ai_robots: Array[Robot] = []

var _finalized: bool = false
var _player_finished: bool = false


func _ready() -> void:
	GameManager.start_race()
	mode = GameManager.get_mode_id()

	if not _create_track():
		if GameManager.online_race_active:
			CloudflareOnlineSession.disconnect_room()
			GameManager.clear_online_race()
		GameManager.go_to_main_menu()
		return

	_create_robots()
	_online_active = GameManager.online_race_active and CloudflareOnlineSession.connected
	if _online_active:
		if not CloudflareOnlineSession.race_state_received.is_connected(_on_online_race_state_received):
			CloudflareOnlineSession.race_state_received.connect(_on_online_race_state_received)
		if not CloudflareOnlineSession.ai_states_received.is_connected(_on_online_ai_states_received):
			CloudflareOnlineSession.ai_states_received.connect(_on_online_ai_states_received)
		_create_online_remote_robots()
	_create_dirt()
	_create_race_manager()
	_create_race_statistics()
	_create_pit_stop()
	_create_camera()
	_create_ghost()
	_create_hud()

	if _online_active:
		var remaining_ms: float = float(GameManager.online_start_at_ms) - float(CloudflareOnlineSession.get_server_time_ms())
		race_manager.countdown_time = maxf(remaining_ms / 1000.0, 0.0)
	race_manager.start_countdown()


# =========================================================
# BUDOWA SCENY
# =========================================================

func _create_track() -> bool:
	var track_data: Dictionary = GameManager.get_track_data()
	var packed: PackedScene = load(str(track_data["scene"])) as PackedScene
	if packed == null:
		push_error("RaceScene: nie można wczytać trasy %s." % track_data["scene"])
		return false

	track = packed.instantiate() as TrackBase
	if track == null:
		push_error("RaceScene: scena trasy nie dziedziczy po TrackBase.")
		return false
	if bool(track_data.get("generated", false)) and track is ProceduralTrack:
		(track as ProceduralTrack).configure(track_data)

	track.name = "Track"
	add_child(track)
	if not track.built:
		track.build_track()
	return track.smooth_route.size() >= 3


func _create_robots() -> void:
	_vehicles = Node3D.new()
	_vehicles.name = "Vehicles"
	add_child(_vehicles)
	var vehicles: Node3D = _vehicles

	var opponents: int = 0
	if mode != "local_multiplayer":
		var available_slots: int = maxi(track.max_racers - 1, 0)
		if GameManager.online_race_active:
			available_slots = maxi(track.max_racers - CloudflareOnlineSession.get_players().size(), 0)
		opponents = clampi(GameManager.opponent_count, 0, available_slots)

	# --- Gracz ---
	var player_config: Dictionary = GameManager.get_player_config()
	player_config["engine_sound_profile"] = SaveManager.get_int("robot_audio", str(int(player_config.get("robot_index", 0))), 0)
	var saved_upgrades: Dictionary = PlayerProgress.get_upgrades(int(player_config.get("robot_index", 0)))
	var upgrade_level_sum: int = 0
	for upgrade_value: Variant in saved_upgrades.values():
		upgrade_level_sum += int(upgrade_value)
	player_config["engine_upgrade_level"] = upgrade_level_sum
	var player_damage: float = 0.0
	if not GameManager.is_graphics_test():
		player_damage = PlayerProgress.get_damage(int(player_config["robot_index"]))

	var player_slot: int = opponents if mode == "race" else 0
	if GameManager.online_race_active:
		var online_roster: Array = CloudflareOnlineSession.get_players()
		for roster_index: int in range(online_roster.size()):
			var roster_entry: Variant = online_roster[roster_index]
			if roster_entry is Dictionary and str(roster_entry.get("player_id", "")) == CloudflareOnlineSession.player_id:
				player_slot = roster_index
				break
	player = _spawn_robot(vehicles, player_config, true, player_damage, player_slot)
	player.display_name = "TY (%s)" % str(player_config["name"])

	if mode == "local_multiplayer":
		var driver_one := LocalPlayerDriver.new()
		driver_one.name = "LocalPlayer1Driver"
		driver_one.player_number = 1
		player.add_child(driver_one)
		player.driver = driver_one

		var second_index := (int(player_config["robot_index"]) + 1) % RobotDatabase.count()
		var second_config := RobotDatabase.build_config(second_index, RobotDatabase.empty_upgrades(), 0, 1)
		local_player_two = _spawn_robot(vehicles, second_config, true, 0.0, 1)
		local_player_two.name = "LocalPlayer2"
		local_player_two.display_name = "GRACZ 2"
		local_player_two.racer_index = 2
		var driver_two := LocalPlayerDriver.new()
		driver_two.name = "LocalPlayer2Driver"
		driver_two.player_number = 2
		local_player_two.add_child(driver_two)
		local_player_two.driver = driver_two
		local_players = [player, local_player_two]
	else:
		var driver := PlayerDriver.new()
		driver.name = "PlayerDriver"
		player.add_child(driver)
		player.driver = driver
		local_players = [player]

	# --- Przeciwnicy AI ---
	var ai_configs: Array[Dictionary] = _pick_online_ai_configs(opponents) if GameManager.online_race_active else _pick_ai_configs(opponents, player_config)
	var styles: Array[int] = [AIDifficulty.Style.BALANCED, AIDifficulty.Style.AGGRESSIVE, AIDifficulty.Style.CAREFUL, AIDifficulty.Style.COLLECTOR]
	var names: Array[String] = AI_NAMES.duplicate()
	if not GameManager.online_race_active:
		styles.shuffle()
		names.shuffle()
	if GameManager.career_active:
		var career_event: Dictionary = PlayerProgress.get_career_event()
		if bool(career_event.get("boss", false)) and not names.is_empty():
			names[0] = str(career_event.get("boss_name", "BOSS KARIERY"))
			styles[0] = AIDifficulty.Style.AGGRESSIVE

	var slot: int = CloudflareOnlineSession.get_players().size() if GameManager.online_race_active else 0
	for i: int in range(opponents):
		if not GameManager.online_race_active and slot == player_slot:
			slot += 1
		var robot: Robot = _spawn_robot(vehicles, ai_configs[i], false, 0.0, slot)
		robot.display_name = LocaleManager.tr_text(names[i % names.size()])
		robot.racer_index = slot + 1
		robot.set_meta("ai_style", styles[i % styles.size()])
		if GameManager.online_race_active:
			robot.set_meta("online_ai_slot", i)
			_online_ai_robots.append(robot)
			if CloudflareOnlineSession.player_id != CloudflareOnlineSession.host_id:
				robot.set_meta("online_ai_remote", true)
				robot.can_drive = false
				robot.collision_layer = 0
				robot.collision_mask = 0
				robot.set_physics_process(false)
		slot += 1


func _pick_online_ai_configs(count: int) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for i: int in range(count):
		var robot_index: int = (i + 1) % RobotDatabase.count()
		var skin_index: int = i % maxi(RobotDatabase.SKINS.size(), 1)
		var neon_index: int = i % maxi(RobotDatabase.NEON_COLORS.size(), 1)
		result.append(RobotDatabase.build_config(robot_index, RobotDatabase.empty_upgrades(), skin_index, neon_index))
	return result


func _create_online_remote_robots() -> void:
	if _vehicles == null:
		return
	var players: Array = CloudflareOnlineSession.get_players()
	for roster_index: int in range(players.size()):
		var player_data: Variant = players[roster_index]
		if not player_data is Dictionary:
			continue
		var remote_id: String = str(player_data.get("player_id", ""))
		if remote_id.is_empty() or remote_id == CloudflareOnlineSession.player_id:
			continue
		var player_name: String = str(player_data.get("player_name", "Robot"))
		var remote_slot: int = roster_index
		var robot_index: int = remote_slot % maxi(RobotDatabase.count(), 1)
		var config: Dictionary = RobotDatabase.build_config(
			robot_index,
			RobotDatabase.empty_upgrades(),
			remote_slot % maxi(RobotDatabase.SKINS.size(), 1),
			remote_slot % maxi(RobotDatabase.NEON_COLORS.size(), 1)
		)
		var remote: Robot = ROBOT_SCENE.instantiate() as Robot
		remote.name = "Online_" + remote_id.substr(0, 8)
		remote.config = config
		_vehicles.add_child(remote)
		remote.global_transform = track.get_start_transform(remote_slot)
		remote.setup(config, false, 0.0)
		remote.display_name = player_name
		remote.racer_index = remote_slot + 1
		remote.set_meta("online_remote", true)
		remote.set_meta("online_player_id", remote_id)
		remote.can_drive = false
		remote.collision_layer = 0
		remote.collision_mask = 0
		remote.process_mode = Node.PROCESS_MODE_DISABLED

		var name_tag := Label3D.new()
		name_tag.name = "OnlineName"
		name_tag.text = player_name
		name_tag.position = Vector3(0.0, 1.55, 0.0)
		name_tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		name_tag.font_size = 40
		name_tag.outline_size = 8
		remote.add_child(name_tag)

		robots.append(remote)
		_online_remote_robots[remote_id] = remote
		_online_remote_buffers[remote_id] = RemoteRaceStateBuffer.new()


func _on_online_race_state_received(remote_id: String, state: Dictionary) -> void:
	if not _online_remote_buffers.has(remote_id):
		return
	var buffer: RemoteRaceStateBuffer = _online_remote_buffers[remote_id]
	buffer.push_snapshot(state)


func _on_online_ai_states_received(states: Array) -> void:
	if CloudflareOnlineSession.player_id == CloudflareOnlineSession.host_id:
		return
	for item: Variant in states:
		if not item is Dictionary:
			continue
		var slot: int = int(item.get("slot", -1))
		if slot < 0 or slot >= _online_ai_robots.size():
			continue
		var ai_robot: Robot = _online_ai_robots[slot]
		ai_robot.global_position = Vector3(float(item.get("x", 0.0)), float(item.get("y", 0.0)), float(item.get("z", 0.0)))
		var rotation: Vector3 = ai_robot.global_rotation
		rotation.y = float(item.get("yaw", 0.0))
		ai_robot.global_rotation = rotation
		ai_robot.velocity = Vector3(float(item.get("vx", 0.0)), 0.0, float(item.get("vz", 0.0)))
		ai_robot.forward_speed = ai_robot.velocity.dot(ai_robot.get_forward())


func _process(delta: float) -> void:
	if not _online_active:
		return
	if player != null and race_manager != null and race_manager.is_running():
		_online_send_accum += delta
		if _online_send_accum >= 0.1:
			_online_send_accum = fmod(_online_send_accum, 0.1)
			CloudflareOnlineSession.send_race_state(player.global_position, player.global_rotation.y, player.velocity)
			if CloudflareOnlineSession.player_id == CloudflareOnlineSession.host_id and not _online_ai_robots.is_empty():
				var ai_states: Array = []
				for ai_robot: Robot in _online_ai_robots:
					ai_states.append({"x": ai_robot.global_position.x, "y": ai_robot.global_position.y, "z": ai_robot.global_position.z, "yaw": ai_robot.global_rotation.y, "vx": ai_robot.velocity.x, "vz": ai_robot.velocity.z})
				CloudflareOnlineSession.send_ai_states(ai_states)

	var server_now: int = CloudflareOnlineSession.get_server_time_ms()
	for remote_id: Variant in _online_remote_robots.keys():
		var remote: Robot = _online_remote_robots[remote_id]
		var buffer: RemoteRaceStateBuffer = _online_remote_buffers[remote_id]
		var sample: Dictionary = buffer.sample(server_now)
		if sample.is_empty() or not is_instance_valid(remote):
			continue
		remote.global_position = sample["position"]
		var remote_rotation: Vector3 = remote.global_rotation
		remote_rotation.y = float(sample["yaw"])
		remote.global_rotation = remote_rotation
		remote.velocity = sample["velocity"]
		remote.forward_speed = remote.velocity.dot(remote.get_forward())


func _exit_tree() -> void:
	if CloudflareOnlineSession.race_state_received.is_connected(_on_online_race_state_received):
		CloudflareOnlineSession.race_state_received.disconnect(_on_online_race_state_received)
	if CloudflareOnlineSession.ai_states_received.is_connected(_on_online_ai_states_received):
		CloudflareOnlineSession.ai_states_received.disconnect(_on_online_ai_states_received)


func _spawn_robot(parent: Node3D, config: Dictionary, is_player: bool, initial_damage: float, slot: int) -> Robot:
	var robot: Robot = ROBOT_SCENE.instantiate() as Robot
	robot.name = "Player" if is_player else "AI_%d" % robots.size()
	if GameManager.career_active:
		var grip_multiplier: float = 0.72 if GameManager.career_time_of_day == "night" else (0.90 if GameManager.career_time_of_day == "evening" else 1.0)
		config["career_grip_multiplier"] = grip_multiplier
	robot.config = config
	parent.add_child(robot)
	robot.global_transform = track.get_start_transform(slot)
	robot.setup(config, is_player, initial_damage)
	robot.reset_physics_interpolation()
	robots.append(robot)
	return robot


## Losowe skórki przeciwników - bez powtórzeń wyglądu, o ile pozwala liczba skórek.
func _pick_ai_configs(count: int, player_config: Dictionary) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	var used: Dictionary = {}
	used["%d_%d" % [int(player_config["robot_index"]), int(player_config["skin_index"])]] = true

	var robot_order: Array[int] = []
	for i: int in range(RobotDatabase.count()):
		robot_order.append(i)
	robot_order.shuffle()

	var upgrades: Dictionary = AIDifficulty.get_upgrades_for(GameManager.difficulty)
	if GameManager.is_graphics_test():
		upgrades = RobotDatabase.empty_upgrades()

	for i: int in range(count):
		var robot_index: int = robot_order[i % robot_order.size()]
		var skins: Array[int] = []
		for s: int in range(RobotDatabase.SKINS.size()):
			skins.append(s)
		skins.shuffle()

		var skin_index: int = skins[0]
		for candidate: int in skins:
			if not used.has("%d_%d" % [robot_index, candidate]):
				skin_index = candidate
				break
		used["%d_%d" % [robot_index, skin_index]] = true

		var neon_index: int = randi() % RobotDatabase.NEON_COLORS.size()
		result.append(RobotDatabase.build_config(robot_index, upgrades, skin_index, neon_index))

	return result


func _create_dirt() -> void:
	dirt_manager = DirtManager.new()
	dirt_manager.name = "DirtManager"
	add_child(dirt_manager)
	dirt_manager.setup(track)


func _create_race_manager() -> void:
	race_manager = RaceManager.new()
	race_manager.name = "RaceManager"
	add_child(race_manager)

	var laps: int = GameManager.total_laps
	var extra_local_players: Array[Robot] = []
	if local_player_two != null:
		extra_local_players.append(local_player_two)
	race_manager.setup(track, robots, player, mode, laps, track.countdown_seconds, extra_local_players)

	# Kierowcy AI dostają dostęp do trasy, brudu i listy rywali.
	for robot: Robot in robots:
		if robot.is_player or bool(robot.get_meta("online_remote", false)) or bool(robot.get_meta("online_ai_remote", false)):
			continue
		var ai := AIDriver.new()
		ai.name = "AIDriver"
		robot.add_child(ai)
		var style: int = int(robot.get_meta("ai_style", AIDifficulty.Style.BALANCED))
		ai.setup(track, AIDifficulty.get_profile(GameManager.difficulty, style), dirt_manager, robots)
		robot.driver = ai

	race_manager.racer_finished.connect(_on_racer_finished)
	race_manager.race_finished.connect(_on_race_finished)
	race_manager.countdown_changed.connect(_on_countdown_changed)
	race_manager.lap_completed.connect(_on_lap_completed)
	race_manager.checkpoint_passed.connect(_on_checkpoint_passed)


func _create_race_statistics() -> void:
	race_statistics = RaceStatistics.new()
	race_statistics.name = "RaceStatistics"
	add_child(race_statistics)
	if race_manager != null:
		race_manager.lap_completed.connect(_on_statistics_lap_completed)


func _on_statistics_lap_completed(racer: Dictionary, _lap: int, _lap_time: float) -> void:
	if bool(racer.get("is_player", false)) and player != null:
		var consumed: float = player.energy.complete_lap()
		if race_statistics != null:
			race_statistics.record_lap_energy(
				consumed / maxf(player.energy.capacity, 0.001) * 100.0,
				player.energy.last_lap_boost_consumed / maxf(player.energy.capacity, 0.001) * 100.0
			)


func _create_pit_stop() -> void:
	pit_stops.clear()
	if GameManager.is_graphics_test():
		for robot: Robot in robots:
			robot.energy.enabled = false
		return

	# Główne stanowiska pit przy starcie zachowują dotychczasową obsługę awarii.
	pit_stop = PitStopSystem.new()
	pit_stop.name = "PitStop_Player"
	add_child(pit_stop)
	pit_stop.setup(track, player, race_manager, 0.0, false, true, race_statistics, 0.0)
	pit_stops.append(pit_stop)
	if local_player_two != null:
		var second_pit := PitStopSystem.new()
		second_pit.name = "PitStop_Player2"
		add_child(second_pit)
		second_pit.setup(track, local_player_two, race_manager, 4.6, false, true, race_statistics, 0.0)
		pit_stops.append(second_pit)

	var ai_index: int = 0
	var ai_count: int = 0
	for candidate: Robot in robots:
		if not candidate.is_player and not bool(candidate.get_meta("online_remote", false)):
			ai_count += 1
	for robot: Robot in robots:
		if robot.is_player or bool(robot.get_meta("online_remote", false)) or bool(robot.get_meta("online_ai_remote", false)):
			continue
		var ai_pit := PitStopSystem.new()
		ai_pit.name = "PitStop_AI_%d" % (ai_index + 1)
		add_child(ai_pit)
		# Wszystkie stacje AI są skupione przy starcie. Nie rozmieszczamy
		# dodatkowych stacji losowo ani wzdłuż okrążenia.
		var service_offset: float = 1.15 + float(ai_index) * 1.15
		ai_pit.setup(track, robot, race_manager, service_offset, true, false, null, 0.0)
		pit_stops.append(ai_pit)
		ai_index += 1


func _create_camera() -> void:
	camera_rig = CameraFollow.new()
	camera_rig.name = "CameraRig"
	add_child(camera_rig)
	camera_rig.set_target(player)


func _create_ghost() -> void:
	if mode != "time_trial":
		return
	ghost = Ghost.new()
	ghost.name = "Ghost"
	add_child(ghost)
	ghost.setup(track.track_id, race_manager, player, GameManager.ghost_enabled)


func _create_hud() -> void:
	hud = HUD_SCENE.instantiate()
	add_child(hud)
	hud.call("setup", {
		"race_manager": race_manager,
		"player": player,
		"track": track,
		"robots": robots,
		"dirt_manager": dirt_manager,
		"mode": mode,
		"scene": self,
		"pit_stop": pit_stop,
		"race_statistics": race_statistics
	})


# =========================================================
# ZDARZENIA WYŚCIGU
# =========================================================

func _on_countdown_changed(seconds_left: int) -> void:
	if seconds_left > 0:
		AudioManager.play("beep", -2.0)
	else:
		AudioManager.play("beep_go", 0.0)


func _on_checkpoint_passed(racer: Dictionary, _checkpoint_index: int, _split_time: float, _elapsed_time: float) -> void:
	if bool(racer.get("is_player", false)):
		AudioManager.play("checkpoint", -2.0)


func _on_lap_completed(racer: Dictionary, _lap: int, _lap_time: float) -> void:
	if bool(racer["is_player"]) and not bool(racer["finished"]):
		AudioManager.play("lap", -3.0)


func _on_racer_finished(racer: Dictionary) -> void:
	var finished_robot: Robot = racer.get("robot") as Robot
	if finished_robot == local_player_two:
		finished_robot.energy.enabled = false
		finished_robot.pit_controlled = false
		_enable_robot_autopilot(finished_robot)
		AudioManager.play("finish", 0.0)
		return
	if not bool(racer["is_player"]):
		return
	_player_finished = true
	player.energy.enabled = false
	player.pit_controlled = false
	AudioManager.play("finish", 0.0)
	# Po mecie robot gracza jedzie dalej na autopilocie (bez wpływu na wynik).
	enable_player_autopilot(true)


func _enable_robot_autopilot(robot: Robot) -> void:
	if robot.driver is AIDriver:
		return
	var ai := AIDriver.new()
	ai.name = "Autopilot"
	robot.add_child(ai)
	ai.setup(track, AIDifficulty.get_profile(AIDifficulty.Level.HARD, AIDifficulty.Style.CAREFUL), dirt_manager, robots)
	robot.driver = ai


## Autopilot robota gracza (po mecie oraz opcjonalnie w teście grafiki).
func enable_player_autopilot(enabled: bool) -> void:
	if enabled:
		if player.driver is AIDriver:
			return
		var ai := AIDriver.new()
		ai.name = "Autopilot"
		player.add_child(ai)
		ai.setup(track, AIDifficulty.get_profile(AIDifficulty.Level.HARD, AIDifficulty.Style.CAREFUL), dirt_manager, robots)
		player.driver = ai
	else:
		var driver: Node = player.get_node_or_null("PlayerDriver")
		if driver != null:
			var old: Node = player.driver
			player.driver = driver
			if old != null and old != driver:
				old.queue_free()


func _on_race_finished(results: Array) -> void:
	if _finalized:
		return
	_finalized = true

	var player_result: Dictionary = {}
	for result: Dictionary in results:
		if bool(result["is_player"]):
			player_result = result
			break

	var rewards: Dictionary = {}
	var records: Dictionary = {}

	if not _online_active and not GameManager.is_graphics_test() and not player_result.is_empty():
		var config: Dictionary = player.config
		var robot_index: int = int(config["robot_index"])
		PlayerProgress.set_damage(robot_index, player.damage.damage)

		var finished: bool = bool(player_result["finished"])
		var total_time: float = float(player_result["time"]) if finished else -1.0
		records = PlayerProgress.submit_times(track.track_id, mode, GameManager.total_laps, total_time, float(player_result["best_lap"]))

		rewards = PlayerProgress.compute_rewards({
			"mode": mode,
			"position": int(player_result["position"]),
			"finished": finished,
			"difficulty": GameManager.difficulty,
			"laps": GameManager.total_laps,
			"laps_done": int(player_result["laps"]),
			"dirt_collected": float(player_result["dirt"]),
			"damage_taken": float(player_result["damage_taken"]),
			"new_total": bool(records.get("new_total", false)),
			"new_lap": bool(records.get("new_lap", false))
		})
		if GameManager.career_active:
			GameManager.career_result_event_index = PlayerProgress.get_career_event_index()
			var event: Dictionary = PlayerProgress.get_career_event()
			var multiplier: float = CareerCampaign.reward_multiplier(GameManager.career_time_of_day)
			var time_bonus: int = roundi(float(rewards["total"]) * (multiplier - 1.0))
			if time_bonus > 0:
				(rewards["items"] as Array).append({"label": "Mnożnik pory dnia ×%.1f" % multiplier, "amount": time_bonus})
				rewards["total"] = int(rewards["total"]) + time_bonus
			var career_result: Dictionary = PlayerProgress.record_career_result(GameManager.career_event_id, int(player_result["position"]), finished)
			GameManager.career_result_advanced = bool(career_result.get("advanced", false))
			if int(career_result.get("bonus", 0)) > 0:
				var advancement_bonus: int = int(career_result["bonus"])
				(rewards["items"] as Array).append({"label": "Awans kampanii — %s" % str(event.get("title", "wydarzenie")), "amount": advancement_bonus})
				rewards["total"] = int(rewards["total"]) + advancement_bonus
				rewards["career_advanced"] = true
			else:
				rewards["career_advanced"] = false
		PlayerProgress.add_currency(int(rewards["total"]))
		PlayerProgress.apply_race_stats(mode, int(player_result["position"]), finished, float(player_result["dirt"]))
		GameManager.last_rewards = rewards
		SaveManager.save_now()

	if hud != null and race_statistics != null:
		hud.set_meta("race_statistics_summary", race_statistics.get_summary())
	hud.call("show_results", results, rewards, records)


# =========================================================
# STEROWANIE SCENĄ (wywoływane z HUD)
# =========================================================

func restart_race() -> void:
	if _online_active:
		CloudflareOnlineSession.disconnect_room()
		GameManager.clear_online_race()
		GameManager.open_hub("multiplayer")
		return
	_persist_damage_on_exit()
	if not GameManager.is_graphics_test():
		GameManager.reroll_random_route_for_retry()
	if GameManager.is_graphics_test():
		GameManager.configure_graphics_test()
	GameManager.launch_race()


func continue_career() -> void:
	GameManager.career_active = false
	GameManager.career_event_id = ""
	GameManager.hub_page = "career"
	GameManager.change_scene(GameManager.SCENE_FEATURE_HUB)


func quit_to_menu() -> void:
	if _online_active:
		CloudflareOnlineSession.disconnect_room()
		GameManager.clear_online_race()
		GameManager.go_to_main_menu()
		return
	_persist_damage_on_exit()
	if GameManager.is_graphics_test():
		var destination: String = GameManager.return_scene
		GameManager.return_scene = GameManager.SCENE_MAIN_MENU
		GameManager.change_scene(destination)
		return
	GameManager.career_active = false
	GameManager.career_event_id = ""
	GameManager.go_to_main_menu()


func quit_to_garage() -> void:
	if _online_active:
		CloudflareOnlineSession.disconnect_room()
		GameManager.clear_online_race()
		GameManager.change_scene(GameManager.SCENE_GARAGE)
		return
	_persist_damage_on_exit()
	GameManager.change_scene(GameManager.SCENE_GARAGE)


func end_test() -> void:
	race_manager.force_end()


## Uszkodzenia zostają zapamiętane także po przerwaniu wyścigu (bez nagród).
func _persist_damage_on_exit() -> void:
	if _finalized or GameManager.is_graphics_test() or player == null:
		return
	PlayerProgress.set_damage(int(player.config["robot_index"]), player.damage.damage)
	SaveManager.save_now()


func cycle_camera_target() -> void:
	if robots.is_empty():
		return
	var index: int = robots.find(camera_rig.target)
	camera_rig.set_target(robots[(index + 1) % robots.size()])


func cycle_camera_mode() -> void:
	if camera_rig != null:
		camera_rig.set_camera_mode(camera_rig.camera_mode + 1)


func get_camera_mode_name() -> String:
	return camera_rig.get_camera_mode_name() if camera_rig != null else "STANDARD"


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		if hud != null and race_manager != null and race_manager.is_running():
			hud.call("open_pause")
	elif what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if hud != null:
			hud.call("handle_back")
