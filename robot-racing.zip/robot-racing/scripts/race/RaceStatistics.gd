class_name RaceStatistics
extends Node
## Zbiera statystyki energii i pit stopów bez przejmowania logiki wyścigu.

signal updated

var lap_energy: Array[float] = []
var total_energy_used: float = 0.0
var boost_energy_used: float = 0.0
var pit_visits: int = 0
var repairs_done: float = 0.0
var pit_time: float = 0.0
var _pit_active: bool = false
var _pit_elapsed: float = 0.0


func record_lap_energy(consumed_percent: float, boost_percent: float = 0.0) -> void:
	lap_energy.append(maxf(consumed_percent, 0.0))
	total_energy_used += maxf(consumed_percent, 0.0)
	boost_energy_used += maxf(boost_percent, 0.0)
	updated.emit()


func begin_pit_stop() -> void:
	if _pit_active:
		return
	_pit_active = true
	_pit_elapsed = 0.0
	pit_visits += 1
	updated.emit()


func add_service_time(delta: float) -> void:
	if _pit_active:
		_pit_elapsed += maxf(delta, 0.0)


func end_pit_stop() -> void:
	if not _pit_active:
		return
	pit_time += _pit_elapsed
	_pit_elapsed = 0.0
	_pit_active = false
	updated.emit()


func record_repair(amount: float) -> void:
	repairs_done += maxf(amount, 0.0)
	updated.emit()


func get_summary() -> Dictionary:
	return {
		"lap_energy": lap_energy.duplicate(),
		"total_energy_used": total_energy_used,
		"boost_energy_used": boost_energy_used,
		"pit_visits": pit_visits,
		"repairs_done": repairs_done,
		"pit_time": pit_time + (_pit_elapsed if _pit_active else 0.0)
	}
