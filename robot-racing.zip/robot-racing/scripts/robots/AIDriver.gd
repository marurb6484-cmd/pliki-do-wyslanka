class_name AIDriver
extends Node
## Kierowca AI.
##
## Steruje robotem wyłącznie przez te same wejścia co gracz (skręt, gaz,
## hamulec, boost). Poziom trudności i styl jazdy wpływają na:
##  - tor jazdy (ścinanie zakrętów),
##  - hamowanie przed zakrętami (margines przyczepności),
##  - czas reakcji i drgania kierownicy, błędy,
##  - mądre użycie boosta (nie przed ostrym zakrętem),
##  - chęć zbierania brudu i omijanie przeszkód/rywali.
##
## Ciężkie obliczenia (planowanie prędkości, przeszkody, rywale, brud, boost)
## wykonywane są 10 razy na sekundę z przesunięciem fazy dla każdego robota,
## a nie w każdej klatce - ważne na Androidzie.

const PLAN_INTERVAL: float = 0.1
const ROBOT_RADIUS: float = 0.17

var track: TrackBase
var dirt_manager: Node
var racers: Array = []
var profile: Dictionary = {}
var rng := RandomNumberGenerator.new()

var _hint: int = -1
var _route_distance: float = 0.0
var _route_lateral: float = 0.0
var _plan_timer: float = 0.0
var _projection_refresh_left: float = 0.0
var _boost_timer: float = 0.0
var _target_speed: float = 8.0

var _lane_offset: float = 0.0
var _racing_offset: float = 0.0
var _avoid_offset: float = 0.0
var _pickup_offset: float = 0.0
var _pickup_decisions: Dictionary = {}
var _front_block_speed: float = INF
var _front_block_bias: float = 0.0

var _steer: float = 0.0
var _noise_time: float = 0.0
var _mistake_left: float = 0.0
var _mistake_kind: int = -1
var _mistake_steer: float = 0.0

var _stuck_time: float = 0.0
var _recover_left: float = 0.0
var _recover_steer: float = 0.0
var _recover_count: int = 0
var _recover_window: float = 0.0
var _hold_left: float = 0.0

var _ray_query: PhysicsRayQueryParameters3D


func setup(race_track: TrackBase, ai_profile: Dictionary, dirt: Node, all_racers: Array) -> void:
	track = race_track
	profile = ai_profile
	dirt_manager = dirt
	racers = all_racers
	rng.randomize()
	_lane_offset = rng.randf_range(-0.12, 0.12) * (1.0 - float(profile.get("line_quality", 0.5)) * 0.6)
	_plan_timer = rng.randf() * PLAN_INTERVAL
	_boost_timer = rng.randf() * 0.3
	_noise_time = rng.randf() * 10.0

	_ray_query = PhysicsRayQueryParameters3D.new()
	_ray_query.collision_mask = Robot.LAYER_WORLD
	_ray_query.hit_from_inside = false


func _p(key: String, default_value: float) -> float:
	return float(profile.get(key, default_value))


func update_input(robot: Robot, delta: float) -> void:
	if track == null or track.smooth_route.is_empty():
		robot.input_throttle = 0.0
		robot.input_brake = 1.0
		return

	# Co pewien czas wymuszamy pełne ponowne znalezienie najbliższego odcinka.
	# Chroni to AI po odbiciu od ściany, teleportacji ratunkowej i na ciasnych
	# sekcjach torów generowanych losowo.
	_projection_refresh_left -= delta
	var projection_hint: int = _hint
	if _projection_refresh_left <= 0.0:
		projection_hint = -1
		_projection_refresh_left = 0.45
	var projection: Dictionary = track.project_point(robot.global_position, projection_hint)
	if float(projection.get("offset", INF)) > track.track_width * 0.75:
		projection = track.project_point(robot.global_position, -1)
	_hint = int(projection["index"])
	_route_distance = float(projection["distance"])
	_route_lateral = float(projection["lateral"])

	var speed: float = robot.forward_speed

	# --- Wstrzymanie po akcji ratunkowej ---
	if _hold_left > 0.0:
		_hold_left -= delta
		_set_inputs(robot, 0.0, 0.0, 1.0)
		return

	# --- Odzyskiwanie po utknięciu: cofanie z kontrą ---
	if _recover_left > 0.0:
		_recover_left -= delta
		_set_inputs(robot, _recover_steer, 0.0, 1.0)
		return

	_plan_timer -= delta
	if _plan_timer <= 0.0:
		_plan_timer = PLAN_INTERVAL
		_plan(robot)

	_boost_timer -= delta
	if _boost_timer <= 0.0:
		_boost_timer = 0.25
		_consider_boost(robot)

	# --- Punkt celu na trasie ---
	var look_ahead: float = clampf(1.0 + absf(speed) * 0.45, 1.5, 7.0)
	var curvature_now: float = absf(track.get_curvature_at(_route_distance + look_ahead * 0.5))
	look_ahead *= lerpf(1.0, 0.72, clampf(curvature_now * 18.0, 0.0, 1.0))
	var target_distance: float = _route_distance + look_ahead
	var max_lateral: float = track.track_width * 0.5 - ROBOT_RADIUS - 0.08
	var target_lateral: float = clampf(_lane_offset + _racing_offset + _avoid_offset + _pickup_offset + _front_block_bias, -max_lateral, max_lateral)
	# Hologram przeciwnika jest wabikiem: AI może lekko odchylić linię w jego stronę,
	# ale nigdy poza bezpieczny korytarz jezdni.
	var decoy_bias: float = _get_hologram_decoy_bias(robot, target_lateral, max_lateral)
	target_lateral = clampf(target_lateral + decoy_bias, -max_lateral, max_lateral)
	var target: Vector3 = track.get_point_at(target_distance) + track.get_side_at(target_distance) * target_lateral

	var to_target: Vector3 = target - robot.global_position
	to_target.y = 0.0
	var forward: Vector3 = robot.get_forward()
	var angle: float = 0.0
	if to_target.length_squared() > 0.01:
		angle = forward.signed_angle_to(to_target.normalized(), Vector3.UP)

	# Kąt dodatni = cel po lewej; skręt dodatni = w prawo.
	var desired: float = clampf(-angle / 0.42, -1.0, 1.0)

	_noise_time += delta
	desired += sin(_noise_time * 2.3) * _p("steer_noise", 0.05) * 0.6
	if _mistake_left > 0.0:
		_mistake_left -= delta
		if _mistake_kind == 0:
			desired += _mistake_steer

	var reaction: float = maxf(_p("reaction", 0.15), 0.03)
	_steer = lerpf(_steer, clampf(desired, -1.0, 1.0), 1.0 - exp(-delta / reaction))

	# --- Prędkość ---
	var target_speed: float = minf(_target_speed, _front_block_speed)
	if absf(angle) > 0.9:
		target_speed = minf(target_speed, robot.max_speed * 0.62)   # duży błąd kierunku - zwolnij i skręć
	if _mistake_left > 0.0 and _mistake_kind == 2:
		target_speed = minf(target_speed, absf(speed) * 0.85)

	var throttle: float = 0.0
	var brake: float = 0.0
	if speed > target_speed + robot.max_speed * 0.18:
		brake = clampf((speed - target_speed) / maxf(robot.max_speed * 0.75, 0.1), 0.3, 1.0)
	elif speed < target_speed - robot.max_speed * 0.08:
		throttle = 1.0
	else:
		throttle = 0.45

	# --- Wykrywanie utknięcia ---
	if throttle > 0.5 and absf(speed) < robot.max_speed * 0.18:
		_stuck_time += delta
	else:
		_stuck_time = maxf(_stuck_time - delta * 2.0, 0.0)

	_recover_window = maxf(_recover_window - delta, 0.0)
	if _recover_window <= 0.0:
		_recover_count = 0

	if _stuck_time > 0.9:
		_stuck_time = 0.0
		_recover_count += 1
		_recover_window = 10.0
		if _recover_count >= 4:
			_rescue(robot)
			return
		_recover_left = 0.8 + rng.randf() * 0.4
		var steer_sign: float = signf(angle) if absf(angle) > 0.05 else (1.0 if rng.randf() > 0.5 else -1.0)
		_recover_steer = steer_sign * 0.9
		_set_inputs(robot, _recover_steer, 0.0, 1.0)
		return

	_set_inputs(robot, _steer, throttle, brake)


func _set_inputs(robot: Robot, steer: float, throttle: float, brake: float) -> void:
	robot.input_steer = clampf(steer, -1.0, 1.0)
	robot.input_throttle = throttle
	robot.input_brake = brake
	robot.input_drift = false


# =========================================================
# PLANOWANIE (10 Hz)
# =========================================================

func _plan(robot: Robot) -> void:
	var lateral_grip: float = robot.get_lateral_grip() * _p("corner_margin", 0.85)
	var brake_decel: float = robot.brake_force * 0.75
	var top: float = robot.max_speed * robot.damage.speed_multiplier() * _p("speed_factor", 0.95)
	if robot.boost.is_active():
		top = robot.get_top_speed()

	# Planowanie prędkości: najostrzejszy zakręt w zasięgu hamowania.
	var limit: float = top
	var s: float = 2.0
	while s <= 36.0:
		var curvature: float = absf(track.get_curvature_at(_route_distance + s))
		if curvature > 0.002:
			var corner_speed: float = sqrt(lateral_grip / curvature)
			var allowed: float = sqrt(corner_speed * corner_speed + 2.0 * brake_decel * maxf(s - 1.5, 0.0))
			limit = minf(limit, allowed)
		s += 2.5

	if _mistake_left > 0.0 and _mistake_kind == 1:
		limit *= 1.18   # błąd: spóźnione hamowanie
	_target_speed = maxf(limit, robot.max_speed * 0.58)

	# Tor jazdy: ścinanie do wewnętrznej strony zakrętu.
	var curvature_ahead: float = 0.0
	for offset: float in [1.5, 3.0, 4.5]:
		curvature_ahead += track.get_curvature_at(_route_distance + offset)
	curvature_ahead /= 3.0
	var apex: float = signf(curvature_ahead) * clampf(absf(curvature_ahead) * 35.0, 0.0, 1.0) * 0.24 * _p("line_quality", 0.5)
	_racing_offset = lerpf(_racing_offset, apex, 0.3)

	var planned: float = _lane_offset + _racing_offset
	_avoid_offset = lerpf(_avoid_offset, _compute_obstacle_offset(planned) + _compute_racer_offset(robot, planned), 0.5)
	_pickup_offset = lerpf(_pickup_offset, _compute_pickup_offset(robot, planned + _avoid_offset), 0.4)
	_check_front_ray(robot)

	# Losowe błędy (łatwiejsze poziomy).
	if _mistake_left <= 0.0 and rng.randf() < _p("mistake_rate", 0.0) * PLAN_INTERVAL:
		_mistake_kind = rng.randi_range(0, 2)
		_mistake_left = rng.randf_range(0.5, 1.2)
		_mistake_steer = rng.randf_range(-0.35, 0.35)


## Omijanie przeszkód znanych z trasy.
func _compute_obstacle_offset(planned: float) -> float:
	var skill: float = _p("avoid_skill", 0.8)
	var detect_range: float = 3.0 + 4.0 * skill
	var half_width: float = track.track_width * 0.5 - ROBOT_RADIUS - 0.08
	var result: float = 0.0

	for obstacle: Dictionary in track.obstacles:
		var ahead: float = (track.wrap_distance(float(obstacle["distance"]) - _route_distance) if track.route_closed else float(obstacle["distance"]) - _route_distance)
		if ahead > detect_range or (not track.route_closed and ahead < 0.0) or ahead < -0.5:
			continue
		var obstacle_lateral: float = float(obstacle["lateral"])
		var clearance: float = float(obstacle["radius"]) + ROBOT_RADIUS + lerpf(0.06, 0.16, skill)
		var difference: float = planned - obstacle_lateral
		if absf(difference) >= clearance:
			continue

		var side: float = signf(difference) if absf(difference) > 0.1 else -signf(obstacle_lateral)
		if side == 0.0:
			side = 1.0
		var pass_lateral: float = obstacle_lateral + clearance * side
		if absf(pass_lateral) > half_width:
			pass_lateral = obstacle_lateral - clearance * side
		var needed: float = (pass_lateral - planned) * lerpf(0.65, 1.0, skill)
		if absf(needed) > absf(result):
			result = needed

	return result


## Wyprzedzanie i unikanie najeżdżania na rywali.
func _compute_racer_offset(robot: Robot, planned: float) -> float:
	_front_block_speed = INF
	var forward: Vector3 = robot.get_forward()
	var right: Vector3 = robot.global_transform.basis.x
	var aggression: float = _p("aggression", 0.5)
	var margin: float = lerpf(0.42, 0.34, aggression)
	var half_width: float = track.track_width * 0.5 - ROBOT_RADIUS - 0.08
	var result: float = 0.0

	for other_variant: Variant in racers:
		var other: Robot = other_variant as Robot
		if other == null or other == robot or not is_instance_valid(other):
			continue
		var relative: Vector3 = other.global_position - robot.global_position
		var ahead: float = relative.dot(forward)
		if ahead < 0.25 or ahead > 3.5:
			continue
		var side_distance: float = relative.dot(right)
		if absf(side_distance) > margin:
			continue
		if other.forward_speed > robot.forward_speed - 0.3 and ahead > 1.2:
			continue

		var other_lateral: float = _route_lateral + side_distance
		var pass_side: float = -signf(side_distance) if absf(side_distance) > 0.06 else (1.0 if other_lateral < 0.0 else -1.0)
		var pass_lateral: float = other_lateral + margin * pass_side
		if absf(pass_lateral) > half_width:
			pass_lateral = other_lateral - margin * pass_side
		if absf(pass_lateral) > half_width:
			# Brak miejsca - jedziemy za rywalem.
			_front_block_speed = minf(_front_block_speed, maxf(other.forward_speed - 0.08, robot.max_speed * 0.55))
			continue
		var needed: float = (pass_lateral - planned) * _p("avoid_skill", 0.8)
		if absf(needed) > absf(result):
			result = needed
		if ahead < 0.9:
			_front_block_speed = minf(_front_block_speed, maxf(other.forward_speed, robot.max_speed * 0.55))

	return result


## Zbieranie brudu: AI zjeżdża po brud, jeśli nie jest to zbyt dużym objazdem.
func _compute_pickup_offset(robot: Robot, planned: float) -> float:
	if dirt_manager == null or robot.tank.is_full():
		return 0.0

	var pickup: Dictionary = dirt_manager.call("find_pickup_ahead", _route_distance, 1.5, 7.0)
	if pickup.is_empty():
		return 0.0

	var id: int = int(pickup["id"])
	if not _pickup_decisions.has(id):
		if _pickup_decisions.size() > 64:
			_pickup_decisions.clear()
		_pickup_decisions[id] = rng.randf() < _p("dirt_skill", 0.6)
	if not bool(_pickup_decisions[id]):
		return 0.0

	var difference: float = float(pickup["lateral"]) - planned
	var max_detour: float = lerpf(0.25, 0.65, _p("dirt_skill", 0.6))
	if absf(difference) > max_detour:
		return 0.0

	# Nie zjeżdżamy po brud, jeśli na tej linii stoi przeszkoda.
	for obstacle: Dictionary in track.obstacles:
		var ahead: float = (track.wrap_distance(float(obstacle["distance"]) - _route_distance) if track.route_closed else float(obstacle["distance"]) - _route_distance)
		if (track.route_closed or ahead >= 0.0) and ahead < float(pickup["ahead"]) + 0.8 and absf(float(obstacle["lateral"]) - float(pickup["lateral"])) < float(obstacle["radius"]) + 0.18:
			return 0.0

	return difference


## Zabezpieczenie: promień przed robotem (ściany, meble poza planem).
func _check_front_ray(robot: Robot) -> void:
	_front_block_bias = 0.0
	var speed: float = absf(robot.forward_speed)
	var forward: Vector3 = robot.get_forward()
	var origin: Vector3 = robot.global_position + Vector3.UP * 0.18 + forward * 0.30
	var length: float = 0.6 + speed * 0.20

	_ray_query.from = origin
	_ray_query.to = origin + forward * length
	_ray_query.exclude = [robot.get_rid()]
	var hit: Dictionary = robot.get_world_3d().direct_space_state.intersect_ray(_ray_query)
	if hit.is_empty():
		return

	var normal: Vector3 = hit["normal"]
	normal.y = 0.0
	if normal.length_squared() < 0.01 or normal.normalized().dot(forward) > -0.35:
		return

	var distance: float = origin.distance_to(hit["position"])
	_front_block_speed = minf(_front_block_speed, maxf(distance * 1.4, robot.max_speed * 0.55))
	var right: Vector3 = robot.global_transform.basis.x
	_front_block_bias = signf(normal.dot(right)) * 0.24 * _p("avoid_skill", 0.8)


# =========================================================
# BOOST
# =========================================================

func _consider_boost(robot: Robot) -> void:
	if not robot.boost.is_ready():
		return
	var boost_id: String = robot.boost.get_selected_id()
	var nearby_racers: int = 0
	var nearest_racer: float = INF
	for other_variant: Variant in racers:
		var other: Robot = other_variant as Robot
		if other == null or other == robot or not is_instance_valid(other):
			continue
		var distance: float = robot.global_position.distance_to(other.global_position)
		if distance <= 12.0:
			nearby_racers += 1
			nearest_racer = minf(nearest_racer, distance)
	var should_activate: bool = false
	match boost_id:
		"turbo":
			if absf(robot.forward_speed) < robot.max_speed * 0.68 or absf(robot.input_steer) > 0.6:
				return
			var boost_top: float = robot.max_speed * robot.damage.speed_multiplier() * robot.boost.speed_multiplier
			var lateral_grip: float = robot.get_lateral_grip() * _p("corner_margin", 0.85)
			var brake_decel: float = robot.brake_force * 0.75
			var reachable: float = minf(boost_top, absf(robot.forward_speed) + robot.acceleration * robot.boost.accel_multiplier * robot.boost.duration * 0.35)
			var check_length: float = reachable * robot.boost.duration * 0.6 + 4.0
			var straight_enough: bool = true
			var sample: float = 2.0
			while sample <= check_length:
				var curvature: float = absf(track.get_curvature_at(_route_distance + sample))
				if curvature > 0.002:
					var corner_speed: float = sqrt(lateral_grip / curvature)
					var allowed: float = sqrt(corner_speed * corner_speed + 2.0 * brake_decel * maxf(sample - 2.0, 0.0))
					if allowed < reachable * 0.95:
						straight_enough = false
						break
				sample += 3.0
			should_activate = straight_enough and rng.randf() < lerpf(0.35, 1.0, _p("boost_skill", 0.6))
		"overdrive":
			# Overdrive stabilizuje robota w zakręcie lub przy ciasnej walce,
			# nie jest drugim Turbo i nigdy nie podnosi prędkości.
			should_activate = (absf(robot.input_steer) >= 0.35 and absf(robot.forward_speed) > robot.max_speed * 0.68) or (nearby_racers > 0 and nearest_racer < 5.5)
		"electric_pulse", "shockwave":
			should_activate = nearby_racers > 0 and nearest_racer <= (8.0 if boost_id == "electric_pulse" else 6.0)
		"shield":
			should_activate = nearby_racers > 0 and nearest_racer <= 7.0
		"slippery_trail":
			# Zostawiamy ślad, gdy ktoś jedzie za robotem.
			for other_variant: Variant in racers:
				var other: Robot = other_variant as Robot
				if other != null and other != robot and is_instance_valid(other):
					var behind: Vector3 = other.global_position - robot.global_position
					if behind.dot(robot.get_forward()) < -0.5 and behind.length() < 7.0:
						should_activate = true
						break
		"magnet":
			if dirt_manager != null and not robot.tank.is_full():
				var pickup_ahead: Dictionary = dirt_manager.call("find_pickup_ahead", _route_distance, 1.5, 7.0)
				should_activate = not pickup_ahead.is_empty()
		"emergency_repair":
			should_activate = robot.damage.damage >= 18.0
		"energy_regenerator":
			should_activate = robot.energy.get_ratio() <= 0.55
		"hologram":
			should_activate = nearby_racers > 0 and nearest_racer <= 10.0
	if should_activate:
		robot.request_boost()


func _get_hologram_decoy_bias(robot: Robot, current_lateral: float, max_lateral: float) -> float:
	var best_bias: float = 0.0
	var best_distance: float = 4.0
	var forward: Vector3 = robot.get_forward()
	for node: Node in get_tree().get_nodes_in_group("ai_decoys"):
		var decoy: Node3D = node as Node3D
		if decoy == null or not is_instance_valid(decoy):
			continue
		if decoy.get_meta("decoy_owner", null) == robot:
			continue
		var offset: Vector3 = decoy.global_position - robot.global_position
		var distance: float = offset.length()
		if distance >= best_distance or offset.dot(forward) < -0.25:
			continue
		var projection: Dictionary = track.project_point(decoy.global_position, _hint)
		var decoy_lateral: float = clampf(float(projection.get("lateral", current_lateral)), -max_lateral, max_lateral)
		var strength: float = clampf(float(decoy.get_meta("decoy_strength", 0.5)), 0.0, 1.0)
		best_bias = (decoy_lateral - current_lateral) * strength * 0.35
		best_distance = distance
	return clampf(best_bias, -0.28, 0.28)

# =========================================================
# AKCJA RATUNKOWA
# =========================================================

## Ostateczność po wielokrotnym nieudanym wyjeździe z blokady:
## robot wraca na środek trasy w tym samym miejscu (bez zysku pozycji)
## i stoi 1 s - kara czasowa, brak przewagi.
func _rescue(robot: Robot) -> void:
	_recover_count = 0
	robot.set_meta("ai_rescues", int(robot.get_meta("ai_rescues", 0)) + 1)
	var point: Vector3 = track.get_point_at(_route_distance - 1.0)
	var forward: Vector3 = track.get_tangent_at(_route_distance - 1.0)
	point.y = 0.15
	robot.reset_to(Transform3D(Basis.looking_at(forward, Vector3.UP), point))
	_hold_left = 1.0
