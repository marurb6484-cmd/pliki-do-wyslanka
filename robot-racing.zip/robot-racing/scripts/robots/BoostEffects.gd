class_name BoostEffects
extends Node3D
## Widowiskowe efekty wizualne boostów (poza płomieniem turbo, który jest częścią
## RobotVisuals). Każdy efekt sam się animuje i sam znika, więc BoostSystem tylko
## tworzy węzeł i dodaje go do robota.
##
##  - impuls elektryczny: rozchodzące się pierścienie, błyskawice, iskry i błysk,
##  - fala uderzeniowa: gruby pierścień, kopuła energii, chmura kurzu,
##  - magnes: pole zasięgu, cząstki wciągane do robota, orbitujące obręcze,
##  - naprawa: unoszące się zielone iskry, pulsujący krzyż i pierścień,
##  - regenerator: spiralne cząstki energii i obracające się obręcze,
##  - overdrive: złota aura z pulsem i orbitującymi iskrami,
##  - tarcza: kopuła z siatką heksagonalną i efektem Fresnela (make_aura_material).

var mode: String = ""
var tint: Color = Color.WHITE
var radius: float = 6.0
var duration: float = 1.0
var persistent: bool = false

var _age: float = 0.0
var _rings: Array[MeshInstance3D] = []
var _ring_materials: Array[StandardMaterial3D] = []
var _spinners: Array[Node3D] = []
var _particles: Array[CPUParticles3D] = []
var _dome: MeshInstance3D
var _dome_material: ShaderMaterial
var _aura: MeshInstance3D
var _aura_material: ShaderMaterial
var _arc_instance: MeshInstance3D
var _arc_mesh: ImmediateMesh
var _arc_timer: float = 0.0
var _light: OmniLight3D
var _cross: Node3D
var _rng := RandomNumberGenerator.new()
var _effects_on: bool = true


static func create(boost_id: String, definition: Dictionary) -> BoostEffects:
	var effect := BoostEffects.new()
	effect.name = "BoostEffect_%s" % boost_id
	effect.mode = boost_id
	effect.tint = color_for(boost_id)
	match boost_id:
		"electric_pulse":
			effect.radius = float(definition.get("radius", 8.0))
			effect.duration = 0.75
		"shockwave":
			effect.radius = float(definition.get("radius", 6.0))
			effect.duration = 0.95
		"magnet":
			effect.radius = float(definition.get("radius", 6.0))
			effect.duration = maxf(float(definition.get("duration", 5.0)), 0.5)
			effect.persistent = true
		"emergency_repair":
			effect.radius = 1.4
			effect.duration = 1.5
		"energy_regenerator":
			effect.radius = 1.2
			effect.duration = maxf(float(definition.get("duration", 3.0)), 0.5)
			effect.persistent = true
		"overdrive":
			effect.radius = 1.5
			effect.duration = maxf(float(definition.get("duration", 3.0)), 0.5)
			effect.persistent = true
		_:
			effect.duration = 0.5
	return effect


static func color_for(boost_id: String) -> Color:
	match boost_id:
		"electric_pulse":
			return Color("#4ceaff")
		"shockwave":
			return Color("#ff9d42")
		"magnet":
			return Color("#d85cff")
		"emergency_repair":
			return Color("#5cff91")
		"energy_regenerator":
			return Color("#42e6c4")
		"overdrive":
			return Color("#ffcf55")
		"shield":
			return Color("#33b4ff")
	return Color("#4ceaff")


## Materiał kopuły: rozbłysk na krawędziach (Fresnel) + przesuwająca się siatka heksagonalna.
static func make_aura_material(color: Color, hex_strength: float = 0.6, fresnel_power: float = 2.4) -> ShaderMaterial:
	var shader: Shader = _aura_shader()
	var material := ShaderMaterial.new()
	material.shader = shader
	material.set_shader_parameter("base_color", color)
	material.set_shader_parameter("hex_strength", hex_strength)
	material.set_shader_parameter("fresnel_power", fresnel_power)
	material.set_shader_parameter("intensity", 1.0)
	material.render_priority = 10
	return material


static var _aura_shader_cache: Shader = null


static func _aura_shader() -> Shader:
	if _aura_shader_cache != null:
		return _aura_shader_cache
	var shader := Shader.new()
	shader.code = """shader_type spatial;
render_mode unshaded, blend_add, cull_disabled, depth_draw_never, depth_test_disabled, fog_disabled;

uniform vec4 base_color : source_color = vec4(0.2, 0.7, 1.0, 1.0);
uniform float fresnel_power = 2.4;
uniform float hex_strength = 0.6;
uniform float hex_scale = 7.0;
uniform float intensity = 1.0;

float hex_dist(vec2 p) {
	p = abs(p);
	return max(dot(p, normalize(vec2(1.0, 1.73))), p.x);
}

void fragment() {
	float fres = pow(1.0 - clamp(dot(normalize(NORMAL), normalize(VIEW)), 0.0, 1.0), fresnel_power);
	vec2 uv = UV * vec2(hex_scale * 2.0, hex_scale);
	uv.y += TIME * 0.35;
	vec2 r = vec2(1.0, 1.73);
	vec2 h = r * 0.5;
	vec2 a = mod(uv, r) - h;
	vec2 b = mod(uv - h, r) - h;
	vec2 gv = dot(a, a) < dot(b, b) ? a : b;
	float edge = smoothstep(0.40, 0.48, hex_dist(gv));
	float pulse = 0.85 + 0.15 * sin(TIME * 6.0);
	float glow = fres * 1.5 + edge * hex_strength * (0.25 + fres);
	ALBEDO = base_color.rgb * glow * pulse * intensity * 1.6;
	ALPHA = clamp((fres * 0.85 + edge * hex_strength * 0.45 + 0.04) * intensity, 0.0, 1.0);
}
"""
	_aura_shader_cache = shader
	return shader


# =========================================================
# BUDOWA
# =========================================================

func _ready() -> void:
	_rng.randomize()
	_effects_on = GameSettings.effects_enabled
	match mode:
		"electric_pulse":
			_build_electric_pulse()
		"shockwave":
			_build_shockwave()
		"magnet":
			_build_magnet()
		"emergency_repair":
			_build_repair()
		"energy_regenerator":
			_build_regenerator()
		"overdrive":
			_build_overdrive()


func _additive_material(color: Color) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	material.no_depth_test = true
	material.render_priority = 10
	material.vertex_color_use_as_albedo = true
	return material


func _add_ring(inner: float, outer: float, color: Color, y: float = 0.0) -> MeshInstance3D:
	var torus := TorusMesh.new()
	torus.inner_radius = inner
	torus.outer_radius = outer
	torus.rings = 40
	torus.ring_segments = 5
	var ring := MeshInstance3D.new()
	ring.mesh = torus
	var material: StandardMaterial3D = _additive_material(color)
	ring.material_override = material
	ring.position.y = y
	ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(ring)
	_rings.append(ring)
	_ring_materials.append(material)
	return ring


func _add_light(color: Color, energy: float, light_range: float, y: float = 0.5) -> void:
	if not _effects_on or GameSettings.quality < GameSettings.Quality.MEDIUM:
		return
	_light = OmniLight3D.new()
	_light.light_color = color
	_light.light_energy = energy
	_light.omni_range = light_range
	_light.position.y = y
	_light.shadow_enabled = false
	add_child(_light)


func _add_particles(emitter_name: String, amount: int, lifetime: float, ramp: Gradient, direction: Vector3, spread: float, velocity_min: float, velocity_max: float, gravity_value: Vector3, scale_min: float, scale_max: float, one_shot: bool, emissive: bool = true, local: bool = false) -> CPUParticles3D:
	if not _effects_on:
		return null
	var particle_scale: float = GameSettings.get_particle_scale()
	if particle_scale <= 0.0:
		return null
	var particles := CPUParticles3D.new()
	particles.name = emitter_name
	particles.amount = maxi(int(round(float(amount) * particle_scale)), 4)
	particles.lifetime = lifetime
	particles.one_shot = one_shot
	if one_shot:
		particles.explosiveness = 0.95
	particles.local_coords = local
	var quad := QuadMesh.new()
	quad.size = Vector2(0.25, 0.25)
	particles.mesh = quad
	var material := StandardMaterial3D.new()
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	material.vertex_color_use_as_albedo = true
	material.no_depth_test = true
	material.render_priority = 10
	material.albedo_texture = RobotVisuals._particle_texture()
	if emissive:
		material.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	particles.material_override = material
	particles.direction = direction
	particles.spread = spread
	particles.initial_velocity_min = velocity_min
	particles.initial_velocity_max = velocity_max
	particles.gravity = gravity_value
	particles.scale_amount_min = scale_min
	particles.scale_amount_max = scale_max
	particles.color_ramp = ramp
	var curve := Curve.new()
	curve.add_point(Vector2(0.0, 1.0))
	curve.add_point(Vector2(1.0, 0.1))
	particles.scale_amount_curve = curve
	particles.emitting = true
	add_child(particles)
	_particles.append(particles)
	return particles


func _ramp(from_color: Color, mid_color: Color, to_color: Color) -> Gradient:
	var gradient := Gradient.new()
	gradient.set_color(0, from_color)
	gradient.set_color(1, to_color)
	gradient.add_point(0.4, mid_color)
	return gradient


func _bright(color: Color, amount: float = 0.55) -> Color:
	return color.lerp(Color.WHITE, amount)


func _build_electric_pulse() -> void:
	for i: int in range(3):
		var ring: MeshInstance3D = _add_ring(0.90, 1.0, Color(tint.r, tint.g, tint.b, 0.9), 0.1 + float(i) * 0.04)
		ring.scale = Vector3(0.1, 1.0, 0.1)
	_arc_mesh = ImmediateMesh.new()
	_arc_instance = MeshInstance3D.new()
	_arc_instance.mesh = _arc_mesh
	_arc_instance.material_override = _additive_material(Color.WHITE)
	_arc_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_arc_instance.position.y = 0.18
	_arc_instance.extra_cull_margin = radius
	add_child(_arc_instance)
	var sparks: CPUParticles3D = _add_particles("Sparks", 36, 0.6, _ramp(_bright(tint, 0.8), tint, Color(tint.r, tint.g, tint.b, 0.0)), Vector3(0, 1, 0), 80.0, 4.0, 10.0, Vector3(0, -9, 0), 0.18, 0.38, true)
	if sparks != null:
		sparks.position.y = 0.3
	_add_light(tint, 5.0, radius, 0.6)


func _build_shockwave() -> void:
	var main_ring: MeshInstance3D = _add_ring(0.78, 1.0, Color(tint.r, tint.g, tint.b, 0.85), 0.08)
	main_ring.scale = Vector3(0.1, 1.0, 0.1)
	var white_ring: MeshInstance3D = _add_ring(0.93, 1.0, Color(1.0, 0.95, 0.85, 0.9), 0.12)
	white_ring.scale = Vector3(0.1, 1.0, 0.1)
	var dome_mesh := SphereMesh.new()
	dome_mesh.radius = 1.0
	dome_mesh.height = 2.0
	dome_mesh.is_hemisphere = true
	dome_mesh.radial_segments = 28
	dome_mesh.rings = 10
	_dome = MeshInstance3D.new()
	_dome.mesh = dome_mesh
	_dome_material = make_aura_material(tint, 0.35, 2.0)
	_dome.material_override = _dome_material
	_dome.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_dome.scale = Vector3(0.2, 0.1, 0.2)
	add_child(_dome)
	var dust: CPUParticles3D = _add_particles("Dust", 34, 0.9, _ramp(Color(0.72, 0.65, 0.55, 0.55), Color(0.6, 0.55, 0.5, 0.35), Color(0.5, 0.46, 0.42, 0.0)), Vector3(0, 0.15, 0), 180.0, 3.5, 7.5, Vector3(0, 0.2, 0), 1.6, 3.0, true, false)
	if dust != null:
		dust.flatness = 0.9
		dust.position.y = 0.15
	var debris: CPUParticles3D = _add_particles("Debris", 24, 0.7, _ramp(_bright(tint, 0.7), tint, Color(tint.r, tint.g, tint.b, 0.0)), Vector3(0, 1, 0), 60.0, 4.0, 9.0, Vector3(0, -14, 0), 0.14, 0.3, true)
	if debris != null:
		debris.position.y = 0.2
	_add_light(tint, 6.0, radius * 0.9, 0.6)


func _build_magnet() -> void:
	# Pole zasięgu na podłodze oraz dwa pierścienie "wciągane" do środka.
	var field: MeshInstance3D = _add_ring(0.985, 1.0, Color(tint.r, tint.g, tint.b, 0.35), 0.06)
	field.scale = Vector3(radius, 1.0, radius)
	for i: int in range(2):
		var pulse_ring: MeshInstance3D = _add_ring(0.93, 1.0, Color(tint.r, tint.g, tint.b, 0.6), 0.08 + float(i) * 0.02)
		pulse_ring.scale = Vector3(radius, 1.0, radius)
	for i: int in range(2):
		var holder := Node3D.new()
		holder.position.y = 0.45
		holder.rotation = Vector3(0.0, 0.0, deg_to_rad(28.0 + 62.0 * float(i)))
		add_child(holder)
		var torus := TorusMesh.new()
		torus.inner_radius = 1.0 + float(i) * 0.35
		torus.outer_radius = 1.04 + float(i) * 0.35
		torus.rings = 36
		torus.ring_segments = 4
		var orbit := MeshInstance3D.new()
		orbit.mesh = torus
		orbit.material_override = _additive_material(Color(tint.r, tint.g, tint.b, 0.8))
		orbit.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		holder.add_child(orbit)
		_spinners.append(holder)
	var motes: CPUParticles3D = _add_particles("Motes", 36, 1.1, _ramp(Color(tint.r, tint.g, tint.b, 0.0), _bright(tint, 0.4), Color(1, 1, 1, 0.0)), Vector3(0, 0, 0), 180.0, 0.0, 0.6, Vector3.ZERO, 0.5, 1.0, false, true)
	if motes != null:
		motes.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
		motes.emission_sphere_radius = minf(radius * 0.55, 3.2)
		motes.radial_accel_min = -6.0
		motes.radial_accel_max = -3.5
		motes.position.y = 0.4
	_add_light(tint, 1.6, 4.0, 0.7)


func _build_repair() -> void:
	var ring: MeshInstance3D = _add_ring(0.88, 1.0, Color(tint.r, tint.g, tint.b, 0.9), 0.1)
	ring.scale = Vector3(0.3, 1.0, 0.3)
	_cross = Node3D.new()
	_cross.position.y = 1.15
	add_child(_cross)
	var cross_material: StandardMaterial3D = _additive_material(Color(tint.r, tint.g, tint.b, 0.9))
	for axis: int in range(2):
		var bar := MeshInstance3D.new()
		var box := BoxMesh.new()
		box.size = Vector3(0.14, 0.62, 0.14) if axis == 0 else Vector3(0.62, 0.14, 0.14)
		bar.mesh = box
		bar.material_override = cross_material
		bar.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		_cross.add_child(bar)
	var sparkles: CPUParticles3D = _add_particles("Sparkles", 42, 1.0, _ramp(_bright(tint, 0.7), tint, Color(tint.r, tint.g, tint.b, 0.0)), Vector3(0, 1, 0), 18.0, 1.4, 2.6, Vector3(0, 0.4, 0), 0.3, 0.7, false)
	if sparkles != null:
		sparkles.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
		sparkles.emission_sphere_radius = 0.75
		sparkles.position.y = 0.15
	_add_light(tint, 3.0, 4.5, 0.8)


func _build_regenerator() -> void:
	for i: int in range(3):
		var holder := Node3D.new()
		holder.position.y = 0.25 + float(i) * 0.3
		add_child(holder)
		var torus := TorusMesh.new()
		torus.inner_radius = 0.92
		torus.outer_radius = 1.0
		torus.rings = 36
		torus.ring_segments = 4
		var orbit := MeshInstance3D.new()
		orbit.mesh = torus
		orbit.material_override = _additive_material(Color(tint.r, tint.g, tint.b, 0.7))
		orbit.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		orbit.scale = Vector3(0.9 + float(i) * 0.2, 1.0, 0.9 + float(i) * 0.2)
		holder.add_child(orbit)
		_spinners.append(holder)
	var energy: CPUParticles3D = _add_particles("Energy", 40, 1.1, _ramp(Color(tint.r, tint.g, tint.b, 0.0), _bright(tint, 0.5), Color(1, 1, 1, 0.0)), Vector3(0, 1, 0), 10.0, 1.2, 2.2, Vector3.ZERO, 0.35, 0.8, false)
	if energy != null:
		energy.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
		energy.emission_sphere_radius = 1.0
		energy.tangential_accel_min = 2.0
		energy.tangential_accel_max = 4.0
		energy.position.y = 0.1
	_add_light(tint, 2.2, 4.0, 0.7)


func _build_overdrive() -> void:
	var aura_mesh := SphereMesh.new()
	aura_mesh.radius = 1.0
	aura_mesh.height = 1.6
	aura_mesh.radial_segments = 28
	aura_mesh.rings = 14
	_aura = MeshInstance3D.new()
	_aura.mesh = aura_mesh
	_aura_material = make_aura_material(tint, 0.25, 2.2)
	_aura.material_override = _aura_material
	_aura.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_aura.position.y = 0.45
	_aura.scale = Vector3.ONE * 1.25
	add_child(_aura)
	var ground: MeshInstance3D = _add_ring(0.85, 1.0, Color(tint.r, tint.g, tint.b, 0.55), 0.06)
	ground.scale = Vector3(1.6, 1.0, 1.6)
	var sparks: CPUParticles3D = _add_particles("Sparks", 30, 0.8, _ramp(_bright(tint, 0.8), tint, Color(tint.r, tint.g, tint.b, 0.0)), Vector3(0, 1, 0), 25.0, 1.6, 3.2, Vector3.ZERO, 0.2, 0.45, false)
	if sparks != null:
		sparks.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
		sparks.emission_sphere_radius = 1.0
		sparks.tangential_accel_min = 3.0
		sparks.tangential_accel_max = 5.0
		sparks.position.y = 0.1
	_add_light(tint, 3.0, 4.5, 0.7)


# =========================================================
# ANIMACJA
# =========================================================

func _process(delta: float) -> void:
	_age += delta
	var ratio: float = clampf(_age / maxf(duration, 0.01), 0.0, 1.0)
	var envelope: float = 1.0
	if persistent:
		envelope = minf(clampf(_age / 0.2, 0.0, 1.0), clampf((duration - _age) / 0.4, 0.0, 1.0))
		if _age > duration - 0.4:
			for particles: CPUParticles3D in _particles:
				if is_instance_valid(particles):
					particles.emitting = false

	match mode:
		"electric_pulse":
			_animate_electric(delta, ratio)
		"shockwave":
			_animate_shockwave(ratio)
		"magnet":
			_animate_magnet(delta, envelope)
		"emergency_repair":
			_animate_repair(delta, ratio)
		"energy_regenerator":
			_animate_regenerator(delta, envelope)
		"overdrive":
			_animate_overdrive(delta, envelope)

	if _age >= duration + 0.8 or (not persistent and ratio >= 1.0 and _age > duration + 0.5):
		queue_free()


func _set_ring(index: int, scale_value: float, alpha: float) -> void:
	if index >= _rings.size():
		return
	var ring: MeshInstance3D = _rings[index]
	ring.scale = Vector3(maxf(scale_value, 0.05), 1.0, maxf(scale_value, 0.05))
	var color: Color = _ring_materials[index].albedo_color
	color.a = clampf(alpha, 0.0, 1.0)
	_ring_materials[index].albedo_color = color


func _animate_electric(delta: float, ratio: float) -> void:
	for i: int in range(_rings.size()):
		var local: float = clampf((ratio - float(i) * 0.12) / (1.0 - float(i) * 0.12), 0.0, 1.0)
		var eased: float = 1.0 - pow(1.0 - local, 3.0)
		_set_ring(i, radius * eased, (1.0 - local) * 0.9)
	_arc_timer -= delta
	if _arc_timer <= 0.0 and _arc_mesh != null and ratio < 0.95:
		_arc_timer = 0.045
		_rebuild_arcs(ratio)
	elif ratio >= 0.95 and _arc_mesh != null:
		_arc_mesh.clear_surfaces()
	if _light != null:
		_light.light_energy = 6.0 * (1.0 - ratio) * (0.7 + 0.3 * sin(_age * 90.0))


func _rebuild_arcs(ratio: float) -> void:
	_arc_mesh.clear_surfaces()
	var reach: float = radius * clampf(ratio * 1.7, 0.08, 1.0)
	var arc_count: int = 8
	for k: int in range(arc_count):
		var base_angle: float = TAU * float(k) / float(arc_count) + _rng.randf_range(-0.22, 0.22)
		var direction := Vector3(cos(base_angle), 0.0, sin(base_angle))
		var perpendicular := Vector3(-direction.z, 0.0, direction.x)
		_arc_mesh.surface_begin(Mesh.PRIMITIVE_TRIANGLE_STRIP)
		var segments: int = 10
		for i: int in range(segments + 1):
			var t: float = float(i) / float(segments)
			var lateral: float = _rng.randf_range(-0.55, 0.55) * (0.25 + t)
			var lift: float = _rng.randf_range(0.0, 0.3)
			var center: Vector3 = direction * (0.5 + reach * t) + perpendicular * lateral + Vector3(0.0, lift, 0.0)
			var width: float = 0.1 * (1.0 - t * 0.65)
			var alpha: float = (1.0 - t * 0.55) * (1.0 - ratio * 0.8)
			var color := Color(tint.r + 0.3, tint.g + 0.2, tint.b, alpha)
			_arc_mesh.surface_set_color(color)
			_arc_mesh.surface_add_vertex(center + perpendicular * width)
			_arc_mesh.surface_set_color(color)
			_arc_mesh.surface_add_vertex(center - perpendicular * width)
		_arc_mesh.surface_end()


func _animate_shockwave(ratio: float) -> void:
	var eased: float = 1.0 - pow(1.0 - ratio, 3.0)
	_set_ring(0, radius * eased, (1.0 - ratio) * 0.85)
	var delayed: float = clampf((ratio - 0.08) / 0.92, 0.0, 1.0)
	_set_ring(1, radius * (1.0 - pow(1.0 - delayed, 3.0)) * 0.92, (1.0 - delayed) * 0.9)
	if _dome != null:
		var dome_ratio: float = clampf(ratio * 1.25, 0.0, 1.0)
		var dome_eased: float = 1.0 - pow(1.0 - dome_ratio, 2.5)
		_dome.scale = Vector3(radius * 0.75 * dome_eased + 0.2, radius * 0.38 * dome_eased + 0.1, radius * 0.75 * dome_eased + 0.2)
		_dome_material.set_shader_parameter("intensity", (1.0 - dome_ratio) * 1.1)
	if _light != null:
		_light.light_energy = 7.0 * pow(1.0 - ratio, 2.0)


func _animate_magnet(delta: float, envelope: float) -> void:
	for i: int in range(_rings.size()):
		if i == 0:
			var base_color: Color = _ring_materials[0].albedo_color
			base_color.a = 0.3 * envelope
			_ring_materials[0].albedo_color = base_color
			continue
		# Pierścienie zaciskają się do środka cyklicznie.
		var phase: float = fposmod(_age * 0.9 + float(i) * 0.5, 1.0)
		_set_ring(i, radius * (1.0 - phase * 0.85), (1.0 - phase) * 0.7 * envelope)
	for i: int in range(_spinners.size()):
		_spinners[i].rotate_y(delta * (2.2 if i % 2 == 0 else -1.7))
	if _light != null:
		_light.light_energy = 1.6 * envelope * (0.85 + 0.15 * sin(_age * 8.0))


func _animate_repair(delta: float, ratio: float) -> void:
	_set_ring(0, 0.3 + 1.7 * (1.0 - pow(1.0 - clampf(ratio * 1.6, 0.0, 1.0), 3.0)), (1.0 - ratio) * 0.9)
	if _cross != null:
		_cross.rotate_y(delta * 3.0)
		var pulse: float = 1.0 + 0.18 * sin(_age * 9.0)
		_cross.scale = Vector3.ONE * pulse * clampf(1.0 - maxf(ratio - 0.7, 0.0) / 0.3, 0.0, 1.0)
		_cross.position.y = 1.0 + 0.25 * sin(_age * 4.0)
	if _age > duration * 0.75:
		for particles: CPUParticles3D in _particles:
			if is_instance_valid(particles):
				particles.emitting = false
	if _light != null:
		_light.light_energy = 3.0 * (1.0 - ratio) * (0.8 + 0.2 * sin(_age * 12.0))


func _animate_regenerator(delta: float, envelope: float) -> void:
	for i: int in range(_spinners.size()):
		_spinners[i].rotate_y(delta * (2.4 if i % 2 == 0 else -1.9))
		_spinners[i].position.y = 0.25 + float(i) * 0.3 + 0.12 * sin(_age * 3.0 + float(i))
	if _light != null:
		_light.light_energy = 2.2 * envelope * (0.8 + 0.2 * sin(_age * 10.0))


func _animate_overdrive(delta: float, envelope: float) -> void:
	if _aura != null:
		var pulse: float = 1.2 + 0.07 * sin(_age * 11.0)
		_aura.scale = Vector3.ONE * pulse
		_aura_material.set_shader_parameter("intensity", envelope)
	for i: int in range(_rings.size()):
		var ring_alpha: float = 0.55 * envelope * (0.7 + 0.3 * sin(_age * 9.0))
		_set_ring(i, 1.6 + 0.15 * sin(_age * 7.0), ring_alpha)
	if _light != null:
		_light.light_energy = 3.0 * envelope * (0.8 + 0.2 * sin(_age * 14.0))
