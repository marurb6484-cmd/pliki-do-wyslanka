class_name BoostSystem
extends Node

const BoostEffectsScript = preload("res://scripts/robots/BoostEffects.gd")
## System 10 typów boostów. Zachowuje stary interfejs (is_active/try_activate,
## speed_multiplier/accel_multiplier), aby AI, kamera i efekty wizualne nadal
## korzystały z jednego API. Każde użycie boosta zużywa jednakową ilość brudu
## ze zbiornika; energia baterii pozostaje osobnym zasobem i warunkiem działania.

signal boost_started
signal boost_ended
signal boost_denied(reason: String)
signal state_changed
signal selected_changed(boost_id: String)

# Zgodność ze starszym HUD-em.
enum State { READY, NOT_ENOUGH_DIRT, ACTIVE, COOLDOWN }

var cost: float = 5.0
var duration: float = 2.0
var cooldown: float = 3.5
var speed_multiplier: float = 1.0
var accel_multiplier: float = 1.0
var tank: DirtTank
var robot: Node3D

var equipped: Array[String] = []
var selected_slot: int = 0
var active_id: String = ""
var active_definition: Dictionary = {}
var _selected_definition_cache: Dictionary = {}
var active_rarity: String = "common"
var _active_left: float = 0.0
var _cooldowns: Dictionary = {}
var _last_state: int = -1
var _shock_left: float = 0.0
var _shock_speed_multiplier: float = 0.65
var _shock_accel_multiplier: float = 0.60
var _slip_left: float = 0.0
var _slip_handling_multiplier: float = 0.55
var _destabilize_left: float = 0.0
var _post_effect_left: float = 0.0
var _post_effect_duration: float = 0.0
var _post_accel_multiplier: float = 1.0
var _turbo_wall_multiplier: float = 1.0
var _shield_hits: int = 0
var _energy_restore_left: float = 0.0
var _energy_restore_total: float = 0.0
var _magnet_timer: float = 0.0
var _trail_timer: float = 0.0
var _hologram: Node3D
var _shield_visual: MeshInstance3D
var _effect_visual: Node3D
var _effect_visual_meshes: Array[MeshInstance3D] = []
var _effect_visual_mode: String = ""
var _effect_visual_timer: float = 0.0
var _effect_visual_duration: float = 0.0


func setup(config: Dictionary, dirt_tank: DirtTank) -> void:
	tank = dirt_tank
	cost = float(config.get("boost_cost", 5.0))
	duration = float(config.get("boost_duration", 2.0))
	cooldown = float(config.get("boost_cooldown", 3.5))
	speed_multiplier = float(config.get("boost_speed_multiplier", 1.4))
	accel_multiplier = float(config.get("boost_accel_multiplier", 2.2))
	_active_left = 0.0
	_cooldowns.clear()
	if tank != null and not tank.changed.is_connected(_on_tank_changed):
		tank.changed.connect(_on_tank_changed)
	_check_state()


func setup_runtime(owner_robot: Node3D) -> void:
	robot = owner_robot
	equipped.clear()
	if robot != null and bool(robot.get("is_player")) and PlayerProgress.boost_loadout != null:
		equipped = PlayerProgress.boost_loadout.get_equipped()
	if equipped.is_empty():
		equipped = ["turbo", "electric_pulse"]
	selected_slot = 0
	for i: int in range(equipped.size()):
		if not equipped[i].is_empty():
			selected_slot = i
			break
	_refresh_selected_definition()
	_update_legacy_values()
	_check_state()


func get_selected_id() -> String:
	if selected_slot < 0 or selected_slot >= equipped.size():
		return ""
	return equipped[selected_slot]


func get_selected_name() -> String:
	var boost_id: String = get_selected_id()
	if boost_id.is_empty():
		return "PUSTY SLOT"
	return str(BoostCatalog.get_definition(boost_id).get("name", boost_id))


func get_selected_short_name() -> String:
	var names: Dictionary = {
		"turbo":"TURBO", "electric_pulse":"IMPULS", "slippery_trail":"ŚLAD",
		"shockwave":"FALA", "shield":"TARCZA", "magnet":"MAGNES",
		"emergency_repair":"NAPRAWA", "energy_regenerator":"ENERGIA",
		"overdrive":"OVERDRIVE", "hologram":"HOLOGRAM"
	}
	return str(names.get(get_selected_id(), "BOOST"))


func select_next() -> void:
	if equipped.is_empty():
		return
	var start: int = selected_slot
	for offset: int in range(1, equipped.size() + 1):
		var candidate: int = (start + offset) % equipped.size()
		if not str(equipped[candidate]).is_empty():
			selected_slot = candidate
			_refresh_selected_definition()
			_update_legacy_values()
			selected_changed.emit(get_selected_id())
			_check_state()
			return


func select_slot(slot_index: int) -> bool:
	if slot_index < 0 or slot_index >= equipped.size() or str(equipped[slot_index]).is_empty():
		return false
	selected_slot = slot_index
	_refresh_selected_definition()
	_update_legacy_values()
	selected_changed.emit(get_selected_id())
	_check_state()
	return true


func is_active() -> bool:
	return _active_left > 0.0 and (robot == null or not active_id.is_empty())


func is_cooling_down() -> bool:
	var key: String = "legacy" if robot == null else get_selected_id()
	return float(_cooldowns.get(key, 0.0)) > 0.0


func has_enough_dirt() -> bool:
	return tank != null and tank.charge + 0.0001 >= cost


func is_ready() -> bool:
	if robot != null:
		if get_selected_id().is_empty():
			return false
		var energy: EnergySystem = _get_energy()
		if energy == null:
			return false
		var minimum_ratio: float = 0.20 if bool(robot.get("is_player")) else 0.40
		var energy_ok: bool = get_selected_id() == "energy_regenerator" or energy.get_ratio() >= minimum_ratio
		return not is_active() and not is_cooling_down() and _shock_left <= 0.0 and has_enough_dirt() and _special_requirements_met(get_selected_id()) and energy_ok
	return not is_active() and not is_cooling_down() and has_enough_dirt()


func get_state() -> int:
	if is_active():
		return State.ACTIVE
	if _shock_left > 0.0:
		return State.NOT_ENOUGH_DIRT
	if robot != null and get_selected_id().is_empty():
		return State.NOT_ENOUGH_DIRT
	if is_cooling_down():
		return State.COOLDOWN
	if not has_enough_dirt() or (robot != null and not _special_requirements_met(get_selected_id())):
		return State.NOT_ENOUGH_DIRT
	if robot != null and get_selected_id() != "energy_regenerator":
		var energy: EnergySystem = _get_energy()
		if energy == null:
			return State.NOT_ENOUGH_DIRT
		var minimum_ratio: float = 0.20 if bool(robot.get("is_player")) else 0.40
		if energy.get_ratio() < minimum_ratio:
			return State.NOT_ENOUGH_DIRT
	return State.READY


func get_active_ratio() -> float:
	return clampf(_active_left / maxf(duration, 0.01), 0.0, 1.0)


func get_cooldown_ratio() -> float:
	var left: float = get_cooldown_left()
	return clampf(left / maxf(cooldown, 0.01), 0.0, 1.0)


func get_cooldown_left() -> float:
	var key: String = "legacy" if robot == null else get_selected_id()
	return float(_cooldowns.get(key, 0.0))


func is_turbo_active() -> bool:
	return is_active() and active_id == "turbo"


func get_collision_push_multiplier() -> float:
	return 1.0 + 0.5 * _turbo_wall_multiplier if is_turbo_active() else 1.0


func get_collision_reaction_multiplier() -> float:
	if is_turbo_active():
		return 1.0 - 0.25 * _turbo_wall_multiplier
	if is_active() and active_id == "overdrive":
		return 1.0 - clampf(float(active_definition.get("collision_resistance_pct", 35.0)) / 100.0, 0.0, 0.65)
	return 1.0


func apply_wall_impact() -> void:
	if is_turbo_active():
		_turbo_wall_multiplier = 0.8
		_update_legacy_values()


func get_brake_multiplier() -> float:
	if is_turbo_active():
		return 1.0 - 0.22 * _turbo_wall_multiplier
	return 1.0


func get_handling_multiplier() -> float:
	var value: float = 1.0
	if is_active() and (active_id == "turbo" or active_id == "overdrive") and active_definition.has("handling_pct"):
		var handling_effect: float = float(active_definition.get("handling_pct", 0.0))
		if active_id == "turbo":
			handling_effect *= _turbo_wall_multiplier
		value *= 1.0 + handling_effect / 100.0
	if _slip_left > 0.0:
		value *= _slip_handling_multiplier
	if _destabilize_left > 0.0:
		value *= 0.7
	return clampf(value, 0.2, 1.5)


func is_shocked() -> bool:
	return _shock_left > 0.0


func get_shock_speed_multiplier() -> float:
	return _shock_speed_multiplier if _shock_left > 0.0 else 1.0


func get_shock_accel_multiplier() -> float:
	return _shock_accel_multiplier if _shock_left > 0.0 else 1.0


func try_activate() -> bool:
	if robot == null:
		return _try_legacy_activate()
	return activate_selected()


func activate_selected() -> bool:
	if robot == null or not is_instance_valid(robot):
		boost_denied.emit("BOOST NIEDOSTĘPNY")
		return false
	var boost_id: String = get_selected_id()
	if boost_id.is_empty():
		boost_denied.emit("PUSTY SLOT")
		return false
	if _shock_left > 0.0:
		_shock_left += 2.0
		boost_denied.emit("PORAŻENIE — BOOST ZABLOKOWANY")
		return false
	if is_active():
		if active_id == "turbo" and boost_id == "turbo" and _active_left < 9.0:
			var extra_time: float = minf(1.0, 9.0 - _active_left)
			var energy: EnergySystem = _get_energy()
			if energy == null or tank == null or tank.charge + 0.0001 < cost:
				boost_denied.emit("ZA MAŁO BRUDU")
				return false
			var total_cost: float = energy.capacity * float(active_definition.get("energy_cost", 30.0)) / 100.0
			var extra_cost: float = total_cost * extra_time / maxf(float(active_definition.get("duration", 3.0)), 0.1)
			if energy.current + 0.0001 >= extra_cost and energy.consume_boost(extra_cost):
				if tank.consume(cost):
					_active_left += extra_time
					return true
				energy.charge(extra_cost)
		boost_denied.emit("INNY BOOST JEST AKTYWNY")
		return false
	if is_cooling_down():
		boost_denied.emit("ODNAWIANIE %.1f s" % get_cooldown_left())
		return false
	if not has_enough_dirt():
		boost_denied.emit("ZA MAŁO BRUDU")
		return false
	if not _special_requirements_met(boost_id):
		boost_denied.emit("BRAK USZKODZEŃ DO NAPRAWY" if boost_id == "emergency_repair" else "BOOST NIEDOSTĘPNY")
		return false

	var definition: Dictionary = get_selected_definition()
	var energy: EnergySystem = _get_energy()
	if energy == null:
		boost_denied.emit("BATERIA NIEDOSTĘPNA")
		return false
	var minimum_ratio: float = 0.20 if bool(robot.get("is_player")) else 0.40
	if boost_id != "energy_regenerator" and energy.get_ratio() < minimum_ratio:
		boost_denied.emit("MINIMALNY POZIOM ENERGII %.0f%%" % (minimum_ratio * 100.0))
		return false
	if not _has_energy_for(definition):
		boost_denied.emit("ZA MAŁO ENERGII")
		return false
	var cost_percent: float = float(definition.get("energy_cost", 0.0))
	var energy_cost: float = energy.capacity * cost_percent / 100.0
	if energy_cost > 0.0 and energy.current + 0.0001 < energy_cost:
		boost_denied.emit("ZA MAŁO ENERGII")
		return false
	# Jeden stały koszt brudu dla wszystkich 10 boostów, niezależnie od ich typu.
	if tank == null or not tank.consume(cost):
		boost_denied.emit("ZA MAŁO BRUDU")
		return false
	if energy_cost > 0.0 and not energy.consume_boost(energy_cost):
		# Zabezpieczenie przed rozjazdem zasobów, jeśli stan energii zmienił się w tej klatce.
		tank.add(cost)
		boost_denied.emit("ZA MAŁO ENERGII")
		return false

	active_id = boost_id
	active_definition = definition.duplicate(true)
	active_rarity = "common"
	duration = float(definition.get("duration", 0.0))
	cooldown = float(definition.get("cooldown", 1.0))
	_active_left = maxf(duration, 0.05)
	_apply_activation_effect(boost_id, definition)
	_create_boost_effect_visual(boost_id, definition)
	_update_legacy_values()
	boost_started.emit()
	_check_state()
	return true


func _apply_activation_effect(boost_id: String, definition: Dictionary) -> void:
	match boost_id:
		"electric_pulse":
			var radius: float = float(definition.get("radius", 8.0))
			for node: Node in get_tree().get_nodes_in_group("racers"):
				var electric_target: Node3D = node as Node3D
				if electric_target == null or electric_target == robot or not is_instance_valid(electric_target):
					continue
				if electric_target.global_position.distance_to(robot.global_position) <= radius:
					var electric_target_boost: BoostSystem = _get_boost(electric_target)
					if electric_target_boost == null:
						continue
					var shock_speed: float = clampf(1.0 + float(definition.get("speed_pct", -35.0)) / 100.0, 0.25, 1.0)
					var shock_accel: float = clampf(1.0 + float(definition.get("accel_pct", -40.0)) / 100.0, 0.2, 1.0)
					electric_target_boost.apply_shock(float(definition.get("duration", 2.0)), shock_speed, shock_accel)
		"shockwave":
			var wave_radius: float = float(definition.get("radius", 6.0))
			var strength: float = float(definition.get("knockback_strength", 8.0))
			for node: Node in get_tree().get_nodes_in_group("racers"):
				var wave_target: Node3D = node as Node3D
				if wave_target == null or wave_target == robot or not is_instance_valid(wave_target):
					continue
				var wave_target_boost: BoostSystem = _get_boost(wave_target)
				if wave_target_boost == null:
					continue
				var offset: Vector3 = wave_target.global_position - robot.global_position
				var distance: float = offset.length()
				if distance <= wave_radius and distance > 0.01:
					if wave_target_boost.consume_shield_hit():
						continue
					var falloff: float = 1.0 - clampf(distance / wave_radius, 0.0, 1.0) * 0.45
					wave_target.call("apply_impulse_velocity", offset.normalized() * strength * falloff)
					wave_target_boost.apply_destabilize(float(definition.get("destabilize_duration", 1.0)))
		"shield":
			_shield_hits = maxi(int(definition.get("blocked_hits", 1)), 1)
			_create_shield_visual()
		"emergency_repair":
			var damage: DamageSystem = _get_damage()
			if damage != null:
				damage.repair(minf(float(definition.get("repair_damage_pct", 30.0)), damage.damage))
		"energy_regenerator":
			var energy: EnergySystem = _get_energy()
			if energy != null:
				_energy_restore_left = maxf(duration, 0.1)
				_energy_restore_total = energy.capacity * float(definition.get("restore_energy_pct", 35.0)) / 100.0
		"slippery_trail":
			_trail_timer = 0.0
		"hologram":
			_create_hologram()


func apply_shock(seconds: float, speed_multiplier_value: float = 0.65, accel_multiplier_value: float = 0.60) -> void:
	if consume_shield_hit():
		return
	if is_active():
		cancel()
	_shock_left = maxf(_shock_left, seconds)
	_shock_speed_multiplier = clampf(speed_multiplier_value, 0.25, 1.0)
	_shock_accel_multiplier = clampf(accel_multiplier_value, 0.2, 1.0)
	_check_state()


func apply_slip(seconds: float, handling_multiplier_value: float = 0.55) -> void:
	if consume_shield_hit():
		return
	_slip_left = maxf(_slip_left, seconds)
	_slip_handling_multiplier = clampf(handling_multiplier_value, 0.2, 1.0)


func apply_destabilize(seconds: float) -> void:
	_destabilize_left = maxf(_destabilize_left, seconds)


func consume_shield_hit() -> bool:
	if _shield_hits <= 0:
		return false
	_shield_hits -= 1
	if _shield_hits <= 0 and active_id == "shield":
		_active_left = 0.0
		_finish_active()
	return true


func tick(delta: float) -> void:
	if robot != null:
		_tick_runtime(delta)
	else:
		_tick_legacy(delta)


func _tick_runtime(delta: float) -> void:
	for key: Variant in _cooldowns.keys():
		var left: float = maxf(float(_cooldowns[key]) - delta, 0.0)
		_cooldowns[key] = left
	_shock_left = maxf(_shock_left - delta, 0.0)
	_slip_left = maxf(_slip_left - delta, 0.0)
	if _shock_left <= 0.0:
		_shock_speed_multiplier = 0.65
		_shock_accel_multiplier = 0.60
	_destabilize_left = maxf(_destabilize_left - delta, 0.0)
	_post_effect_left = maxf(_post_effect_left - delta, 0.0)
	if _post_effect_left <= 0.0 or _post_effect_duration <= 0.0:
		_post_accel_multiplier = 1.0
	else:
		var recovery_ratio: float = clampf(_post_effect_left / _post_effect_duration, 0.0, 1.0)
		_post_accel_multiplier = lerpf(1.0, 0.8, recovery_ratio)

	if _energy_restore_left > 0.0:
		var step: float = minf(delta, _energy_restore_left)
		var restore: float = _energy_restore_total * step / maxf(_energy_restore_left, step)
		var energy: EnergySystem = _get_energy()
		if energy != null:
			energy.charge(restore)
		_energy_restore_total = maxf(_energy_restore_total - restore, 0.0)
		_energy_restore_left = maxf(_energy_restore_left - step, 0.0)

	if active_id == "slippery_trail" and is_active():
		_trail_timer -= delta
		if _trail_timer <= 0.0:
			_trail_timer = 0.35
			_create_slip_patch()
	if active_id == "magnet" and is_active():
		_magnet_timer -= delta
		if _magnet_timer <= 0.0:
			_magnet_timer = 0.08
			_pull_nearby_pickups()
	if active_id == "hologram" and is_active():
		_update_hologram()
	_update_boost_effect_visual(delta)
	if active_id == "shield" and is_active() and _shield_visual != null and is_instance_valid(_shield_visual):
		_shield_visual.global_position = robot.global_position + Vector3.UP * 0.7
	if is_active() and active_id != "energy_regenerator":
		var active_energy: EnergySystem = _get_energy()
		if active_energy == null or active_energy.current <= 0.0:
			_finish_active()
	if is_active():
		_active_left = maxf(_active_left - delta, 0.0)
		if _active_left <= 0.0:
			_finish_active()
	_update_legacy_values()
	_check_state()


func _finish_active() -> void:
	var finished_id: String = active_id
	if not finished_id.is_empty():
		_cooldowns[finished_id] = float(active_definition.get("cooldown", cooldown))
	if finished_id == "turbo":
		_post_effect_duration = float(active_definition.get("post_duration", 3.0))
		_post_effect_left = _post_effect_duration
		_post_accel_multiplier = 0.8
	if finished_id == "turbo":
		_turbo_wall_multiplier = 1.0
	if finished_id == "hologram":
		_remove_hologram()
	_remove_boost_effect_visual()
	if finished_id == "shield":
		_shield_hits = 0
		_remove_shield_visual()
	active_id = ""
	active_definition.clear()
	_active_left = 0.0
	_update_legacy_values()
	boost_ended.emit()
	_check_state()


func _create_boost_effect_visual(boost_id: String, definition: Dictionary) -> void:
	_remove_boost_effect_visual()
	if robot == null:
		return
	if boost_id not in ["electric_pulse", "shockwave", "magnet", "emergency_repair", "energy_regenerator", "overdrive"]:
		return
	# Efekt sam się animuje (BoostEffects); tu tylko go tworzymy i pilnujemy czasu życia.
	var effect = BoostEffectsScript.create(boost_id, definition)
	_effect_visual = effect
	robot.add_child(effect)
	effect.position = Vector3(0.0, 0.05, 0.0)
	_effect_visual_mode = boost_id
	_effect_visual_meshes.clear()
	_effect_visual_duration = maxf(effect.duration, 0.1)
	_effect_visual_timer = _effect_visual_duration


func _update_boost_effect_visual(delta: float) -> void:
	if _effect_visual == null or not is_instance_valid(_effect_visual):
		return
	_effect_visual_timer = maxf(_effect_visual_timer - delta, 0.0)
	if _effect_visual_timer <= 0.0:
		# Dajemy efektowi chwilę na wygaszenie, po czym sam się usuwa.
		_effect_visual = null
		_effect_visual_mode = ""


func _remove_boost_effect_visual() -> void:
	if _effect_visual != null and is_instance_valid(_effect_visual):
		_effect_visual.queue_free()
	_effect_visual = null
	_effect_visual_meshes.clear()
	_effect_visual_mode = ""
	_effect_visual_timer = 0.0
	_effect_visual_duration = 0.0


func _create_slip_patch() -> void:
	if robot == null:
		return
	var area := Area3D.new()
	area.name = "BoostSlipPatch"
	area.collision_layer = 0
	area.collision_mask = 2
	area.monitoring = true
	area.monitorable = false
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(4.0, 1.4, maxf(float(active_definition.get("trail_length", 6.0)), 2.0))
	shape.shape = box
	area.add_child(shape)
	var mesh := MeshInstance3D.new()
	var box_mesh := BoxMesh.new()
	box_mesh.size = Vector3(4.0, 0.08, maxf(float(active_definition.get("trail_length", 6.0)), 2.0))
	mesh.mesh = box_mesh
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(0.92, 0.28, 0.82, 0.22)
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.emission_enabled = true
	material.emission = Color(0.55, 0.08, 0.42)
	material.emission_energy_multiplier = 0.65
	mesh.material_override = material
	area.add_child(mesh)
	var parent: Node = robot.get_parent()
	if parent != null:
		parent.add_child(area)
		area.global_transform = robot.global_transform
		area.global_position -= _get_forward() * (float(active_definition.get("trail_length", 6.0)) * 0.5 + 1.0)
		area.body_entered.connect(_on_slip_patch_body_entered.bind(area))
		var patch_lifetime: float = float(active_definition.get("duration", 8.0))
		var slip_strength: float = clampf(1.0 + float(active_definition.get("handling_pct", -45.0)) / 100.0, 0.2, 1.0)
		area.set_meta("slip_strength", slip_strength)
		area.set_meta("slip_duration", float(active_definition.get("target_duration", 2.0)))
		var timer := get_tree().create_timer(patch_lifetime)
		timer.timeout.connect(area.queue_free)


func _on_slip_patch_body_entered(body: Node3D, patch: Area3D) -> void:
	var target_boost: BoostSystem = _get_boost(body)
	if target_boost != null and body != robot and is_instance_valid(patch):
		target_boost.apply_slip(float(patch.get_meta("slip_duration", 2.0)), float(patch.get_meta("slip_strength", 0.55)))


func _pull_nearby_pickups() -> void:
	if robot == null:
		return
	var radius: float = float(active_definition.get("radius", 6.0))
	var speed: float = float(active_definition.get("attraction_speed", 5.0))
	for node: Node in get_tree().get_nodes_in_group("dirt_pickups"):
		var area: Area3D = node as Area3D
		if area == null or not area.monitoring:
			continue
		var offset: Vector3 = robot.global_position - area.global_position
		var distance: float = offset.length()
		if distance > 0.1 and distance <= radius:
			area.global_position += offset.normalized() * minf(speed * 0.08, distance)


func _create_shield_visual() -> void:
	_remove_shield_visual()
	if robot == null:
		return
	_shield_visual = MeshInstance3D.new()
	_shield_visual.name = "BoostShieldVisual"
	var sphere := SphereMesh.new()
	sphere.radius = 1.55
	sphere.height = 2.3
	sphere.radial_segments = 28
	sphere.rings = 14
	_shield_visual.mesh = sphere
	_shield_visual.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_shield_visual.material_override = BoostEffectsScript.make_aura_material(Color(0.2, 0.7, 1.0), 0.7, 2.2)
	robot.add_child(_shield_visual)
	_shield_visual.position = Vector3.UP * 0.7


func _remove_shield_visual() -> void:
	if _shield_visual != null and is_instance_valid(_shield_visual):
		_shield_visual.queue_free()
	_shield_visual = null


func _create_hologram() -> void:
	_remove_hologram()
	if robot == null:
		return
	_hologram = Node3D.new()
	_hologram.name = "BoostHologram"
	var source: Node = robot.get_node_or_null("Visuals")
	if source != null:
		for child: Node in source.get_children():
			if child is MeshInstance3D:
				var clone: MeshInstance3D = (child as MeshInstance3D).duplicate() as MeshInstance3D
				if clone != null:
					var material := StandardMaterial3D.new()
					material.albedo_color = Color(0.1, 0.85, 1.0, 0.28)
					material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
					material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
					material.emission_enabled = true
					material.emission = Color(0.05, 0.7, 1.0)
					clone.material_override = material
					_hologram.add_child(clone)
	if _hologram.get_child_count() == 0:
		var mesh := MeshInstance3D.new()
		var sphere := SphereMesh.new()
		sphere.radius = 0.9
		sphere.height = 0.5
		mesh.mesh = sphere
		_hologram.add_child(mesh)
	_hologram.add_to_group("ai_decoys")
	_hologram.set_meta("decoy_owner", robot)
	_hologram.set_meta("decoy_strength", float(active_definition.get("decoy_strength", 0.5)))
	var parent: Node = robot.get_parent()
	if parent != null:
		parent.add_child(_hologram)
	_update_hologram()


func _update_hologram() -> void:
	if _hologram == null or robot == null:
		return
	_hologram.global_transform = robot.global_transform
	_hologram.global_position += _get_forward() * 2.2
	_hologram.global_position += robot.global_transform.basis.x * 1.25


func _remove_hologram() -> void:
	if _hologram != null and is_instance_valid(_hologram):
		_hologram.queue_free()
	_hologram = null


func _refresh_selected_definition() -> void:
	var boost_id: String = get_selected_id()
	_selected_definition_cache = BoostUpgradeSystem.apply_to_definition(boost_id, "common") if not boost_id.is_empty() else {}


func _update_legacy_values() -> void:
	var boost_id: String = active_id if not active_id.is_empty() else get_selected_id()
	var definition: Dictionary = active_definition if not active_id.is_empty() else _selected_definition_cache
	duration = float(definition.get("duration", 2.0))
	cooldown = float(definition.get("cooldown", 3.5))
	var accel_pct: float = float(definition.get("accel_pct", 0.0))
	var speed_pct: float = float(definition.get("speed_pct", 0.0))
	var wall_factor: float = _turbo_wall_multiplier if boost_id == "turbo" else 1.0
	# Turbo jest jedynym boostem zwiększającym prędkość lub przyspieszenie.
	accel_multiplier = (1.0 + accel_pct / 100.0) * wall_factor if is_active() and boost_id == "turbo" else (_post_accel_multiplier if _post_effect_left > 0.0 else 1.0)
	speed_multiplier = (1.0 + speed_pct / 100.0) * wall_factor if is_active() and boost_id == "turbo" else 1.0


func _get_selected_cooldown() -> float:
	return float(_selected_definition_cache.get("cooldown", 0.0))


func _get_selected_cost() -> float:
	return float(_selected_definition_cache.get("energy_cost", 0.0))


func get_selected_definition() -> Dictionary:
	return _selected_definition_cache.duplicate(true)


func _has_energy_for(definition: Dictionary) -> bool:
	var energy: EnergySystem = _get_energy()
	if energy == null or not energy.enabled:
		return false
	var cost_amount: float = energy.capacity * float(definition.get("energy_cost", 0.0)) / 100.0
	return energy.current + 0.0001 >= cost_amount


func _get_energy(owner: Node3D = null) -> EnergySystem:
	var target: Node3D = robot if owner == null else owner
	if target == null:
		return null
	return target.get("energy") as EnergySystem


func _get_damage(owner: Node3D = null) -> DamageSystem:
	var target: Node3D = robot if owner == null else owner
	if target == null:
		return null
	return target.get("damage") as DamageSystem


func _get_boost(owner: Node3D = null) -> BoostSystem:
	var target: Node3D = robot if owner == null else owner
	if target == null:
		return null
	return target.get("boost") as BoostSystem


func _get_forward() -> Vector3:
	if robot == null or not robot.has_method("get_forward"):
		return Vector3.FORWARD
	var direction: Variant = robot.call("get_forward")
	if typeof(direction) == TYPE_VECTOR3:
		return direction
	return Vector3.FORWARD


func _special_requirements_met(boost_id: String) -> bool:
	if boost_id == "emergency_repair" and robot != null:
		var damage: DamageSystem = _get_damage()
		return damage != null and damage.damage > 0.01
	if boost_id == "energy_regenerator" and robot != null:
		var energy: EnergySystem = _get_energy()
		return energy != null and energy.current < energy.capacity - 0.01
	return true


func _try_legacy_activate() -> bool:
	if is_active() or is_cooling_down():
		boost_denied.emit("ODNAWIANIE")
		return false
	if not has_enough_dirt() or not tank.consume(cost):
		boost_denied.emit("ZA MAŁO BRUDU")
		return false
	_active_left = duration
	active_id = "legacy"
	boost_started.emit()
	_check_state()
	return true


func _tick_legacy(delta: float) -> void:
	if _active_left > 0.0:
		_active_left -= delta
		if _active_left <= 0.0:
			_active_left = 0.0
			active_id = ""
			_cooldowns["legacy"] = cooldown
			boost_ended.emit()
	else:
		var left: float = maxf(float(_cooldowns.get("legacy", 0.0)) - delta, 0.0)
		_cooldowns["legacy"] = left
	_check_state()


func cancel() -> void:
	if robot != null:
		if is_active():
			var previous: String = active_id
			_cooldowns[previous] = float(active_definition.get("cooldown", cooldown))
			active_id = ""
			active_definition.clear()
			_active_left = 0.0
			if previous == "turbo":
				_turbo_wall_multiplier = 1.0
			if previous == "hologram":
				_remove_hologram()
			_remove_boost_effect_visual()
			if previous == "shield":
				_shield_hits = 0
				_remove_shield_visual()
			if previous == "energy_regenerator":
				_energy_restore_left = 0.0
				_energy_restore_total = 0.0
			boost_ended.emit()
			_update_legacy_values()
			_check_state()
		return
	if _active_left > 0.0:
		_active_left = 0.0
		active_id = ""
		_cooldowns["legacy"] = cooldown
		boost_ended.emit()
		_check_state()


func _on_tank_changed(_charge: float, _capacity: float) -> void:
	_check_state()


func _check_state() -> void:
	var current_state: int = get_state()
	if current_state != _last_state:
		_last_state = current_state
		state_changed.emit()
