class_name DamageSystem
extends Node
## Uszkodzenia robota (0-100%).
##
## - Siła uszkodzenia zależy od prędkości uderzenia (składowa prostopadła
##   do przeszkody - otarcia o bandę nie niszczą robota).
## - Limit uszkodzeń na jedno uderzenie (pojedyncze dotknięcie nie niszczy robota).
## - Ochrona przed wielokrotnym naliczaniem: osobny czas blokady dla każdego obiektu.
## - Stopnie: sprawny / lekkie / średnie / poważne - wpływają na prędkość,
##   przyspieszenie, przyczepność i ściąganie w bok.
## - Przy 100% uszkodzeń system pit stopu przejmuje robota i odsyła go do stacji.

signal damage_changed(value: float, stage: int)
signal impact(strength: float, world_position: Vector3, damage_amount: float)

enum Stage { NONE, LIGHT, MEDIUM, SEVERE }

const STAGE_NAMES: Array[String] = ["SPRAWNY", "LEKKIE", "ŚREDNIE", "POWAŻNE"]
const STAGE_COLORS: Array[Color] = [
	Color(0.2, 1.0, 0.45),
	Color(0.95, 0.9, 0.2),
	Color(1.0, 0.55, 0.1),
	Color(1.0, 0.18, 0.15)
]

## Poniżej tej prędkości uderzenia (m/s) nie ma uszkodzeń.
var min_impact_speed: float = 3.0
## Procent uszkodzeń na każdy m/s ponad progiem.
var damage_per_speed: float = 1.5
## Maksymalne uszkodzenie z jednego uderzenia.
var max_per_hit: float = 12.0
## Czas blokady ponownego naliczenia dla tego samego obiektu.
var hit_cooldown: float = 0.5

var damage: float = 0.0
var damage_taken_this_race: float = 0.0
## Ściąganie w bok: + prawo, - lewo (zależy od strony uderzeń).
var pull_side: float = 0.0
var enabled: bool = true
var resistance_multiplier: float = 1.0

var _cooldowns: Dictionary = {}


func setup(initial_damage: float) -> void:
	damage = clampf(initial_damage, 0.0, 100.0)
	damage_taken_this_race = 0.0
	pull_side = 0.0
	damage_changed.emit(damage, get_stage())


func tick(delta: float) -> void:
	if _cooldowns.is_empty():
		return
	for key: int in _cooldowns.keys():
		var left: float = float(_cooldowns[key]) - delta
		if left <= 0.0:
			_cooldowns.erase(key)
		else:
			_cooldowns[key] = left


func is_on_cooldown(collider_id: int) -> bool:
	return _cooldowns.has(collider_id)


## Rejestruje uderzenie. Zwraca naliczone uszkodzenie (0 = brak) lub -1,
## jeżeli to samo uderzenie zostało już policzone (blokada czasowa).
func register_impact(impact_speed: float, collider_id: int, local_hit: Vector3, world_position: Vector3) -> float:
	if _cooldowns.has(collider_id):
		return -1.0
	_cooldowns[collider_id] = hit_cooldown

	var strength: float = clampf(impact_speed / 14.0, 0.0, 1.0)
	var amount: float = 0.0

	if enabled and impact_speed > min_impact_speed:
		amount = minf((impact_speed - min_impact_speed) * damage_per_speed * resistance_multiplier, max_per_hit)
		var before: float = damage
		damage = minf(damage + amount, 100.0)
		amount = damage - before
		damage_taken_this_race += amount

		if absf(local_hit.x) > absf(local_hit.z) * 0.6:
			pull_side = clampf(pull_side + signf(local_hit.x) * amount / 60.0, -1.0, 1.0)

		damage_changed.emit(damage, get_stage())

	impact.emit(strength, world_position, amount)
	return amount


## Uszkodzenia od konkretnych obiektów otoczenia. Wartość jest ustalana
## przez typ przedmiotu, a blokada zapobiega wielokrotnemu naliczeniu kontaktu.
func apply_environment_damage(amount: float, collider_id: int, world_position: Vector3) -> float:
	if not enabled or amount <= 0.0 or _cooldowns.has(collider_id):
		return 0.0
	_cooldowns[collider_id] = hit_cooldown
	var before: float = damage
	var reduced_amount: float = amount * resistance_multiplier
	damage = minf(damage + reduced_amount, 100.0)
	var applied: float = damage - before
	damage_taken_this_race += applied
	if applied > 0.0:
		damage_changed.emit(damage, get_stage())
	impact.emit(clampf(amount / 30.0, 0.0, 1.0), world_position, applied)
	return applied


func get_stage() -> int:
	if damage >= 75.0:
		return Stage.SEVERE
	if damage >= 50.0:
		return Stage.MEDIUM
	if damage >= 25.0:
		return Stage.LIGHT
	return Stage.NONE


func get_stage_name() -> String:
	return STAGE_NAMES[get_stage()]


func get_stage_color() -> Color:
	return STAGE_COLORS[get_stage()]


func speed_multiplier() -> float:
	return 1.0 - 0.25 * smoothstep(20.0, 100.0, damage)


func accel_multiplier() -> float:
	return 1.0 - 0.2 * smoothstep(35.0, 100.0, damage)


func grip_multiplier() -> float:
	return 1.0 - 0.15 * smoothstep(50.0, 100.0, damage)


## Delikatne ściąganie kierownicy przy dużych uszkodzeniach (max ~7%).
func steer_pull() -> float:
	if damage < 50.0:
		return 0.0
	return clampf(pull_side, -1.0, 1.0) * 0.07 * (damage - 50.0) / 50.0


func repair(amount: float) -> void:
	damage = maxf(damage - amount, 0.0)
	if damage <= 0.0:
		pull_side = 0.0
	damage_changed.emit(damage, get_stage())
