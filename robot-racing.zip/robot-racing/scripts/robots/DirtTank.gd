class_name DirtTank
extends Node
## Zbiornik brudu robota - zasób zbierany na trasie i wykorzystywany w statystykach/nagrodach.
## Ten sam system dla gracza i przeciwników AI.

signal changed(charge: float, capacity: float)
signal collected(amount: float)

var capacity: float = 10.0
var charge: float = 0.0
## Całkowita ilość brudu zebrana w tym wyścigu (do nagród i statystyk).
var total_collected: float = 0.0


func setup(new_capacity: float) -> void:
	capacity = maxf(new_capacity, 1.0)
	charge = clampf(charge, 0.0, capacity)
	changed.emit(charge, capacity)


func is_full() -> bool:
	return charge >= capacity - 0.01


func get_ratio() -> float:
	return clampf(charge / capacity, 0.0, 1.0)


## Dodaje wyłącznie ilość, która faktycznie zmieściła się w zbiorniku.
## Zwraca przyjętą ilość, aby punkty kurzu nie znikały bez miejsca na zasób.
func add(amount: float) -> float:
	var requested: float = maxf(amount, 0.0)
	if requested <= 0.0:
		return 0.0
	var accepted: float = minf(requested, maxf(capacity - charge, 0.0))
	if accepted <= 0.0:
		return 0.0
	charge += accepted
	total_collected += accepted
	changed.emit(charge, capacity)
	collected.emit(accepted)
	return accepted


func consume(amount: float) -> bool:
	if charge + 0.0001 < amount:
		return false
	charge = maxf(charge - amount, 0.0)
	changed.emit(charge, capacity)
	return true


func reset() -> void:
	charge = 0.0
	total_collected = 0.0
	changed.emit(charge, capacity)
