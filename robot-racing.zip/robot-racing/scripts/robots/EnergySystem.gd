class_name EnergySystem
extends Node
## Bateria robota wyścigowego. Oddzielna od zbiornika brudu używanego przez boost.

signal changed(current: float, capacity: float)
signal depleted
signal lap_recorded(consumed: float, remaining: float)

var capacity: float = 100.0
var current: float = 100.0
var enabled: bool = true
var _depleted_emitted: bool = false
var _signal_timer: float = 0.0
var lap_start_energy: float = 100.0
var last_lap_consumed: float = 0.0
var total_consumed: float = 0.0
var current_lap_consumed: float = 0.0
var total_boost_consumed: float = 0.0
var current_lap_boost_consumed: float = 0.0
var last_lap_boost_consumed: float = 0.0

## Zużycie bazowe baterii; koszt boosta jest pobierany jednorazowo przez BoostSystem.
const BASE_DRAIN: float = 0.18
const SPEED_DRAIN: float = 0.78
const BOOST_DRAIN: float = 1.15


func setup(config: Dictionary, active: bool = true) -> void:
	enabled = active
	capacity = maxf(float(config.get("battery_capacity", 100.0)), 1.0)
	current = capacity
	_depleted_emitted = false
	total_consumed = 0.0
	current_lap_consumed = 0.0
	last_lap_consumed = 0.0
	total_boost_consumed = 0.0
	current_lap_boost_consumed = 0.0
	last_lap_boost_consumed = 0.0
	lap_start_energy = current
	changed.emit(current, capacity)


func tick(delta: float, speed_ratio: float, boost_active: bool) -> void:
	if not enabled or current <= 0.0:
		return
	var ratio: float = clampf(speed_ratio, 0.0, 1.5)
	var drain: float = BASE_DRAIN + SPEED_DRAIN * pow(ratio, 1.45)
	if boost_active:
		drain += BOOST_DRAIN
	var consumed: float = minf(drain * delta, current)
	current = maxf(current - consumed, 0.0)
	total_consumed += consumed
	current_lap_consumed += consumed
	if boost_active and drain > 0.0:
		var boost_share: float = consumed * BOOST_DRAIN / drain
		total_boost_consumed += boost_share
		current_lap_boost_consumed += boost_share
	_signal_timer -= delta
	if _signal_timer <= 0.0 or current <= 0.0:
		_signal_timer = 0.2
		changed.emit(current, capacity)
	if current <= 0.0 and not _depleted_emitted:
		_depleted_emitted = true
		depleted.emit()


func charge(amount: float) -> void:
	if amount <= 0.0:
		return
	var before: float = current
	current = minf(current + amount, capacity)
	if current > 0.0:
		_depleted_emitted = false
	if absf(current - before) > 0.001:
		changed.emit(current, capacity)




## Jednorazowy koszt aktywacji boosta. Koszt jest zaliczany do statystyk energii boostów.
func consume_boost(amount: float) -> bool:
	if amount <= 0.0:
		return true
	if not enabled or current + 0.0001 < amount:
		return false
	var consumed: float = minf(amount, current)
	current = maxf(current - consumed, 0.0)
	total_consumed += consumed
	current_lap_consumed += consumed
	total_boost_consumed += consumed
	current_lap_boost_consumed += consumed
	changed.emit(current, capacity)
	if current <= 0.0 and not _depleted_emitted:
		_depleted_emitted = true
		depleted.emit()
	return true

func get_ratio() -> float:
	return clampf(current / maxf(capacity, 0.001), 0.0, 1.0)


func is_empty() -> bool:
	return current <= 0.0


## Zamyka pomiar zużycia energii na okrążeniu. Ładowanie nie jest liczone jako zużycie.
func complete_lap() -> float:
	last_lap_consumed = current_lap_consumed
	last_lap_boost_consumed = current_lap_boost_consumed
	current_lap_consumed = 0.0
	current_lap_boost_consumed = 0.0
	lap_start_energy = current
	lap_recorded.emit(last_lap_consumed, current)
	return last_lap_consumed


func get_last_lap_consumption_percent() -> float:
	return last_lap_consumed / maxf(capacity, 0.001) * 100.0


func get_current_lap_consumption_percent() -> float:
	return current_lap_consumed / maxf(capacity, 0.001) * 100.0
