class_name LocalPlayerDriver
extends Node
## Lokalny kierowca dla dwóch osób przy jednym urządzeniu.
## Gracz 1: WASD / pad 0. Gracz 2: strzałki / pad 1.
## Na Androidzie gracz 1 może nadal korzystać z dotykowego HUD-u; drugi gracz wymaga pada.

@export_range(1, 2) var player_number: int = 1
var touch: Node = null
var _robot: Robot
var _keyboard_steer: float = 0.0
var _boost_key_was_down: bool = false
var _boost_pad_was_down: bool = false
var _touch_connected: bool = false

func update_input(robot: Robot, delta: float) -> void:
	_robot = robot
	var steer := 0.0
	var throttle := 0.0
	var brake := 0.0
	var drift := false
	var pad := player_number - 1
	var connected := Input.get_connected_joypads().has(pad)

	if player_number == 1:
		if touch == null or not is_instance_valid(touch):
			touch = get_tree().get_first_node_in_group("touch_controls")
		if touch != null:
			if touch.has_signal("boost_pressed") and not _touch_connected:
				touch.connect("boost_pressed", _on_touch_boost)
				_touch_connected = true
			steer = float(touch.get("steer"))
			throttle = 1.0 if bool(touch.get("gas_pressed")) else 0.0
			brake = 1.0 if bool(touch.get("brake_pressed")) else 0.0
			drift = bool(touch.get("drift_pressed"))
		if Input.is_key_pressed(KEY_A): steer = -1.0
		if Input.is_key_pressed(KEY_D): steer = 1.0
		if Input.is_key_pressed(KEY_W): throttle = 1.0
		if Input.is_key_pressed(KEY_S): brake = 1.0
		if Input.is_key_pressed(KEY_CTRL): drift = true
		if Input.is_key_pressed(KEY_SPACE):
			if not _boost_key_was_down: robot.request_boost()
			_boost_key_was_down = true
		else:
			_boost_key_was_down = false
		if Input.is_key_pressed(KEY_TAB):
			if not _tab_was_down: robot.boost.select_next()
			_tab_was_down = true
		else:
			_tab_was_down = false
	else:
		if Input.is_key_pressed(KEY_LEFT): steer = -1.0
		if Input.is_key_pressed(KEY_RIGHT): steer = 1.0
		if Input.is_key_pressed(KEY_UP): throttle = 1.0
		if Input.is_key_pressed(KEY_DOWN): brake = 1.0
		if Input.is_key_pressed(KEY_SHIFT): drift = true
		if Input.is_key_pressed(KEY_ENTER):
			if not _boost_key_was_down: robot.request_boost()
			_boost_key_was_down = true
		else:
			_boost_key_was_down = false
		if Input.is_key_pressed(KEY_R):
			if not _r_was_down: robot.boost.select_next()
			_r_was_down = true
		else:
			_r_was_down = false

	if connected:
		var axis := Input.get_joy_axis(pad, JOY_AXIS_LEFT_X)
		if absf(axis) > absf(steer): steer = axis
		if Input.is_joy_button_pressed(pad, JOY_BUTTON_A): throttle = 1.0
		if Input.is_joy_button_pressed(pad, JOY_BUTTON_B): brake = 1.0
		if Input.is_joy_button_pressed(pad, JOY_BUTTON_X):
			if not _boost_pad_was_down: robot.request_boost()
			_boost_pad_was_down = true
		else:
			_boost_pad_was_down = false
		if Input.is_joy_button_pressed(pad, JOY_BUTTON_Y):
			if not _pad_y_was_down: robot.boost.select_next()
			_pad_y_was_down = true
		else:
			_pad_y_was_down = false
		drift = drift or Input.is_joy_button_pressed(pad, JOY_BUTTON_RIGHT_SHOULDER)

	var rate := 6.0 * GameSettings.steering_sensitivity
	_keyboard_steer = move_toward(_keyboard_steer, steer, rate * delta)
	robot.input_steer = clampf(_keyboard_steer, -1.0, 1.0)
	robot.input_throttle = throttle
	robot.input_brake = brake
	robot.input_drift = drift

var _tab_was_down := false
var _r_was_down := false
var _pad_y_was_down := false


func _on_touch_boost() -> void:
	if _robot != null and is_instance_valid(_robot):
		_robot.request_boost()
