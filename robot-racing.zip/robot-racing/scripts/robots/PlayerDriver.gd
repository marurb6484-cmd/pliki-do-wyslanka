class_name PlayerDriver
extends Node
## Kierowca - gracz. Łączy sterowanie dotykowe (TouchControls) z klawiaturą
## i padem (do testów na PC). Ustawia wejście robota w każdej klatce fizyki.

var touch: Node = null
var _robot: Robot = null
var _keyboard_steer: float = 0.0


func update_input(robot: Robot, delta: float) -> void:
	if _robot != robot:
		_robot = robot

	if touch == null or not is_instance_valid(touch):
		_find_touch()

	var steer: float = 0.0
	var throttle: float = 0.0
	var brake: float = 0.0
	var drift: bool = false

	if touch != null:
		steer = float(touch.get("steer"))
		throttle = 1.0 if bool(touch.get("gas_pressed")) else 0.0
		brake = 1.0 if bool(touch.get("brake_pressed")) else 0.0
		drift = bool(touch.get("drift_pressed"))

	# Klawiatura: płynne narastanie skrętu zamiast skoku 0 -> 1.
	var key_axis: float = Input.get_axis("steer_left", "steer_right")
	var rate: float = 6.0 * GameSettings.steering_sensitivity
	_keyboard_steer = move_toward(_keyboard_steer, key_axis, rate * delta)
	if absf(_keyboard_steer) > absf(steer):
		steer = _keyboard_steer

	if Input.is_action_pressed("accelerate"):
		throttle = 1.0
	if Input.is_action_pressed("brake"):
		brake = 1.0
	if Input.is_action_pressed("drift"):
		drift = true
	if Input.is_action_just_pressed("boost_next"):
		robot.boost.select_next()
	if Input.is_action_just_pressed("boost"):
		robot.request_boost()

	robot.input_steer = clampf(steer, -1.0, 1.0)
	robot.input_throttle = throttle
	robot.input_brake = brake
	robot.input_drift = drift


func _find_touch() -> void:
	touch = get_tree().get_first_node_in_group("touch_controls")
	if touch != null and touch.has_signal("boost_pressed"):
		if not touch.is_connected("boost_pressed", _on_touch_boost):
			touch.connect("boost_pressed", _on_touch_boost)


func _on_touch_boost() -> void:
	if _robot != null and is_instance_valid(_robot):
		_robot.request_boost()
