class_name Robot
extends CharacterBody3D
## Robot wyścigowy - wspólna fizyka jazdy dla gracza i przeciwników AI.
##
## Robot nie wie, kto nim steruje. Sterowanie dostarcza "kierowca" (PlayerDriver
## lub AIDriver), który w każdej klatce fizyki ustawia input_* przez
## update_input(robot, delta). Dzięki temu AI ma dokładnie te same możliwości
## i ograniczenia co gracz (brak oszukiwania).
##
## Model jazdy (zręcznościowy, przewidywalny):
##  - przyspieszanie z łagodnym spadkiem przy prędkości maksymalnej,
##  - hamowanie, a po zatrzymaniu (przytrzymanie hamulca) cofanie,
##  - skręt ograniczony przyczepnością (im szybciej, tym większy promień),
##  - prędkość obrotu narasta płynnie (brak niekontrolowanego wirowania),
##  - kontrolowany poślizg (drift) przy ostrym skręcie z hamulcem/przyciskiem drift,
##  - obracanie w miejscu przy małej prędkości (jak prawdziwy robot sprzątający).

signal collided(strength: float, world_position: Vector3, with_robot: bool, damage_amount: float)
signal dirt_collected(amount: float)

const LAYER_WORLD: int = 1
const LAYER_ROBOTS: int = 2

# ---------------------------------------------------------
# Parametry jazdy (bazowe; statystyki konkretnego robota z konfiguracji)
# ---------------------------------------------------------
@export_group("Jazda")
@export var max_speed: float = 2.59
@export var acceleration: float = 2.52
@export var grip: float = 7.5
@export var max_reverse_speed: float = 1.0
@export var reverse_acceleration: float = 1.75
@export var brake_force: float = 6.2
@export var coast_drag: float = 0.85
@export var gravity: float = 20.0

@export_group("Skręcanie")
@export var max_turn_rate: float = 3.25
@export var in_place_turn_rate: float = 2.0
@export var yaw_response: float = 12.0
@export var drift_grip_factor: float = 0.45

@export_group("Kolizje")
@export var bounce: float = 0.35

var is_player: bool = false
var config: Dictionary = {}
var display_name: String = "Robot"
var racer_index: int = 0

## Kierowca: obiekt z metodą update_input(robot: Robot, delta: float).
var driver: Node = null
## Czy robot może jechać (false podczas odliczania).
var can_drive: bool = false
## Robot jest chwilowo prowadzony przez system pit stopu.
var pit_controlled: bool = false
## Blokada jazdy po resecie pozycji; nie wpływa na AI ani pit stop.
var drive_locked: bool = false

# Wejście ustawiane przez kierowcę
var input_steer: float = 0.0
var input_throttle: float = 0.0
var input_brake: float = 0.0
var input_drift: bool = false
var _boost_requested: bool = false

# Stan (do odczytu przez HUD, AI, dźwięk, kamerę)
var forward_speed: float = 0.0
var lateral_speed: float = 0.0
var yaw_rate: float = 0.0
var is_reversing: bool = false
var is_drifting: bool = false
var lateral_grip_accel: float = 10.0

var _reverse_hold: float = 0.0
var _external_impulse: Vector3 = Vector3.ZERO
var _bounced_this_frame: bool = false

@onready var tank: DirtTank = $DirtTank
@onready var boost: BoostSystem = $BoostSystem
@onready var damage: DamageSystem = $DamageSystem
@onready var visuals: RobotVisuals = $Visuals
@onready var robot_audio: RobotAudio = $RobotAudio
@onready var energy: EnergySystem = $EnergySystem


func _ready() -> void:
	add_to_group("racers")
	collision_layer = LAYER_ROBOTS
	collision_mask = LAYER_WORLD | LAYER_ROBOTS
	floor_snap_length = 0.24
	floor_max_angle = deg_to_rad(48.0)
	floor_stop_on_slope = true
	wall_min_slide_angle = deg_to_rad(10.0)
	max_slides = 8
	safe_margin = 0.008

	# Robot wstawiony ręcznie do sceny (bez RaceScene) dostaje konfigurację domyślną.
	call_deferred("_ensure_setup")


func _ensure_setup() -> void:
	if config.is_empty():
		setup(RobotDatabase.build_config(0, RobotDatabase.empty_upgrades(), 0, 0), false, 0.0)


## Konfiguracja robota (statystyki po ulepszeniach i wygląd).
func setup(robot_config: Dictionary, player: bool, initial_damage: float) -> void:
	config = robot_config
	is_player = player
	display_name = str(config.get("name", "Robot"))

	max_speed = float(config.get("max_speed", max_speed))
	acceleration = float(config.get("acceleration", acceleration))
	grip = float(config.get("grip", grip)) * float(config.get("career_grip_multiplier", 1.0))

	if not is_node_ready():
		await ready

	tank.setup(float(config.get("capacity", 10.0)))	
	boost.setup(config, tank)
	energy.setup(config, true)
	boost.setup_runtime(self)
	damage.setup(initial_damage)
	damage.resistance_multiplier = clampf(float(config.get("damage_resistance_multiplier", 1.0)), 0.55, 1.0)
	visuals.build(config, is_player)
	robot_audio.setup(self)

	if not damage.impact.is_connected(_on_damage_impact):
		damage.impact.connect(_on_damage_impact)


# Kompatybilność ze starymi skryptami (current_speed, try_boost).
var current_speed: float:
	get:
		return forward_speed


func try_boost() -> void:
	request_boost()


func request_boost() -> void:
	_boost_requested = true


func get_lateral_grip() -> float:
	return lateral_grip_accel


func get_top_speed() -> float:
	var top: float = max_speed * damage.speed_multiplier()
	if boost.is_active():
		top *= boost.speed_multiplier
	top *= boost.get_shock_speed_multiplier()
	return top


func get_forward() -> Vector3:
	var forward: Vector3 = -global_transform.basis.z
	forward.y = 0.0
	return forward.normalized()


# =========================================================
# FIZYKA
# =========================================================

func _physics_process(delta: float) -> void:
	damage.tick(delta)
	boost.tick(delta)
	_bounced_this_frame = false

	if can_drive and not drive_locked and driver != null and is_instance_valid(driver):
		driver.call("update_input", self, delta)
	else:
		input_steer = 0.0
		input_throttle = 0.0
		input_brake = 0.0
		input_drift = false
		_boost_requested = false

	if _boost_requested:
		_boost_requested = false
		var regen_allowed: bool = boost.get_selected_id() == "energy_regenerator"
		if can_drive and not pit_controlled and (not energy.is_empty() or regen_allowed):
			boost.try_activate()

	if pit_controlled:
		# PitStopSystem steruje pozycją robota; wejście gazu pozostaje dostępne
		# dla przerwania serwisu.
		_hold_still(delta)
		var pit_incoming: Vector3 = velocity
		move_and_slide()
		_stabilize_landing()
		_handle_collisions(pit_incoming)
		forward_speed = 0.0
		lateral_speed = 0.0
		visuals.update_visuals(delta, self)
		return

	if can_drive and not drive_locked and not energy.is_empty():
		_apply_driving(delta)
	else:
		_hold_still(delta)

	var incoming: Vector3 = velocity
	move_and_slide()
	_stabilize_landing()
	_handle_collisions(incoming)

	var forward: Vector3 = get_forward()
	forward_speed = velocity.dot(forward)
	lateral_speed = velocity.dot(global_transform.basis.x)

	if can_drive and not drive_locked:
		energy.tick(delta, absf(forward_speed) / maxf(max_speed, 0.1), false)

	visuals.update_visuals(delta, self)


## Wygasza pionowy ruch po kontakcie z podłożem, żeby lądowanie nie
## powodowało kolejnych mikro-podbić i drgań CharacterBody3D.
func _stabilize_landing() -> void:
	if not is_on_floor():
		return
	# Po kontakcie z podłożem kasujemy całą składową pionową, także małe
	# dodatnie odbicie powodujące efekt ponownego podskakiwania. Ruch poziomy
	# pozostaje nietknięty, więc robot nie traci prędkości po zwykłym lądowaniu.
	velocity.y = 0.0


## Postój (odliczanie): robot stoi w miejscu, działa tylko grawitacja.
func _hold_still(delta: float) -> void:
	is_reversing = false
	is_drifting = false
	yaw_rate = 0.0
	_reverse_hold = 0.0
	var vertical: float = -0.5 if is_on_floor() else velocity.y - gravity * delta
	velocity = Vector3(move_toward(velocity.x, 0.0, brake_force * delta), vertical, move_toward(velocity.z, 0.0, brake_force * delta))


func _apply_driving(delta: float) -> void:
	var forward: Vector3 = get_forward()
	var right: Vector3 = global_transform.basis.x
	right.y = 0.0
	right = right.normalized()

	var v_long: float = velocity.dot(forward)
	var v_lat: float = velocity.dot(right)
	var v_vertical: float = velocity.y

	var top: float = get_top_speed()
	var accel: float = acceleration * damage.accel_multiplier() * boost.get_shock_accel_multiplier()
	accel *= boost.accel_multiplier

	var throttle: float = clampf(input_throttle, 0.0, 1.0)
	var braking: float = clampf(input_brake, 0.0, 1.0)

	# --- Gaz / hamulec / cofanie ---
	is_reversing = false
	if throttle > 0.05 and braking < 0.5:
		_reverse_hold = 0.0
		if v_long < -0.3:
			v_long = move_toward(v_long, 0.0, brake_force * boost.get_brake_multiplier() * delta)
		elif v_long > top:
			# Po zakończeniu boosta zwalniamy płynnie, a nie skokowo.
			v_long = move_toward(v_long, top, (coast_drag + 4.0) * delta)
		else:
			var ratio: float = clampf(v_long / maxf(top, 0.1), 0.0, 1.0)
			var effective: float = accel * (1.0 - 0.6 * ratio * ratio) * throttle
			v_long = minf(v_long + effective * delta, top * maxf(throttle, 0.3))
	elif braking > 0.05:
		if v_long > 0.4:
			_reverse_hold = 0.0
			v_long = move_toward(v_long, 0.0, brake_force * boost.get_brake_multiplier() * braking * delta)
		else:
			_reverse_hold += delta
			if _reverse_hold > 0.12 or v_long < -0.05:
				is_reversing = true
				v_long = move_toward(v_long, -max_reverse_speed * damage.speed_multiplier(), reverse_acceleration * delta)
	else:
		_reverse_hold = 0.0
		v_long = move_toward(v_long, 0.0, coast_drag * delta)

	# --- Skręcanie ograniczone przyczepnością ---
	var steer: float = clampf(input_steer + damage.steer_pull(), -1.0, 1.0)
	var speed_abs: float = absf(v_long)
	var speed_ratio: float = clampf(speed_abs / maxf(max_speed, 0.1), 0.0, 1.5)

	lateral_grip_accel = (3.5 + grip * 1.05) * damage.grip_multiplier() * boost.get_handling_multiplier()

	is_drifting = speed_ratio > 0.45 and absf(steer) > 0.5 and (input_drift or (braking > 0.5 and throttle > 0.5))

	var grip_limit: float = lateral_grip_accel * (1.3 if is_drifting else 1.0) / maxf(speed_abs, 0.5)
	var turn_rate: float = max_turn_rate * lerpf(1.0, 0.75, clampf(speed_ratio, 0.0, 1.0))
	var allowed_rate: float = minf(turn_rate, grip_limit)
	# Przy niskiej prędkości robot potrafi obracać się w miejscu.
	allowed_rate = maxf(allowed_rate, in_place_turn_rate * (1.0 - clampf(speed_abs / 1.5, 0.0, 1.0)))

	var target_yaw: float = -steer * allowed_rate
	if v_long < -0.3:
		target_yaw = -target_yaw

	yaw_rate = move_toward(yaw_rate, target_yaw, yaw_response * delta)

	var horizontal: Vector3 = forward * v_long + right * v_lat
	rotate_y(yaw_rate * delta)

	forward = get_forward()
	right = global_transform.basis.x
	right.y = 0.0
	right = right.normalized()

	var new_long: float = horizontal.dot(forward)
	var new_lat: float = horizontal.dot(right)

	# --- Przyczepność boczna (kontrolowany poślizg) ---
	var grip_factor: float = drift_grip_factor if is_drifting else 1.0
	var removed: float = minf(absf(new_lat), lateral_grip_accel * 1.6 * grip_factor * delta)
	new_lat = move_toward(new_lat, 0.0, removed)
	# Utrata części prędkości przy ślizgu (opór opon/szczotek).
	new_long = move_toward(new_long, 0.0, removed * 0.12)
	new_lat = clampf(new_lat, -maxf(1.5, absf(new_long) * 0.75), maxf(1.5, absf(new_long) * 0.75))

	# --- Grawitacja ---
	if is_on_floor():
		v_vertical = -0.5
	else:
		v_vertical -= gravity * delta

	velocity = forward * new_long + right * new_lat + Vector3.UP * v_vertical

	if _external_impulse != Vector3.ZERO:
		velocity += _external_impulse
		_external_impulse = Vector3.ZERO


# =========================================================
# KOLIZJE
# =========================================================

func _handle_collisions(incoming: Vector3) -> void:
	var count: int = get_slide_collision_count()
	for i: int in range(count):
		var collision: KinematicCollision3D = get_slide_collision(i)
		var normal: Vector3 = collision.get_normal()
		normal.y = 0.0
		if normal.length_squared() < 0.25:
			continue    # podłoga
		normal = normal.normalized()

		var into: float = -incoming.dot(normal)
		var collider: Object = collision.get_collider()
		if collider == null:
			continue

		var other: Robot = collider as Robot
		var impact_speed: float = into
		if other != null:
			impact_speed = maxf(-(incoming - other.velocity).dot(normal), 0.0)

		if impact_speed < 0.6:
			continue

		var hit_position: Vector3 = collision.get_position()
		var local_hit: Vector3 = to_local(hit_position)
		var damage_scale: float = 0.6 if other != null else 1.0
		var amount: float = damage.register_impact(impact_speed * damage_scale, collider.get_instance_id(), local_hit, hit_position)
		# Ręcznie przekazujemy uderzenie do małych fizycznych przedmiotów.
		# Dzięki temu RigidBody3D dostaje impuls także przy kolizji z CharacterBody3D.
		if other == null and collider is RigidBody3D and collider.has_method("receive_robot_impact"):
			collider.call("receive_robot_impact", self, incoming, impact_speed, hit_position)

		if other == null and boost.is_turbo_active():
			boost.apply_wall_impact()

		if not _bounced_this_frame and into > 0.5:
			_bounced_this_frame = true
			var reaction_multiplier: float = boost.get_collision_reaction_multiplier() if other != null else 1.0
			velocity += normal * into * bounce * reaction_multiplier
			# Tłumienie obrotu po uderzeniu - robot nie wpada w wirowanie.
			yaw_rate *= 0.3

		if other != null and amount >= 0.0:
			other.receive_robot_hit(self, -normal, impact_speed, hit_position, boost.get_collision_push_multiplier())

		if amount >= 0.0:
			collided.emit(clampf(impact_speed / 14.0, 0.0, 1.0), hit_position, other != null, amount)


## Wywoływane, gdy inny robot uderzy w tego robota.
func receive_robot_hit(other: Robot, push_direction: Vector3, impact_speed: float, hit_position: Vector3, push_multiplier: float = 1.0) -> void:
	push_direction.y = 0.0
	if push_direction.length_squared() > 0.001:
		_external_impulse += push_direction.normalized() * impact_speed * 0.45 * push_multiplier * boost.get_collision_reaction_multiplier()
	var amount: float = damage.register_impact(impact_speed * 0.6, other.get_instance_id(), to_local(hit_position), hit_position)
	if amount >= 0.0:
		collided.emit(clampf(impact_speed / 14.0, 0.0, 1.0), hit_position, true, amount)


func apply_impulse_velocity(impulse: Vector3) -> void:
	_external_impulse += impulse


func _on_damage_impact(strength: float, world_position: Vector3, _amount: float) -> void:
	visuals.play_impact(strength, world_position)


# =========================================================
# BRUD
# =========================================================

## Wywoływane przez DirtManager. Zwraca true, jeśli brud został przyjęty.
func collect_dirt(amount: float) -> bool:
	var accepted: float = tank.add(amount)
	if accepted > 0.0:
		dirt_collected.emit(accepted)
		return true
	return false


# =========================================================
# RESET POZYCJI (np. po wypadnięciu poza świat)
# =========================================================

func reset_to(new_transform: Transform3D, cancel_boost: bool = true) -> void:
	pit_controlled = false
	drive_locked = false
	global_transform = new_transform
	velocity = Vector3.ZERO
	yaw_rate = 0.0
	forward_speed = 0.0
	lateral_speed = 0.0
	_reverse_hold = 0.0
	_external_impulse = Vector3.ZERO
	input_steer = 0.0
	input_throttle = 0.0
	input_brake = 0.0
	input_drift = false
	is_reversing = false
	is_drifting = false
	if cancel_boost:
		boost.cancel()
	reset_physics_interpolation()
