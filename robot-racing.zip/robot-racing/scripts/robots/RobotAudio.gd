class_name RobotAudio
extends Node3D
## Dźwięki robota: praca silnika (wysokość zależna od prędkości), boost,
## kolizje, zbieranie brudu, odmowa boosta.

var _robot: Robot
var _engine: AudioStreamPlayer3D
var _update_timer: float = 0.0


func setup(robot: Robot) -> void:
	_robot = robot

	if _engine == null:
		_engine = AudioStreamPlayer3D.new()
		_engine.name = "Engine"
		_engine.bus = "Engine"
		_engine.unit_size = 4.0 if robot.is_player else 2.5
		_engine.max_distance = 30.0 if robot.is_player else 18.0
		_engine.attenuation_filter_cutoff_hz = 20500.0
		_engine.doppler_tracking = AudioStreamPlayer3D.DOPPLER_TRACKING_DISABLED
		add_child(_engine)

	_engine.stream = AudioManager.get_engine_stream(int(robot.config.get("engine_sound_profile", 0)))
	_engine.volume_db = -6.0 if robot.is_player else -12.0

	if not robot.boost.boost_started.is_connected(_on_boost_started):
		robot.boost.boost_started.connect(_on_boost_started)
		robot.boost.boost_denied.connect(_on_boost_denied)
		robot.collided.connect(_on_collided)
		robot.dirt_collected.connect(_on_dirt_collected)


func _process(delta: float) -> void:
	if _robot == null or _engine == null:
		return

	# Aktualizacja silnika 15 razy na sekundę wystarcza i oszczędza CPU.
	_update_timer -= delta
	if _update_timer > 0.0:
		return
	_update_timer = 0.066

	if not _engine.playing and _engine.stream != null:
		_engine.play()

	var speed_ratio: float = clampf(absf(_robot.forward_speed) / maxf(_robot.max_speed, 0.1), 0.0, 1.6)
	var upgrade_bass: float = clampf(float(_robot.config.get("engine_upgrade_level", 0)) * 0.006, 0.0, 0.12)
	var pitch: float = 0.55 + speed_ratio * 0.85 + (0.2 if _robot.boost.is_active() else 0.0) - upgrade_bass
	_engine.pitch_scale = lerpf(_engine.pitch_scale, pitch, 0.5)
	var base: float = -6.0 if _robot.is_player else -12.0
	_engine.volume_db = base - 6.0 + 6.0 * clampf(_robot.input_throttle + speed_ratio * 0.5, 0.0, 1.0)


func _on_boost_started() -> void:
	if _robot.is_player:
		AudioManager.play("boost", 0.0)
	else:
		AudioManager.play_at("boost", _robot.global_position, -4.0)


func _on_boost_denied(_reason: String) -> void:
	if _robot.is_player:
		AudioManager.play("denied", -4.0)


func _on_collided(strength: float, world_position: Vector3, _with_robot: bool, damage_amount: float) -> void:
	var sound: String = "hit" if damage_amount > 0.0 else "hit_light"
	var volume: float = lerpf(-14.0, 0.0, strength)
	if _robot.is_player:
		AudioManager.play(sound, volume, randf_range(0.9, 1.1))
		if damage_amount > 0.0:
			GameSettings.vibrate(int(lerpf(30.0, 120.0, strength)))
	else:
		AudioManager.play_at(sound, world_position, volume - 3.0, randf_range(0.9, 1.1))


func _on_dirt_collected(amount: float) -> void:
	if _robot.is_player:
		AudioManager.play("pickup", -3.0, 0.9 + amount * 0.05)
