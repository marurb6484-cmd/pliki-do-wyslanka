class_name RobotVisuals
extends Node3D

const BoostEffectsScript = preload("res://scripts/robots/BoostEffects.gd")
## Wygląd robota sprzątającego budowany proceduralnie (tanio na Androidzie).
##
## Modele odwzorowują prawdziwe odkurzacze automatyczne:
##  - gładka obudowa z lekko wypukłą pokrywą i ciemnym szklanym panelem,
##  - przedni zderzak z oknem czujników, świecące reflektory,
##  - wieżyczka LiDAR (modele z mapowaniem laserowym) lub kamera nawigacyjna,
##  - przycisk zasilania z pierścieniem LED, otwory zbiornika na kurz,
##  - szczotka boczna (jedna lub dwie) z obracającymi się włosiami,
##  - duże koła napędowe z bieżnikiem, które naprawdę się toczą.
## Kształty (id w RobotDatabase): disc = okrągły, wedge = typ „D”, square = zaokrąglony
## kwadrat, heavy = wysoki okrągły z dużym LiDAR-em, hex = ultra-płaski.
##
## Skórki działają w kategoriach znanych ze skórek mebli (fabryczna, realistyczna,
## kreskówkowa, neonowa, pastelowa) - zmieniają materiały, nie geometrię.
##
## Efekty boosta (turbo): dwie dysze z płomieniem (rdzeń + otoczka), strumień
## z shadera, smuga światła, iskry, błysk zapłonu i fala uderzeniowa.
## Wspólne siatki są tworzone raz i współdzielone przez wszystkie roboty.

static var _shared: Dictionary = {}

## Parametry bryły: a = półszerokość, bf/nf = głębokość i ostrość przodu,
## bb/nb = głębokość i ostrość tyłu (superelipsa), h = wysokość obudowy.
const SHAPES: Dictionary = {
	"disc": {"a": 0.70, "bf": 0.70, "nf": 2.0, "bb": 0.70, "nb": 2.0, "h": 0.38, "turret": 0, "camera": false, "brushes": 1, "arc": 150.0, "vents": false, "button_z": 0.02},
	"wedge": {"a": 0.70, "bf": 0.60, "nf": 6.0, "bb": 0.70, "nb": 2.0, "h": 0.37, "turret": 1, "camera": false, "brushes": 1, "arc": 170.0, "vents": true, "button_z": -0.24},
	"square": {"a": 0.72, "bf": 0.70, "nf": 3.4, "bb": 0.72, "nb": 3.4, "h": 0.40, "turret": 0, "camera": true, "brushes": 2, "arc": 150.0, "vents": true, "button_z": 0.06},
	"heavy": {"a": 0.72, "bf": 0.72, "nf": 2.0, "bb": 0.72, "nb": 2.0, "h": 0.43, "turret": 2, "camera": false, "brushes": 2, "arc": 200.0, "vents": true, "button_z": -0.30},
	"hex": {"a": 0.66, "bf": 0.66, "nf": 2.0, "bb": 0.66, "nb": 2.0, "h": 0.34, "turret": 0, "camera": false, "brushes": 1, "arc": 140.0, "vents": false, "button_z": 0.0},
	# Pięć odrębnych platform konstrukcyjnych inspirowanych referencjami użytkownika.
	# Wszystkie mieszczą się w dotychczasowej obwiedni robota (ok. 30–35 cm po skali 0.22).
	"model_dreame": {"a": 0.70, "bf": 0.70, "nf": 2.0, "bb": 0.70, "nb": 2.0, "h": 0.36, "turret": 0, "camera": false, "brushes": 1, "arc": 155.0, "vents": false, "button_z": -0.20},
	"model_saros": {"a": 0.70, "bf": 0.62, "nf": 5.2, "bb": 0.68, "nb": 4.2, "h": 0.363, "turret": 0, "camera": false, "brushes": 2, "arc": 165.0, "vents": false, "button_z": 0.30},
	"model_roomba": {"a": 0.70, "bf": 0.59, "nf": 6.0, "bb": 0.70, "nb": 2.0, "h": 0.395, "turret": 0, "camera": false, "brushes": 1, "arc": 175.0, "vents": true, "button_z": 0.28},
	"model_xiaomi": {"a": 0.70, "bf": 0.70, "nf": 2.0, "bb": 0.70, "nb": 2.0, "h": 0.44, "turret": 0, "camera": false, "brushes": 1, "arc": 155.0, "vents": false, "button_z": -0.24},
	"model_narwal": {"a": 0.70, "bf": 0.70, "nf": 2.0, "bb": 0.70, "nb": 2.0, "h": 0.47, "turret": 0, "camera": false, "brushes": 2, "arc": 155.0, "vents": false, "button_z": 0.24},
	# Pięć nowych platform dodanych bez zmiany istniejących modeli.
	"spider": {"a": 0.72, "bf": 0.66, "nf": 3.0, "bb": 0.72, "nb": 2.6, "h": 0.20, "turret": 0, "camera": false, "brushes": 1, "arc": 155.0, "vents": false, "button_z": -0.18, "wheel_scale": 0.8, "style": "spider"},
	"slimarm": {"a": 0.68, "bf": 0.68, "nf": 2.2, "bb": 0.68, "nb": 2.2, "h": 0.17, "turret": 0, "camera": false, "brushes": 1, "arc": 165.0, "vents": false, "button_z": 0.26, "wheel_scale": 0.7, "style": "slimarm"},
	"roomba": {"a": 0.70, "bf": 0.70, "nf": 2.0, "bb": 0.70, "nb": 2.0, "h": 0.25, "turret": 0, "camera": false, "brushes": 1, "arc": 230.0, "vents": false, "button_z": 0.0, "matte": true, "style": "roomba"},
	"periscope": {"a": 0.70, "bf": 0.70, "nf": 2.0, "bb": 0.70, "nb": 2.0, "h": 0.24, "turret": 2, "camera": false, "brushes": 1, "arc": 155.0, "vents": true, "button_z": -0.34, "style": "periscope"},
	"whale": {"a": 0.70, "bf": 0.60, "nf": 2.0, "bb": 0.70, "nb": 2.0, "h": 0.22, "turret": 0, "camera": false, "brushes": 2, "arc": 155.0, "vents": false, "button_z": 0.24, "wheel_scale": 0.85, "style": "whale"},
}

var is_player: bool = false
var ghost: bool = false
var config: Dictionary = {}

var _shape_id: String = "disc"
var _shape: Dictionary = {}
var _category: String = "factory"

var _body_material: StandardMaterial3D
var _trim_material: StandardMaterial3D
var _panel_material: StandardMaterial3D
var _bumper_material: StandardMaterial3D
var _lens_material: StandardMaterial3D
var _neon_material: StandardMaterial3D
var _thruster_material: StandardMaterial3D
var _led_material: StandardMaterial3D

var _model: Node3D
var _top_plate: Node3D
var _brush_left: Node3D
var _brush_right: Node3D
var _wheel_left: Node3D
var _wheel_right: Node3D
var _neon_light: OmniLight3D
var _head_light: SpotLight3D
var _smoke: CPUParticles3D
var _sparks: CPUParticles3D
var _boost_glow: OmniLight3D

# Efekty boosta
var _nozzle_points: Array[Vector3] = []
var _jets: Array[MeshInstance3D] = []
var _vfx_emitters: Array = []        # [CPUParticles3D, bazowa liczba cząstek]
var _flame_emitters: Array[CPUParticles3D] = []
var _trail: CPUParticles3D
var _boost_sparks: CPUParticles3D
var _ignite_sparks: CPUParticles3D

var _primary: Color = Color.WHITE
var _neon_color: Color = Color.CYAN
var _last_damage: float = -1.0
var _flicker_time: float = 0.0
var _boost_visual: bool = false
var _boost_level: float = 0.0
var _ignite_time: float = 0.0
var _vfx_time: float = 0.0
var _built: bool = false
var _vfx_scale: float = 1.0
var _upgrade_levels: Dictionary = {}
var _accent_material: StandardMaterial3D
var _glass_material: StandardMaterial3D


# =========================================================
# BUDOWA
# =========================================================

func build(robot_config: Dictionary, player: bool, as_ghost: bool = false) -> void:
	config = robot_config
	is_player = player
	ghost = as_ghost

	for child: Node in get_children():
		child.queue_free()
	_jets.clear()
	_vfx_emitters.clear()
	_vfx_scale = 1.0
	_flame_emitters.clear()
	_nozzle_points.clear()
	_trail = null
	_boost_sparks = null
	_ignite_sparks = null
	_neon_light = null
	_head_light = null
	_boost_glow = null
	_smoke = null
	_sparks = null
	_brush_left = null
	_brush_right = null

	_shape_id = str(config.get("shape", "disc"))
	if not SHAPES.has(_shape_id):
		_shape_id = "disc"
	_shape = SHAPES[_shape_id]
	_category = str(config.get("skin_category", "factory"))

	_primary = config.get("primary_color", Color(0.9, 0.9, 0.92))
	_neon_color = config.get("neon_color", Color(0.0, 0.9, 1.0))
	var secondary: Color = config.get("secondary_color", Color(0.12, 0.16, 0.2))
	_create_materials(secondary)

	_model = Node3D.new()
	_model.name = "Model"
	add_child(_model)

	_build_body()
	_build_details()
	_upgrade_levels = config.get("upgrade_levels", {})
	if not ghost:
		_build_upgrade_visuals()
		_build_boost_modules()

	if ghost:
		_apply_ghost_look()
	else:
		_build_lights()
		_build_particles()
		_build_jets()

	# Cała bryła ma bazowo ok. 1,4–1,56 m; skala 0,22 daje ok. 31,7–34,3 cm.
	# Jednolita skala zachowuje proporcje modeli, ulepszeń i części zamiennych.
	_model.scale = Vector3.ONE * 0.22
	_built = true
	_last_damage = -1.0
	apply_graphics()
	if not GameSettings.graphics_changed.is_connected(apply_graphics):
		GameSettings.graphics_changed.connect(apply_graphics)


func _exit_tree() -> void:
	if GameSettings.graphics_changed.is_connected(apply_graphics):
		GameSettings.graphics_changed.disconnect(apply_graphics)


func _create_materials(secondary: Color) -> void:
	var metallic: float = clampf(float(config.get("metallic", 0.15)), 0.0, 0.6)
	var roughness: float = clampf(float(config.get("roughness", 0.4)), 0.15, 0.9)

	_body_material = StandardMaterial3D.new()
	_body_material.albedo_color = _primary
	_body_material.metallic = metallic
	_body_material.roughness = roughness
	if bool(_shape.get("matte", false)):
		_body_material.metallic = minf(_body_material.metallic, 0.05)
		_body_material.roughness = maxf(_body_material.roughness, 0.8)
		_body_material.clearcoat_enabled = false
	elif _category != "pastel":
		# Lakierowany plastik: delikatna warstwa połysku jak w prawdziwych robotach.
		_body_material.clearcoat_enabled = true
		_body_material.clearcoat = 0.75 if _category == "cartoon" else 0.5
		_body_material.clearcoat_roughness = 0.18

	_trim_material = StandardMaterial3D.new()
	_trim_material.albedo_color = secondary
	_trim_material.metallic = 0.55
	_trim_material.roughness = 0.3
	if _category == "neon":
		_trim_material.emission_enabled = true
		_trim_material.emission = secondary
		_trim_material.emission_energy_multiplier = 1.8

	_panel_material = StandardMaterial3D.new()
	_panel_material.albedo_color = Color(0.016, 0.02, 0.028) if _category != "pastel" else Color(0.2, 0.22, 0.26)
	_panel_material.metallic = 0.5
	_panel_material.roughness = 0.1
	_panel_material.clearcoat_enabled = true
	_panel_material.clearcoat = 1.0
	_panel_material.clearcoat_roughness = 0.05

	_bumper_material = StandardMaterial3D.new()
	_bumper_material.albedo_color = Color(0.055, 0.06, 0.07)
	_bumper_material.metallic = 0.1
	_bumper_material.roughness = 0.55
	if _category == "pastel" or _category == "cartoon":
		_bumper_material.albedo_color = secondary
		_bumper_material.roughness = 0.5

	_lens_material = StandardMaterial3D.new()
	_lens_material.albedo_color = Color(0.9, 0.96, 1.0)
	_lens_material.emission_enabled = true
	_lens_material.emission = Color(0.95, 0.97, 1.0)
	_lens_material.emission_energy_multiplier = 2.5

	_neon_material = StandardMaterial3D.new()
	_neon_material.albedo_color = _neon_color
	_neon_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_neon_material.emission_enabled = true
	_neon_material.emission = _neon_color
	_neon_material.emission_energy_multiplier = 3.0

	_thruster_material = StandardMaterial3D.new()
	_thruster_material.albedo_color = Color(0.06, 0.06, 0.07)
	_thruster_material.metallic = 0.7
	_thruster_material.roughness = 0.35
	_thruster_material.emission_enabled = true
	_thruster_material.emission = Color(1.0, 0.45, 0.1)
	_thruster_material.emission_energy_multiplier = 0.0

	_led_material = StandardMaterial3D.new()
	_led_material.albedo_color = _neon_color
	_led_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_led_material.emission_enabled = true
	_led_material.emission = _neon_color
	_led_material.emission_energy_multiplier = 2.2

	# Materiały robota mają osobny priorytet renderowania względem oznaczeń jezdni.
	# Zachowujemy kolory i wygląd skórek, ale bryła robota nie powinna ginąć pod liniami.
	for robot_material: StandardMaterial3D in [_body_material, _trim_material, _panel_material, _bumper_material, _lens_material, _neon_material, _thruster_material, _led_material]:
		robot_material.render_priority = 2


# =========================================================
# SIATKI (wspólne)
# =========================================================

static func _get_mesh(key: String) -> Mesh:
	if _shared.has(key):
		return _shared[key]

	var mesh: Mesh
	match key:
		"tire":
			var tire := CylinderMesh.new()
			tire.top_radius = 0.17
			tire.bottom_radius = 0.17
			tire.height = 0.13
			tire.radial_segments = 22
			tire.rings = 1
			mesh = tire
		"hub":
			var hub := CylinderMesh.new()
			hub.top_radius = 0.095
			hub.bottom_radius = 0.095
			hub.height = 0.142
			hub.radial_segments = 12
			hub.rings = 1
			mesh = hub
		"tread":
			var tread := BoxMesh.new()
			tread.size = Vector3(0.136, 0.035, 0.05)
			mesh = tread
		"brush_hub":
			var brush_hub := CylinderMesh.new()
			brush_hub.top_radius = 0.045
			brush_hub.bottom_radius = 0.055
			brush_hub.height = 0.05
			brush_hub.radial_segments = 12
			brush_hub.rings = 1
			mesh = brush_hub
		"arm":
			var arm := BoxMesh.new()
			arm.size = Vector3(0.30, 0.012, 0.034)
			mesh = arm
		"tip":
			var tip := SphereMesh.new()
			tip.radius = 0.032
			tip.height = 0.05
			tip.radial_segments = 8
			tip.rings = 3
			mesh = tip
		"turret_base":
			var base := CylinderMesh.new()
			base.top_radius = 0.15
			base.bottom_radius = 0.17
			base.height = 0.05
			base.radial_segments = 28
			base.rings = 1
			mesh = base
		"turret_cap":
			var cap := CylinderMesh.new()
			cap.top_radius = 0.125
			cap.bottom_radius = 0.14
			cap.height = 0.045
			cap.radial_segments = 28
			cap.rings = 1
			mesh = cap
		"turret_window":
			var window := BoxMesh.new()
			window.size = Vector3(0.20, 0.018, 0.012)
			mesh = window
		"button":
			var button := CylinderMesh.new()
			button.top_radius = 0.08
			button.bottom_radius = 0.085
			button.height = 0.016
			button.radial_segments = 24
			button.rings = 1
			mesh = button
		"led_ring":
			var led := TorusMesh.new()
			led.inner_radius = 0.083
			led.outer_radius = 0.104
			led.rings = 28
			led.ring_segments = 6
			mesh = led
		"small_button":
			var small := CylinderMesh.new()
			small.top_radius = 0.03
			small.bottom_radius = 0.032
			small.height = 0.012
			small.radial_segments = 14
			small.rings = 1
			mesh = small
		"slot":
			var slot := BoxMesh.new()
			slot.size = Vector3(0.30, 0.006, 0.016)
			mesh = slot
		"lens":
			var lens := BoxMesh.new()
			lens.size = Vector3(0.11, 0.042, 0.022)
			mesh = lens
		"window":
			var window := BoxMesh.new()
			window.size = Vector3(0.50, 0.052, 0.02)
			mesh = window
		"camera_eye":
			var eye := CylinderMesh.new()
			eye.top_radius = 0.045
			eye.bottom_radius = 0.05
			eye.height = 0.012
			eye.radial_segments = 16
			eye.rings = 1
			mesh = eye
		"nozzle":
			var nozzle := BoxMesh.new()
			nozzle.size = Vector3(0.22, 0.07, 0.05)
			mesh = nozzle
		"nozzle_glow":
			var glow := BoxMesh.new()
			glow.size = Vector3(0.17, 0.028, 0.012)
			mesh = glow
		"neon":
			var ring := TorusMesh.new()
			ring.inner_radius = 0.7
			ring.outer_radius = 0.8
			ring.rings = 24
			ring.ring_segments = 4
			mesh = ring
		"jet":
			# Stożek: szeroka podstawa (+Y) przy dyszy, czubek (-Y) z tyłu.
			var jet := CylinderMesh.new()
			jet.top_radius = 0.085
			jet.bottom_radius = 0.0
			jet.height = 1.0
			jet.radial_segments = 10
			jet.rings = 1
			mesh = jet
		"shock_ring":
			var shock := TorusMesh.new()
			shock.inner_radius = 0.9
			shock.outer_radius = 1.0
			shock.rings = 36
			shock.ring_segments = 4
			mesh = shock
		"particle":
			var quad := QuadMesh.new()
			quad.size = Vector2(0.25, 0.25)
			mesh = quad

	_shared[key] = mesh
	return mesh


## Obrys bryły we współrzędnych biegunowych (superelipsa osobno dla przodu i tyłu).
static func _outline(shape: Dictionary, phi: float) -> float:
	var cos_part: float = absf(cos(phi))
	var sin_value: float = sin(phi)
	var front: bool = sin_value < 0.0
	var a: float = float(shape["a"])
	var b: float = float(shape["bf"]) if front else float(shape["bb"])
	var n: float = float(shape["nf"]) if front else float(shape["nb"])
	var term: float = pow(cos_part / a, n) + pow(absf(sin_value) / b, n)
	return pow(maxf(term, 0.000001), -1.0 / n)


## Odległość krawędzi obrysu od środka wzdłuż osi Z dla danego x (wartość dodatnia).
static func _edge_z(shape: Dictionary, x_value: float, front: bool) -> float:
	var a: float = float(shape["a"])
	var b: float = float(shape["bf"]) if front else float(shape["bb"])
	var n: float = float(shape["nf"]) if front else float(shape["nb"])
	var t: float = clampf(1.0 - pow(minf(absf(x_value) / a, 1.0), n), 0.0, 1.0)
	return b * pow(t, 1.0 / n)


## Bryła obrotowa po obrysie. `profile` to lista Vector2(skala obrysu, wysokość),
## uporządkowana od GÓRY do DOŁU (zgodnie z kolejnością wierzchołków Godota).
static func _lathe(shape: Dictionary, profile: Array, segments: int, phi_from: float, phi_to: float) -> ArrayMesh:
	var rings: int = profile.size()
	var full: bool = absf((phi_to - phi_from) - TAU) < 0.001
	var grid: Array = []
	for i: int in range(rings):
		var row := PackedVector3Array()
		var profile_point: Vector2 = profile[i]
		for j: int in range(segments + 1):
			var phi: float = phi_from + (phi_to - phi_from) * float(j) / float(segments)
			var radius: float = _outline(shape, phi) * profile_point.x
			row.append(Vector3(radius * cos(phi), profile_point.y, radius * sin(phi)))
		grid.append(row)

	var verts := PackedVector3Array()
	var norms := PackedVector3Array()
	var indices := PackedInt32Array()
	for i: int in range(rings):
		var row: PackedVector3Array = grid[i]
		var previous_row: PackedVector3Array = grid[maxi(i - 1, 0)]
		var next_row: PackedVector3Array = grid[mini(i + 1, rings - 1)]
		for j: int in range(segments + 1):
			verts.append(row[j])
			var j_before: int = posmod(j - 1, segments) if full else maxi(j - 1, 0)
			var j_after: int = posmod(j + 1, segments) if full else mini(j + 1, segments)
			var along_phi: Vector3 = row[j_after] - row[j_before]
			var along_profile: Vector3 = next_row[j] - previous_row[j]
			var normal: Vector3 = along_phi.cross(along_profile)
			if normal.length_squared() < 0.0000001:
				normal = Vector3.UP if i == 0 else Vector3.DOWN
			norms.append(normal.normalized())
	for i: int in range(rings - 1):
		for j: int in range(segments):
			var a_index: int = i * (segments + 1) + j
			var b_index: int = a_index + segments + 1
			indices.append(a_index)
			indices.append(b_index)
			indices.append(a_index + 1)
			indices.append(a_index + 1)
			indices.append(b_index)
			indices.append(b_index + 1)

	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = norms
	arrays[Mesh.ARRAY_INDEX] = indices
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return mesh


func _body_part_mesh(part: String) -> Mesh:
	var key: String = "lathe|%s|%s" % [_shape_id, part]
	if _shared.has(key):
		return _shared[key]
	var h: float = float(_shape["h"])
	var base_y: float = 0.045
	var span: float = h - base_y
	var mesh: ArrayMesh
	match part:
		"shell":
			var fractions: Array[Vector2] = [
				Vector2(0.0, 0.0), Vector2(0.35, 0.0), Vector2(0.72, 0.02), Vector2(0.90, 0.10),
				Vector2(0.965, 0.28), Vector2(0.995, 0.50), Vector2(1.0, 0.62), Vector2(1.0, 0.82),
				Vector2(0.985, 0.93), Vector2(0.94, 1.0), Vector2(0.0, 1.0)
			]
			var profile: Array = []
			for f: Vector2 in fractions:
				profile.append(Vector2(f.x, h - span * f.y))
			mesh = _lathe(_shape, profile, 56, 0.0, TAU)
		"panel":
			var top_y: float = h + 0.007
			mesh = _lathe(_shape, [Vector2(0.0, top_y), Vector2(0.57, top_y), Vector2(0.615, top_y - 0.006), Vector2(0.615, h - 0.012)], 56, 0.0, TAU)
		"rim":
			mesh = _lathe(_shape, [Vector2(0.618, h + 0.0035), Vector2(0.64, h + 0.0045), Vector2(0.66, h + 0.0015), Vector2(0.668, h - 0.006)], 56, 0.0, TAU)
		"bumper":
			var y_low: float = 0.082
			var y_high: float = minf(0.205, h - 0.045)
			var arc: float = deg_to_rad(float(_shape["arc"]))
			var profile_b: Array = [
				Vector2(1.0, y_high), Vector2(1.016, y_high - 0.014), Vector2(1.025, (y_low + y_high) * 0.5),
				Vector2(1.017, y_low + 0.012), Vector2(1.0, y_low)
			]
			mesh = _lathe(_shape, profile_b, 40, -PI * 0.5 - arc * 0.5, -PI * 0.5 + arc * 0.5)
	_shared[key] = mesh
	return mesh


func _add_mesh_obj(mesh: Mesh, material: Material, position_value: Vector3, rotation_value: Vector3 = Vector3.ZERO, scale_value: Vector3 = Vector3.ONE, parent: Node3D = null) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	instance.mesh = mesh
	instance.material_override = material
	instance.position = position_value
	instance.rotation = rotation_value
	instance.scale = scale_value
	(parent if parent != null else _model).add_child(instance)
	return instance


func _add_mesh(mesh_key: String, material: Material, position_value: Vector3, rotation_value: Vector3 = Vector3.ZERO, scale_value: Vector3 = Vector3.ONE, parent: Node3D = null) -> MeshInstance3D:
	return _add_mesh_obj(_get_mesh(mesh_key), material, position_value, rotation_value, scale_value, parent)


func _build_body() -> void:
	var shell: MeshInstance3D = _add_mesh_obj(_body_part_mesh("shell"), _body_material, Vector3.ZERO)
	shell.name = "Shell"
	var bumper: MeshInstance3D = _add_mesh_obj(_body_part_mesh("bumper"), _bumper_material, Vector3.ZERO)
	bumper.name = "Bumper"
	var rim: MeshInstance3D = _add_mesh_obj(_body_part_mesh("rim"), _trim_material, Vector3.ZERO)
	rim.name = "LidRim"
	_top_plate = _add_mesh_obj(_body_part_mesh("panel"), _panel_material, Vector3.ZERO)
	_top_plate.name = "TopPanel"


func _build_details() -> void:
	var h: float = float(_shape["h"])
	var shape_a: float = float(_shape["a"])
	var button_z: float = float(_shape["button_z"])
	var turret: int = int(_shape["turret"])

	# --- Koła napędowe ukryte całkowicie wewnątrz obudowy ---
	# Opony i piasty pozostają elementami mechanicznymi/animowanymi, ale nie
	# wystają przez boczną ani dolną powierzchnię skorupy.
	_wheel_left = _build_wheel()
	var wheel_scale: float = float(_shape.get("wheel_scale", 1.0))
	_wheel_left.position = Vector3(-shape_a * 0.24, 0.27, 0.035)
	_wheel_left.scale = Vector3.ONE * 0.35 * Vector3(1.0, wheel_scale, wheel_scale)
	_wheel_right = _build_wheel()
	_wheel_right.position = Vector3(shape_a * 0.24, 0.27, 0.035)
	_wheel_right.scale = Vector3.ONE * 0.35 * Vector3(1.0, wheel_scale, wheel_scale)

	# --- Szczotki boczne (przy przednich narożnikach, wystają poza obrys) ---
	var brush_count: int = int(_shape["brushes"])
	var brush_x: float = shape_a * 0.66
	var brush_z: float = -_edge_z(_shape, brush_x, true) * 0.82
	_brush_left = _build_brush(Vector3(-brush_x, 0.062, brush_z))
	if brush_count >= 2:
		_brush_right = _build_brush(Vector3(brush_x, 0.062, brush_z))

	# Pięć modeli ma własne, rozpoznawalne zespoły czujników i modułów.
	# Wspólne pozostają koła, szczotki, punkty boosta i podwozie wyścigowe.
	if _shape_id.begins_with("model_"):
		_build_signature_details(h, shape_a)
		return

	# --- Wieżyczka LiDAR ---
	if turret > 0:
		var scale_factor: float = 1.0 if turret == 1 else 1.28
		var turret_z: float = 0.14
		var base_mesh: MeshInstance3D = _add_mesh("turret_base", _trim_material, Vector3(0.0, h + 0.022, turret_z), Vector3.ZERO, Vector3(scale_factor, 1.0, scale_factor))
		base_mesh.name = "LidarBase"
		var cap_mesh: MeshInstance3D = _add_mesh("turret_cap", _panel_material, Vector3(0.0, h + 0.066, turret_z), Vector3.ZERO, Vector3(scale_factor, 1.0, scale_factor))
		cap_mesh.name = "LidarCap"
		# Szczeliny okna lasera dookoła czapki.
		for k: int in range(4):
			var angle: float = float(k) * PI * 0.5 + PI * 0.25
			var window_pos := Vector3(cos(angle) * 0.128 * scale_factor, h + 0.066, turret_z + sin(angle) * 0.128 * scale_factor)
			_add_mesh("turret_window", _led_material, window_pos, Vector3(0.0, -angle + PI * 0.5, 0.0), Vector3(0.7 * scale_factor, 0.4, 1.0))

	# --- Kamera nawigacyjna (model kwadratowy) ---
	if bool(_shape["camera"]):
		var camera_z: float = -_edge_z(_shape, 0.0, true) * 0.62
		_add_mesh("camera_eye", _panel_material, Vector3(0.0, h + 0.004, camera_z))
		_add_mesh("camera_eye", _trim_material, Vector3(0.0, h + 0.001, camera_z), Vector3.ZERO, Vector3(1.45, 0.6, 1.45))
		_add_mesh("camera_eye", _lens_material, Vector3(0.0, h + 0.011, camera_z), Vector3.ZERO, Vector3(0.45, 0.4, 0.45))

	# --- Przyciski i pierścień LED ---
	var button_node: MeshInstance3D = _add_mesh("button", _trim_material, Vector3(0.0, h + 0.014, button_z))
	button_node.name = "PowerButton"
	var led: MeshInstance3D = _add_mesh("led_ring", _led_material, Vector3(0.0, h + 0.018, button_z), Vector3.ZERO, Vector3(1.0, 0.35, 1.0))
	led.name = "StatusLed"
	led.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	for side: float in [-1.0, 1.0]:
		_add_mesh("small_button", _trim_material, Vector3(side * 0.2, h + 0.012, button_z + 0.02))

	# --- Otwory zbiornika na kurz ---
	if bool(_shape["vents"]):
		for k: int in range(4):
			_add_mesh("slot", _panel_material, Vector3(0.0, h + 0.004, 0.36 + float(k) * 0.045))

	# --- Okno czujników i reflektory na przednim zderzaku ---
	var front_z: float = -_edge_z(_shape, 0.0, true) * 1.025
	var window_y: float = minf(0.15, h - 0.075)
	var window_node: MeshInstance3D = _add_mesh("window", _panel_material, Vector3(0.0, window_y, front_z - 0.002))
	window_node.name = "SensorWindow"
	var lens_x: float = 0.27
	var lens_z: float = -_edge_z(_shape, lens_x, true) * 1.025 - 0.003
	for side: float in [-1.0, 1.0]:
		_add_mesh("lens", _lens_material, Vector3(side * lens_x, window_y, lens_z))

	# --- Dysze turbo (z tyłu, żarzą się podczas boosta) ---
	var rear_y: float = minf(0.135, h - 0.09)
	for side: float in [-1.0, 1.0]:
		var nozzle_x: float = side * 0.24
		var nozzle_z: float = _edge_z(_shape, nozzle_x, false) * 1.01
		_add_mesh("nozzle", _bumper_material, Vector3(nozzle_x, rear_y, nozzle_z))
		_add_mesh("nozzle_glow", _thruster_material, Vector3(nozzle_x, rear_y, nozzle_z + 0.028))
		_nozzle_points.append(Vector3(nozzle_x, rear_y, nozzle_z + 0.04))

	# --- Podświetlenie pod podwoziem ---
	var neon_scale: float = shape_a / 0.70
	var neon := _add_mesh("neon", _neon_material, Vector3(0.0, 0.05, 0.0), Vector3.ZERO, Vector3(neon_scale, 0.3, neon_scale))
	neon.name = "NeonRing"
	neon.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_build_style_details()


## Charakterystyczne detale pięciu nowych platform. Geometria jest proceduralna i lekka.
func _build_style_details() -> void:
	var style: String = str(_shape.get("style", ""))
	if style.is_empty():
		return
	var h: float = float(_shape["h"])
	var a: float = float(_shape["a"])
	var front: float = _edge_z(_shape, 0.0, true)
	var rear: float = _edge_z(_shape, 0.0, false)
	var front_y: float = minf(0.15, h - 0.045)
	var metal: StandardMaterial3D = _make_metal(Color(0.5, 0.52, 0.56), 0.75, 0.32)
	var dark_metal: StandardMaterial3D = _make_metal(Color(0.12, 0.13, 0.15), 0.65, 0.38)
	var eye_glow: StandardMaterial3D = _make_glow(Color(0.55, 0.8, 1.0), 1.6)
	var pad_material: StandardMaterial3D = _make_metal(Color(0.72, 0.73, 0.75), 0.02, 0.92)
	match style:
		"spider":
			# Płaski czujnik dToF, przednie kamery, wysunięta szczotka i tylne pady.
			_cyl(0.125, 0.012, _trim_material, Vector3(0.0, h + 0.006, -front * 0.38))
			_cyl(0.105, 0.018, _panel_material, Vector3(0.0, h + 0.018, -front * 0.38))
			for side: float in [-1.0, 1.0]:
				var cam_x: float = side * 0.20
				var cam_z: float = -_edge_z(_shape, absf(cam_x), true) * 1.02 - 0.008
				_cyl(0.052, 0.022, _panel_material, Vector3(cam_x, front_y, cam_z), Vector3(PI * 0.5, 0.0, 0.0))
				_cyl(0.026, 0.024, eye_glow, Vector3(cam_x, front_y, cam_z - 0.004), Vector3(PI * 0.5, 0.0, 0.0))
			if _brush_left != null:
				var arm_x: float = a + 0.34
				var arm_z: float = -front * 0.58
				_brush_left.position = Vector3(-arm_x, 0.062, arm_z)
				_box(Vector3(arm_x - a * 0.52, 0.028, 0.045), dark_metal, Vector3(-(arm_x + a * 0.52) * 0.5, 0.075, arm_z))
				_sphere(0.035, metal, Vector3(-a * 0.58, 0.075, arm_z))
			for side: float in [-1.0, 1.0]:
				_cyl(0.18, 0.022, pad_material, Vector3(side * 0.29, 0.035, rear * 0.86))
		"slimarm":
			# Ultra-płaska platforma z ramieniem i podwójną kamerą.
			_cyl(0.105, 0.018, _trim_material, Vector3(0.0, h + 0.012, 0.10))
			_sphere(0.035, metal, Vector3(0.0, h + 0.035, 0.10))
			_box(Vector3(0.07, 0.032, 0.30), metal, Vector3(0.0, h + 0.055, 0.25))
			_sphere(0.03, dark_metal, Vector3(0.0, h + 0.075, 0.40))
			_box(Vector3(0.055, 0.026, 0.23), dark_metal, Vector3(0.0, h + 0.09, 0.31))
			for side: float in [-1.0, 1.0]:
				var cam_x: float = side * 0.15
				var cam_z: float = -_edge_z(_shape, absf(cam_x), true) * 1.02 - 0.008
				_cyl(0.06, 0.024, _panel_material, Vector3(cam_x, front_y, cam_z), Vector3(PI * 0.5, 0.0, 0.0))
				_cyl(0.03, 0.026, eye_glow, Vector3(cam_x, front_y, cam_z - 0.004), Vector3(PI * 0.5, 0.0, 0.0))
			_sphere(0.012, _make_glow(Color(1.0, 0.55, 0.2), 2.0), Vector3(0.0, h + 0.10, 0.40))
		"roomba":
			# Matowa, klasyczna okrągła obudowa z kamerą i tylną klapą mopa.
			_box(Vector3(0.48, 0.012, 0.26), _trim_material, Vector3(0.0, h + 0.006, 0.10))
			_box(Vector3(0.42, 0.008, 0.22), _panel_material, Vector3(0.0, h + 0.014, 0.10))
			_box(Vector3(0.42, 0.045, 0.022), _panel_material, Vector3(0.0, front_y, -front * 1.02))
			_cyl(0.045, 0.018, eye_glow, Vector3(0.0, front_y + 0.004, -front * 1.04), Vector3(PI * 0.5, 0.0, 0.0))
			_box(Vector3(0.30, 0.018, 0.20), pad_material, Vector3(0.0, h + 0.018, rear * 0.55))
			_box(Vector3(0.26, 0.012, 0.018), dark_metal, Vector3(0.0, h + 0.028, rear * 0.55 - 0.10))
		"periscope":
			# Szeroki sensor strukturalny i wysunięty tylny moduł mopujący.
			_box(Vector3(0.76, 0.042, 0.022), _panel_material, Vector3(0.0, front_y + 0.025, -front * 1.02))
			for side: float in [-1.0, 1.0]:
				_box(Vector3(0.045, 0.014, 0.012), _make_glow(Color(1.0, 0.28, 0.22), 1.8), Vector3(side * 0.30, front_y + 0.025, -front * 1.04))
			_box(Vector3(0.82, 0.045, 0.28), pad_material, Vector3(0.0, 0.055, rear * 0.95))
			_box(Vector3(0.82, 0.012, 0.25), dark_metal, Vector3(0.0, 0.082, rear * 0.95))
		"whale":
			# Opływowa bryła, kamery AI, boczny czujnik i dwa tylne pady.
			for side: float in [-1.0, 1.0]:
				var cam_x: float = side * 0.17
				var cam_z: float = -_edge_z(_shape, absf(cam_x), true) * 1.0
				_cyl(0.062, 0.022, _panel_material, Vector3(cam_x, front_y, cam_z), Vector3(PI * 0.5, 0.0, 0.0))
				_cyl(0.03, 0.024, eye_glow, Vector3(cam_x, front_y, cam_z - 0.004), Vector3(PI * 0.5, 0.0, 0.0))
				_cyl(0.22, 0.022, pad_material, Vector3(side * 0.32, 0.035, rear * 0.78))
			_box(Vector3(0.025, 0.05, 0.12), dark_metal, Vector3(-a * 0.98, 0.14, -0.20))


## Charakterystyczne elementy pięciu modeli. Używa wyłącznie prostych siatek Godota
## i StandardMaterial3D, więc nie zależy od SSR, SDFGI, SSAO, glow ani jakości cieni.
func _build_signature_details(h: float, shape_a: float) -> void:
	var dark_glass: StandardMaterial3D = _make_metal(Color(0.012, 0.018, 0.026), 0.42, 0.12)
	var satin: StandardMaterial3D = _make_metal(Color(0.24, 0.27, 0.30), 0.62, 0.34)
	var rubber: StandardMaterial3D = _shared_dark()
	var lens_blue: StandardMaterial3D = _make_glow(Color(0.16, 0.48, 0.72), 1.1)
	var mop_mat: StandardMaterial3D = _make_metal(Color(0.32, 0.36, 0.39), 0.04, 0.88)
	var accent: StandardMaterial3D = _make_metal(_primary.darkened(0.18), 0.28, 0.36)
	var front_z: float = -_edge_z(_shape, 0.0, true)
	var rear_z: float = _edge_z(_shape, 0.0, false)
	var front_y: float = minf(0.145, h * 0.60)
	var top_y: float = h + 0.012

	match _shape_id:
		"model_dreame":
			# Płaski, schowany moduł dToF zamiast wysokiej wieżyczki.
			var dtof_base: MeshInstance3D = _cyl(0.205, 0.026, satin, Vector3(0.0, top_y + 0.012, 0.18), Vector3.ZERO, 0.19)
			dtof_base.name = "RetractableDToFBase"
			_cyl(0.164, 0.012, dark_glass, Vector3(0.0, top_y + 0.032, 0.18))
			for i: int in range(8):
				var dtof_angle: float = TAU * float(i) / 8.0
				_cyl(0.012, 0.006, _led_material, Vector3(cos(dtof_angle) * 0.15, top_y + 0.040, 0.18 + sin(dtof_angle) * 0.15))
			# Dwie kamery przednie i wąski pas czujników.
			_box(Vector3(0.43, 0.045, 0.018), dark_glass, Vector3(0.0, front_y, -front_z * 0.98))
			for side: float in [-1.0, 1.0]:
				_cyl(0.035, 0.014, lens_blue, Vector3(side * 0.145, front_y + 0.004, -front_z - 0.012), Vector3(PI * 0.5, 0.0, 0.0))
			# Wysuwane boczne ramię szczotki i dwa tylne pady mopujące.
			var arm_pivot := Node3D.new()
			arm_pivot.name = "ExtendableSideArmPivot"
			arm_pivot.position = Vector3(shape_a * 0.56, h * 0.62, 0.04)
			_model.add_child(arm_pivot)
			_box(Vector3(0.30, 0.035, 0.045), satin, Vector3(0.13, 0.0, 0.0), Vector3(0.0, 0.0, -0.10), arm_pivot)
			_cyl(0.09, 0.018, mop_mat, Vector3(-0.25, 0.045, rear_z * 0.68))
			_cyl(0.09, 0.018, mop_mat, Vector3(0.25, 0.045, rear_z * 0.68))
			for side: float in [-1.0, 1.0]:
				_box(Vector3(0.025, 0.012, 0.12), rubber, Vector3(side * 0.25, 0.057, rear_z * 0.68))

		"model_saros":
			# Brak wieżyczki: podwójny układ kamer w przedniej listwie.
			_box(Vector3(0.50, 0.052, 0.025), dark_glass, Vector3(0.0, front_y, -front_z * 0.98))
			for side: float in [-1.0, 1.0]:
				_cyl(0.045, 0.016, lens_blue, Vector3(side * 0.15, front_y + 0.006, -front_z - 0.014), Vector3(PI * 0.5, 0.0, 0.0))
				_cyl(0.060, 0.012, satin, Vector3(side * 0.15, top_y, -0.12))
			# Składane, pięcioosiowe ramię OmniGrip — segmenty i przeguby są osobnymi węzłami.
			var arm_root := Node3D.new()
			arm_root.name = "FiveAxisFoldedArm"
			arm_root.position = Vector3(0.0, top_y + 0.02, 0.10)
			_model.add_child(arm_root)
			_cyl(0.105, 0.045, satin, Vector3.ZERO, Vector3.ZERO, -1.0, arm_root)
			_box(Vector3(0.25, 0.035, 0.055), accent, Vector3(0.02, 0.035, 0.08), Vector3(0.0, 0.0, -0.10), arm_root)
			_cyl(0.052, 0.052, satin, Vector3(0.12, 0.05, 0.08), Vector3.ZERO, -1.0, arm_root)
			_box(Vector3(0.20, 0.028, 0.045), accent, Vector3(0.22, 0.075, 0.08), Vector3(0.0, 0.0, 0.18), arm_root)
			_cyl(0.042, 0.045, satin, Vector3(0.31, 0.08, 0.08), Vector3.ZERO, -1.0, arm_root)
			_box(Vector3(0.13, 0.025, 0.04), accent, Vector3(0.37, 0.105, 0.08), Vector3(0.0, 0.0, -0.12), arm_root)
			for side: float in [-1.0, 1.0]:
				_box(Vector3(0.018, 0.055, 0.025), satin, Vector3(0.43, 0.08, 0.08 + side * 0.035), Vector3(0.0, 0.0, side * 0.12), arm_root)
			# Płaskie osłony modułów mopujących pod tylną krawędzią.
			for side: float in [-1.0, 1.0]:
				_cyl(0.105, 0.018, mop_mat, Vector3(side * 0.29, 0.045, rear_z * 0.70))

		"model_roomba":
			# Charakterystyczna pokrywa i przednia kamera; podnoszony mop schowany z tyłu.
			_box(Vector3(0.56, 0.018, 0.34), satin, Vector3(0.0, top_y, 0.12))
			_box(Vector3(0.48, 0.012, 0.27), _panel_material, Vector3(0.0, top_y + 0.012, 0.12))
			_box(Vector3(0.46, 0.055, 0.025), dark_glass, Vector3(0.0, front_y, -front_z * 0.98))
			_cyl(0.045, 0.016, lens_blue, Vector3(0.0, front_y + 0.004, -front_z - 0.015), Vector3(PI * 0.5, 0.0, 0.0))
			# Widoczny zawias oraz podnoszony moduł mopa na tylnej pokrywie.
			for side: float in [-1.0, 1.0]:
				_cyl(0.035, 0.24, satin, Vector3(side * 0.20, top_y + 0.055, 0.38), Vector3(0.0, 0.0, PI * 0.5))
			_box(Vector3(0.38, 0.07, 0.19), _body_material, Vector3(0.0, top_y + 0.07, 0.40))
			_box(Vector3(0.31, 0.018, 0.10), mop_mat, Vector3(0.0, top_y + 0.025, 0.50))

		"model_xiaomi":
			# Klasyczna centralna wieżyczka LDS i szeroki przedni sensor strukturalny.
			_cyl(0.165, 0.045, satin, Vector3(0.0, top_y + 0.020, 0.10))
			_cyl(0.132, 0.035, dark_glass, Vector3(0.0, top_y + 0.055, 0.10))
			_box(Vector3(0.52, 0.060, 0.025), dark_glass, Vector3(0.0, front_y, -front_z * 0.98))
			for side: float in [-1.0, 1.0]:
				_cyl(0.028, 0.016, lens_blue, Vector3(side * 0.205, front_y + 0.006, -front_z - 0.014), Vector3(PI * 0.5, 0.0, 0.0))
			# Boczne wysuwane ramię mopa oraz dwa dyski mopujące.
			var mop_arm := Node3D.new()
			mop_arm.name = "EdgeMopExtension"
			mop_arm.position = Vector3(shape_a * 0.62, 0.09, rear_z * 0.40)
			_model.add_child(mop_arm)
			_box(Vector3(0.22, 0.025, 0.04), satin, Vector3(0.10, 0.0, 0.0), Vector3(0.0, 0.0, -0.08), mop_arm)
			for side: float in [-1.0, 1.0]:
				_cyl(0.105, 0.018, mop_mat, Vector3(side * 0.28, 0.045, rear_z * 0.68))

		"model_narwal":
			# Dwie duże kamery AI oraz osobny czujnik krawędziowy na boku.
			_box(Vector3(0.54, 0.055, 0.026), dark_glass, Vector3(0.0, front_y, -front_z * 0.98))
			for side: float in [-1.0, 1.0]:
				_cyl(0.050, 0.016, lens_blue, Vector3(side * 0.16, front_y + 0.005, -front_z - 0.015), Vector3(PI * 0.5, 0.0, 0.0))
			_box(Vector3(0.025, 0.045, 0.10), dark_glass, Vector3(shape_a * 0.99, 0.13, 0.08))
			_cyl(0.022, 0.012, _led_material, Vector3(shape_a * 1.01, 0.13, 0.08), Vector3(0.0, 0.0, PI * 0.5))
			# Dwa obrotowe, trójpłatowe pady Reuleaux: centralna piasta + trzy miękkie płaty.
			for side: float in [-1.0, 1.0]:
				var center := Vector3(side * 0.29, 0.045, rear_z * 0.62)
				_cyl(0.105, 0.018, mop_mat, center)
				for blade: int in range(3):
					var blade_angle: float = TAU * float(blade) / 3.0
					_cyl(0.048, 0.014, mop_mat, center + Vector3(cos(blade_angle) * 0.055, 0.006, sin(blade_angle) * 0.055))
				_cyl(0.025, 0.024, satin, center + Vector3(0.0, 0.012, 0.0))

	# Fabryczny przycisk zasilania pozostaje w każdym wariancie, ale nie jest logotypem.
	var power_z: float = float(_shape["button_z"])
	_cyl(0.052, 0.014, satin, Vector3(0.0, top_y + 0.012, power_z))
	_cyl(0.034, 0.008, _led_material, Vector3(0.0, top_y + 0.023, power_z))
	# Wspólne, neutralne dysze boosta zostają w tylnej strefie każdej platformy.
	var rear_y: float = minf(0.135, h - 0.09)
	for side: float in [-1.0, 1.0]:
		var nozzle_x: float = side * 0.24
		var nozzle_z: float = _edge_z(_shape, nozzle_x, false) * 1.01
		_add_mesh("nozzle", _bumper_material, Vector3(nozzle_x, rear_y, nozzle_z))
		_add_mesh("nozzle_glow", _thruster_material, Vector3(nozzle_x, rear_y, nozzle_z + 0.028))
		_nozzle_points.append(Vector3(nozzle_x, rear_y, nozzle_z + 0.04))
	var neon := _add_mesh("neon", _neon_material, Vector3(0.0, 0.05, 0.0), Vector3.ZERO, Vector3(shape_a / 0.70, 0.3, shape_a / 0.70))
	neon.name = "NeonRing"
	neon.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	# Boczne szyny montażowe są bazą dla widocznych modułów ulepszeń.
	for side: float in [-1.0, 1.0]:
		_box(Vector3(0.035, 0.018, 0.46), satin, Vector3(side * 0.57, h + 0.012, 0.04))
		for slot: int in range(3):
			_box(Vector3(0.045, 0.009, 0.055), _trim_material, Vector3(side * 0.57, h + 0.024, -0.12 + float(slot) * 0.16))


# =========================================================
# ULEPSZENIA ROBOTA - KAŻDY POZIOM DODAJE WIDOCZNY ELEMENT
# =========================================================

func _level(upgrade_id: String) -> int:
	return clampi(int(_upgrade_levels.get(upgrade_id, 0)), 0, 5)


func _box(size: Vector3, material: Material, pos: Vector3, rot: Vector3 = Vector3.ZERO, parent: Node3D = null) -> MeshInstance3D:
	var key: String = "box|%.3f|%.3f|%.3f" % [size.x, size.y, size.z]
	if not _shared.has(key):
		var mesh := BoxMesh.new()
		mesh.size = size
		_shared[key] = mesh
	return _add_mesh_obj(_shared[key] as Mesh, material, pos, rot, Vector3.ONE, parent)


func _cyl(radius: float, height: float, material: Material, pos: Vector3, rot: Vector3 = Vector3.ZERO, top_radius: float = -1.0, parent: Node3D = null) -> MeshInstance3D:
	var key: String = "cyl|%.3f|%.3f|%.3f" % [radius, height, top_radius]
	if not _shared.has(key):
		var mesh := CylinderMesh.new()
		mesh.top_radius = radius if top_radius < 0.0 else top_radius
		mesh.bottom_radius = radius
		mesh.height = height
		mesh.radial_segments = 14
		mesh.rings = 1
		_shared[key] = mesh
	return _add_mesh_obj(_shared[key] as Mesh, material, pos, rot, Vector3.ONE, parent)


func _sphere(radius: float, material: Material, pos: Vector3, scale_value: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var key: String = "sph|%.3f" % radius
	if not _shared.has(key):
		var mesh := SphereMesh.new()
		mesh.radius = radius
		mesh.height = radius * 2.0
		mesh.radial_segments = 12
		mesh.rings = 6
		_shared[key] = mesh
	return _add_mesh_obj(_shared[key] as Mesh, material, pos, Vector3.ZERO, scale_value)


func _make_glow(color: Color, energy: float = 2.5) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.emission_enabled = true
	material.emission = color
	material.emission_energy_multiplier = energy
	return material


func _make_metal(color: Color, metallic: float = 0.8, rough: float = 0.3) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.metallic = metallic
	material.roughness = rough
	return material


func _build_upgrade_visuals() -> void:
	var h: float = float(_shape["h"])
	var a: float = float(_shape["a"])
	var front: float = _edge_z(_shape, 0.0, true)
	var rear: float = _edge_z(_shape, 0.0, false)
	var accent: Color = _trim_material.albedo_color if _category != "neon" else _trim_material.emission
	if accent.get_luminance() < 0.12:
		accent = Color(0.95, 0.35, 0.12)
	_accent_material = _make_metal(accent, 0.5, 0.3)
	var accent_glow: StandardMaterial3D = _make_glow(accent.lightened(0.2), 2.2)
	_glass_material = StandardMaterial3D.new()
	_glass_material.albedo_color = Color(0.08, 0.12, 0.16, 0.5)
	_glass_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_glass_material.roughness = 0.08
	_glass_material.metallic = 0.3

	# --- PRĘDKOŚĆ: pasy, splitter, płetwy, spoiler, świecące krawędzie ---
	var speed: int = _level("speed")
	if speed >= 1:
		for side: float in [-1.0, 1.0]:
			_box(Vector3(0.05, 0.006, 0.75), _accent_material, Vector3(side * 0.13, h + 0.01, 0.0))
	if speed >= 2:
		_box(Vector3(a * 1.2, 0.014, 0.11), _accent_material, Vector3(0.0, 0.06, front - 0.02))
	if speed >= 3:
		for side: float in [-1.0, 1.0]:
			_box(Vector3(0.018, 0.075, 0.42), _accent_material, Vector3(side * (a * 0.96), h * 0.62, 0.22), Vector3(0.0, side * 0.12, 0.0))
	if speed >= 4:
		var wing_z: float = rear * 0.88
		for side: float in [-1.0, 1.0]:
			_box(Vector3(0.02, 0.11, 0.03), _trim_material, Vector3(side * 0.34, h + 0.05, wing_z))
		_box(Vector3(0.84, 0.014, 0.15), _accent_material, Vector3(0.0, h + 0.11, wing_z))
	if speed >= 5:
		_box(Vector3(a * 1.2, 0.008, 0.012), accent_glow, Vector3(0.0, 0.052, front - 0.085))
		for side: float in [-1.0, 1.0]:
			_box(Vector3(0.016, 0.05, 0.17), accent_glow, Vector3(side * 0.43, h + 0.11, rear * 0.88))

	# --- PRZYSPIESZENIE: rząd kondensatorów mocy z tyłu pokrywy ---
	var accel: int = _level("accel")
	var cap_material: StandardMaterial3D = _make_metal(Color(0.7, 0.72, 0.76), 0.85, 0.25)
	for k: int in range(accel):
		var x_pos: float = (float(k) - float(accel - 1) * 0.5) * 0.095
		var capacitor_z: float = (-rear * 0.32 if _shape_id.begins_with("model_") else rear * 0.2) + 0.02
		var capacitor: MeshInstance3D = _cyl(0.028, 0.09, cap_material, Vector3(x_pos, h + 0.04, capacitor_z))
		capacitor.name = "Capacitor%d" % k
		_cyl(0.022, 0.012, accent_glow if accel >= 5 else _accent_material, Vector3(x_pos, h + 0.09, capacitor_z))

	# --- PRZYCZEPNOŚĆ: szersze opony, kolorowe piasty, osłony boczne ---
	var grip: int = _level("grip")
	if grip >= 1 and _wheel_left != null:
		var hub_material: StandardMaterial3D = _make_metal(Color(0.95, 0.78, 0.25) if grip >= 5 else accent, 0.8, 0.28)
		var wheel_scale: float = float(_shape.get("wheel_scale", 1.0))
		for wheel: Node3D in [_wheel_left, _wheel_right]:
			wheel.scale = Vector3(1.0 + 0.07 * float(grip), 1.0 + 0.03 * float(grip), 1.0 + 0.03 * float(grip)) * Vector3(1.0, wheel_scale, wheel_scale)
			(wheel.get_child(1) as MeshInstance3D).material_override = hub_material
	if grip >= 3:
		var rubber: StandardMaterial3D = _shared_dark()
		for side: float in [-1.0, 1.0]:
			_box(Vector3(0.03, 0.05, 0.62), rubber, Vector3(side * (a * 0.99), 0.075, 0.1))
	if grip >= 4:
		for side: float in [-1.0, 1.0]:
			_box(Vector3(0.012, 0.02, 0.5), accent_glow, Vector3(side * (a * 1.005), 0.115, 0.1))

	# --- POJEMNOŚĆ: pojemnik na kurz z poziomem zabrudzenia i wskaźnikami ---
	var capacity: int = _level("capacity")
	if capacity >= 1:
		var bin_width: float = 0.26 + 0.05 * float(capacity)
		var bin_z: float = rear * (0.78 if _shape_id.begins_with("model_") else 0.58)
		_box(Vector3(bin_width, 0.04 + 0.01 * float(capacity), 0.2), _glass_material, Vector3(0.0, h + 0.02 + 0.005 * float(capacity), bin_z))
		var fill: StandardMaterial3D = _make_metal(Color(0.45, 0.33, 0.22), 0.0, 0.9)
		_box(Vector3(bin_width * 0.86, 0.02 + 0.006 * float(capacity), 0.16), fill, Vector3(0.0, h + 0.012 + 0.003 * float(capacity), bin_z))
		for k: int in range(capacity):
			var led_x: float = (float(k) - float(capacity - 1) * 0.5) * 0.045
			_box(Vector3(0.026, 0.008, 0.012), _make_glow(Color(0.4, 1.0, 0.5), 2.0), Vector3(led_x, h + 0.062 + 0.01 * float(capacity), bin_z - 0.11))

	# --- BATERIA: komórki LED, boczne ogniwa, rdzeń energetyczny ---
	var battery: int = _level("battery")
	for k: int in range(battery):
		var cell_color: Color = Color(1.0, 0.45, 0.2).lerp(Color(0.3, 1.0, 0.5), float(k) / 4.0)
		_box(Vector3(0.05, 0.008, 0.032), _make_glow(cell_color, 2.2), Vector3(-a * 0.6, h - 0.016, -0.2 + float(k) * 0.085), Vector3(0.0, 0.0, 0.0))
	if battery >= 3:
		var cell_glow: StandardMaterial3D = _make_glow(Color(0.25, 0.95, 0.85), 2.0)
		for side: float in [-1.0, 1.0]:
			_cyl(0.045, 0.3, _make_metal(Color(0.2, 0.22, 0.25), 0.7, 0.3), Vector3(side * (a * 0.93), 0.17, 0.32), Vector3(PI * 0.5, 0.0, 0.0))
			_cyl(0.047, 0.04, cell_glow, Vector3(side * (a * 0.93), 0.17, 0.32 - 0.1), Vector3(PI * 0.5, 0.0, 0.0))
	if battery >= 5:
		var core: MeshInstance3D = _add_mesh("led_ring", _make_glow(Color(0.3, 1.0, 0.9), 3.0), Vector3(0.0, h + 0.02, float(_shape["button_z"])), Vector3.ZERO, Vector3(1.4, 0.4, 1.4))
		core.name = "BatteryCore"

	# --- PANCERNY ZDERZAK: moduł ochronny na przodzie i osłony narożników ---
	var bumper: int = _level("bumper")
	if bumper >= 1:
		var bumper_width: float = a * (1.9 + 0.06 * float(bumper))
		var bumper_depth: float = 0.055 + 0.012 * float(bumper)
		_box(Vector3(bumper_width, 0.055 + 0.008 * float(bumper), bumper_depth), _bumper_material, Vector3(0.0, h * 0.34, front - 0.035))
		for side: float in [-1.0, 1.0]:
			_box(Vector3(0.075, 0.09 + 0.01 * float(bumper), 0.12), _bumper_material, Vector3(side * a * 0.88, h * 0.32, front - 0.015))
	if bumper >= 3:
		for side: float in [-1.0, 1.0]:
			_box(Vector3(0.035, 0.045, 0.48), _accent_material, Vector3(side * a * 0.96, h * 0.38, 0.0))

	# --- MOC BOOSTA: większe dysze, chromowane ramki, dopalacz ---
	var boost_level: int = _level("boost")
	_vfx_scale = 1.0 + 0.12 * float(boost_level)
	if boost_level >= 1:
		var chrome: StandardMaterial3D = _make_metal(Color(0.85, 0.87, 0.9), 0.95, 0.2)
		var rear_y: float = minf(0.135, h - 0.09)
		for point: Vector3 in _nozzle_points:
			var frame_scale: float = 1.0 + 0.09 * float(boost_level)
			var z_pos: float = point.z - 0.012
			_box(Vector3(0.25 * frame_scale, 0.012, 0.014), chrome, Vector3(point.x, rear_y + 0.045 * frame_scale, z_pos))
			_box(Vector3(0.25 * frame_scale, 0.012, 0.014), chrome, Vector3(point.x, rear_y - 0.045 * frame_scale, z_pos))
			if boost_level >= 3:
				_box(Vector3(0.012, 0.09 * frame_scale, 0.014), chrome, Vector3(point.x - 0.125 * frame_scale, rear_y, z_pos))
				_box(Vector3(0.012, 0.09 * frame_scale, 0.014), chrome, Vector3(point.x + 0.125 * frame_scale, rear_y, z_pos))
	if boost_level >= 5:
		var center_point := Vector3(0.0, minf(0.135, h - 0.09), rear + 0.04)
		_box(Vector3(0.16, 0.08, 0.05), _bumper_material, center_point - Vector3(0, 0, 0.03))
		_box(Vector3(0.12, 0.03, 0.012), _thruster_material, center_point - Vector3(0, 0, 0.0))
		_nozzle_points.append(center_point)


# =========================================================
# MODUŁY BOOSTÓW - KAŻDY WYBRANY BOOST DODAJE ELEMENT NA ROBOCIE
# =========================================================

func _equipped_boost_ids() -> Array[String]:
	var result: Array[String] = []
	if config.has("boost_ids"):
		for id_value: Variant in config["boost_ids"]:
			result.append(str(id_value))
	elif is_player and PlayerProgress != null and PlayerProgress.boost_loadout != null:
		result = PlayerProgress.boost_loadout.get_equipped()
	else:
		result = ["turbo", "electric_pulse"]
	return result


func _boost_ratio(boost_id: String) -> float:
	if not is_player:
		return 0.0
	var params: Array = BoostUpgradeSystem.get_parameters(boost_id)
	if params.is_empty():
		return 0.0
	var total: int = 0
	for parameter: Dictionary in params:
		total += BoostUpgradeSystem.get_level(boost_id, "common", str(parameter.get("id", "")))
	return clampf(float(total) / float(params.size() * BoostUpgradeSystem.MAX_LEVEL), 0.0, 1.0)


## Punkt na pokrywie: kąt liczony od przodu (0 = przód), dodatni = prawa strona.
func _lid_point(angle_deg: float, radius_scale: float = 0.78) -> Vector3:
	var h: float = float(_shape["h"])
	var phi: float = deg_to_rad(angle_deg) - PI * 0.5
	var radius: float = _outline(_shape, phi) * radius_scale
	return Vector3(radius * cos(phi), h - 0.012, radius * sin(phi))


func _build_boost_modules() -> void:
	var h: float = float(_shape["h"])
	var a: float = float(_shape["a"])
	var rear: float = _edge_z(_shape, 0.0, false)
	for boost_id: String in _equipped_boost_ids():
		if boost_id.is_empty():
			continue
		var ratio: float = _boost_ratio(boost_id)
		var size: float = 1.0 + 0.5 * ratio
		var glow_energy: float = 2.0 + 2.5 * ratio
		var tint: Color = BoostEffectsScript.color_for(boost_id)
		var glow: StandardMaterial3D = _make_glow(tint, glow_energy)
		match boost_id:
			"turbo":
				# Pomarańczowe pasy przy dyszach i wloty powietrza.
				for point: Vector3 in _nozzle_points:
					_box(Vector3(0.2, 0.012, 0.012), _make_glow(Color(1.0, 0.5, 0.12), 1.6 + 2.0 * ratio), Vector3(point.x, point.y + 0.055, point.z - 0.02))
				for side: float in [-1.0, 1.0]:
					_box(Vector3(0.1 * size, 0.035, 0.12), _bumper_material, _lid_point(side * 150.0, 0.7) + Vector3(0, 0.012, 0), Vector3(0.0, side * 0.3, 0.0))
			"electric_pulse":
				var base: Vector3 = _lid_point(40.0)
				_cyl(0.012, 0.2 * size, _make_metal(Color(0.8, 0.82, 0.85)), base + Vector3(0, 0.1 * size, 0))
				_sphere(0.032 * size, glow, base + Vector3(0, 0.205 * size, 0))
				_add_mesh("led_ring", glow, base + Vector3(0, 0.12 * size, 0), Vector3.ZERO, Vector3(0.5, 0.5, 0.5))
			"slippery_trail":
				var tank_pos := Vector3(0.0, 0.105, rear + 0.035)
				_cyl(0.045 * size, 0.18, _make_metal(Color(0.75, 0.85, 0.2), 0.3, 0.45), tank_pos, Vector3(0.0, 0.0, PI * 0.5))
				_cyl(0.014, 0.05, glow, tank_pos + Vector3(0, -0.04, 0.03))
			"shockwave":
				var front_point: Vector3 = _lid_point(0.0, 0.84)
				for side: float in [-1.0, 1.0]:
					_box(Vector3(0.05 * size, 0.04, 0.17 * size), _make_metal(Color(0.95, 0.5, 0.15), 0.4, 0.35), front_point + Vector3(side * 0.09, 0.012, 0.0), Vector3(0.0, side * -0.45, 0.0))
				_sphere(0.034 * size, glow, front_point + Vector3(0, 0.03, 0.04))
			"shield":
				var belt := TorusMesh.new()
				belt.inner_radius = 0.97
				belt.outer_radius = 1.0
				belt.rings = 40
				belt.ring_segments = 4
				var belt_instance: MeshInstance3D = _add_mesh_obj(belt, glow, Vector3(0.0, h * 0.5, 0.0), Vector3.ZERO, Vector3(a * 1.02, 0.5 * size, a * 1.02))
				belt_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
				for k: int in range(3):
					var pod_angle: float = 120.0 * float(k) + 60.0
					_sphere(0.03 * size, glow, _lid_point(pod_angle, 0.9) + Vector3(0, 0.02, 0))
			"magnet":
				var m: Vector3 = _lid_point(-40.0)
				var red: StandardMaterial3D = _make_metal(Color(0.85, 0.12, 0.12), 0.4, 0.35)
				for side: float in [-1.0, 1.0]:
					_box(Vector3(0.035, 0.1 * size, 0.035), red, m + Vector3(side * 0.065 * size, 0.05 * size, 0.0))
					_box(Vector3(0.035, 0.03, 0.035), _make_metal(Color(0.85, 0.87, 0.9)), m + Vector3(side * 0.065 * size, 0.115 * size, 0.0))
				_box(Vector3(0.165 * size, 0.035, 0.035), red, m + Vector3(0, 0.0, 0.0) + Vector3(0, 0.0, 0.0))
			"emergency_repair":
				var kit_pos: Vector3 = _lid_point(-75.0)
				_box(Vector3(0.15 * size, 0.055 * size, 0.12 * size), _make_metal(Color(0.95, 0.95, 0.96), 0.0, 0.5), kit_pos + Vector3(0, 0.028 * size, 0))
				_box(Vector3(0.07 * size, 0.008, 0.02 * size), glow, kit_pos + Vector3(0, 0.058 * size, 0))
				_box(Vector3(0.02 * size, 0.008, 0.07 * size), glow, kit_pos + Vector3(0, 0.058 * size, 0))
			"energy_regenerator":
				var panel_pos: Vector3 = _lid_point(78.0, 0.8)
				_box(Vector3(0.17 * size, 0.012, 0.2 * size), _make_metal(Color(0.08, 0.35, 0.4), 0.7, 0.15), panel_pos + Vector3(0, 0.03, 0), Vector3(0.0, 0.0, -0.2))
				_box(Vector3(0.02, 0.025, 0.2 * size), glow, panel_pos + Vector3(0, 0.0, 0))
			"overdrive":
				var gold: StandardMaterial3D = _make_metal(Color(1.0, 0.8, 0.25), 0.9, 0.22)
				for side: float in [-1.0, 1.0]:
					_box(Vector3(0.025, 0.1 * size, 0.28 * size), gold, Vector3(side * a * 0.97, h * 0.65, 0.05), Vector3(0.0, side * 0.1, side * 0.15))
				_box(Vector3(0.3, 0.008, 0.012), glow, Vector3(0.0, h + 0.006, rear * 0.35))
			"hologram":
				var projector: Vector3 = _lid_point(-110.0, 0.8)
				_cyl(0.05 * size, 0.02, _make_metal(Color(0.2, 0.22, 0.26)), projector + Vector3(0, 0.01, 0))
				var dome: MeshInstance3D = _sphere(0.05 * size, _make_glow(Color(tint.r, tint.g, tint.b, 0.6), glow_energy * 0.8), projector + Vector3(0, 0.03, 0), Vector3(1.0, 0.7, 1.0))
				dome.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


func _build_wheel() -> Node3D:
	var holder := Node3D.new()
	_model.add_child(holder)
	var dark: StandardMaterial3D = _shared_dark()
	var tire := MeshInstance3D.new()
	tire.mesh = _get_mesh("tire")
	tire.material_override = dark
	tire.rotation = Vector3(0.0, 0.0, PI * 0.5)
	holder.add_child(tire)
	var hub := MeshInstance3D.new()
	hub.mesh = _get_mesh("hub")
	hub.material_override = _shared_hub()
	hub.rotation = Vector3(0.0, 0.0, PI * 0.5)
	holder.add_child(hub)
	# Klocki bieżnika - po nich widać, że koło się toczy.
	for k: int in range(8):
		var angle: float = TAU * float(k) / 8.0
		var tread := MeshInstance3D.new()
		tread.mesh = _get_mesh("tread")
		tread.material_override = dark
		tread.position = Vector3(0.0, sin(angle) * 0.172, cos(angle) * 0.172)
		tread.rotation = Vector3(-angle, 0.0, 0.0)
		holder.add_child(tread)
	return holder


func _build_brush(position_value: Vector3) -> Node3D:
	var holder := Node3D.new()
	holder.position = position_value
	_model.add_child(holder)
	var brush_material: StandardMaterial3D = _shared_brush()
	var hub := MeshInstance3D.new()
	hub.mesh = _get_mesh("brush_hub")
	hub.material_override = _shared_hub()
	holder.add_child(hub)
	for k: int in range(5):
		var angle: float = TAU * float(k) / 5.0
		var arm := MeshInstance3D.new()
		arm.mesh = _get_mesh("arm")
		arm.material_override = brush_material
		arm.position = Vector3(cos(angle) * 0.16, 0.0, -sin(angle) * 0.16)
		arm.rotation = Vector3(0.0, angle, 0.0)
		holder.add_child(arm)
		var tip := MeshInstance3D.new()
		tip.mesh = _get_mesh("tip")
		tip.material_override = brush_material
		tip.position = Vector3(cos(angle) * 0.30, 0.0, -sin(angle) * 0.30)
		holder.add_child(tip)
	return holder


static func _shared_dark() -> StandardMaterial3D:
	if not _shared.has("mat_dark"):
		var material := StandardMaterial3D.new()
		material.albedo_color = Color(0.025, 0.028, 0.032)
		material.roughness = 0.9
		_shared["mat_dark"] = material
	return _shared["mat_dark"]


static func _shared_hub() -> StandardMaterial3D:
	if not _shared.has("mat_hub"):
		var material := StandardMaterial3D.new()
		material.albedo_color = Color(0.55, 0.57, 0.6)
		material.metallic = 0.7
		material.roughness = 0.4
		_shared["mat_hub"] = material
	return _shared["mat_hub"]


static func _shared_brush() -> StandardMaterial3D:
	if not _shared.has("mat_brush"):
		var material := StandardMaterial3D.new()
		material.albedo_color = Color(0.88, 0.5, 0.14)
		material.roughness = 0.75
		_shared["mat_brush"] = material
	return _shared["mat_brush"]


# =========================================================
# ŚWIATŁA
# =========================================================

func _build_lights() -> void:
	var h: float = float(_shape["h"])
	_neon_light = OmniLight3D.new()
	_neon_light.name = "NeonLight"
	_neon_light.position = Vector3(0, 0.1, 0)
	_neon_light.light_color = _neon_color
	_neon_light.light_energy = 2.0
	_neon_light.omni_range = 0.65
	_neon_light.omni_attenuation = 1.2
	_neon_light.shadow_enabled = false
	_model.add_child(_neon_light)

	var front_z: float = -_edge_z(_shape, 0.0, true)
	_head_light = SpotLight3D.new()
	_head_light.name = "HeadLight"
	_head_light.position = Vector3(0, minf(0.16, h - 0.07), front_z)
	_head_light.rotation = Vector3(deg_to_rad(-6.0), 0, 0)
	_head_light.light_color = Color(1.0, 0.96, 0.88)
	_head_light.light_energy = 3.0
	_head_light.spot_range = 2.4
	_head_light.spot_angle = 30.0
	_head_light.spot_attenuation = 1.0
	_model.add_child(_head_light)

	_boost_glow = OmniLight3D.new()
	_boost_glow.name = "BoostGlow"
	_boost_glow.position = Vector3(0, 0.3, _edge_z(_shape, 0.0, false) + 0.5)
	_boost_glow.light_color = Color(1.0, 0.55, 0.18)
	_boost_glow.light_energy = 2.5
	_boost_glow.omni_range = 0.85
	_boost_glow.visible = false
	_model.add_child(_boost_glow)


# =========================================================
# CZĄSTECZKI
# =========================================================

## Miękka, okrągła tekstura cząsteczek (generowana raz, współdzielona).
static func _particle_texture() -> Texture2D:
	if not _shared.has("tex_particle"):
		var gradient := Gradient.new()
		gradient.set_color(0, Color(1, 1, 1, 1))
		gradient.set_color(1, Color(1, 1, 1, 0))
		gradient.add_point(0.45, Color(1, 1, 1, 0.65))
		var texture := GradientTexture2D.new()
		texture.gradient = gradient
		texture.fill = GradientTexture2D.FILL_RADIAL
		texture.fill_from = Vector2(0.5, 0.5)
		texture.fill_to = Vector2(1.0, 0.5)
		texture.width = 64
		texture.height = 64
		_shared["tex_particle"] = texture
	return _shared["tex_particle"]


## Strumień płomienia z shadera (jasny rdzeń przy dyszy, pomarańczowy czubek).
static func _jet_material() -> ShaderMaterial:
	if not _shared.has("mat_jet"):
		var shader := Shader.new()
		shader.code = """shader_type spatial;
render_mode unshaded, blend_add, cull_disabled, depth_draw_never, depth_test_disabled, fog_disabled;

uniform vec4 core_color : source_color = vec4(0.75, 0.9, 1.0, 1.0);
uniform vec4 tip_color : source_color = vec4(1.0, 0.42, 0.08, 1.0);
uniform float intensity = 1.0;
varying float t;

void vertex() {
	t = clamp(VERTEX.y + 0.5, 0.0, 1.0);
}

void fragment() {
	float flick = 0.78 + 0.22 * sin(TIME * 70.0 + t * 25.0);
	float bands = 0.7 + 0.3 * sin(t * 38.0 - TIME * 90.0);
	vec3 col = mix(tip_color.rgb, core_color.rgb, pow(t, 1.4));
	float facing = pow(clamp(dot(normalize(NORMAL), normalize(VIEW)), 0.0, 1.0), 1.4);
	ALBEDO = col * 2.2 * intensity;
	ALPHA = clamp(pow(t, 1.2) * flick * bands * (0.3 + 0.7 * facing) * intensity, 0.0, 1.0);
}
"""
		var material := ShaderMaterial.new()
		material.shader = shader
		material.render_priority = 10
		_shared["mat_jet"] = material
	return _shared["mat_jet"]


## Zwolnienie współdzielonych zasobów (przy zamykaniu gry).
static func clear_shared_cache() -> void:
	_shared.clear()


func _make_particle_material(color: Color, emissive: bool) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	material.vertex_color_use_as_albedo = true
	material.albedo_color = color
	material.albedo_texture = _particle_texture()
	if emissive:
		material.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	return material


func _make_ramp(colors: Array, offsets: Array) -> Gradient:
	var gradient := Gradient.new()
	gradient.set_color(0, colors[0])
	gradient.set_color(1, colors[colors.size() - 1])
	for i: int in range(1, colors.size() - 1):
		gradient.add_point(float(offsets[i]), colors[i])
	return gradient


func _make_emitter(emitter_name: String, pos: Vector3, amount: int, lifetime: float, ramp: Gradient, emissive: bool, direction: Vector3, spread: float, velocity_min: float, velocity_max: float, gravity_value: Vector3, scale_min: float, scale_max: float, local: bool = false, one_shot: bool = false, shrink: bool = false) -> CPUParticles3D:
	var particles := CPUParticles3D.new()
	particles.name = emitter_name
	particles.position = pos
	particles.emitting = false
	particles.one_shot = one_shot
	if one_shot:
		particles.explosiveness = 0.95
	particles.amount = amount
	particles.lifetime = lifetime
	particles.local_coords = local
	particles.mesh = _get_mesh("particle")
	particles.material_override = _make_particle_material(Color.WHITE, emissive)
	particles.direction = direction
	particles.spread = spread
	particles.initial_velocity_min = velocity_min
	particles.initial_velocity_max = velocity_max
	particles.gravity = gravity_value
	particles.scale_amount_min = scale_min * (_vfx_scale if emitter_name.begins_with("Flame") or emitter_name == "BoostTrail" else 1.0)
	particles.scale_amount_max = scale_max * (_vfx_scale if emitter_name.begins_with("Flame") or emitter_name == "BoostTrail" else 1.0)
	particles.color_ramp = ramp
	if shrink:
		var curve := Curve.new()
		curve.add_point(Vector2(0.0, 1.0))
		curve.add_point(Vector2(1.0, 0.0))
		particles.scale_amount_curve = curve
	_model.add_child(particles)
	_vfx_emitters.append([particles, amount])
	return particles


func _build_particles() -> void:
	var h: float = float(_shape["h"])
	var rear_z: float = _edge_z(_shape, 0.0, false)

	# --- Płomień turbo: rdzeń + otoczka z każdej dyszy ---
	var core_ramp: Gradient = _make_ramp(
		[Color(0.85, 0.95, 1.0, 1.0), Color(0.5, 0.78, 1.0, 0.9), Color(0.3, 0.45, 1.0, 0.0)],
		[0.0, 0.4, 1.0]
	)
	var outer_ramp: Gradient = _make_ramp(
		[Color(1.0, 0.92, 0.55, 0.95), Color(1.0, 0.55, 0.12, 0.8), Color(0.9, 0.2, 0.05, 0.0)],
		[0.0, 0.35, 1.0]
	)
	for index: int in range(_nozzle_points.size()):
		var point: Vector3 = _nozzle_points[index]
		var core := _make_emitter("FlameCore%d" % index, point, 9, 0.2, core_ramp, true, Vector3(0, 0, 1), 4.0, 7.0, 10.0, Vector3.ZERO, 0.7, 1.1, false, false, true)
		var outer := _make_emitter("FlameOuter%d" % index, point, 11, 0.4, outer_ramp, true, Vector3(0, 0, 1), 11.0, 3.5, 6.5, Vector3.ZERO, 1.2, 2.0, false, false, true)
		_flame_emitters.append(core)
		_flame_emitters.append(outer)

	# --- Smuga światła za robotem ---
	var trail_ramp: Gradient = _make_ramp(
		[Color(_neon_color.r, _neon_color.g, _neon_color.b, 0.75), Color(_neon_color.r, _neon_color.g, _neon_color.b, 0.3), Color(_neon_color.r, _neon_color.g, _neon_color.b, 0.0)],
		[0.0, 0.5, 1.0]
	)
	_trail = _make_emitter("BoostTrail", Vector3(0, 0.12, rear_z + 0.15), 26, 0.65, trail_ramp, true, Vector3(0, 0, 1), 6.0, 0.0, 0.4, Vector3.ZERO, 1.2, 1.9, false, false, true)

	# --- Iskry lecące z tyłu i odbijające się od podłogi ---
	var spark_ramp: Gradient = _make_ramp(
		[Color(1.0, 0.97, 0.7, 1.0), Color(1.0, 0.6, 0.15, 0.9), Color(1.0, 0.3, 0.05, 0.0)],
		[0.0, 0.4, 1.0]
	)
	_boost_sparks = _make_emitter("BoostSparks", Vector3(0, 0.1, rear_z + 0.1), 18, 0.5, spark_ramp, true, Vector3(0, 0.6, 1.0), 35.0, 3.0, 7.0, Vector3(0, -14, 0), 0.14, 0.3)

	# --- Iskry zapłonu (jednorazowy wybuch przy starcie boosta) ---
	_ignite_sparks = _make_emitter("IgniteSparks", Vector3(0, 0.15, rear_z), 30, 0.6, spark_ramp, true, Vector3(0, 0.4, 1.0), 60.0, 4.0, 10.0, Vector3(0, -12, 0), 0.18, 0.4, false, true)

	# --- Dym przy uszkodzeniach ---
	var smoke_gradient := Gradient.new()
	smoke_gradient.set_color(0, Color(0.35, 0.35, 0.35, 0.55))
	smoke_gradient.set_color(1, Color(0.15, 0.15, 0.15, 0.0))
	_smoke = _make_emitter("DamageSmoke", Vector3(0, h + 0.1, 0.1), 14, 1.2, smoke_gradient, false, Vector3(0, 1, 0), 25.0, 0.6, 1.2, Vector3(0, 0.4, 0), 1.2, 2.4)

	# --- Iskry przy uderzeniach (jednorazowe) ---
	var impact_gradient := Gradient.new()
	impact_gradient.set_color(0, Color(1.0, 0.95, 0.6, 1.0))
	impact_gradient.set_color(1, Color(1.0, 0.4, 0.05, 0.0))
	_sparks = _make_emitter("Sparks", Vector3.ZERO, 14, 0.45, impact_gradient, true, Vector3(0, 1, 0), 70.0, 2.5, 5.5, Vector3(0, -12, 0), 0.25, 0.5, false, true)


func _build_jets() -> void:
	for index: int in range(_nozzle_points.size()):
		var point: Vector3 = _nozzle_points[index]
		var jet := MeshInstance3D.new()
		jet.name = "BoostJet%d" % index
		jet.mesh = _get_mesh("jet")
		jet.material_override = _jet_material()
		jet.rotation = Vector3(-PI * 0.5, 0.0, 0.0)
		jet.position = point + Vector3(0, 0, 0.1)
		jet.scale = Vector3(1.0, 0.2, 1.0)
		jet.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		jet.visible = false
		_model.add_child(jet)
		_jets.append(jet)


func _apply_ghost_look() -> void:
	var ghost_material := StandardMaterial3D.new()
	ghost_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	ghost_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	ghost_material.albedo_color = Color(0.55, 0.85, 1.0, 0.35)
	ghost_material.cull_mode = BaseMaterial3D.CULL_DISABLED
	for node: Node in _model.find_children("*", "MeshInstance3D", true, false):
		var mesh_instance: MeshInstance3D = node as MeshInstance3D
		mesh_instance.material_override = ghost_material
		mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


# =========================================================
# USTAWIENIA GRAFICZNE
# =========================================================

func apply_graphics() -> void:
	if not _built or ghost:
		return

	var neon_ring: Node3D = _model.get_node_or_null("NeonRing") as Node3D
	if neon_ring != null:
		neon_ring.visible = GameSettings.neon_enabled

	var fade: float = GameSettings.light_fade_distance()

	if _neon_light != null:
		_neon_light.visible = GameSettings.neon_light_allowed(is_player)
		_neon_light.distance_fade_enabled = not is_player
		_neon_light.distance_fade_begin = fade
		_neon_light.distance_fade_length = 4.0

	if _head_light != null:
		_head_light.visible = GameSettings.headlights_light_allowed(is_player)
		_head_light.shadow_enabled = GameSettings.headlight_shadows_allowed(is_player)
		_head_light.distance_fade_enabled = not is_player
		_head_light.distance_fade_begin = fade
		_head_light.distance_fade_length = 5.0

	_lens_material.emission_energy_multiplier = 2.5 if GameSettings.headlights_enabled else 0.2

	var particle_scale: float = GameSettings.get_particle_scale()
	if not is_player:
		particle_scale *= 0.55
	for entry: Variant in _vfx_emitters:
		var pair: Array = entry as Array
		_configure_particles(pair[0] as CPUParticles3D, int(pair[1]), particle_scale)

	if _boost_glow != null:
		_boost_glow.visible = _boost_visual and GameSettings.quality >= GameSettings.Quality.MEDIUM and GameSettings.effects_enabled
	_refresh_boost_emitters()


func _configure_particles(particles: CPUParticles3D, base_amount: int, particle_scale: float) -> void:
	if particles == null:
		return
	if particle_scale <= 0.0:
		particles.emitting = false
		particles.visible = false
		return
	particles.visible = true
	var amount: int = maxi(int(round(base_amount * particle_scale)), 4)
	if particles.amount != amount:
		particles.amount = amount


func _boost_effects_allowed() -> bool:
	return GameSettings.effects_enabled


func _refresh_boost_emitters() -> void:
	var active: bool = _boost_visual and _boost_effects_allowed()
	for particles: CPUParticles3D in _flame_emitters:
		if particles != null and particles.visible:
			particles.emitting = active
	if _trail != null and _trail.visible:
		_trail.emitting = active
	if _boost_sparks != null and _boost_sparks.visible:
		_boost_sparks.emitting = active


# =========================================================
# AKTUALIZACJA CO KLATKĘ (lekka)
# =========================================================

func update_visuals(delta: float, robot: Robot) -> void:
	if not _built:
		return

	var speed: float = robot.forward_speed
	var spin: float = clampf(absf(speed) * 1.6 + 4.0, 0.0, 26.0)
	if _brush_left != null:
		_brush_left.rotate_y(spin * delta)
	if _brush_right != null:
		_brush_right.rotate_y(-spin * delta)
	if _wheel_left != null:
		_wheel_left.rotate_x(speed * delta / 0.17)
		_wheel_right.rotate_x(speed * delta / 0.17)

	# Lekki przechył nadwozia w zakrętach i przy hamowaniu.
	var roll: float = clampf(-robot.yaw_rate * absf(speed) * 0.012, -0.12, 0.12)
	var pitch: float = clampf((robot.input_brake - robot.input_throttle * 0.3) * 0.04, -0.05, 0.06) if absf(speed) > 1.0 else 0.0
	var boosting: bool = false
	if not ghost:
		boosting = robot.boost.is_turbo_active()
		if boosting:
			# Przy turbo nos unosi się lekko, a nadwozie delikatnie drży.
			pitch += 0.05 * _boost_level
			_vfx_time += delta
			roll += sin(_vfx_time * 55.0) * 0.006 * _boost_level
	_model.rotation.z = lerpf(_model.rotation.z, roll, 1.0 - exp(-8.0 * delta))
	_model.rotation.x = lerpf(_model.rotation.x, pitch, 1.0 - exp(-6.0 * delta))

	if ghost:
		return

	if boosting != _boost_visual:
		_set_boost_visual(boosting)
	_update_boost_look(delta, robot)

	var damage_value: float = robot.damage.damage
	if absf(damage_value - _last_damage) > 0.5:
		_update_damage_look(damage_value)

	# Migające reflektory przy poważnych uszkodzeniach.
	if damage_value >= 75.0 and _head_light != null and _head_light.visible:
		_flicker_time += delta
		_head_light.light_energy = 3.0 if fmod(_flicker_time, 0.9) > 0.12 else 0.6


func _set_boost_visual(active: bool) -> void:
	_boost_visual = active
	_refresh_boost_emitters()
	if active:
		_play_boost_ignition()
	if _boost_glow != null:
		_boost_glow.visible = (active or _boost_level > 0.02) and GameSettings.quality >= GameSettings.Quality.MEDIUM and GameSettings.effects_enabled


## Płynne wejście i wyjście z efektu: strumienie rosną, dysze żarzą się, LED zmienia kolor.
func _update_boost_look(delta: float, robot: Robot) -> void:
	var target: float = 1.0 if (_boost_visual and _boost_effects_allowed()) else 0.0
	var rate: float = 7.0 if target > _boost_level else 3.5
	_boost_level = move_toward(_boost_level, target, delta * rate)
	var level: float = _boost_level

	_thruster_material.emission_energy_multiplier = 5.0 * level
	_thruster_material.emission = Color(1.0, 0.45, 0.1).lerp(Color(1.0, 0.9, 0.7), level * 0.5)
	_neon_material.emission_energy_multiplier = lerpf(3.0, 7.0, level)
	var led_color: Color = _neon_color.lerp(Color(1.0, 0.55, 0.12), level)
	_led_material.emission = led_color
	_led_material.albedo_color = led_color
	_led_material.emission_energy_multiplier = lerpf(2.2, 4.5, level)

	var speed_ratio: float = clampf(absf(robot.forward_speed) / maxf(robot.max_speed, 0.1), 0.0, 1.8)
	var pulse: float = 0.88 + 0.12 * sin(_vfx_time * 48.0)
	for jet: MeshInstance3D in _jets:
		jet.visible = level > 0.02 and GameSettings.effects_enabled
		if jet.visible:
			var length: float = lerpf(0.15, 0.9 + speed_ratio * 0.9, level) * pulse * _vfx_scale
			var width: float = lerpf(0.5, 1.0, level) * _vfx_scale
			jet.scale = Vector3(width, length, width)
			jet.position.z = _nozzle_points[0].z + 0.06 + length * 0.5
			var jet_material: ShaderMaterial = jet.material_override as ShaderMaterial
			if jet_material != null:
				jet_material.set_shader_parameter("intensity", level)

	if _boost_glow != null and _boost_glow.visible:
		var flash: float = 0.0
		if _ignite_time > 0.0:
			_ignite_time = maxf(_ignite_time - delta, 0.0)
			flash = _ignite_time / 0.35 * 7.0
		_boost_glow.light_energy = (3.2 + sin(_vfx_time * 42.0) * 0.8) * maxf(level, 0.2) + flash
		_boost_glow.light_color = Color(1.0, 0.55, 0.18).lerp(Color(0.6, 0.8, 1.0), 0.25 * level)
	elif _boost_glow != null and level <= 0.02:
		_boost_glow.visible = false


## Zapłon: błysk światła, iskry i rozchodząca się fala uderzeniowa przy podłodze.
func _play_boost_ignition() -> void:
	if not GameSettings.effects_enabled:
		return
	_ignite_time = 0.35
	if _ignite_sparks != null and _ignite_sparks.visible:
		_ignite_sparks.restart()
		_ignite_sparks.emitting = true
	if not is_inside_tree():
		return
	for ring_index: int in range(2):
		var ring := MeshInstance3D.new()
		ring.mesh = _get_mesh("shock_ring")
		ring.top_level = true
		ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		var material := StandardMaterial3D.new()
		material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		material.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
		var ring_color: Color = Color(1.0, 0.7, 0.3, 0.85) if ring_index == 0 else Color(_neon_color.r, _neon_color.g, _neon_color.b, 0.7)
		material.albedo_color = ring_color
		ring.material_override = material
		add_child(ring)
		ring.global_position = global_position + Vector3(0, 0.06 + ring_index * 0.03, 0)
		ring.scale = Vector3(0.4, 1.0, 0.4)
		var final_scale: float = 3.4 - ring_index * 0.9
		var duration: float = 0.5 + ring_index * 0.15
		var tween: Tween = create_tween()
		tween.set_parallel(true)
		tween.tween_property(ring, "scale", Vector3(final_scale, 1.0, final_scale), duration).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
		tween.tween_property(material, "albedo_color:a", 0.0, duration).set_ease(Tween.EASE_IN)
		tween.chain().tween_callback(ring.queue_free)


func _update_damage_look(damage_value: float) -> void:
	_last_damage = damage_value
	var t: float = clampf(damage_value / 100.0, 0.0, 1.0)
	_body_material.albedo_color = _primary.lerp(Color(0.18, 0.17, 0.16), t * 0.5)
	_body_material.roughness = lerpf(clampf(float(config.get("roughness", 0.4)), 0.15, 0.9), 0.85, t)

	if _top_plate != null:
		# Przekrzywiona pokrywa od średnich uszkodzeń.
		var tilt: float = smoothstep(50.0, 100.0, damage_value) * 0.12
		_top_plate.rotation = Vector3(tilt * 0.6, 0.0, tilt)

	if _smoke != null and _smoke.visible:
		_smoke.emitting = damage_value >= 50.0
		var dark: float = 0.35 if damage_value < 75.0 else 0.12
		var gradient: Gradient = _smoke.color_ramp
		gradient.set_color(0, Color(dark, dark, dark, 0.6))

	if _head_light != null and damage_value < 75.0:
		_head_light.light_energy = 3.0


func play_impact(strength: float, world_position: Vector3) -> void:
	if _sparks == null or not _sparks.visible or strength < 0.2:
		return
	_sparks.global_position = world_position + Vector3.UP * 0.2
	_sparks.restart()
	_sparks.emitting = true
