
class_name StationConfig
extends RefCounted
## Dane i walidacja konfiguracji stacji dokującej.

const DEFAULT_LED_COLOR: Color = Color(0.0, 0.85, 1.0)


static func create_default(robot_color: Color) -> Dictionary:
	return {
		"type": 0,
		"level": 1,
		"body_color": robot_color,
		"led_color": DEFAULT_LED_COLOR,
		"rotation_degrees": 0.0,
		"service_owned": [],
		"service_equipped": [],
		"bonus_owned": [],
		"bonus_equipped": []
	}


static func normalize(data: Dictionary, robot_color: Color) -> Dictionary:
	var result: Dictionary = data.duplicate(true)

	# Migracja starszego formatu bonusów.
	if result.has("bonuses") and result["bonuses"] is Dictionary:
		var old_bonuses: Dictionary = result["bonuses"]

		if not result.has("bonus_owned"):
			result["bonus_owned"] = []

		if not result.has("bonus_equipped"):
			result["bonus_equipped"] = []

		for key: Variant in old_bonuses.keys():
			if bool(old_bonuses[key]):
				var module_id: String = str(key)

				if not result["bonus_owned"].has(module_id):
					result["bonus_owned"].append(module_id)

				if not result["bonus_equipped"].has(module_id):
					result["bonus_equipped"].append(module_id)

		result.erase("bonuses")

	# Typ stacji.
	result["type"] = clampi(
		int(result.get("type", 0)),
		0,
		StationDatabase.STATION_TYPES.size() - 1
	)

	# Poziom stacji.
	result["level"] = clampi(
		int(result.get("level", 1)),
		1,
		StationDatabase.get_max_level()
	)

	# Kolory.
	var body_color: Variant = result.get("body_color", robot_color)
	if body_color is Color:
		result["body_color"] = robot_color
	else:
		result["body_color"] = robot_color

	var led_color: Variant = result.get("led_color", DEFAULT_LED_COLOR)
	if led_color is Color:
		result["led_color"] = led_color
	else:
		result["led_color"] = DEFAULT_LED_COLOR

	# Obrót.
	result["rotation_degrees"] = fposmod(
		float(result.get("rotation_degrees", 0.0)),
		360.0
	)

	# Listy modułów.
	result["service_owned"] = _normalize_string_array(
		result.get("service_owned", [])
	)
	result["service_equipped"] = _normalize_string_array(
		result.get("service_equipped", [])
	)
	result["bonus_owned"] = _normalize_string_array(
		result.get("bonus_owned", [])
	)
	result["bonus_equipped"] = _normalize_string_array(
		result.get("bonus_equipped", [])
	)

	# Wyposażenie musi należeć do posiadanych modułów.
	result["service_equipped"] = _keep_owned(
		result["service_equipped"],
		result["service_owned"]
	)

	result["bonus_equipped"] = _keep_owned(
		result["bonus_equipped"],
		result["bonus_owned"]
	)

	# Limit slotów bonusowych odpowiada poziomowi stacji.
	var bonus_limit: int = int(result["level"])
	if result["bonus_equipped"].size() > bonus_limit:
		result["bonus_equipped"].resize(bonus_limit)

	return result


static func _normalize_string_array(value: Variant) -> Array[String]:
	var result: Array[String] = []

	if not value is Array:
		return result

	for item: Variant in value:
		var item_id: String = str(item)

		if not item_id.is_empty() and not result.has(item_id):
			result.append(item_id)

	return result


static func _keep_owned(
	equipped: Array[String],
	owned: Array[String]
) -> Array[String]:
	var result: Array[String] = []

	for module_id: String in equipped:
		if owned.has(module_id) and not result.has(module_id):
			result.append(module_id)

	return result


static func normalize_equipped_bonuses(data: Dictionary) -> Dictionary:
	var result: Dictionary = data.duplicate(true)

	var owned: Array[String] = _normalize_string_array(
		result.get("bonus_owned", [])
	)
	var equipped: Array[String] = _normalize_string_array(
		result.get("bonus_equipped", [])
	)

	equipped = _keep_owned(equipped, owned)

	var limit: int = clampi(
		int(result.get("level", 1)),
		1,
		StationDatabase.get_max_level()
	)

	if equipped.size() > limit:
		equipped.resize(limit)

	result["bonus_owned"] = owned
	result["bonus_equipped"] = equipped

	return result
