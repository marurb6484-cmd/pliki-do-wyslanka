
class_name StationDatabase
extends RefCounted
## Centralna baza danych stacji dokujących.
## Przechowuje typy stacji, ceny poziomów oraz dostępne moduły.

# =========================================================
# TYPY STACJI
# =========================================================

const STATION_TYPES: Array[String] = [
	"SERWISOWA",
	"TURBO",
	"FORTRESS"
]


# =========================================================
# KOSZTY ROZBUDOWY STACJI
# =========================================================

# Indeks 0 = zakup poziomu 2.
# Indeks 1 = zakup poziomu 3 itd.

const LEVEL_COSTS: Array[int] = [
	350,
	700,
	1200,
	1900
]


# =========================================================
# MODUŁY SERWISOWE
# =========================================================

const SERVICE_MODULES: Array[Dictionary] = [
	{
		"id": "repair_arm",
		"name": "RAMIĘ NAPRAWCZE",
		"cost": 250
	},
	{
		"id": "cleaning_system",
		"name": "SYSTEM CZYSZCZENIA",
		"cost": 300
	},
	{
		"id": "power_coil",
		"name": "CEWKA ŁADOWANIA",
		"cost": 400
	},
	{
		"id": "shield_frame",
		"name": "OSŁONA SERWISOWA",
		"cost": 450
	}
]


# =========================================================
# MODUŁY BONUSOWE
# =========================================================

const BONUS_MODULES: Array[Dictionary] = [
	{
		"id": "quick_charge",
		"name": "SZYBKIE ŁADOWANIE",
		"cost": 180
	},
	{
		"id": "turbo_start",
		"name": "TURBO START",
		"cost": 220
	},
	{
		"id": "traction",
		"name": "TRAKCJA",
		"cost": 180
	},
	{
		"id": "dirt_storage",
		"name": "ZBIORNIK BRUDU",
		"cost": 200
	},
	{
		"id": "stabilizer",
		"name": "STABILIZACJA",
		"cost": 240
	},
	{
		"id": "aero",
		"name": "MODUŁ AERO",
		"cost": 260
	}
]


# =========================================================
# FUNKCJE PUBLICZNE
# =========================================================

static func get_station_types() -> Array[String]:
	return STATION_TYPES.duplicate()


static func get_level_costs() -> Array[int]:
	return LEVEL_COSTS.duplicate()


static func get_level_cost(current_level: int) -> int:
	var cost_index: int = current_level - 1

	if cost_index < 0 or cost_index >= LEVEL_COSTS.size():
		return -1

	return LEVEL_COSTS[cost_index]


static func get_service_modules() -> Array[Dictionary]:
	return SERVICE_MODULES.duplicate(true)


static func get_bonus_modules() -> Array[Dictionary]:
	return BONUS_MODULES.duplicate(true)


static func get_module(
	module_id: String,
	module_list: Array[Dictionary]
) -> Dictionary:
	for module: Dictionary in module_list:
		if str(module.get("id", "")) == module_id:
			return module.duplicate(true)

	return {}


static func find_service_module(module_id: String) -> Dictionary:
	return get_module(module_id, SERVICE_MODULES)


static func find_bonus_module(module_id: String) -> Dictionary:
	return get_module(module_id, BONUS_MODULES)


static func get_station_type_name(type_index: int) -> String:
	if type_index < 0 or type_index >= STATION_TYPES.size():
		return STATION_TYPES[0]

	return STATION_TYPES[type_index]


static func get_max_level() -> int:
	return LEVEL_COSTS.size() + 1


static func get_module_count(module_list: Array[Dictionary]) -> int:
	return module_list.size()
