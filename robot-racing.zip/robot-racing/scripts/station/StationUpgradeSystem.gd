class_name StationUpgradeSystem
extends RefCounted
## Przelicza wpływ poziomu i modułów stacji na parametry serwisu.

const BASE_CHARGE_RATE: float = 10.0
const BASE_REPAIR_RATE: float = 7.0


static func get_service_rates(station_data: Dictionary) -> Dictionary:
	var service: Array = station_data.get("service_equipped", [])
	var bonus: Array = station_data.get("bonus_equipped", [])
	var level: int = maxi(int(station_data.get("level", 1)), 1)
	var charge: float = BASE_CHARGE_RATE * (1.0 + float(level - 1) * 0.08)
	var repair: float = BASE_REPAIR_RATE * (1.0 + float(level - 1) * 0.05)
	if service.has("power_coil"):
		charge *= 1.2
	if bonus.has("quick_charge"):
		charge *= 1.55
	if service.has("repair_arm"):
		repair *= 1.6
	if int(station_data.get("type", 0)) == 1:
		charge *= 1.1
	return {"charge_rate": charge, "repair_rate": repair}
