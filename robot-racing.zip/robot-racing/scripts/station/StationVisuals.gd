class_name StationVisuals
extends RefCounted
## Główny koordynator budowania wyglądu stacji dokującej.

var _structure: StationStructure
var _type_visuals: StationTypeVisuals
var _level_visuals: StationLevelVisuals
var _service_visuals: StationServiceVisuals
var _bonus_visuals: StationBonusVisuals


func _init() -> void:
	_structure = StationStructure.new()
	_type_visuals = StationTypeVisuals.new()
	_level_visuals = StationLevelVisuals.new()
	_service_visuals = StationServiceVisuals.new()
	_bonus_visuals = StationBonusVisuals.new()


func build(
	parent: Node3D,
	station_data: Dictionary
) -> void:
	if not is_instance_valid(parent):
		return

	_clear_children(parent)
	# Stacja ma zachować oryginalną geometrię, ale jej gabaryt w świecie
	# dopasowujemy proporcjonalnie do robota 30–35 cm.
	parent.scale = Vector3.ONE * 0.35

	var body_color: Color = _get_color(
		station_data.get("body_color", Color.WHITE),
		Color.WHITE
	)

	var led_color: Color = _get_color(
		station_data.get("led_color", StationConfig.DEFAULT_LED_COLOR),
		StationConfig.DEFAULT_LED_COLOR
	)

	var type_index: int = clampi(
		int(station_data.get("type", 0)),
		0,
		StationDatabase.STATION_TYPES.size() - 1
	)

	var level: int = clampi(
		int(station_data.get("level", 1)),
		1,
		StationDatabase.get_max_level()
	)

	var service_equipped: Array = _get_array(
		station_data.get("service_equipped", [])
	)

	var bonus_equipped: Array = _get_array(
		station_data.get("bonus_equipped", [])
	)

	# Podstawowa konstrukcja (geometria zależna od poziomu).
	_structure.build(
		parent,
		body_color,
		led_color,
		level
	)

	# Wygląd wybranego typu.
	_type_visuals.build(
		parent,
		type_index,
		body_color,
		led_color
	)

	# Elementy wynikające z poziomu stacji.
	_level_visuals.build(
		parent,
		level,
		body_color,
		led_color
	)

	# Zamontowane moduły serwisowe.
	_service_visuals.build(
		parent,
		service_equipped,
		body_color,
		led_color,
		level,
		type_index
	)

	# Zamontowane moduły bonusowe.
	_bonus_visuals.build(
		parent,
		bonus_equipped,
		body_color,
		led_color,
		level,
		type_index
	)


func rebuild(
	parent: Node3D,
	station_data: Dictionary
) -> void:
	build(parent, station_data)


func _clear_children(parent: Node3D) -> void:
	for child: Node in parent.get_children():
		parent.remove_child(child)
		child.queue_free()


func _get_color(value: Variant, fallback: Color) -> Color:
	if value is Color:
		return value

	return fallback


func _get_array(value: Variant) -> Array:
	if value is Array:
		return value.duplicate(true)

	return []
