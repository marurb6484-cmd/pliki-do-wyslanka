class_name StationBonusVisuals
extends RefCounted
## Wizualizacja wyposażonych modułów bonusowych.
## level i station_type są opcjonalne (stare wywołania nadal działają).

func build(
	parent: Node3D,
	equipped_modules: Array,
	body_color: Color,
	led_color: Color,
	level: int = 1,
	station_type: int = 0
) -> void:
	if not is_instance_valid(parent):
		return

	var c: Dictionary = StationPartKit.ctx(level)

	for module_value: Variant in equipped_modules:
		var module_id: String = str(module_value)
		var kit: StationPartKit = null

		match module_id:
			"quick_charge":
				kit = StationPartKit.create(parent, "QuickCharge", body_color, led_color, station_type)
				_build_quick_charge(kit, c)

			"turbo_start":
				kit = StationPartKit.create(parent, "TurboStart", body_color, led_color, station_type)
				_build_turbo_start(kit, c)

			"traction":
				kit = StationPartKit.create(parent, "Traction", body_color, led_color, station_type)
				_build_traction(kit, c)

			"dirt_storage":
				kit = StationPartKit.create(parent, "DirtStorage", body_color, led_color, station_type)
				_build_dirt_storage(kit, c)

			"stabilizer":
				kit = StationPartKit.create(parent, "Stabilizer", body_color, led_color, station_type)
				_build_stabilizer(kit, c)

			"aero":
				kit = StationPartKit.create(parent, "Aero", body_color, led_color, station_type)
				_build_aero(kit, c)

		if kit != null:
			kit.flush()


## Szybkie ładowanie: dwa radiatory styków dużej mocy po bokach ściany dokowania.
func _build_quick_charge(k: StationPartKit, _c: Dictionary) -> void:
	var zb: float = StationStructure.BACK_Z
	var y: float = 0.30

	for s: float in [-1.0, 1.0]:
		var x: float = s * 0.5
		k.box("metal", Vector3(x, y, zb - 0.031), Vector3(0.16, 0.2, 0.012))
		for i: int in 5:
			k.box("steel", Vector3(x + (float(i) - 2.0) * 0.034, y, zb - 0.041), Vector3(0.012, 0.17, 0.008))
		k.box("led", Vector3(x, y + 0.115, zb - 0.034), Vector3(0.12, 0.012, 0.008))
		k.box("dark", Vector3(x, y - 0.115, zb - 0.034), Vector3(0.12, 0.014, 0.012))


## Turbo start: blok dwóch dysz na tylnej ścianie (lewy dolny róg).
func _build_turbo_start(k: StationPartKit, c: Dictionary) -> void:
	var w: float = c["w"]
	var fz: float = c["front_z"]
	var x: float = -(w * 0.5 - 0.34)
	var y: float = 0.27

	k.box("dark", Vector3(x, y, fz + 0.01), Vector3(0.5, 0.22, 0.02))
	k.box("body", Vector3(x, y, fz + 0.08), Vector3(0.46, 0.2, 0.12), 0.04)
	k.box("led", Vector3(x, y + 0.09, fz + 0.1415), Vector3(0.2, 0.01, 0.004))

	for i: int in 3:
		k.box("metal", Vector3(x + (float(i) - 1.0) * 0.12, y + 0.11, fz + 0.08), Vector3(0.01, 0.02, 0.1))

	for n: float in [-1.0, 1.0]:
		var nx: float = x + n * 0.11
		k.cyl("steel", Vector3(nx, y, fz + 0.19), 0.075, 0.048, 0.1, 2, 16)
		k.cyl("led", Vector3(nx, y, fz + 0.2405), 0.066, 0.066, 0.004, 2, 16)
		k.cyl("gloss", Vector3(nx, y, fz + 0.2425), 0.048, 0.048, 0.004, 2, 16)


## Trakcja: niskie maty antypoślizgowe na wjeździe platformy (wys. ok. 1,6 cm).
func _build_traction(k: StationPartKit, c: Dictionary) -> void:
	var pw: float = c["pw"]
	var pz: float = float(c["plat_front_z"]) + 0.22
	var pad_w: float = pw * 0.2

	for s: float in [-1.0, 1.0]:
		var x: float = s * pw * 0.2
		k.box("rubber", Vector3(x, 0.148, pz), Vector3(pad_w, 0.016, 0.18))
		for e: float in [-1.0, 1.0]:
			k.box("trim", Vector3(x + e * (pad_w * 0.5 - 0.006), 0.15, pz), Vector3(0.012, 0.02, 0.18))
		for i: int in 5:
			k.box("metal", Vector3(x, 0.1585, pz - 0.07 + 0.035 * float(i)), Vector3(pad_w - 0.04, 0.005, 0.012))
		k.box("led", Vector3(x, 0.152, pz - 0.085), Vector3(pad_w * 0.7, 0.008, 0.008))


## Zbiornik brudu: wymienny zbiornik z okienkiem, uchwytem i zaworem na tylnej ścianie (prawy róg).
func _build_dirt_storage(k: StationPartKit, c: Dictionary) -> void:
	var w: float = c["w"]
	var h: float = c["h"]
	var fz: float = c["front_z"]
	var tw: float = 0.36
	var th: float = clampf(h * 0.62, 0.3, 0.9)
	var x: float = w * 0.5 - 0.3
	var y0: float = 0.16
	var yc: float = y0 + th * 0.5
	var zs: float = fz + 0.03
	var zf: float = zs + 0.2

	# Płyta mocująca i korpus zbiornika.
	k.box("dark", Vector3(x, yc, fz + 0.015), Vector3(tw - 0.08, th * 0.8, 0.03))
	k.box("body", Vector3(x, yc, zs + 0.1), Vector3(tw, th, 0.2), 0.04)

	# Okienko z osadem i podziałką.
	var wy: float = yc + th * 0.02
	k.box("gloss", Vector3(x, wy, zf + 0.003), Vector3(tw * 0.64, th * 0.72, 0.01))
	k.box("dirt", Vector3(x, wy - th * 0.72 * 0.27, zf + 0.007), Vector3(tw * 0.58, th * 0.72 * 0.46, 0.008))
	for i: int in 4:
		var ty: float = wy + th * 0.72 * (-0.3 + 0.2 * float(i))
		k.box("metal", Vector3(x + tw * 0.27, ty, zf + 0.012), Vector3(tw * 0.1, 0.006, 0.004))

	# Pokrywa z uchwytem.
	var cap_top: float = yc + th * 0.5 + 0.0325
	k.box("trim", Vector3(x, yc + th * 0.5 + 0.015, zs + 0.1), Vector3(tw * 0.8, 0.035, 0.17), 0.015)
	for e: float in [-1.0, 1.0]:
		k.box("dark", Vector3(x + e * tw * 0.2, cap_top + 0.02, zs + 0.1), Vector3(0.02, 0.04, 0.03))
	k.box("metal", Vector3(x, cap_top + 0.045, zs + 0.1), Vector3(tw * 0.5, 0.02, 0.03))

	# Zawór spustowy i dioda poziomu.
	k.cyl("metal", Vector3(x, y0 - 0.025, zs + 0.1), 0.03, 0.03, 0.05, 1, 12)
	k.box("led", Vector3(x - tw * 0.5 + 0.03, yc, zf + 0.003), Vector3(0.01, th * 0.5, 0.008))


## Stabilizacja: dwa żyroskopowe pody na górnych narożnikach tylnej ściany.
func _build_stabilizer(k: StationPartKit, c: Dictionary) -> void:
	var w: float = c["w"]
	var h: float = c["h"]
	var fz: float = c["front_z"]
	var y: float = 0.03 + h * 0.72
	var x: float = w * 0.5 - 0.22

	for s: float in [-1.0, 1.0]:
		var px: float = s * x
		k.box("dark", Vector3(px, y, fz + 0.012), Vector3(0.26, 0.26, 0.024), 0.02)
		for dx: float in [-0.1, 0.1]:
			for dy: float in [-0.1, 0.1]:
				k.box("metal", Vector3(px + dx, y + dy, fz + 0.026), Vector3(0.016, 0.016, 0.006))
		k.cyl("body", Vector3(px, y, fz + 0.084), 0.1, 0.1, 0.12, 2, 20)
		k.cyl("trim", Vector3(px, y, fz + 0.15), 0.108, 0.108, 0.02, 2, 20)
		k.cyl("led", Vector3(px, y, fz + 0.1615), 0.09, 0.09, 0.002, 2, 20)
		k.cyl("metal", Vector3(px, y, fz + 0.1625), 0.075, 0.075, 0.005, 2, 20)
		k.cyl("gloss", Vector3(px, y, fz + 0.167), 0.03, 0.03, 0.004, 2, 12)


## Aero: spoiler na górnej tylnej krawędzi (nad ekranem, poza koroną poziomów 3-5).
func _build_aero(k: StationPartKit, c: Dictionary) -> void:
	var w: float = c["w"]
	var fz: float = c["front_z"]
	var top_y: float = c["top_y"]
	var span: float = w * 0.72
	var wy: float = top_y + 0.19
	var wz: float = fz + 0.02

	for s: float in [-1.0, 1.0]:
		k.box("dark", Vector3(s * w * 0.3, top_y + 0.085, fz - 0.095), Vector3(0.07, 0.17, 0.06), 0.015)
		k.box("metal", Vector3(s * w * 0.3, wy + 0.02, wz), Vector3(0.025, 0.006, 0.025))
		k.box("dark", Vector3(s * (span * 0.5 - 0.01), wy, wz), Vector3(0.02, 0.1, 0.3))

	k.box("body", Vector3(0.0, wy, wz), Vector3(span, 0.035, 0.26), 0.015, Vector3(-6.0, 0.0, 0.0))
	k.box("trim", Vector3(0.0, wy, wz - 0.125), Vector3(span * 0.96, 0.012, 0.012))
	k.box("led", Vector3(0.0, wy - 0.022, wz + 0.12), Vector3(span * 0.6, 0.008, 0.01))
