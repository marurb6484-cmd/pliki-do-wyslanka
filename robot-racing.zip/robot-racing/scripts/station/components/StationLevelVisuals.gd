class_name StationLevelVisuals
extends RefCounted
## Dodatkowe elementy wizualne zależne od poziomu (pozycje liczone z profilu StationStructure).

var _body_mat: StandardMaterial3D
var _dark_mat: StandardMaterial3D
var _led_mat: StandardMaterial3D


func build(
	parent: Node3D,
	level: int,
	body_color: Color,
	led_color: Color
) -> void:
	if not is_instance_valid(parent):
		return

	var safe_level: int = clampi(
		level,
		1,
		StationDatabase.get_max_level()
	)

	_body_mat = _make_material(body_color, 0.2, 0.4)
	_dark_mat = _make_material(Color(0.07, 0.09, 0.11), 0.4, 0.35)
	_led_mat = _make_material(led_color, 0.1, 0.3, true)

	for current_level: int in range(2, safe_level + 1):
		_build_level(parent, current_level, safe_level)


func _build_level(parent: Node3D, level: int, max_level: int) -> void:
	var p: Dictionary = StationStructure.get_profile(max_level)
	var w: float = p["w"]
	var h: float = p["h"]
	var d: float = p["d"]
	var pw: float = p["pw"]
	var fz: float = p["front_z"]
	var top_y: float = p["top_y"]
	var back_z: float = StationStructure.BACK_Z

	match level:
		2:
			for sx: float in [-1.0, 1.0]:
				var side: String = "Left" if sx < 0.0 else "Right"
				_add_box(
					parent,
					"Level2%sPanel" % side,
					Vector3(sx * (w * 0.5 + 0.04), 0.03 + h * 0.5, back_z + d * 0.4),
					Vector3(0.08, h * 0.5, d * 0.55),
					_dark_mat
				)
			_add_box(
				parent,
				"Level2FrontLED",
				Vector3(0.0, h * 0.5, fz + 0.01),
				Vector3(w * 0.6, 0.045, 0.035),
				_led_mat
			)

		3:
			# Moduł górny jest zastępowany koroną na poziomie 5.
			if max_level < 5:
				var mz: float = back_z + d * 0.45
				_add_box(
					parent,
					"Level3TopModule",
					Vector3(0.0, top_y + 0.11, mz),
					Vector3(w * 0.55, 0.22, d * 0.55),
					_dark_mat
				)
				_add_box(
					parent,
					"Level3TopLED",
					Vector3(0.0, top_y + 0.235, mz),
					Vector3(w * 0.38, 0.045, 0.035),
					_led_mat
				)

		4:
			var wing_h: float = h * 0.55
			var wing_y: float = 0.03 + h * 0.45
			var wing_z: float = back_z + d * 0.5
			for sx: float in [-1.0, 1.0]:
				var side: String = "Left" if sx < 0.0 else "Right"
				var wx: float = sx * (w * 0.5 + 0.115)
				_add_box(
					parent,
					"Level4%sWing" % side,
					Vector3(wx, wing_y, wing_z),
					Vector3(0.22, wing_h, d * 0.7),
					_body_mat
				)
				_add_box(
					parent,
					"Level4%sLED" % side,
					Vector3(wx, wing_y + wing_h * 0.3, wing_z + d * 0.35 + 0.0175),
					Vector3(0.12, 0.055, 0.035),
					_led_mat
				)

		5:
			var cz: float = back_z + d * 0.5
			_add_box(
				parent,
				"Level5UpperArmor",
				Vector3(0.0, top_y + 0.07, cz),
				Vector3(w * 0.8, 0.14, d * 0.65),
				_body_mat
			)
			_add_box(
				parent,
				"Level5CenterCore",
				Vector3(0.0, top_y + 0.2, cz),
				Vector3(w * 0.3, 0.12, d * 0.4),
				_dark_mat
			)
			_add_box(
				parent,
				"Level5CoreLED",
				Vector3(0.0, top_y + 0.27, cz),
				Vector3(w * 0.2, 0.035, 0.035),
				_led_mat
			)
			_add_box(
				parent,
				"Level5PlatformLED",
				Vector3(0.0, 0.15, float(p["plat_front_z"]) - 0.017),
				Vector3(pw * 0.6, 0.03, 0.01),
				_led_mat
			)


func _make_material(
	color: Color,
	metallic: float = 0.3,
	roughness: float = 0.3,
	emission: bool = false
) -> StandardMaterial3D:
	var material: StandardMaterial3D = StandardMaterial3D.new()
	material.albedo_color = color
	material.metallic = metallic
	material.roughness = roughness

	if emission:
		material.emission_enabled = true
		material.emission = color
		material.emission_energy_multiplier = 1.5

	return material


func _add_box(
	parent: Node3D,
	node_name: String,
	position: Vector3,
	box_size: Vector3,
	material: Material
) -> MeshInstance3D:
	var instance: MeshInstance3D = MeshInstance3D.new()
	instance.name = node_name

	var mesh: BoxMesh = BoxMesh.new()
	mesh.size = box_size

	instance.mesh = mesh
	instance.material_override = material
	instance.position = position
	instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

	parent.add_child(instance)
	return instance
