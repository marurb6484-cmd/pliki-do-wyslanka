class_name StationPartKit
extends RefCounted
## Wspólny zestaw narzędzi dla modułów stacji: batching siatek (1 węzeł na materiał),
## zaokrąglone bryły, cylindry i materiały z cache.

static var _mesh_cache: Dictionary = {}
static var _mat_cache: Dictionary = {}

var body_color: Color = Color.WHITE
var led_color: Color = Color(0.0, 0.85, 1.0)
var station_type: int = 0
var root: Node3D
var _batches: Dictionary = {}


static func create(
	parent: Node3D,
	node_name: String,
	body: Color,
	led: Color,
	type_index: int = 0
) -> StationPartKit:
	var kit: StationPartKit = StationPartKit.new()
	kit.body_color = body
	kit.led_color = led
	kit.station_type = clampi(type_index, 0, 2)
	kit.root = Node3D.new()
	kit.root.name = node_name
	parent.add_child(kit.root)
	return kit


## Wymiary stacji dla poziomu + płaszczyzna boczna (side_x), na której montuje się moduły.
static func ctx(level: int) -> Dictionary:
	var lv: int = clampi(level, 1, 5)
	var p: Dictionary = StationStructure.get_profile(lv)
	var ext: float = 0.0
	if lv >= 4:
		ext = 0.225
	elif lv >= 2:
		ext = 0.08
	p["side_x"] = float(p["w"]) * 0.5 + ext
	p["level"] = lv
	return p


## Rodzaje: body, dark, gloss, metal, steel, rubber, accent, led, screen, water, dirt, trim.
## "trim" zależy od typu stacji: SERWISOWA = metal, TURBO = akcent LED, FORTRESS = stal.
func box(
	kind: String,
	pos: Vector3,
	size: Vector3,
	radius: float = 0.0,
	rot_deg: Vector3 = Vector3.ZERO
) -> void:
	var rot: Basis = Basis.from_euler(rot_deg * (PI / 180.0))
	_append(kind, _box_mesh(size, radius), Transform3D(rot, pos))


## Cylinder/stożek ściętym wzdłuż osi: 0 = X, 1 = Y, 2 = Z. r_top leży po stronie +osi.
func cyl(
	kind: String,
	pos: Vector3,
	r_top: float,
	r_bottom: float,
	length: float,
	axis: int = 1,
	segments: int = 16
) -> void:
	var rot: Basis = Basis.IDENTITY
	if axis == 0:
		rot = Basis(Vector3(0.0, 0.0, 1.0), -PI * 0.5)
	elif axis == 2:
		rot = Basis(Vector3(1.0, 0.0, 0.0), PI * 0.5)
	_append(kind, _cyl_mesh(r_top, r_bottom, length, segments), Transform3D(rot, pos))


func flush() -> void:
	for key: String in _batches.keys():
		var entry: Dictionary = _batches[key]
		var surface_tool: SurfaceTool = entry["st"]
		var mesh_instance: MeshInstance3D = MeshInstance3D.new()
		mesh_instance.name = "Mesh_" + key
		mesh_instance.mesh = surface_tool.commit()
		mesh_instance.material_override = entry["mat"]
		mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(mesh_instance)
	_batches.clear()


func _append(kind: String, mesh: ArrayMesh, xf: Transform3D) -> void:
	var key: String = kind
	if kind == "trim":
		key = ["metal", "accent", "steel"][station_type]

	if not _batches.has(key):
		var new_tool: SurfaceTool = SurfaceTool.new()
		new_tool.begin(Mesh.PRIMITIVE_TRIANGLES)
		_batches[key] = {"mat": _material(key), "st": new_tool}

	var surface_tool: SurfaceTool = _batches[key]["st"]
	surface_tool.append_from(mesh, 0, xf)


func _material(kind: String) -> StandardMaterial3D:
	var cache_key: String = "%s|%s|%s" % [kind, body_color.to_html(), led_color.to_html()]
	if _mat_cache.has(cache_key):
		return _mat_cache[cache_key]

	var m: StandardMaterial3D = StandardMaterial3D.new()
	m.metallic = 0.0
	m.roughness = 0.5

	match kind:
		"body":
			m.albedo_color = body_color
			m.roughness = 0.5
		"dark":
			m.albedo_color = Color(0.07, 0.085, 0.10)
			m.metallic = 0.1
			m.roughness = 0.5
		"gloss":
			m.albedo_color = Color(0.02, 0.03, 0.04)
			m.metallic = 0.35
			m.roughness = 0.12
		"metal":
			m.albedo_color = Color(0.72, 0.74, 0.77)
			m.metallic = 0.9
			m.roughness = 0.32
		"steel":
			m.albedo_color = Color(0.25, 0.27, 0.30)
			m.metallic = 0.8
			m.roughness = 0.45
		"rubber":
			m.albedo_color = Color(0.03, 0.03, 0.035)
			m.roughness = 0.95
		"accent":
			m.albedo_color = led_color.darkened(0.55)
			m.roughness = 0.55
		"water":
			m.albedo_color = Color(0.10, 0.34, 0.48)
			m.metallic = 0.1
			m.roughness = 0.08
		"dirt":
			m.albedo_color = Color(0.30, 0.22, 0.14)
			m.metallic = 0.1
			m.roughness = 0.1
		"screen":
			m.albedo_color = Color(0.015, 0.04, 0.05)
			m.metallic = 0.3
			m.roughness = 0.1
			m.emission_enabled = true
			m.emission = led_color.darkened(0.75)
			m.emission_energy_multiplier = 0.6
		"led":
			m.albedo_color = led_color
			m.metallic = 0.05
			m.roughness = 0.2
			m.emission_enabled = true
			m.emission = led_color
			m.emission_energy_multiplier = 1.1
		_:
			m.albedo_color = Color(0.5, 0.5, 0.5)

	_mat_cache[cache_key] = m
	return m


## Prostopadłościan: radius <= 0.01 = ostre (12 tri), inaczej zaokrąglony (108 tri).
func _box_mesh(size: Vector3, radius: float) -> ArrayMesh:
	var cache_key: String = "b|%s|%s" % [str(size), str(radius)]
	if _mesh_cache.has(cache_key):
		return _mesh_cache[cache_key]

	var sharp: bool = radius <= 0.01
	var half: Vector3 = size * 0.5
	var r: float = 0.0
	if not sharp:
		r = clampf(radius, 0.002, minf(half.x, minf(half.y, half.z)) * 0.95)
	var inner: Vector3 = half - Vector3(r, r, r)

	var verts: PackedVector3Array = PackedVector3Array()
	var norms: PackedVector3Array = PackedVector3Array()
	var idx: PackedInt32Array = PackedInt32Array()

	for axis: int in 3:
		for sgn: float in [-1.0, 1.0]:
			var ua: int = (axis + 1) % 3
			var va: int = (axis + 2) % 3
			var cu: PackedFloat32Array
			var cv: PackedFloat32Array
			if sharp:
				cu = PackedFloat32Array([-half[ua], half[ua]])
				cv = PackedFloat32Array([-half[va], half[va]])
			else:
				cu = PackedFloat32Array([-half[ua], -inner[ua], inner[ua], half[ua]])
				cv = PackedFloat32Array([-half[va], -inner[va], inner[va], half[va]])
			var out_n: Vector3 = Vector3.ZERO
			out_n[axis] = sgn
			var base: int = verts.size()
			var nv: int = cv.size()

			for i: int in cu.size():
				for j: int in nv:
					var q: Vector3 = Vector3.ZERO
					q[axis] = sgn * half[axis]
					q[ua] = cu[i]
					q[va] = cv[j]
					if sharp:
						verts.append(q)
						norms.append(out_n)
					else:
						var cc: Vector3 = q.clamp(-inner, inner)
						var dv: Vector3 = q - cc
						var n: Vector3 = out_n
						if dv.length() > 0.0001:
							n = dv.normalized()
						verts.append(cc + n * r)
						norms.append(n)

			for i: int in cu.size() - 1:
				for j: int in nv - 1:
					var a: int = base + i * nv + j
					var b: int = base + (i + 1) * nv + j
					var c2: int = base + (i + 1) * nv + j + 1
					var d2: int = base + i * nv + j + 1
					if sgn > 0.0:
						idx.append_array([a, c2, b, a, d2, c2])
					else:
						idx.append_array([a, b, c2, a, c2, d2])

	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = norms
	arrays[Mesh.ARRAY_INDEX] = idx

	var mesh: ArrayMesh = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	_mesh_cache[cache_key] = mesh
	return mesh


## Cylinder/stożek ścięty wzdłuż osi Y (bez UV, z nakładkami).
func _cyl_mesh(r_top: float, r_bottom: float, length: float, segments: int) -> ArrayMesh:
	var cache_key: String = "c|%s|%s|%s|%s" % [str(r_top), str(r_bottom), str(length), str(segments)]
	if _mesh_cache.has(cache_key):
		return _mesh_cache[cache_key]

	var seg: int = maxi(segments, 6)
	var half: float = length * 0.5
	var slope: float = (r_bottom - r_top) / maxf(length, 0.0001)

	var verts: PackedVector3Array = PackedVector3Array()
	var norms: PackedVector3Array = PackedVector3Array()
	var idx: PackedInt32Array = PackedInt32Array()

	for i: int in seg + 1:
		var ang: float = TAU * float(i) / float(seg)
		var cs: float = cos(ang)
		var sn: float = sin(ang)
		var nrm: Vector3 = Vector3(cs, slope, sn).normalized()
		verts.append(Vector3(cs * r_top, half, sn * r_top))
		norms.append(nrm)
		verts.append(Vector3(cs * r_bottom, -half, sn * r_bottom))
		norms.append(nrm)

	for i: int in seg:
		var a0: int = i * 2
		idx.append_array([a0, a0 + 1, a0 + 3, a0, a0 + 3, a0 + 2])

	var top_c: int = verts.size()
	verts.append(Vector3(0.0, half, 0.0))
	norms.append(Vector3.UP)
	var bot_c: int = verts.size()
	verts.append(Vector3(0.0, -half, 0.0))
	norms.append(Vector3.DOWN)

	var ring_base: int = verts.size()
	for i: int in seg + 1:
		var ang2: float = TAU * float(i) / float(seg)
		var cs2: float = cos(ang2)
		var sn2: float = sin(ang2)
		verts.append(Vector3(cs2 * r_top, half, sn2 * r_top))
		norms.append(Vector3.UP)
		verts.append(Vector3(cs2 * r_bottom, -half, sn2 * r_bottom))
		norms.append(Vector3.DOWN)

	for i: int in seg:
		var b0: int = ring_base + i * 2
		idx.append_array([top_c, b0, b0 + 2])
		idx.append_array([bot_c, b0 + 3, b0 + 1])

	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = norms
	arrays[Mesh.ARRAY_INDEX] = idx

	var mesh: ArrayMesh = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	_mesh_cache[cache_key] = mesh
	return mesh