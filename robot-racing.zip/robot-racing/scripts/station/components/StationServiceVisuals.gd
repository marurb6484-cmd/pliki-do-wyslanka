class_name StationServiceVisuals
extends RefCounted
## Wizualizacja zamontowanych modułów serwisowych.
## level i station_type są opcjonalne (stare wywołania nadal działają).

func build(
	parent: Node3D,
	equipped_modules: Array,
	body_color: Color,
	led_color: Color,
	level: int = 1,
	station_type: int = 0
) -> void:
	if not is_instance_valid(parent):
		return

	var c: Dictionary = StationPartKit.ctx(level)

	for module_value: Variant in equipped_modules:
		var module_id: String = str(module_value)
		var kit: StationPartKit = null

		match module_id:
			"repair_arm":
				kit = StationPartKit.create(parent, "RepairArm", body_color, led_color, station_type)
				_build_repair_arm(kit, c)

			"cleaning_system":
				kit = StationPartKit.create(parent, "CleaningSystem", body_color, led_color, station_type)
				_build_cleaning_system(kit, c)

			"power_coil":
				kit = StationPartKit.create(parent, "PowerCoil", body_color, led_color, station_type)
				_build_power_coil(kit, c)

			"shield_frame":
				kit = StationPartKit.create(parent, "ShieldFrame", body_color, led_color, station_type)
				_build_shield_frame(kit, c)

		if kit != null:
			kit.flush()


## Ramię naprawcze: lewa ściana boczna, złożone wzdłuż obudowy.
func _build_repair_arm(k: StationPartKit, c: Dictionary) -> void:
	var h: float = c["h"]
	var d: float = c["d"]
	var s: float = -1.0
	var o: float = c["side_x"]
	var y: float = 0.03 + h * 0.6
	var z0: float = StationStructure.BACK_Z + d * 0.3
	var up: float = d * 0.55
	var fore: float = d * 0.45
	var ang: float = 28.0
	var dir: Vector3 = Vector3(0.0, sin(deg_to_rad(ang)), cos(deg_to_rad(ang)))
	var ax: float = s * (o + 0.17)

	# Płyta mocująca ze śrubami.
	k.box("dark", Vector3(s * (o + 0.025), y, z0 + 0.02), Vector3(0.05, 0.32, 0.36), 0.015)
	for dy: float in [-0.12, 0.12]:
		for dz: float in [-0.13, 0.13]:
			k.box("metal", Vector3(s * (o + 0.054), y + dy, z0 + 0.02 + dz), Vector3(0.012, 0.028, 0.028))

	# Obudowa przegubu barkowego.
	k.box("body", Vector3(s * (o + 0.10), y, z0), Vector3(0.1, 0.2, 0.2), 0.035)
	k.cyl("metal", Vector3(ax, y, z0), 0.075, 0.075, 0.14, 0, 16)

	# Ramię górne z przewodem.
	k.box("body", Vector3(ax, y, z0 + up * 0.5), Vector3(0.07, 0.085, up), 0.02)
	k.box("rubber", Vector3(s * (o + 0.215), y + 0.015, z0 + up * 0.5), Vector3(0.014, 0.014, up * 0.9))

	# Łokieć i przedramię (uniesione).
	k.cyl("metal", Vector3(ax, y, z0 + up), 0.06, 0.06, 0.12, 0, 14)
	var elbow_z: float = z0 + up
	k.box(
		"metal",
		Vector3(ax, y + dir.y * fore * 0.5, elbow_z + dir.z * fore * 0.5),
		Vector3(0.055, 0.06, fore),
		0.015,
		Vector3(-ang, 0.0, 0.0)
	)

	# Nadgarstek, szczęki chwytaka i lampka robocza.
	var tip_y: float = y + dir.y * fore
	var tip_z: float = elbow_z + dir.z * fore
	k.cyl("dark", Vector3(ax, tip_y, tip_z), 0.04, 0.04, 0.09, 0, 12)
	for j: float in [-1.0, 1.0]:
		k.box(
			"dark",
			Vector3(ax + j * 0.028, tip_y + dir.y * 0.07, tip_z + dir.z * 0.07),
			Vector3(0.016, 0.05, 0.1),
			0.0,
			Vector3(-ang, 0.0, 0.0)
		)
	k.box("led", Vector3(ax, tip_y + 0.045, tip_z), Vector3(0.035, 0.01, 0.035))


## System czyszczenia: prawa ściana boczna, jednostka płuczko-suszarka z wlotem wody.
func _build_cleaning_system(k: StationPartKit, c: Dictionary) -> void:
	var h: float = c["h"]
	var d: float = c["d"]
	var s: float = 1.0
	var o: float = c["side_x"]
	var ht: float = minf(0.46, h * 0.75)
	var ln: float = d * 0.7
	var dp: float = 0.22
	var y: float = 0.03 + h * 0.5
	var zc: float = StationStructure.BACK_Z + d * 0.5
	var fx: float = o + 0.04 + dp

	# Płyta mocująca i obudowa.
	k.box("dark", Vector3(s * (o + 0.02), y, zc), Vector3(0.04, ht * 0.9, ln * 0.9))
	k.box("body", Vector3(s * (o + 0.04 + dp * 0.5), y, zc), Vector3(dp, ht, ln), 0.035)

	# Kratka nawiewu z żebrami.
	k.box("dark", Vector3(s * (fx + 0.003), y + ht * 0.08, zc), Vector3(0.008, ht * 0.5, ln * 0.72))
	for i: int in 5:
		var sy: float = y + ht * 0.08 + ht * 0.5 * (-0.4 + 0.2 * float(i))
		k.box("metal", Vector3(s * (fx + 0.009), sy, zc), Vector3(0.008, 0.012, ln * 0.62))

	# Mini wyświetlacz, dioda i pasek LED.
	k.box("screen", Vector3(s * (fx + 0.003), y - ht * 0.34, zc - ln * 0.2), Vector3(0.008, 0.06, 0.14))
	k.box("led", Vector3(s * (fx + 0.004), y - ht * 0.34, zc + ln * 0.22), Vector3(0.008, 0.016, 0.016))
	k.box("led", Vector3(s * (fx + 0.003), y + ht * 0.44, zc), Vector3(0.008, 0.014, ln * 0.5))

	# Rura wodna na wspornikach z kołnierzem.
	var ty: float = y + ht * 0.5
	for dz: float in [-1.0, 1.0]:
		k.box("dark", Vector3(s * (o + 0.10), ty + 0.015, zc + dz * ln * 0.35), Vector3(0.1, 0.03, 0.04))
	k.cyl("metal", Vector3(s * (o + 0.10), ty + 0.05, zc), 0.025, 0.025, ln * 0.8, 2, 12)
	k.cyl("trim", Vector3(s * (o + 0.10), ty + 0.05, zc + ln * 0.4), 0.033, 0.033, 0.03, 2, 12)

	# Dysza spryskująca pod obudową.
	k.cyl("metal", Vector3(s * (o + 0.14), y - ht * 0.5 - 0.03, zc), 0.03, 0.02, 0.06, 1, 12)


## Cewka ładowania: płaski moduł indukcyjny na ścianie dokowania (nie blokuje robota).
func _build_power_coil(k: StationPartKit, _c: Dictionary) -> void:
	var zb: float = StationStructure.BACK_Z
	var y: float = 0.30

	k.cyl("trim", Vector3(0.0, y, zb - 0.033), 0.175, 0.175, 0.014, 2, 24)
	k.cyl("dark", Vector3(0.0, y, zb - 0.034), 0.15, 0.15, 0.016, 2, 24)
	k.cyl("led", Vector3(0.0, y, zb - 0.0425), 0.125, 0.125, 0.002, 2, 24)
	k.cyl("gloss", Vector3(0.0, y, zb - 0.0432), 0.1, 0.1, 0.002, 2, 24)
	k.cyl("metal", Vector3(0.0, y, zb - 0.0442), 0.035, 0.035, 0.004, 2, 16)


## Osłona serwisowa: opancerzone płyty na zewnętrznych stronach prowadnic + zderzaki wejściowe.
func _build_shield_frame(k: StationPartKit, c: Dictionary) -> void:
	var pw: float = c["pw"]
	var pd: float = c["pd"]
	var gh: float = c["gh"]
	var lv: int = c["level"]
	var gx: float = pw * 0.5 - 0.17
	var gw: float = 0.12 if lv == 1 else 0.16
	var gz: float = float(c["plat_cz"]) - 0.03
	var gl: float = pd - 0.35
	var top: float = 0.08 + gh
	var plate_h: float = gh + 0.06
	var plate_y: float = 0.10 + plate_h * 0.5

	for s: float in [-1.0, 1.0]:
		var px: float = s * (gx + gw * 0.5 + 0.02)

		# Płyta pancerna, listwa wierzchnia, szczelina LED i śruby.
		k.box("body", Vector3(px, plate_y, gz), Vector3(0.035, plate_h, gl * 0.9), 0.015)
		k.box("trim", Vector3(px, 0.10 + plate_h + 0.007, gz), Vector3(0.05, 0.014, gl * 0.9))
		k.box("led", Vector3(px + s * 0.019, plate_y - 0.01, gz), Vector3(0.006, 0.014, gl * 0.6))
		for i: int in 4:
			k.box(
				"metal",
				Vector3(px + s * 0.019, plate_y + 0.035, gz + (float(i) - 1.5) * gl * 0.28),
				Vector3(0.008, 0.02, 0.02)
			)

		# Zderzak na wjeździe prowadnicy.
		var bz: float = gz - gl * 0.5 - 0.02
		k.box("dark", Vector3(s * gx, 0.08 + gh * 0.4, bz), Vector3(gw + 0.07, gh * 0.8, 0.07), 0.02)
		k.box("trim", Vector3(s * gx, 0.08 + gh * 0.8 + 0.008, bz), Vector3(gw + 0.07, 0.014, 0.075))
