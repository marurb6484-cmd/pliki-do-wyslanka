class_name StationStructure
extends RefCounted
## Buduje konstrukcję stacji zależną od poziomu 1-5 (proceduralnie, mobile-friendly).

const BACK_Z: float = 0.345
const PLATFORM_BACK_Z: float = 0.425

## w/h/d - obudowa, pw/pd - platforma, gh - wysokość prowadnic, r - zaokrąglenie, screen - ekran (0 = brak).
const PROFILES: Array = [
	{"w": 1.7, "h": 0.55, "d": 0.6, "pw": 2.4, "pd": 2.1, "gh": 0.16, "r": 0.03, "screen": Vector2(0.0, 0.0)},
	{"w": 1.95, "h": 0.72, "d": 0.66, "pw": 2.55, "pd": 2.2, "gh": 0.22, "r": 0.04, "screen": Vector2(0.5, 0.24)},
	{"w": 2.25, "h": 0.9, "d": 0.75, "pw": 2.7, "pd": 2.35, "gh": 0.28, "r": 0.06, "screen": Vector2(0.72, 0.34)},
	{"w": 2.45, "h": 1.2, "d": 0.82, "pw": 2.9, "pd": 2.5, "gh": 0.32, "r": 0.08, "screen": Vector2(0.95, 0.5)},
	{"w": 2.65, "h": 1.55, "d": 0.9, "pw": 3.1, "pd": 2.65, "gh": 0.36, "r": 0.1, "screen": Vector2(1.15, 0.62)},
]

static var _mesh_cache: Dictionary = {}
static var _screen_cache: Dictionary = {}

var _materials: Dictionary = {}
var _batches: Dictionary = {}


## Wymiary stacji dla poziomu (używane też przez StationLevelVisuals).
static func get_profile(level: int) -> Dictionary:
	var p: Dictionary = (PROFILES[clampi(level, 1, 5) - 1] as Dictionary).duplicate()
	p["front_z"] = BACK_Z + float(p["d"])
	p["body_cz"] = BACK_Z + float(p["d"]) * 0.5
	p["top_y"] = float(p["h"]) + 0.12
	p["plat_cz"] = PLATFORM_BACK_Z - float(p["pd"]) * 0.5
	p["plat_front_z"] = PLATFORM_BACK_Z - float(p["pd"])
	return p


func build(parent: Node3D, body_color: Color, led_color: Color, level: int = 1) -> void:
	if not is_instance_valid(parent):
		return

	_materials.clear()
	_batches.clear()

	var lv: int = clampi(level, 1, 5)
	var p: Dictionary = get_profile(lv)
	var w: float = p["w"]
	var h: float = p["h"]
	var d: float = p["d"]
	var pw: float = p["pw"]
	var pd: float = p["pd"]
	var gh: float = p["gh"]
	var r: float = p["r"]
	var screen: Vector2 = p["screen"]
	var fz: float = p["front_z"]
	var bcz: float = p["body_cz"]
	var top_y: float = p["top_y"]
	var pcz: float = p["plat_cz"]

	var rough: float = [0.75, 0.6, 0.5, 0.4, 0.3][lv - 1]
	var body_mat: StandardMaterial3D = _make_material(body_color, 0.0, rough)
	var dark_mat: StandardMaterial3D = _make_material(Color(0.055, 0.075, 0.09), 0.1, 0.4)
	var gloss_mat: StandardMaterial3D = _make_material(Color(0.02, 0.03, 0.04), 0.35, 0.1)
	var glass_mat: StandardMaterial3D = _make_material(Color(0.04, 0.08, 0.11), 0.4, 0.08)
	var platform_mat: StandardMaterial3D = _make_material(Color(0.12, 0.15, 0.17), 0.05, 0.6)
	var rubber_mat: StandardMaterial3D = _make_material(Color(0.03, 0.03, 0.035), 0.0, 0.95)
	var metal_mat: StandardMaterial3D = _make_material(Color(0.7, 0.72, 0.75), 0.85, 0.3)
	var led_mat: StandardMaterial3D = _make_material(led_color, 0.05, 0.2, true)

	_materials = {
		"body": body_mat, "dark": dark_mat, "gloss": gloss_mat, "glass": glass_mat,
		"platform": platform_mat, "rubber": rubber_mat, "metal": metal_mat, "led": led_mat
	}

	# --- Obudowa ---
	_add_rbox(parent, "StationBody", Vector3(0.0, 0.03 + h * 0.5, bcz), Vector3(w, h, d), r, body_mat, true)

	var top_mat: StandardMaterial3D = body_mat
	if lv == 2:
		top_mat = dark_mat
	elif lv >= 3:
		top_mat = gloss_mat
	_add_rbox(parent, "StationTop", Vector3(0.0, h + 0.06, bcz), Vector3(w - 0.3, 0.12, d - 0.13), r * 0.8, top_mat)

	if lv >= 3:
		_batch("Metal", metal_mat, Vector3(0.0, h + 0.03, bcz), Vector3(w - 0.26, 0.02, d - 0.09), 0.009)
		_batch("Glass", glass_mat, Vector3(-w * 0.22, top_y + 0.001, bcz), Vector3(w * 0.33, 0.006, d * 0.5), 0.003)

	if lv >= 2:
		var vents: int = 3 if lv == 2 else 5
		for k: int in vents:
			_batch("Dark", dark_mat, Vector3(w * 0.22, top_y + 0.002, bcz - 0.14 + 0.07 * k), Vector3(w * 0.31, 0.008, 0.025), 0.003)

		# Szczeliny obudowy.
		_batch("Dark", dark_mat, Vector3(0.0, 0.30, fz + 0.002), Vector3(w - 0.27, 0.012, 0.006), 0.002)
		for sx: float in [-1.0, 1.0]:
			_batch("Dark", dark_mat, Vector3(sx * (w * 0.5 + 0.002), 0.30, bcz), Vector3(0.006, 0.012, d * 0.67), 0.002)

	# Klapy serwisowe z zatrzaskami.
	if lv >= 3:
		for sx: float in [-1.0, 1.0]:
			_batch("Dark", dark_mat, Vector3(sx * (w * 0.5 + 0.0015), h * 0.55, bcz), Vector3(0.006, h * 0.51, d * 0.59), 0.003)
			_batch("Metal", metal_mat, Vector3(sx * (w * 0.5 + 0.006), h * 0.55, bcz + 0.17 * d / 0.75), Vector3(0.012, 0.1, 0.02), 0.004)

	# --- Przód: panel statusu ---
	if lv == 1:
		_add_rbox(parent, "StatusLED", Vector3(0.0, 0.03 + h * 0.7, fz + 0.005), Vector3(0.25, 0.03, 0.04), 0.01, led_mat)
	else:
		var sy: float = h * 0.74
		_batch("Dark", dark_mat, Vector3(0.0, sy, fz + 0.005), Vector3(screen.x + 0.08, screen.y + 0.06, 0.03), 0.01)
		_add_rbox(parent, "StatusScreen", Vector3(0.0, sy, fz + 0.01), Vector3(screen.x, screen.y, 0.035), 0.02, gloss_mat)
		_add_display(parent, _make_display_material(led_color), Vector2(screen.x - 0.08, screen.y - 0.04), Vector3(0.0, sy, fz + 0.0287))
		_add_rbox(parent, "StatusLED", Vector3(0.0, h + 0.01, fz + 0.005), Vector3(screen.x - 0.1, 0.035, 0.05), 0.01, led_mat)
		_add_rbox(parent, "BodyLED", Vector3(0.0, 0.12, fz + 0.01), Vector3(w - 0.6, 0.045, 0.035), 0.01, led_mat)

	# --- Strona dokowania ---
	var wall_h: float = minf(0.42, h - 0.14)
	_batch("Dark", dark_mat, Vector3(0.0, 0.09 + wall_h * 0.5, BACK_Z - 0.01), Vector3(minf(1.3, w - 0.5), wall_h, 0.03), 0.01)
	_batch("Led", led_mat, Vector3(0.0, 0.09 + wall_h + 0.03, BACK_Z - 0.01), Vector3(0.6, 0.025, 0.02), 0.008)
	_batch("Metal", metal_mat, Vector3(-0.35, 0.2, BACK_Z - 0.027), Vector3(0.12, 0.05, 0.03), 0.01)
	_batch("Metal", metal_mat, Vector3(0.35, 0.2, BACK_Z - 0.027), Vector3(0.12, 0.05, 0.03), 0.01)

	# --- Platforma najazdowa ---
	_add_rbox(parent, "StationPlatform", Vector3(0.0, 0.07, pcz), Vector3(pw, 0.14, pd), minf(r, 0.05), platform_mat, true)
	_add_rbox(parent, "PlatformFront", Vector3(0.0, 0.15, p["plat_front_z"] + 0.045), Vector3(pw, 0.12, 0.12), 0.04, dark_mat)

	# Zielona mata naprowadzająco-ładująca przed platformą — widoczna z kierunku najazdu robota.
	var charge_green: Color = Color("#22e878")
	var charge_mat: StandardMaterial3D = _make_material(charge_green, 0.05, 0.28, true)
	var charge_edge_mat: StandardMaterial3D = _make_material(Color("#b9ffd4"), 0.0, 0.25, true)
	var charge_z: float = float(p["plat_front_z"]) - 0.48
	_add_rbox(parent, "GreenChargingPad", Vector3(0.0, -0.008, charge_z), Vector3(minf(pw * 0.72, 2.15), 0.035, 0.82), 0.09, charge_mat)
	_add_rbox(parent, "ChargingPadGuide", Vector3(0.0, 0.014, charge_z), Vector3(0.09, 0.008, 0.56), 0.025, charge_edge_mat)
	for mark_x: float in [-0.58, 0.58]:
		_add_rbox(parent, "ChargingPadMark", Vector3(mark_x, 0.014, charge_z), Vector3(0.045, 0.008, 0.48), 0.018, charge_edge_mat)
	if lv >= 2:
		_batch("Rubber", rubber_mat, Vector3(-pw * 0.2, 0.146, pcz), Vector3(pw * 0.2, 0.012, pd - 0.65), 0.004)
		_batch("Rubber", rubber_mat, Vector3(pw * 0.2, 0.146, pcz), Vector3(pw * 0.2, 0.012, pd - 0.65), 0.004)

	# --- Prowadnice boczne ---
	var gx: float = pw * 0.5 - 0.17
	var gw: float = 0.12 if lv == 1 else 0.16
	var gz: float = pcz - 0.03
	_add_rbox(parent, "LeftGuide", Vector3(-gx, 0.08 + gh * 0.5, gz), Vector3(gw, gh, pd - 0.35), 0.04, body_mat)
	_add_rbox(parent, "RightGuide", Vector3(gx, 0.08 + gh * 0.5, gz), Vector3(gw, gh, pd - 0.35), 0.04, body_mat)
	if lv >= 2:
		_add_rbox(parent, "LeftGuideLED", Vector3(-gx, 0.09 + gh, gz), Vector3(0.07, 0.035, pd - 0.6), 0.01, led_mat)
		_add_rbox(parent, "RightGuideLED", Vector3(gx, 0.09 + gh, gz), Vector3(0.07, 0.035, pd - 0.6), 0.01, led_mat)

	_flush_batches(parent)


func _make_material(
	color: Color,
	metallic: float = 0.0,
	roughness: float = 0.5,
	emission: bool = false
) -> StandardMaterial3D:
	var material: StandardMaterial3D = StandardMaterial3D.new()
	material.albedo_color = color
	material.metallic = metallic
	material.roughness = roughness

	if emission:
		material.emission_enabled = true
		material.emission = color
		material.emission_energy_multiplier = 1.5

	return material


func _make_display_material(led_color: Color) -> StandardMaterial3D:
	var material: StandardMaterial3D = StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_texture = _get_screen_texture(led_color)
	material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR
	return material


func _add_box(
	parent: Node3D,
	node_name: String,
	position: Vector3,
	box_size: Vector3,
	material: Material
) -> MeshInstance3D:
	var mesh_instance: MeshInstance3D = MeshInstance3D.new()
	mesh_instance.name = node_name

	var box_mesh: BoxMesh = BoxMesh.new()
	box_mesh.size = box_size

	mesh_instance.mesh = box_mesh
	mesh_instance.material_override = material
	mesh_instance.position = position

	parent.add_child(mesh_instance)

	return mesh_instance


func _add_rbox(
	parent: Node3D,
	node_name: String,
	position: Vector3,
	box_size: Vector3,
	radius: float,
	material: Material,
	shadow: bool = false
) -> MeshInstance3D:
	var mesh_instance: MeshInstance3D = MeshInstance3D.new()
	mesh_instance.name = node_name
	mesh_instance.mesh = _rounded_box_mesh(box_size, radius)
	mesh_instance.material_override = material
	mesh_instance.position = position
	if not shadow:
		mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mesh_instance)
	return mesh_instance


func _add_display(parent: Node3D, material: Material, quad_size: Vector2, pos: Vector3) -> void:
	var quad: QuadMesh = QuadMesh.new()
	quad.size = quad_size

	var mesh_instance: MeshInstance3D = MeshInstance3D.new()
	mesh_instance.name = "StatusDisplay"
	mesh_instance.mesh = quad
	mesh_instance.material_override = material
	mesh_instance.position = pos
	mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mesh_instance)


## Dodaje element do wspólnej siatki danego materiału (1 draw call na materiał).
func _batch(key: String, material: Material, pos: Vector3, box_size: Vector3, radius: float) -> void:
	if not _batches.has(key):
		var st: SurfaceTool = SurfaceTool.new()
		st.begin(Mesh.PRIMITIVE_TRIANGLES)
		_batches[key] = {"mat": material, "st": st}

	var surface_tool: SurfaceTool = _batches[key]["st"]
	surface_tool.append_from(
		_rounded_box_mesh(box_size, radius),
		0,
		Transform3D(Basis.IDENTITY, pos)
	)


func _flush_batches(parent: Node3D) -> void:
	for key: String in _batches.keys():
		var surface_tool: SurfaceTool = _batches[key]["st"]
		var mesh_instance: MeshInstance3D = MeshInstance3D.new()
		mesh_instance.name = "Detail_" + key
		mesh_instance.mesh = surface_tool.commit()
		mesh_instance.material_override = _batches[key]["mat"]
		mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		parent.add_child(mesh_instance)
	_batches.clear()


## Zaokrąglony prostopadłościan (~300 tri). Dla radius <= 0.01 zwykły box (12 tri).
func _rounded_box_mesh(box_size: Vector3, radius: float) -> ArrayMesh:
	var cache_key: String = "%s|%s" % [str(box_size), str(radius)]
	if _mesh_cache.has(cache_key):
		return _mesh_cache[cache_key]

	var sharp: bool = radius <= 0.01
	var half: Vector3 = box_size * 0.5
	var r: float = 0.0
	if not sharp:
		r = clampf(radius, 0.002, minf(half.x, minf(half.y, half.z)) * 0.95)
	var inner: Vector3 = half - Vector3(r, r, r)

	var verts: PackedVector3Array = PackedVector3Array()
	var norms: PackedVector3Array = PackedVector3Array()
	var idx: PackedInt32Array = PackedInt32Array()

	for axis: int in 3:
		for sgn: float in [-1.0, 1.0]:
			var ua: int = (axis + 1) % 3
			var va: int = (axis + 2) % 3
			var cu: PackedFloat32Array
			var cv: PackedFloat32Array
			if sharp:
				cu = PackedFloat32Array([-half[ua], half[ua]])
				cv = PackedFloat32Array([-half[va], half[va]])
			else:
				cu = _axis_coords(half[ua], inner[ua], r)
				cv = _axis_coords(half[va], inner[va], r)
			var out_n: Vector3 = Vector3.ZERO
			out_n[axis] = sgn
			var base: int = verts.size()
			var nv: int = cv.size()

			for i: int in cu.size():
				for j: int in nv:
					var q: Vector3 = Vector3.ZERO
					q[axis] = sgn * half[axis]
					q[ua] = cu[i]
					q[va] = cv[j]
					if sharp:
						verts.append(q)
						norms.append(out_n)
					else:
						var c: Vector3 = q.clamp(-inner, inner)
						var dv: Vector3 = q - c
						var n: Vector3 = out_n
						if dv.length() > 0.0001:
							n = dv.normalized()
						verts.append(c + n * r)
						norms.append(n)

			for i: int in cu.size() - 1:
				for j: int in nv - 1:
					var a: int = base + i * nv + j
					var b: int = base + (i + 1) * nv + j
					var cc: int = base + (i + 1) * nv + j + 1
					var dd: int = base + i * nv + j + 1
					if sgn > 0.0:
						idx.append_array([a, cc, b, a, dd, cc])
					else:
						idx.append_array([a, b, cc, a, cc, dd])

	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = norms
	arrays[Mesh.ARRAY_INDEX] = idx

	var mesh: ArrayMesh = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	_mesh_cache[cache_key] = mesh
	return mesh


func _axis_coords(h: float, inner: float, r: float) -> PackedFloat32Array:
	return PackedFloat32Array([
		-h, -(inner + r * 0.5), -inner, inner, inner + r * 0.5, h
	])


## Proceduralna tekstura ekranu 256x120 (cache per kolor LED).
func _get_screen_texture(led: Color) -> ImageTexture:
	var key: String = led.to_html()
	if _screen_cache.has(key):
		return _screen_cache[key]

	var w: int = 256
	var h: int = 120
	var img: Image = Image.create(w, h, false, Image.FORMAT_RGBA8)
	var bg: Color = Color(0.02, 0.05, 0.065)

	for y: int in h:
		var t: float = float(y) / float(h - 1)
		img.fill_rect(
			Rect2i(0, y, w, 1),
			Color(0.01 + 0.02 * t, 0.03 + 0.03 * t, 0.04 + 0.04 * t, 1.0)
		)

	var dim: Color = led.darkened(0.55)

	img.fill_rect(Rect2i(0, 0, w, 3), dim)
	img.fill_rect(Rect2i(0, h - 3, w, 3), dim)
	img.fill_rect(Rect2i(0, 0, 3, h), dim)
	img.fill_rect(Rect2i(w - 3, 0, 3, h), dim)

	img.fill_rect(Rect2i(14, 14, 10, 10), led)
	img.fill_rect(Rect2i(196, 12, 48, 20), led)
	img.fill_rect(Rect2i(199, 15, 42, 14), bg)
	img.fill_rect(Rect2i(202, 18, 32, 8), led)
	img.fill_rect(Rect2i(244, 18, 4, 8), led)

	for yy: int in range(36, 100):
		for xx: int in range(32, 96):
			var dist: float = Vector2(xx - 64, yy - 68).length()
			if (dist < 30.0 and dist > 22.0) or dist < 8.0:
				img.set_pixel(xx, yy, led)

	img.fill_rect(Rect2i(118, 48, 110, 8), dim)
	img.fill_rect(Rect2i(118, 66, 80, 8), dim)
	img.fill_rect(Rect2i(118, 84, 95, 8), dim)
	img.fill_rect(Rect2i(14, 104, 228, 6), dim)
	img.fill_rect(Rect2i(14, 104, 150, 6), led)

	var tex: ImageTexture = ImageTexture.create_from_image(img)
	_screen_cache[key] = tex
	return tex
