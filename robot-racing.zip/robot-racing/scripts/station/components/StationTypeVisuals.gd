
class_name StationTypeVisuals
extends RefCounted
## Dodatkowe elementy wizualne zależne od typu stacji.

func build(
	parent: Node3D,
	type_index: int,
	body_color: Color,
	led_color: Color
) -> void:
	if not is_instance_valid(parent):
		return

	match clampi(type_index, 0, 2):
		0:
			_build_service_station(parent, body_color, led_color)
		1:
			_build_turbo_station(parent, body_color, led_color)
		2:
			_build_fortress_station(parent, body_color, led_color)


func _build_service_station(
	parent: Node3D,
	body_color: Color,
	led_color: Color
) -> void:
	var dark_mat: StandardMaterial3D = _material(
		Color(0.08, 0.12, 0.15)
	)
	var body_mat: StandardMaterial3D = _material(body_color)
	var led_mat: StandardMaterial3D = _emission_material(led_color)

	_box(
		parent,
		"ServiceLeftArm",
		Vector3(-1.22, 0.78, 0.55),
		Vector3(0.22, 0.85, 0.28),
		dark_mat
	)

	_box(
		parent,
		"ServiceRightArm",
		Vector3(1.22, 0.78, 0.55),
		Vector3(0.22, 0.85, 0.28),
		dark_mat
	)

	_box(
		parent,
		"ServiceTopBar",
		Vector3(0.0, 1.22, 0.55),
		Vector3(2.55, 0.13, 0.28),
		body_mat
	)

	_box(
		parent,
		"ServiceCenterLED",
		Vector3(0.0, 1.30, 0.70),
		Vector3(0.85, 0.045, 0.035),
		led_mat
	)


func _build_turbo_station(
	parent: Node3D,
	body_color: Color,
	led_color: Color
) -> void:
	var body_mat: StandardMaterial3D = _material(body_color)
	var dark_mat: StandardMaterial3D = _material(
		Color(0.045, 0.065, 0.08)
	)
	var led_mat: StandardMaterial3D = _emission_material(led_color)

	_box(
		parent,
		"TurboLeftHousing",
		Vector3(-0.92, 0.78, 0.55),
		Vector3(0.42, 0.55, 0.45),
		body_mat
	)

	_box(
		parent,
		"TurboRightHousing",
		Vector3(0.92, 0.78, 0.55),
		Vector3(0.42, 0.55, 0.45),
		body_mat
	)

	_box(
		parent,
		"TurboTopPanel",
		Vector3(0.0, 1.18, 0.58),
		Vector3(1.75, 0.15, 0.42),
		dark_mat
	)

	_box(
		parent,
		"TurboLeftLED",
		Vector3(-0.92, 0.80, 0.79),
		Vector3(0.25, 0.07, 0.035),
		led_mat
	)

	_box(
		parent,
		"TurboRightLED",
		Vector3(0.92, 0.80, 0.79),
		Vector3(0.25, 0.07, 0.035),
		led_mat
	)

	_box(
		parent,
		"TurboTopLED",
		Vector3(0.0, 1.28, 0.80),
		Vector3(1.15, 0.045, 0.035),
		led_mat
	)


func _build_fortress_station(
	parent: Node3D,
	body_color: Color,
	led_color: Color
) -> void:
	var body_mat: StandardMaterial3D = _material(body_color)
	var armor_mat: StandardMaterial3D = _material(
		Color(0.12, 0.16, 0.19),
		0.65
	)
	var led_mat: StandardMaterial3D = _emission_material(led_color)

	_box(
		parent,
		"FortressLeftArmor",
		Vector3(-1.15, 0.68, 0.52),
		Vector3(0.42, 0.95, 0.48),
		armor_mat
	)

	_box(
		parent,
		"FortressRightArmor",
		Vector3(1.15, 0.68, 0.52),
		Vector3(0.42, 0.95, 0.48),
		armor_mat
	)

	_box(
		parent,
		"FortressTopArmor",
		Vector3(0.0, 1.18, 0.55),
		Vector3(2.45, 0.22, 0.55),
		body_mat
	)

	_box(
		parent,
		"FortressFrontPlate",
		Vector3(0.0, 0.72, 1.13),
		Vector3(1.75, 0.42, 0.10),
		armor_mat
	)

	_box(
		parent,
		"FortressCenterLED",
		Vector3(0.0, 0.75, 1.19),
		Vector3(0.85, 0.06, 0.035),
		led_mat
	)


func _material(
	color: Color,
	metallic: float = 0.35
) -> StandardMaterial3D:
	var material: StandardMaterial3D = StandardMaterial3D.new()
	material.albedo_color = color
	material.metallic = metallic
	material.roughness = 0.32
	return material


func _emission_material(color: Color) -> StandardMaterial3D:
	var material: StandardMaterial3D = _material(color, 0.1)
	material.emission_enabled = true
	material.emission = color
	material.emission_energy_multiplier = 1.5
	return material


func _box(
	parent: Node3D,
	node_name: String,
	position: Vector3,
	box_size: Vector3,
	material: Material
) -> MeshInstance3D:
	var instance: MeshInstance3D = MeshInstance3D.new()
	instance.name = node_name

	var mesh: BoxMesh = BoxMesh.new()
	mesh.size = box_size

	instance.mesh = mesh
	instance.material_override = material
	instance.position = position

	parent.add_child(instance)
	return instance
