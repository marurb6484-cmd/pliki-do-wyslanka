extends TrackBase
## ROBOT RACING - TOR W MIESZKANIU
##
## Geometria zachowana z poprzedniej wersji (te same pomieszczenia, meble,
## przebieg trasy i bandy), ale zoptymalizowana pod Androida:
##  - bandy i listwy są jedną siatką na stronę zamiast ~430 osobnych obiektów,
##  - kolizje band to jedno StaticBody z wieloma kształtami,
##  - wspólne materiały dla tych samych kolorów,
##  - nawierzchnia ma normalne i UV (poprawne oświetlenie).
## Dodatkowo: przeszkody (zabawki) na torze, linia startu w szachownicę,
## lampy sufitowe (od jakości WYSOKIEJ).

const BARRIER_OFFSET: float = 5.15
const BARRIER_HEIGHT: float = 0.85
const BARRIER_THICKNESS: float = 0.30

const FLOOR_COLOR := Color(0.76, 0.72, 0.65)
const WALL_COLOR := Color(0.43, 0.42, 0.39)
const TRACK_COLOR := Color(0.27, 0.29, 0.30)
const RAIL_COLOR := Color(0.0, 0.65, 0.9)


func _get_default_route() -> Array[Vector3]:
	return [
		Vector3(-25, 0, 25), Vector3(-10, 0, 27), Vector3(7, 0, 27), Vector3(23, 0, 24),
		Vector3(35, 0, 18), Vector3(42, 0, 9), Vector3(44, 0, -1), Vector3(40, 0, -10),
		Vector3(31, 0, -16), Vector3(18, 0, -19), Vector3(3, 0, -19), Vector3(-12, 0, -17),
		Vector3(-26, 0, -12), Vector3(-38, 0, -5), Vector3(-45, 0, 4), Vector3(-46, 0, 13),
		Vector3(-41, 0, 21), Vector3(-33, 0, 26)
	]


func _build_geometry() -> void:
	nav_floor_bounds.clear()
	nav_obstacle_bounds.clear()
	nav_floor_height = 0.025

	_build_base()
	_build_track_surface()
	_build_barriers()
	_build_start_line()
	_build_checkpoint_gates()
	_build_apartment()
	_build_track_obstacles()
	_build_lamps()


## Widoczne bramki kontrolne na standardowej trasie mieszkania.
## Są budowane w tej samej geometrii co jezdnia, więc nie znikają na trasach nieproceduralnych.
func _build_checkpoint_gates() -> void:
	if route_length <= 1.0 or smooth_route.size() < 4:
		return
	var gate_material := StandardMaterial3D.new()
	gate_material.albedo_color = Color("#19dfff")
	gate_material.emission_enabled = true
	gate_material.emission = Color("#00bde8")
	gate_material.emission_energy_multiplier = 3.0
	gate_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	for checkpoint_index: int in range(3):
		var distance: float = route_length * float(checkpoint_index + 1) * 0.25
		var center: Vector3 = get_point_at(distance)
		var tangent: Vector3 = get_tangent_at(distance)
		var gate := Node3D.new()
		gate.name = "Checkpoint_%02d" % (checkpoint_index + 1)
		gate.position = Vector3(center.x, 0.03, center.z)
		gate.rotation.y = atan2(-tangent.x, -tangent.z)
		add_child(gate)
		for side_sign: float in [-1.0, 1.0]:
			var post := MeshInstance3D.new()
			var post_mesh := BoxMesh.new()
			post_mesh.size = Vector3(0.48, 3.8, 0.48)
			post.mesh = post_mesh
			post.material_override = gate_material
			post.position = Vector3(side_sign * (track_width * 0.5 - 0.24), 1.9, 0.0)
			gate.add_child(post)
		var top := MeshInstance3D.new()
		var top_mesh := BoxMesh.new()
		top_mesh.size = Vector3(track_width + 0.15, 0.42, 0.5)
		top.mesh = top_mesh
		top.material_override = gate_material
		top.position = Vector3(0.0, 3.8, 0.0)
		gate.add_child(top)
		var label := Label3D.new()
		label.text = "CP%d" % (checkpoint_index + 1)
		label.font_size = 64
		label.outline_size = 12
		label.modulate = Color.WHITE
		label.position = Vector3(0.0, 4.45, 0.0)
		label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		label.no_depth_test = true
		gate.add_child(label)


# =========================================================
# PODŁOGA I ŚCIANY ZEWNĘTRZNE
# =========================================================

func _build_base() -> void:
	var floor_visual: MeshInstance3D = _box("PodlogaBazowa", Vector3(0, -0.3, 0), Vector3(100, 0.6, 80), FLOOR_COLOR)
	var floor_material := StandardMaterial3D.new()
	floor_material.albedo_color = FLOOR_COLOR
	floor_material.roughness = 0.85
	floor_visual.material_override = floor_material
	make_glossy(floor_material, 0.35)

	_box("ScianaPolnoc", Vector3(0, 5.5, -40), Vector3(100, 11, 0.5), WALL_COLOR)
	_box("ScianaPoludnie", Vector3(0, 5.5, 40), Vector3(100, 11, 0.5), WALL_COLOR)
	_box("ScianaZachod", Vector3(-50, 5.5, 0), Vector3(0.5, 11, 80), WALL_COLOR)
	_box("ScianaWschod", Vector3(50, 5.5, 0), Vector3(0.5, 11, 80), WALL_COLOR)


# =========================================================
# NAWIERZCHNIA TORU
# =========================================================

func _build_track_surface() -> void:
	var tool := SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)

	var half_width: float = track_width * 0.5
	var count: int = smooth_route.size()
	var bounds := AABB()

	for i: int in range(count):
		var next_index: int = (i + 1) % count
		var side_a: Vector3 = get_side_at_index(i)
		var side_b: Vector3 = get_side_at_index(next_index)

		var left_a: Vector3 = smooth_route[i] + side_a * half_width
		var right_a: Vector3 = smooth_route[i] - side_a * half_width
		var left_b: Vector3 = smooth_route[next_index] + side_b * half_width
		var right_b: Vector3 = smooth_route[next_index] - side_b * half_width

		left_a.y = 0.025
		right_a.y = 0.025
		left_b.y = 0.025
		right_b.y = 0.025

		var v0: float = route_cum[i] / 4.0
		var v1: float = route_cum[i + 1] / 4.0

		# Kolejność wierzchołków jak w oryginale; normalna w górę.
		tool.set_normal(Vector3.UP)
		tool.set_uv(Vector2(0, v0))
		tool.add_vertex(left_a)
		tool.set_uv(Vector2(1, v0))
		tool.add_vertex(right_a)
		tool.set_uv(Vector2(1, v1))
		tool.add_vertex(right_b)

		tool.set_uv(Vector2(0, v0))
		tool.add_vertex(left_a)
		tool.set_uv(Vector2(1, v1))
		tool.add_vertex(right_b)
		tool.set_uv(Vector2(0, v1))
		tool.add_vertex(left_b)

	var mesh_instance := MeshInstance3D.new()
	mesh_instance.name = "NawierzchniaTor"
	mesh_instance.mesh = tool.commit()
	bounds = mesh_instance.mesh.get_aabb()
	mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

	var material := StandardMaterial3D.new()
	material.albedo_color = TRACK_COLOR
	material.roughness = 0.95
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	mesh_instance.material_override = material
	make_glossy(material, 0.5)
	add_child(mesh_instance)

	nav_floor_bounds.append(bounds)
	_build_edge_stripes()


## Białe linie krawędzi toru - jedna siatka, bez kolizji.
func _build_edge_stripes() -> void:
	var tool := SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)
	tool.set_normal(Vector3.UP)
	var count: int = smooth_route.size()
	var half_width: float = track_width * 0.5

	for side_sign: float in [-1.0, 1.0]:
		for i: int in range(count):
			var next_index: int = (i + 1) % count
			var side_a: Vector3 = get_side_at_index(i) * side_sign
			var side_b: Vector3 = get_side_at_index(next_index) * side_sign
			var outer_a: Vector3 = smooth_route[i] + side_a * (half_width - 0.15)
			var inner_a: Vector3 = smooth_route[i] + side_a * (half_width - 0.40)
			var outer_b: Vector3 = smooth_route[next_index] + side_b * (half_width - 0.15)
			var inner_b: Vector3 = smooth_route[next_index] + side_b * (half_width - 0.40)
			outer_a.y = 0.032
			inner_a.y = 0.032
			outer_b.y = 0.032
			inner_b.y = 0.032
			tool.add_vertex(outer_a)
			tool.add_vertex(inner_a)
			tool.add_vertex(inner_b)
			tool.add_vertex(outer_a)
			tool.add_vertex(inner_b)
			tool.add_vertex(outer_b)

	var stripes := MeshInstance3D.new()
	stripes.name = "LinieKrawedzi"
	stripes.mesh = tool.commit()
	stripes.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(0.92, 0.92, 0.88)
	material.roughness = 0.8
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	stripes.material_override = material
	add_child(stripes)


# =========================================================
# BANDY (scalone siatki + jedno ciało kolizyjne)
# =========================================================

func _build_barriers() -> void:
	# Wzdłuż jezdni pozostają wyłącznie cienkie linie krawędziowe z
	# _build_edge_stripes(); nie budujemy ścian ani niewidzialnych band.
	return


## Dodaje prostopadłościan (12 trójkątów z normalnymi) do SurfaceTool.
func _append_box(tool: SurfaceTool, box_transform: Transform3D, size: Vector3) -> void:
	var h: Vector3 = size * 0.5
	var faces: Array = [
		[Vector3(1, 0, 0), [Vector3(h.x, -h.y, -h.z), Vector3(h.x, h.y, -h.z), Vector3(h.x, h.y, h.z), Vector3(h.x, -h.y, h.z)]],
		[Vector3(-1, 0, 0), [Vector3(-h.x, -h.y, h.z), Vector3(-h.x, h.y, h.z), Vector3(-h.x, h.y, -h.z), Vector3(-h.x, -h.y, -h.z)]],
		[Vector3(0, 1, 0), [Vector3(-h.x, h.y, -h.z), Vector3(-h.x, h.y, h.z), Vector3(h.x, h.y, h.z), Vector3(h.x, h.y, -h.z)]],
		[Vector3(0, 0, 1), [Vector3(h.x, -h.y, h.z), Vector3(h.x, h.y, h.z), Vector3(-h.x, h.y, h.z), Vector3(-h.x, -h.y, h.z)]],
		[Vector3(0, 0, -1), [Vector3(-h.x, -h.y, -h.z), Vector3(-h.x, h.y, -h.z), Vector3(h.x, h.y, -h.z), Vector3(h.x, -h.y, -h.z)]]
	]
	for face: Array in faces:
		var normal: Vector3 = box_transform.basis * (face[0] as Vector3)
		var corners: Array = face[1]
		var c0: Vector3 = box_transform * (corners[0] as Vector3)
		var c1: Vector3 = box_transform * (corners[1] as Vector3)
		var c2: Vector3 = box_transform * (corners[2] as Vector3)
		var c3: Vector3 = box_transform * (corners[3] as Vector3)
		tool.set_normal(normal)
		tool.add_vertex(c0)
		tool.set_normal(normal)
		tool.add_vertex(c2)
		tool.set_normal(normal)
		tool.add_vertex(c1)
		tool.set_normal(normal)
		tool.add_vertex(c0)
		tool.set_normal(normal)
		tool.add_vertex(c3)
		tool.set_normal(normal)
		tool.add_vertex(c2)


# =========================================================
# LINIA STARTU I METY (szachownica)
# =========================================================

func _build_start_line() -> void:
	var start: Vector3 = get_point_at(0.0)
	var forward: Vector3 = get_tangent_at(0.0)
	var side := Vector3(-forward.z, 0.0, forward.x)
	var basis := Basis.looking_at(forward, Vector3.UP)

	var tiles: int = 12
	var tile_width: float = track_width / tiles
	var white: StandardMaterial3D = get_material(Color(0.95, 0.95, 0.9), 0.7)
	var black: StandardMaterial3D = get_material(Color(0.05, 0.05, 0.06), 0.7)
	var tile_mesh := BoxMesh.new()
	tile_mesh.size = Vector3(tile_width, 0.02, 0.5)

	for row: int in range(2):
		for i: int in range(tiles):
			var tile := MeshInstance3D.new()
			tile.mesh = tile_mesh
			tile.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			var lateral: float = -track_width * 0.5 + tile_width * (i + 0.5)
			var position: Vector3 = start + side * lateral + forward * (row * 0.5 - 0.25)
			position.y = 0.045
			tile.transform = Transform3D(basis, position)
			tile.material_override = white if (i + row) % 2 == 0 else black
			add_child(tile)

	# Brama startowa nad torem.
	var arch_material: StandardMaterial3D = get_material(Color(0.1, 0.12, 0.15), 0.4, 0.6)
	for side_sign: float in [-1.0, 1.0]:
		var pillar_pos: Vector3 = start + side * (BARRIER_OFFSET + 0.4) * side_sign
		pillar_pos.y = 1.4
		var pillar_body := StaticBody3D.new()
		pillar_body.name = "KolumnaBramaStartowa_%s" % str(side_sign)
		pillar_body.collision_layer = Robot.LAYER_WORLD
		pillar_body.collision_mask = 0
		pillar_body.transform = Transform3D(basis, pillar_pos)
		var pillar_mesh := BoxMesh.new()
		pillar_mesh.size = Vector3(0.3, 2.8, 0.3)
		var pillar_collision := CollisionShape3D.new()
		var pillar_shape := BoxShape3D.new()
		pillar_shape.size = pillar_mesh.size
		pillar_collision.shape = pillar_shape
		pillar_body.add_child(pillar_collision)
		var pillar := MeshInstance3D.new()
		pillar.mesh = pillar_mesh
		pillar.material_override = arch_material
		pillar_body.add_child(pillar)
		add_child(pillar_body)

	var banner := MeshInstance3D.new()
	var banner_mesh := BoxMesh.new()
	banner_mesh.size = Vector3((BARRIER_OFFSET + 0.4) * 2.0 + 0.3, 0.45, 0.2)
	banner.mesh = banner_mesh
	var banner_material := StandardMaterial3D.new()
	banner_material.albedo_color = Color(0.0, 0.55, 0.8)
	banner_material.emission_enabled = true
	banner_material.emission = Color(0.0, 0.7, 1.0)
	banner_material.emission_energy_multiplier = 0.8
	banner.material_override = banner_material
	var banner_pos: Vector3 = start
	banner_pos.y = 2.65
	banner.transform = Transform3D(basis, banner_pos)
	add_child(banner)


# =========================================================
# MIESZKANIE (meble jak w poprzedniej wersji)
# =========================================================

func _build_apartment() -> void:
	# Ściany i elementy konstrukcyjne pomieszczeń pozostają geometrią architektoniczną.
	# Meble i wyposażenie pobieramy ze wspólnej biblioteki modeli używanej także
	# przez generator proceduralny i podgląd edytora.
	_box("ScianaWewnetrzna1", Vector3(-18, 5.5, 4), Vector3(0.35, 11, 12), WALL_COLOR)
	_box("ScianaWewnetrzna2", Vector3(18, 5.5, 4), Vector3(0.35, 11, 12), WALL_COLOR)
	_box("ScianaWewnetrzna3", Vector3(0, 5.5, -2), Vector3(15, 11, 0.35), WALL_COLOR)

	# SALON — modele z biblioteki FurnitureModels.
	_add_room_model("DywanSalon", "rug", Vector3(-8, 0.0, 8), Vector3(5.2, 1.0, 4.5), false)
	_add_room_model("Kanapa", "sofa", Vector3(-12, 0.0, 9), Vector3(3.2, 1.6, 2.5), true, Vector3(6.6, 1.6, 2.5))
	_add_room_model("Fotel", "chair", Vector3(-2, 0.0, 10), Vector3(2.5, 1.25, 2.5), true, Vector3(2.3, 1.5, 2.2))
	_add_room_model("StolikSalon", "table", Vector3(-8, 0.0, 5), Vector3(2.4, 1.2, 2.2), true, Vector3(4.1, 1.0, 2.4))
	_add_room_model("SzafkaTV", "cabinet", Vector3(-15, 0.0, 1), Vector3(1.4, 1.1, 4.0), true, Vector3(2.2, 1.4, 5.5))
	_add_room_model("Telewizor", "tv", Vector3(-15.9, 0.0, 1), Vector3(2.5, 1.8, 1.0), true, Vector3(3.9, 2.0, 0.7))

	# KUCHNIA.
	_add_room_model("SzafkiKuchenne", "kitchen_counter", Vector3(10, 0.0, 8), Vector3(5.4, 1.0, 2.5), true, Vector3(9.5, 1.6, 2.0))
	_add_room_model("Lodowka", "fridge", Vector3(15, 0.0, 13), Vector3(2.0, 1.4, 2.5), true, Vector3(3.0, 2.8, 3.0))
	_add_room_model("WyspaKuchenna", "table", Vector3(8, 0.0, 0), Vector3(3.6, 1.5, 2.6), true, Vector3(6.0, 1.4, 2.5))

	# SYPIALNIA.
	_add_room_model("DywanSypialnia", "rug", Vector3(-8, 0.0, -29), Vector3(5.2, 1.0, 4.0), false)
	_add_room_model("Lozko", "bed", Vector3(-8, 0.0, -30), Vector3(4.0, 1.0, 3.3), true, Vector3(8.0, 1.3, 5.0))
	_add_room_model("Zaglowek", "pillow", Vector3(-8, 0.8, -32.5), Vector3(4.0, 3.0, 1.0), true, Vector3(8.0, 1.2, 0.4))
	_add_room_model("Komoda", "cabinet", Vector3(2, 0.0, -30), Vector3(2.8, 1.1, 2.5), true, Vector3(4.0, 1.6, 2.0))

	# POKÓJ DZIECIĘCY.
	_add_room_model("LozkoDzieciece", "bed", Vector3(32, 0.0, -29), Vector3(3.5, 1.0, 2.7), true, Vector3(7.0, 1.3, 4.0))
	_add_room_model("RegalZabawek", "bookshelf", Vector3(43, 0.0, -29), Vector3(1.5, 1.2, 8.0), true, Vector3(2.0, 2.2, 5.0))
	_add_room_model("SkrzyniaZabawek", "box", Vector3(29, 0.0, -22), Vector3(2.5, 1.0, 1.8), true, Vector3(3.0, 1.0, 2.0))

	# ŁAZIENKA — wanna, umywalka i szafka korzystają z osobnych modeli 3D.
	_add_room_model("Wanna", "bathtub", Vector3(31, 0.0, 4), Vector3(3.2, 1.0, 2.4), true, Vector3(7.0, 1.1, 3.0))
	_add_room_model("Umywalka", "sink", Vector3(28, 0.0, 5), Vector3(1.8, 1.0, 1.8), true, Vector3(3.0, 1.4, 2.0))
	_add_room_model("SzafkaLazienkowa", "cabinet", Vector3(28, 0.0, 11), Vector3(2.0, 1.4, 2.0), true, Vector3(3.0, 2.0, 2.0))


func _add_room_model(object_name: String, kind: String, object_position: Vector3, model_scale: Vector3, with_collision: bool = true, collision_size: Vector3 = Vector3.ONE, variant: int = 0) -> void:
	if StylePackManager.is_downloaded_only_mode() and not StylePackManager.has_kind_asset(kind):
		return
	var holder: Node3D
	if with_collision:
		var body := StaticBody3D.new()
		body.name = object_name
		body.position = object_position
		body.collision_layer = 1
		body.collision_mask = 0
		var collision := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = collision_size
		collision.shape = shape
		body.add_child(collision)
		add_child(body)
		nav_obstacle_bounds.append(AABB(object_position - collision_size * 0.5, collision_size))
		holder = body
	else:
		holder = Node3D.new()
		holder.name = object_name
		holder.position = object_position
		add_child(holder)
	var model: Node3D = TrackModelLibrary.make_furniture(kind, variant)
	model.scale = model_scale
	holder.add_child(model)


# =========================================================
# PRZESZKODY NA TORZE (zabawki) - AI je omija, kolizje powodują uszkodzenia
# =========================================================

func _build_track_obstacles() -> void:
	# Pozycje i hitboxy pozostają zgodne z dotychczasowym torem, ale wygląd
	# pochodzi teraz z tej samej biblioteki modeli co generator i edytor.
	var layout: Array = [
		[0.14, 2.6, "robot_toy"],
		[0.29, -2.5, "shoe"],
		[0.44, 2.4, "tennis_ball"],
		[0.58, -2.6, "robot_toy"],
		[0.72, 2.5, "book"],
		[0.86, -2.4, "tennis_ball"]
	]
	for i: int in range(layout.size()):
		var entry: Array = layout[i]
		var distance: float = float(entry[0]) * route_length
		var lateral: float = float(entry[1])
		var kind: String = str(entry[2])
		if StylePackManager.is_downloaded_only_mode() and not StylePackManager.has_kind_asset(kind):
			continue
		var position: Vector3 = get_point_at(distance) + get_side_at(distance) * lateral
		var forward: Vector3 = get_tangent_at(distance)
		var basis := Basis.looking_at(forward, Vector3.UP).rotated(Vector3.UP, 0.4 * (i % 3 - 1))
		var radius: float = 0.7
		var height: float = 0.8
		var collision_shape: Shape3D
		var model_scale := Vector3.ONE
		match kind:
			"robot_toy":
				var toy_shape := BoxShape3D.new()
				toy_shape.size = Vector3(1.0, 0.9, 1.0)
				collision_shape = toy_shape
				model_scale = Vector3(1.8, 0.75, 1.8)
				height = 0.9
				radius = 0.75
			"shoe":
				var shoe_shape := BoxShape3D.new()
				shoe_shape.size = Vector3(0.6, 0.35, 1.3)
				collision_shape = shoe_shape
				model_scale = Vector3(1.1, 0.9, 1.15)
				height = 0.35
				radius = 0.75
			"tennis_ball":
				var ball_shape := SphereShape3D.new()
				ball_shape.radius = 0.55
				collision_shape = ball_shape
				model_scale = Vector3(2.0, 2.0, 2.0)
				height = 1.1
				radius = 0.6
			_:
				var book_shape := BoxShape3D.new()
				book_shape.size = Vector3(1.2, 0.3, 0.9)
				collision_shape = book_shape
				model_scale = Vector3(1.2, 1.0, 1.0)
				height = 0.3
				radius = 0.75
		position.y = height * 0.5
		var body := StaticBody3D.new()
		body.name = "Przeszkoda_%d_%s" % [i, kind]
		body.collision_layer = 1
		body.collision_mask = 0
		body.transform = Transform3D(basis, position)
		var visual: Node3D = TrackModelLibrary.make_furniture(kind, i % 4)
		visual.scale = model_scale
		body.add_child(visual)
		var collision := CollisionShape3D.new()
		collision.shape = collision_shape
		body.add_child(collision)
		add_child(body)
		register_obstacle(position, radius)
		nav_obstacle_bounds.append(body.transform * AABB(Vector3(-radius, -height * 0.5, -radius), Vector3(radius * 2.0, height, radius * 2.0)))


func _build_lamps() -> void:
	add_lamp(Vector3(-25, 3.6, 18), Color(1.0, 0.86, 0.7), 1.3, 16.0)
	add_lamp(Vector3(20, 3.6, 18), Color(1.0, 0.86, 0.7), 1.3, 16.0)
	add_lamp(Vector3(-20, 3.6, -15), Color(0.85, 0.9, 1.0), 1.1, 16.0)
	add_lamp(Vector3(30, 3.6, -14), Color(0.85, 0.9, 1.0), 1.1, 16.0)


# =========================================================
# FUNKCJE POMOCNICZE
# =========================================================

func _box(object_name: String, object_position: Vector3, object_size: Vector3, object_color: Color, with_collision: bool = true, is_floor: bool = false, roughness: float = 0.85, metallic: float = 0.0) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = object_size

	var visual := MeshInstance3D.new()
	visual.name = object_name + "_Visual"
	visual.mesh = mesh
	visual.material_override = get_material(object_color, roughness, metallic)

	var bounds := AABB(object_position - object_size * 0.5, object_size)

	if with_collision:
		var body := StaticBody3D.new()
		body.name = object_name
		body.position = object_position
		body.collision_layer = 1
		body.collision_mask = 0
		var collision := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = object_size
		collision.shape = shape
		body.add_child(collision)
		body.add_child(visual)
		add_child(body)
	else:
		visual.position = object_position
		visual.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(visual)

	if is_floor:
		nav_floor_bounds.append(bounds)
	elif object_size.y > 0.25 and object_position.y - object_size.y * 0.5 < 1.0:
		nav_obstacle_bounds.append(bounds)

	return visual
