extends ProceduralTrack

## Domyślna trasa mieszkania. Korzysta z tego samego generatora i skali co
## edytor tras, dzięki czemu pokoje mają do 40 m², a jezdnia pasuje do robota 30–35 cm.

func _ready() -> void:
	# Scena zawiera historyczne waypointy; nowa trasa pochodzi z danych generatora.
	waypoints_path = NodePath("__GeneratedRouteOnly")
	if generated_data.is_empty():
		var default_data: Dictionary = TrackGeneratorScript.generate(20261117, 1, 2, 1, "apartment", "MIESZKANIE", 5, 2, 1, "lap")
		default_data["id"] = "apartment"
		default_data["track_id"] = "apartment"
		default_data["name"] = "MIESZKANIE"
		default_data["display_name"] = "MIESZKANIE"
		configure(default_data)
	super._ready()
