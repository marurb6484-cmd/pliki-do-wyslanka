extends RigidBody3D
## Przesuwalna przeszkoda torowa. Uderzenie robota odpycha obiekt,
## a dopiero seria mocnych kolizji może go usunąć.

@export_range(1.0, 200.0, 1.0) var durability: float = 100.0
@export_range(0.0, 50.0, 0.5) var damage_amount: float = 10.0
var remaining_durability: float = 100.0
var _destroyed: bool = false
var _robot_cooldowns: Dictionary = {}

func _ready() -> void:
	remaining_durability = maxf(durability, 1.0)
	collision_layer = Robot.LAYER_WORLD
	collision_mask = Robot.LAYER_ROBOTS | Robot.LAYER_WORLD
	contact_monitor = true
	max_contacts_reported = 4
	continuous_cd = true
	mass = 2.5
	linear_damp = 0.8
	angular_damp = 1.5
	can_sleep = true
	var surface := PhysicsMaterial.new()
	surface.friction = 0.48
	surface.bounce = 0.12
	physics_material_override = surface
	body_entered.connect(_on_body_entered)

func _physics_process(delta: float) -> void:
	for key: String in _robot_cooldowns.keys():
		_robot_cooldowns[key] = maxf(float(_robot_cooldowns[key]) - delta, 0.0)

func _on_body_entered(body: Node) -> void:
	if body is Robot:
		var robot := body as Robot
		var speed: float = Vector2(robot.velocity.x, robot.velocity.z).length()
		receive_robot_impact(robot, robot.velocity, speed, global_position)

func receive_robot_impact(robot: Robot, incoming_velocity: Vector3, impact_speed: float, hit_position: Vector3) -> void:
	if _destroyed or not is_instance_valid(robot):
		return
	var robot_key: String = str(robot.get_instance_id())
	if float(_robot_cooldowns.get(robot_key, 0.0)) > 0.0:
		return
	_robot_cooldowns[robot_key] = 0.38
	var direction: Vector3 = incoming_velocity
	direction.y = 0.0
	if direction.length_squared() < 0.04:
		direction = hit_position - global_position
		direction.y = 0.0
	if direction.length_squared() < 0.001:
		direction = Vector3.FORWARD
	direction = direction.normalized()
	var shove: float = clampf(5.5 + impact_speed * 1.25, 7.0, 20.0)
	apply_central_impulse(direction * shove + Vector3.UP * 0.35)
	linear_velocity += direction * clampf(1.8 + impact_speed * 0.22, 2.0, 6.0)
	apply_torque_impulse(Vector3(randf_range(-0.8, 0.8), randf_range(-1.2, 1.2), randf_range(-0.8, 0.8)))
	sleeping = false
	remaining_durability = maxf(remaining_durability - 18.0 * clampf(impact_speed / 10.0, 0.35, 1.5), 0.0)
	if robot.damage != null:
		robot.damage.apply_environment_damage(damage_amount, get_instance_id(), hit_position)
	if remaining_durability <= 0.0:
		_destroyed = true
		collision_layer = 0
		collision_mask = 0
		var tween := create_tween()
		tween.tween_property(self, "scale", scale * 0.08, 0.16)
		tween.tween_callback(queue_free)
