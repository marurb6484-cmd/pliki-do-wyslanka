class_name ProceduralTrack
extends TrackBase

const TrackGeneratorScript = preload("res://scripts/tracks/TrackGenerator.gd")
## Lekka, proceduralna trasa 3D. Geometria powstaje z danych wygenerowanych
## przez TrackGenerator; nie ładuje zewnętrznych skryptów ani paczek kodu.

const WALL_HEIGHT: float = 1.15
const WALL_THICKNESS: float = 0.12
const ROOM_WALL_HEIGHT: float = 2.75
const ROOM_DOOR_HEIGHT: float = 2.05

var generated_data: Dictionary = {}
var generated_route: Array[Vector3] = []
var generated_obstacles: Array[Vector3] = []
var generated_decorations: Array[Dictionary] = []
var generated_stations: Array[Dictionary] = []
var _billboard_materials: Array[StandardMaterial3D] = []
var _youtube_requests: Array[HTTPRequest] = []

## Dodatkowa szerokość ciemnego obrysu używana wyłącznie w podglądzie generatora.
## W wyścigu pozostaje 0, więc geometria jezdni nie zmienia się.
@export var preview_outline_extra_width: float = 0.0
@export var preview_selected_obstacle_index: int = -1
@export var preview_selected_decoration_index: int = -1
## W podglądzie z góry (edytor) sufit jest ukryty, żeby było widać całe mieszkanie.
@export var room_ceiling_visible: bool = true

var room_builder: RoomBuilder
var generated_furnishings: Array[Dictionary] = []


func configure(data: Dictionary) -> void:
	generated_data = data.duplicate(true)
	RoomStyleCatalog.ensure_defaults(generated_data)
	RoomTextures.prewarm(generated_data)
	generated_route.clear()
	for point: Variant in generated_data.get("route", []):
		if typeof(point) == TYPE_VECTOR3:
			generated_route.append(point)
	generated_obstacles.clear()
	for point: Variant in generated_data.get("obstacles", []):
		if typeof(point) == TYPE_VECTOR3:
			generated_obstacles.append(point)
	generated_decorations.clear()
	var start_clearance: Dictionary = generated_data.get("start_room_bounds", {})
	for decoration: Variant in generated_data.get("decorations", []):
		if typeof(decoration) != TYPE_DICTIONARY:
			continue
		var decoration_copy: Dictionary = decoration.duplicate(true)
		var decoration_position: Vector3 = decoration_copy.get("position", Vector3.ZERO)
		if not start_clearance.is_empty() and TrackGeneratorScript._point_inside_bounds_xz(decoration_position, start_clearance, 0.85):
			continue
		generated_decorations.append(decoration_copy)
	# Odtwarzamy stacje ze wspólnej funkcji generatora. Chroni to także
	# podgląd 3D przed błędnymi pozycjami zapisanymi w starszych trasach.
	generated_stations = TrackGeneratorScript.make_docking_stations(
		generated_route,
		float(generated_data.get("track_width", 1.2))
	)
	# Zawsze odtwarzamy chroniony pokój startowy z aktualnej geometrii trasy.
	# Nie ufamy start_room_bounds zapisanym w starszych seedach/zapisach, bo
	# mogły opisywać pokój przesunięty na jedną stronę i ścianę na linii startu.
	generated_data["start_room_bounds"] = TrackGeneratorScript._make_start_room_bounds(
		generated_route,
		generated_stations,
		float(generated_data.get("track_width", 1.2))
	)
	route_closed = bool(generated_data.get("route_closed", generated_data.get("generated", true)))
	track_id = str(generated_data.get("id", "generated"))
	display_name = str(generated_data.get("name", "Trasa proceduralna"))
	track_width = clampf(float(generated_data.get("track_width", 1.65)), 0.8, 2.45)
	var map_scale: float = [0.18, 0.22, 0.26, 0.30, 0.34, 0.40][clampi(int(generated_data.get("size_level", 1)), 0, 5)]
	# Nowe mapy v26+ używają prostych odcinków zamiast wygładzania narożników.
	spline_steps = 1 if int(generated_data.get("generator_version", 1)) >= 26 else 6
	reflection_extents = Vector3(55.0 * map_scale, 4.0, 45.0 * map_scale)
	default_laps = int(generated_data.get("default_laps", 3))
	max_racers = int(generated_data.get("max_racers", 5))
	dirt_pickup_count = clampi(int(generated_data.get("dirt_pickup_count", 12 + int(generated_data.get("complexity", 2)))), 0, 12)


## Pora dnia zmienia światło otoczenia, słońce i tło PRZED zbudowaniem środowiska.
func _build_environment() -> void:
	room_builder = RoomBuilder.create(self, generated_data, not room_ceiling_visible)
	room_builder.apply_environment(self)
	super._build_environment()


func _get_default_route() -> Array[Vector3]:
	var result: Array[Vector3] = []
	result.assign(generated_route)
	return result


func _build_geometry() -> void:
	if smooth_route.size() < 6:
		push_error("ProceduralTrack: nieprawidłowa trasa — za mało punktów.")
		return
	_build_floor()
	_build_track_ribbon()
	_build_walls()
	_build_obstacles()
	_build_checkpoint_gates()
	_build_room_furnishings()
	_build_decorations()
	_build_channel_billboards()
	_build_start_line()
	_apply_object_skin()


## Nakłada wybraną skórkę (materiały) na meble, zwierzęta i przeszkody.
## Geometria modeli, kolizje i stacje dokujące pozostają bez zmian.
func _apply_object_skin() -> void:
	var prefixes: Array[String] = ["Dekoracja_", "OkraglaPrzeszkoda_", "Wyposazenie_"]
	ObjectSkins.apply_to_named_children(self, prefixes, GameSettings.object_skin)


## Zmiana grafiki (w tym skórki obiektów) odświeża materiały na żywo.
func apply_graphics() -> void:
	super.apply_graphics()
	_apply_object_skin()
	if room_builder != null:
		# Rzeczywiste światła pokojów od jakości ŚREDNIEJ; niżej zostają plamy światła.
		var real_lights: bool = GameSettings.quality >= GameSettings.Quality.MEDIUM
		for light: OmniLight3D in room_builder.lights:
			if is_instance_valid(light):
				light.visible = real_lights
		for light: OmniLight3D in room_builder.negative_lights:
			if is_instance_valid(light):
				light.visible = real_lights


func _build_floor() -> void:
	var min_x: float = INF
	var max_x: float = -INF
	var min_z: float = INF
	var max_z: float = -INF
	for point: Vector3 in smooth_route:
		min_x = minf(min_x, point.x)
		max_x = maxf(max_x, point.x)
		min_z = minf(min_z, point.z)
		max_z = maxf(max_z, point.z)
	# Granice podłogi są wyznaczane z zapisanych granic pomieszczeń, bez sztucznego marginesu wokół trasy.
	var room_bounds_for_floor: Array = generated_data.get("room_bounds", [])
	if not room_bounds_for_floor.is_empty():
		min_x = INF
		max_x = -INF
		min_z = INF
		max_z = -INF
		for room_value: Variant in room_bounds_for_floor:
			if room_value is Dictionary:
				min_x = minf(min_x, float(room_value.get("min_x", min_x)))
				max_x = maxf(max_x, float(room_value.get("max_x", max_x)))
				min_z = minf(min_z, float(room_value.get("min_z", min_z)))
				max_z = maxf(max_z, float(room_value.get("max_z", max_z)))
		var start_bounds: Dictionary = generated_data.get("start_room_bounds", {})
		if not start_bounds.is_empty():
			min_x = minf(min_x, float(start_bounds.get("min_x", min_x)))
			max_x = maxf(max_x, float(start_bounds.get("max_x", max_x)))
			min_z = minf(min_z, float(start_bounds.get("min_z", min_z)))
			max_z = maxf(max_z, float(start_bounds.get("max_z", max_z)))
	var floor_size := Vector3(max_x - min_x + 0.4, 0.5, max_z - min_z + 0.4)
	var center := Vector3((min_x + max_x) * 0.5, -0.28, (min_z + max_z) * 0.5)
	var body := StaticBody3D.new()
	body.name = "PodlogaPomieszczenia"
	body.collision_layer = 1
	body.collision_mask = 0
	body.position = center
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = floor_size
	collision.shape = shape
	body.add_child(collision)
	add_child(body)
	var floor_mesh := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = floor_size
	floor_mesh.mesh = box
	# Przy realistycznych pokojach podłoga bazowa jest przykryta, więc nie liczymy dla niej tekstury.
	var floor_texture: Texture2D = null
	if room_builder == null or not room_builder.has_rooms():
		floor_texture = _make_floor_texture(int(generated_data.get("floor_texture", 0)), int(generated_data.get("floor_texture_seed", generated_data.get("seed", 1))))
	var material := StandardMaterial3D.new()
	material.albedo_color = _theme_floor_color()
	material.albedo_texture = floor_texture
	material.roughness = 0.88
	material.uv1_scale = Vector3(maxf(floor_size.x / 2.4, 1.0), 1.0, maxf(floor_size.z / 2.4, 1.0))
	floor_mesh.material_override = material
	floor_mesh.position = center
	add_child(floor_mesh)
	nav_floor_bounds.append(AABB(center - floor_size * 0.5, floor_size))
	nav_floor_height = 0.0
	# Podłoga jest dzielona zgodnie z losowym układem pomieszczeń z generatora.
	# Każdy pokój otrzymuje własny wariant materiału, bez sztucznego krzyża 2x2.
	var room_bounds: Array = generated_data.get("room_bounds", [])
	if room_bounds.is_empty():
		var half_x: float = floor_size.x * 0.5
		var half_z: float = floor_size.z * 0.5
		for sx: int in range(2):
			for sz: int in range(2):
				room_bounds.append({"min_x": center.x - half_x + half_x * float(sx), "max_x": center.x - half_x + half_x * float(sx + 1), "min_z": center.z - half_z + half_z * float(sz), "max_z": center.z - half_z + half_z * float(sz + 1)})
	var zone_variants: Array[int] = _floor_zone_variants()
	var texture_cache: Dictionary = {}
	var zone_roughness: Dictionary = {0: 0.38, 1: 0.62, 2: 1.0, 3: 0.86, 4: 0.30}
	var floor_seed: int = int(generated_data.get("floor_texture_seed", generated_data.get("seed", 1)))
	for room_index: int in range(room_bounds.size()):
		var room: Dictionary = room_bounds[room_index]
		# Materiał jest nanoszony na cienką, bezgrubościową powierzchnię XZ.
		# Nie używamy BoxMesh: jego boczne ścianki wyglądały jak osobne panele
		# lub płyty położone na właściwej podłodze.
		var room_width: float = maxf(float(room.get("max_x", center.x + 1.0)) - float(room.get("min_x", center.x - 1.0)), 1.0)
		var room_depth: float = maxf(float(room.get("max_z", center.z + 1.0)) - float(room.get("min_z", center.z - 1.0)), 1.0)
		# Powierzchnia jest minimalnie nad górą bazowej kolizji (-0.03),
		# ale nie ma grubości ani widocznej krawędzi.
		var room_center := Vector3((float(room.get("min_x", center.x)) + float(room.get("max_x", center.x))) * 0.5, -0.022, (float(room.get("min_z", center.z)) + float(room.get("max_z", center.z))) * 0.5)
		var zone_variant: int = zone_variants[room_index % zone_variants.size()]
		var realistic_floor: bool = room_builder != null and room_builder.has_rooms()
		if not realistic_floor and not texture_cache.has(zone_variant):
			texture_cache[zone_variant] = _make_floor_texture(zone_variant, floor_seed + room_index * 13)
		var patch := MeshInstance3D.new()
		var patch_mesh := PlaneMesh.new()
		patch_mesh.size = Vector2(room_width, room_depth)
		patch.mesh = patch_mesh
		var patch_material := StandardMaterial3D.new()
		patch_material.albedo_color = Color.WHITE
		patch_material.albedo_texture = texture_cache.get(zone_variant, null) as Texture2D
		patch_material.roughness = float(zone_roughness.get(zone_variant, 0.9))
		patch_material.uv1_scale = Vector3(maxf(room_width / 2.4, 1.0), 1.0, maxf(room_depth / 2.4, 1.0))
		patch.material_override = patch_material
		if room_builder != null and room_builder.has_rooms():
			patch.material_override = RoomTextures.floor_material(room_builder.floor_style_for(room_index), room_width, room_depth, str(generated_data.get("external_floor_texture_path", "")))
		patch.position = room_center
		patch.name = "StrefaPodlogi_Pokoj_%02d" % room_index
		add_child(patch)
	var start_bounds: Dictionary = generated_data.get("start_room_bounds", {})
	if not start_bounds.is_empty():
		var start_width: float = maxf(float(start_bounds.get("max_x", 0.0)) - float(start_bounds.get("min_x", 0.0)), 1.0)
		var start_depth: float = maxf(float(start_bounds.get("max_z", 0.0)) - float(start_bounds.get("min_z", 0.0)), 1.0)
		var start_patch := MeshInstance3D.new()
		var start_mesh := PlaneMesh.new()
		start_mesh.size = Vector2(start_width, start_depth)
		start_patch.mesh = start_mesh
		start_patch.name = "PodlogaOsobnegoPokojuStartowego"
		var start_material: StandardMaterial3D = RoomTextures.floor_material(room_builder.floor_style_for(0), start_width, start_depth, str(generated_data.get("external_floor_texture_path", ""))) if room_builder != null and room_builder.has_rooms() else material.duplicate() as StandardMaterial3D
		start_patch.material_override = start_material
		start_patch.position = Vector3((float(start_bounds.get("min_x", 0.0)) + float(start_bounds.get("max_x", 0.0))) * 0.5, -0.021, (float(start_bounds.get("min_z", 0.0)) + float(start_bounds.get("max_z", 0.0))) * 0.5)
		add_child(start_patch)
	_build_room_shell(floor_size, center)


func _build_room_shell(floor_size: Vector3, center: Vector3) -> void:
	# Półprzezroczysty sufit pozwala kamerze wyścigu nadal pokazywać trasę.
	var ceiling_body := StaticBody3D.new()
	ceiling_body.name = "SufitPomieszczenia"
	ceiling_body.collision_layer = 1
	ceiling_body.collision_mask = 0
	var ceiling_shape_node := CollisionShape3D.new()
	var ceiling_shape := BoxShape3D.new()
	ceiling_shape.size = Vector3(floor_size.x, 0.16, floor_size.z)
	ceiling_shape_node.shape = ceiling_shape
	ceiling_body.add_child(ceiling_shape_node)
	var ceiling := MeshInstance3D.new()
	ceiling.name = "SufitWidoczny"
	ceiling.add_to_group("race_room_ceiling")
	var ceiling_mesh := BoxMesh.new()
	ceiling_mesh.size = ceiling_shape.size
	ceiling.mesh = ceiling_mesh
	var ceiling_material := StandardMaterial3D.new()
	# Sufit ma być wyraźnie widoczny jako pełna część mieszkania, ale
	# pozostaje półprzezroczysty, żeby kamera wyścigu nadal widziała tor.
	var realistic_rooms: bool = room_builder != null and room_builder.has_rooms()
	if realistic_rooms:
		# Pełny, matowy sufit - oświetlany lampami pokoju.
		ceiling_material.albedo_color = room_builder.ceiling_color()
		ceiling_material.cull_mode = BaseMaterial3D.CULL_DISABLED
		ceiling_material.roughness = 0.95
	else:
		ceiling_material.albedo_color = Color("#a9c4d6", 0.96)
		ceiling_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		ceiling_material.cull_mode = BaseMaterial3D.CULL_DISABLED
		ceiling_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		ceiling_material.roughness = 0.9
	ceiling.material_override = ceiling_material
	ceiling_body.position = Vector3(center.x, ROOM_WALL_HEIGHT, center.z)
	ceiling.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	ceiling_body.add_child(ceiling)
	ceiling_body.visible = room_ceiling_visible
	add_child(ceiling_body)
	if room_builder != null and room_builder.has_rooms():
		room_builder.build_ceiling_lights()
	else:
		_build_ceiling_fixtures(floor_size, center)
	# Zewnętrzne ściany wyznaczają pokoje i zatrzymują roboty poza planszą.
	var wall_material := StandardMaterial3D.new()
	wall_material.albedo_color = Color("#d6cfc2") if (room_builder != null and room_builder.has_rooms()) else Color("#596675")
	wall_material.roughness = 0.82
	var trim_material := StandardMaterial3D.new()
	trim_material.albedo_color = Color("#a9c0ce")
	trim_material.metallic = 0.28
	for side_index: int in range(4):
		var along_x: bool = side_index < 2
		var wall_vertical: bool = not along_x
		var wall_axis: float = center.z - floor_size.z * 0.5 if side_index == 0 else center.z + floor_size.z * 0.5 if side_index == 1 else center.x - floor_size.x * 0.5 if side_index == 2 else center.x + floor_size.x * 0.5
		var wall_min: float = center.x - floor_size.x * 0.5 if along_x else center.z - floor_size.z * 0.5
		var wall_max: float = center.x + floor_size.x * 0.5 if along_x else center.z + floor_size.z * 0.5
		var start_bounds: Dictionary = generated_data.get("start_room_bounds", {})
		if _partition_intersects_start_room(start_bounds, wall_vertical, wall_axis, wall_min, wall_max):
			continue
		# Również zewnętrzny obrys jest dzielony w miejscu przecięcia z trasą.
		var openings: Array[Vector2] = TrackGeneratorScript.get_room_partition_openings(
			generated_route, wall_vertical, wall_axis, track_width, wall_min, wall_max, route_closed
		)
		var cursor: float = wall_min
		for opening: Vector2 in openings:
			_add_outer_room_wall_piece(along_x, side_index, center, opening.x - cursor, cursor, wall_material, trim_material, floor_size)
			cursor = maxf(cursor, opening.y)
		_add_outer_room_wall_piece(along_x, side_index, center, wall_max - cursor, cursor, wall_material, trim_material, floor_size)

	_build_internal_room_partitions(floor_size, center, wall_material, trim_material)
	_build_room_wall_posters(floor_size, center)
	if room_builder != null and room_builder.has_rooms():
		room_builder.build_walls()
	_build_start_room_walls()


## Trzy ściany wydzielają pusty pokój startowy; czwarta strona pozostaje otwarta
## w kierunku linii startu i toru, aby roboty mogły swobodnie wyjeżdżać.
func _build_start_room_walls() -> void:
	var bounds: Dictionary = generated_data.get("start_room_bounds", {})
	if bounds.is_empty():
		return
	var center: Vector3 = bounds.get("center", Vector3.ZERO)
	var tangent: Vector3 = bounds.get("tangent", Vector3.FORWARD)
	var side: Vector3 = bounds.get("side", Vector3.RIGHT)
	var room_length: float = float(bounds.get("length", 10.5))
	# W nowych danych width jest pełną szerokością pokoju. Obsługa starszych
	# zapisów pozostaje kompatybilna przez domyślną wartość.
	var room_width: float = float(bounds.get("width", 6.4))
	if tangent.length_squared() < 0.001 or side.length_squared() < 0.001:
		return
	tangent = tangent.normalized()
	side = side.normalized()	
	var wall_material := StandardMaterial3D.new()
	wall_material.albedo_color = Color("#d7d2c8")
	wall_material.roughness = 0.86
	var wall_height: float = ROOM_WALL_HEIGHT
	var thickness: float = 0.16
	var root := Node3D.new()
	root.name = "PustyPokojStartowyScianyBoczne"
	add_child(root)
	# Wyłącznie dwie równoległe ściany boczne. Przód i tył są całkowicie otwarte.
	for side_sign: float in [-1.0, 1.0]:
		var wall_center: Vector3 = center + side * side_sign * (room_width * 0.5)
		var wall_a: Vector3 = wall_center - tangent * (room_length * 0.5)
		var wall_b: Vector3 = wall_center + tangent * (room_length * 0.5)
		if not TrackGeneratorScript.wall_line_segment_clear_of_route(generated_route, wall_a, wall_b, track_width, route_closed, 1.65):
			continue
		var wall_body := StaticBody3D.new()
		wall_body.name = "ScianaBocznaStartowa_%s" % ("Lewa" if side_sign < 0.0 else "Prawa")
		wall_body.collision_layer = 1
		wall_body.collision_mask = 0
		wall_body.position = center + side * side_sign * (room_width * 0.5) + Vector3.UP * (wall_height * 0.5)
		wall_body.rotation.y = atan2(-tangent.x, -tangent.z)
		var wall_size := Vector3(thickness, wall_height, room_length)
		var collision := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = wall_size
		collision.shape = shape
		wall_body.add_child(collision)
		var mesh := MeshInstance3D.new()
		var box := BoxMesh.new()
		box.size = wall_size
		mesh.mesh = box
		mesh.material_override = wall_material
		mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		wall_body.add_child(mesh)
		root.add_child(wall_body)


func _build_ceiling_fixtures(floor_size: Vector3, center: Vector3) -> void:
	# Cztery plafony pod sufitem podkreślają, że generator tworzy wnętrze mieszkania.
	# Światła korzystają z istniejącego systemu jakości grafiki TrackBase.
	var fixture_material := StandardMaterial3D.new()
	fixture_material.albedo_color = Color("#fff0cf")
	fixture_material.emission_enabled = true
	fixture_material.emission = Color("#ffe2ad")
	fixture_material.emission_energy_multiplier = 0.65
	fixture_material.roughness = 0.42
	var fixture_positions: Array[Vector3] = [
		center + Vector3(-floor_size.x * 0.25, ROOM_WALL_HEIGHT - 0.22, -floor_size.z * 0.25),
		center + Vector3(floor_size.x * 0.25, ROOM_WALL_HEIGHT - 0.22, -floor_size.z * 0.25),
		center + Vector3(-floor_size.x * 0.25, ROOM_WALL_HEIGHT - 0.22, floor_size.z * 0.25),
		center + Vector3(floor_size.x * 0.25, ROOM_WALL_HEIGHT - 0.22, floor_size.z * 0.25)
	]
	for index: int in range(fixture_positions.size()):
		var fixture := MeshInstance3D.new()
		fixture.name = "PlafonSufitowy_%d" % index
		var fixture_mesh := BoxMesh.new()
		fixture_mesh.size = Vector3(0.9, 0.06, 0.42)
		fixture.mesh = fixture_mesh
		fixture.material_override = fixture_material
		fixture.position = fixture_positions[index]
		add_child(fixture)
		add_lamp(fixture.position + Vector3(0.0, -0.45, 0.0), Color("#ffe4ba"), 0.65, clampf(minf(floor_size.x, floor_size.z) * 0.55, 2.5, 5.0))


func _add_outer_room_wall_piece(along_x: bool, side_index: int, center: Vector3, length: float, from_value: float, wall_material: StandardMaterial3D, trim_material: StandardMaterial3D, floor_size: Vector3) -> void:
	if length < 0.35:
		return
	var wall_axis: float = center.z - floor_size.z * 0.5 if side_index == 0 else center.z + floor_size.z * 0.5 if side_index == 1 else center.x - floor_size.x * 0.5 if side_index == 2 else center.x + floor_size.x * 0.5
	if not TrackGeneratorScript.wall_segment_clear_of_route(generated_route, not along_x, wall_axis, from_value, from_value + length, track_width, route_closed, 1.65):
		return
	var wall_size := Vector3(length, ROOM_WALL_HEIGHT, WALL_THICKNESS) if along_x else Vector3(WALL_THICKNESS, ROOM_WALL_HEIGHT, length)
	var wall_position: Vector3
	if along_x:
		var z_value: float = center.z - floor_size.z * 0.5 if side_index == 0 else center.z + floor_size.z * 0.5
		wall_position = Vector3(from_value + length * 0.5, ROOM_WALL_HEIGHT * 0.5, z_value)
	else:
		var x_value: float = center.x - floor_size.x * 0.5 if side_index == 2 else center.x + floor_size.x * 0.5
		wall_position = Vector3(x_value, ROOM_WALL_HEIGHT * 0.5, from_value + length * 0.5)
	var wall_body := StaticBody3D.new()
	wall_body.name = "ScianaZewnetrzna_%d" % side_index
	wall_body.collision_layer = 1
	wall_body.collision_mask = 0
	wall_body.position = wall_position
	var wall_collision := CollisionShape3D.new()
	var wall_shape := BoxShape3D.new()
	wall_shape.size = wall_size
	wall_collision.shape = wall_shape
	wall_body.add_child(wall_collision)
	var wall_mesh := MeshInstance3D.new()
	var wall_box := BoxMesh.new()
	wall_box.size = wall_size
	wall_mesh.mesh = wall_box
	wall_mesh.material_override = wall_material
	wall_body.add_child(wall_mesh)
	var wall_trim := MeshInstance3D.new()
	var trim_mesh := BoxMesh.new()
	trim_mesh.size = Vector3(length, 0.08, 0.16) if along_x else Vector3(0.16, 0.08, length)
	wall_trim.mesh = trim_mesh
	wall_trim.material_override = trim_material
	wall_trim.position.y = ROOM_WALL_HEIGHT * 0.5 - 0.12
	wall_body.add_child(wall_trim)
	add_child(wall_body)


func _build_internal_room_partitions(floor_size: Vector3, center: Vector3, wall_material: StandardMaterial3D, trim_material: StandardMaterial3D) -> void:
	# Zamiast dwóch przecinających się osi mieszkanie otrzymuje nieregularny
	# podział maksymalnie ośmiu większych pomieszczeń wygenerowany z seedu trasy.
	if str(generated_data.get("theme", "apartment")) in ["futuristic", "pro_league", "cleaning_hall"]:
		return
	var partitions: Array = generated_data.get("room_partitions", [])
	# Brak wygenerowanych podziałów oznacza otwartą przestrzeń.
	# Nie wolno wstawiać w ich miejsce domyślnego krzyża ścian — taki
	# fallback przecinał trasę i tworzył kolizje mimo poprawnego generatora.
	if partitions.is_empty():
		return
	var protected_start: Dictionary = generated_data.get("start_room_bounds", {})
	for partition: Dictionary in partitions:
		var vertical: bool = bool(partition.get("vertical", true))
		var axis: float = float(partition.get("axis", 0.0))
		var extent_min: float = float(partition.get("min", 0.0))
		var extent_max: float = float(partition.get("max", 0.0))
		# Start jest strefą chronioną: żadna ściana z generatora nie może
		# przecinać jej prostokątnego obszaru, nawet jeśli generator wylosował drzwi.
		if _partition_intersects_start_room(protected_start, vertical, axis, extent_min, extent_max):
			continue
		_build_partition_wall(vertical, axis, extent_min, extent_max, wall_material, trim_material, not bool(partition.get("alcove", false)))


func _partition_intersects_start_room(bounds: Dictionary, vertical: bool, axis: float, extent_min: float, extent_max: float) -> bool:
	if bounds.is_empty():
		return false
	if vertical:
		return axis >= float(bounds.get("min_x", INF)) - WALL_THICKNESS and axis <= float(bounds.get("max_x", -INF)) + WALL_THICKNESS and extent_max > float(bounds.get("min_z", INF)) and extent_min < float(bounds.get("max_z", -INF))
	return axis >= float(bounds.get("min_z", INF)) - WALL_THICKNESS and axis <= float(bounds.get("max_z", -INF)) + WALL_THICKNESS and extent_max > float(bounds.get("min_x", INF)) and extent_min < float(bounds.get("max_x", -INF))

func _build_partition_wall(vertical: bool, axis_value: float, extent_min: float, extent_max: float, wall_material: StandardMaterial3D, trim_material: StandardMaterial3D, allow_fallback_door: bool = true) -> void:
	var openings: Array[Vector2] = TrackGeneratorScript.get_room_partition_openings(
		generated_route, vertical, axis_value, track_width, extent_min, extent_max, route_closed
	)
	var cursor: float = extent_min
	for opening: Vector2 in openings:
		_add_partition_segment(vertical, axis_value, cursor, opening.x, wall_material)
		_add_door_frame(vertical, axis_value, opening, wall_material, trim_material)
		cursor = maxf(cursor, opening.y)
	_add_partition_segment(vertical, axis_value, cursor, extent_max, wall_material)


func _add_partition_segment(vertical: bool, axis_value: float, from_value: float, to_value: float, wall_material: StandardMaterial3D) -> void:
	# W miejscu przecięcia ścian wycinamy odcinek szerokości drugiej ściany.
	# Zapobiega to nakładaniu dwóch brył i podwójnym kolizjom w narożnikach/T.
	var cuts: Array[Vector2] = []
	for other_variant: Variant in generated_data.get("room_partitions", []):
		if not other_variant is Dictionary:
			continue
		var other: Dictionary = other_variant
		var other_vertical: bool = bool(other.get("vertical", true))
		if other_vertical == vertical:
			continue
		var other_axis: float = float(other.get("axis", 0.0))
		var other_min: float = float(other.get("min", 0.0))
		var other_max: float = float(other.get("max", 0.0))
		var crossing_is_inside: bool = other_axis >= from_value and other_axis <= to_value
		var current_axis_inside: bool = axis_value >= other_min and axis_value <= other_max
		if crossing_is_inside and current_axis_inside:
			cuts.append(Vector2(other_axis - WALL_THICKNESS * 0.5, other_axis + WALL_THICKNESS * 0.5))
	cuts.sort_custom(func(a: Vector2, b: Vector2) -> bool: return a.x < b.x)
	var cursor: float = from_value
	for cut: Vector2 in cuts:
		var cut_start: float = clampf(cut.x, from_value, to_value)
		var cut_end: float = clampf(cut.y, from_value, to_value)
		if cut_start - cursor >= 0.5:
			_add_partition_segment_piece(vertical, axis_value, cursor, cut_start, wall_material)
		cursor = maxf(cursor, cut_end)
	if to_value - cursor >= 0.5:
		_add_partition_segment_piece(vertical, axis_value, cursor, to_value, wall_material)


func _add_partition_segment_piece(vertical: bool, axis_value: float, from_value: float, to_value: float, wall_material: StandardMaterial3D) -> void:
	var length: float = to_value - from_value
	if length < 0.5:
		return
	if not TrackGeneratorScript.wall_segment_clear_of_route(generated_route, vertical, axis_value, from_value, to_value, track_width, route_closed, 1.65):
		return
	var wall_size := Vector3(WALL_THICKNESS, ROOM_WALL_HEIGHT, length) if vertical else Vector3(length, ROOM_WALL_HEIGHT, WALL_THICKNESS)
	var wall_body := StaticBody3D.new()
	wall_body.name = "ScianaDzialowa_%s" % ("Pionowa" if vertical else "Pozioma")
	wall_body.collision_layer = 1
	wall_body.collision_mask = 0
	wall_body.position = Vector3(axis_value, ROOM_WALL_HEIGHT * 0.5, (from_value + to_value) * 0.5) if vertical else Vector3((from_value + to_value) * 0.5, ROOM_WALL_HEIGHT * 0.5, axis_value)
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = wall_size
	collision.shape = shape
	wall_body.add_child(collision)
	var mesh_instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = wall_size
	mesh_instance.mesh = mesh
	mesh_instance.material_override = wall_material
	wall_body.add_child(mesh_instance)
	add_child(wall_body)


func _add_door_frame(_vertical: bool, _axis_value: float, _opening: Vector2, _wall_material: StandardMaterial3D, _trim_material: StandardMaterial3D) -> void:
	# Otwór jest korytarzem przejazdowym, a nie zwykłymi drzwiami.
	# Nie dodajemy nadproża ani górnej bryły ściany: kamera GTA 1 widziała
	# je jako fragment ściany przecinający tor.
	return


func _build_room_wall_posters(floor_size: Vector3, center: Vector3) -> void:
	# Obrazkowe plakaty na ścianach pokoi; używają tych samych miniatur co banery.
	var poster_positions: Array[Vector3] = [
		center + Vector3(0.0, 1.65, -floor_size.z * 0.5 + 0.14),
		center + Vector3(0.0, 1.65, floor_size.z * 0.5 - 0.14),
		center + Vector3(-floor_size.x * 0.5 + 0.14, 1.65, 0.0),
		center + Vector3(floor_size.x * 0.5 - 0.14, 1.65, 0.0)
	]
	for poster_index: int in range(poster_positions.size()):
		var poster := MeshInstance3D.new()
		poster.name = "PlakatSzakalNaScianie_%d" % poster_index
		var poster_mesh := QuadMesh.new()
		poster_mesh.size = Vector2(1.5, 0.7)
		poster.mesh = poster_mesh
		var poster_material := StandardMaterial3D.new()
		poster_material.albedo_color = Color("#17394e")
		poster_material.cull_mode = BaseMaterial3D.CULL_DISABLED
		poster_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		poster.material_override = poster_material
		poster.position = poster_positions[poster_index]
		if poster_index == 1:
			poster.rotation.y = PI
		elif poster_index == 2:
			poster.rotation.y = PI * 0.5
		elif poster_index == 3:
			poster.rotation.y = -PI * 0.5
		add_child(poster)
		_billboard_materials.append(poster_material)
		var caption := Label3D.new()
		caption.text = "SZAKAL  •  PC ON ANDROID"
		caption.font_size = 18
		caption.outline_size = 4
		caption.pixel_size = 0.003
		caption.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		caption.no_depth_test = true
		caption.position = poster.position + Vector3(0.0, -0.32, 0.02)
		add_child(caption)


## Warianty tekstur dla czterech stref podłogi: 0 płytki, 1 drewno, 2 wykładzina,
## 3 kamień/beton, 4 panele futurystyczne. Dobór zależy od motywu pomieszczenia.
func _floor_zone_variants() -> Array[int]:
	match str(generated_data.get("theme", "apartment")):
		"kitchen":
			return [0, 1, 0, 3]
		"bedroom":
			return [2, 1, 2, 1]
		"futuristic", "pro_league":
			return [4, 3, 4, 3]
		"office":
			return [3, 0, 3, 4]
	return [1, 2, 0, 3]


func _build_track_ribbon() -> void:
	# Jezdnia ma jeden, stały kolor dla wybranego motywu. Kolory podłogi,
	# mebli i dekoracji pozostają osobne, dzięki czemu elementy nie zlewają się.
	_build_track_outline()
	var theme: String = str(generated_data.get("theme", "apartment"))
	var route_colors: Dictionary = {
		"apartment": Color("#42647f"),
		"kitchen": Color("#a85b43"),
		"bedroom": Color("#765b91"),
		"futuristic": Color("#087f9e"),
		"office": Color("#536b7d"),
		"pro_league": Color("#075e83")
	}
	var tool := SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)
	var half_width: float = track_width * 0.5
	var road_segment_count: int = smooth_route.size() if route_closed else smooth_route.size() - 1
	for i: int in range(road_segment_count):
		var next_index: int = (i + 1) % smooth_route.size() if route_closed else i + 1
		var side_a: Vector3 = get_side_at_index(i) * half_width
		var side_b: Vector3 = get_side_at_index(next_index) * half_width
		var a_left: Vector3 = smooth_route[i] - side_a
		var a_right: Vector3 = smooth_route[i] + side_a
		var b_left: Vector3 = smooth_route[next_index] - side_b
		var b_right: Vector3 = smooth_route[next_index] + side_b
		a_left.y = 0.018
		a_right.y = 0.018
		b_left.y = 0.018
		b_right.y = 0.018
		tool.add_vertex(a_left)
		tool.add_vertex(a_right)
		tool.add_vertex(b_right)
		tool.add_vertex(a_left)
		tool.add_vertex(b_right)
		tool.add_vertex(b_left)
	tool.generate_normals()
	var road := MeshInstance3D.new()
	road.name = "JednolitaNawierzchniaTrasy"
	road.mesh = tool.commit()
	var road_material := StandardMaterial3D.new()
	road_material.albedo_color = route_colors.get(theme, route_colors["apartment"])
	road_material.roughness = 0.78
	road_material.metallic = 0.08 if theme == "futuristic" or theme == "pro_league" else 0.0
	road_material.emission_enabled = theme == "futuristic" or theme == "pro_league"
	road_material.emission = Color("#06485b") if theme == "futuristic" or theme == "pro_league" else Color.BLACK
	road_material.emission_energy_multiplier = 0.35
	road.material_override = road_material
	add_child(road)
	_build_edge_markers()


func _build_center_markers() -> void:
	# Krótkie jasne kreski środka jezdni ułatwiają odczyt przebiegu toru.
	var marker_material := StandardMaterial3D.new()
	marker_material.albedo_color = Color("#f7f3dc")
	marker_material.emission_enabled = true
	marker_material.emission = Color("#d9e7ef")
	marker_material.emission_energy_multiplier = 0.42
	var dash_mesh := BoxMesh.new()
	dash_mesh.size = Vector3(0.16, 0.035, 1.35)
	var marker_limit: int = smooth_route.size() - 1 if route_closed else smooth_route.size() - 2
	for i: int in range(2, marker_limit, 9):
		var next_index: int = (i + 1) % smooth_route.size() if route_closed else i + 1
		var direction: Vector3 = smooth_route[next_index] - smooth_route[i]
		direction.y = 0.0
		if direction.length() < 0.1:
			continue
		var dash := MeshInstance3D.new()
		dash.name = "SrodkowaKreska"
		dash.mesh = dash_mesh
		dash.material_override = marker_material
		dash.position = (smooth_route[i] + smooth_route[next_index]) * 0.5 + Vector3.UP * 0.09
		dash.rotation.y = atan2(-direction.x, -direction.z)
		add_child(dash)


func _build_track_outline() -> void:
	var tool := SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)
	var outline_half_width: float = track_width * 0.5 + 0.28 + maxf(preview_outline_extra_width, 0.0)
	var outline_segments: int = smooth_route.size() if route_closed else smooth_route.size() - 1
	for i: int in range(outline_segments):
		var next_index: int = (i + 1) % smooth_route.size() if route_closed else i + 1
		var side_a: Vector3 = get_side_at_index(i) * outline_half_width
		var side_b: Vector3 = get_side_at_index(next_index) * outline_half_width
		var a_left: Vector3 = smooth_route[i] - side_a
		var a_right: Vector3 = smooth_route[i] + side_a
		var b_left: Vector3 = smooth_route[next_index] - side_b
		var b_right: Vector3 = smooth_route[next_index] + side_b
		a_left.y = 0.008
		a_right.y = 0.008
		b_left.y = 0.008
		b_right.y = 0.008
		tool.add_vertex(a_left)
		tool.add_vertex(a_right)
		tool.add_vertex(b_right)
		tool.add_vertex(a_left)
		tool.add_vertex(b_right)
		tool.add_vertex(b_left)
	tool.generate_normals()
	var outline := MeshInstance3D.new()
	outline.name = "KontrastowyPodkladTrasy"
	outline.mesh = tool.commit()
	var material := StandardMaterial3D.new()
	material.albedo_color = Color("#17232b")
	material.roughness = 0.92
	outline.material_override = material
	add_child(outline)


func _build_edge_markers() -> void:
	# Linie są osobną, nieprzezroczystą geometrią NAD teksturą jezdni.
	# Podkład zapewnia kontrast na jasnych i ciemnych materiałach podłogi.
	var under_material := StandardMaterial3D.new()
	under_material.albedo_color = Color("#101820")
	under_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	under_material.render_priority = -2
	under_material.cull_mode = BaseMaterial3D.CULL_DISABLED
	under_material.roughness = 1.0
	var line_material := StandardMaterial3D.new()
	line_material.albedo_color = Color("#e8f7ff")
	line_material.emission_enabled = true
	line_material.emission = Color("#72dfff")
	line_material.emission_energy_multiplier = 0.8
	line_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	line_material.render_priority = -2
	line_material.cull_mode = BaseMaterial3D.CULL_DISABLED
	line_material.roughness = 0.45
	for side_sign: float in [-1.0, 1.0]:
		for layer: int in range(2):
			var tool := SurfaceTool.new()
			tool.begin(Mesh.PRIMITIVE_TRIANGLES)
			var half_line_width: float = 0.055 if layer == 0 else 0.032
			var lateral_offset: float = track_width * 0.5 - 0.06
			var edge_segments: int = smooth_route.size() if route_closed else smooth_route.size() - 1
			for i: int in range(edge_segments):
				var next_index: int = (i + 1) % smooth_route.size() if route_closed else i + 1
				var side_a: Vector3 = get_side_at_index(i)
				var side_b: Vector3 = get_side_at_index(next_index)
				var edge_a: Vector3 = smooth_route[i] + side_a * lateral_offset * side_sign
				var edge_b: Vector3 = smooth_route[next_index] + side_b * lateral_offset * side_sign
				var width_a: Vector3 = side_a * half_line_width
				var width_b: Vector3 = side_b * half_line_width
				# Linie leżą nisko na nawierzchni; nie wiszą na wysokości obudowy robota.
				var y_value: float = 0.020 if layer == 0 else 0.024
				edge_a.y = y_value
				edge_b.y = y_value
				tool.add_vertex(edge_a - width_a)
				tool.add_vertex(edge_a + width_a)
				tool.add_vertex(edge_b + width_b)
				tool.add_vertex(edge_a - width_a)
				tool.add_vertex(edge_b + width_b)
				tool.add_vertex(edge_b - width_b)
			tool.generate_normals()
			var edge := MeshInstance3D.new()
			edge.name = "PodkladLiniiTrasy" if layer == 0 else "LiniaKrawedziTrasy"
			edge.mesh = tool.commit()
			edge.material_override = under_material if layer == 0 else line_material
			edge.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			add_child(edge)


func _build_walls() -> void:
	# Granice toru są oznaczone cienkimi liniami na nawierzchni.
	# Nie tworzymy już ścian ani niewidzialnych kolizji wzdłuż jezdni;
	# otwarta przestrzeń pozwala na swobodny przejazd i objazdy.
	return


func _build_manual_reentry_markers() -> void:
	var marker_material := StandardMaterial3D.new()
	marker_material.albedo_color = Color("#35d9e8")
	marker_material.emission_enabled = true
	marker_material.emission = Color("#20bccc")
	marker_material.emission_energy_multiplier = 1.6
	marker_material.roughness = 0.35
	for fraction: float in [0.20, 0.40, 0.60, 0.80]:
		var gate_distance: float = route_length * fraction
		for edge_offset: float in [-0.8, 0.8]:
			var distance_value: float = wrapf(gate_distance + edge_offset, 0.0, route_length)
			var point: Vector3 = get_point_at(distance_value)
			var side: Vector3 = get_side_at(distance_value)
			for side_sign: float in [-1.0, 1.0]:
				var marker := MeshInstance3D.new()
				marker.name = "ZnacznikBramyPowrotnej"
				var marker_mesh := BoxMesh.new()
				marker_mesh.size = Vector3(0.10, 0.45, 0.10)
				marker.mesh = marker_mesh
				marker.material_override = marker_material
				marker.position = point + side * (track_width * 0.5 + 0.42) * side_sign + Vector3.UP * 0.22
				add_child(marker)


func _is_manual_reentry_gate(distance_value: float) -> bool:
	if route_length <= 0.0:
		return false
	var gate_half_width: float = 0.8
	for fraction: float in [0.20, 0.40, 0.60, 0.80]:
		var gate_distance: float = route_length * fraction
		var difference: float = absf(distance_value - gate_distance)
		difference = minf(difference, route_length - difference)
		if difference <= gate_half_width:
			return true
	return false


func _build_obstacles() -> void:
	# Okrągłe, niskie przeszkody — bez kierunkowego czubka i ostrych narożników.
	var obstacle_radii: Array[float] = [0.16, 0.19, 0.23, 0.27]
	var obstacle_heights: Array[float] = [0.18, 0.22, 0.28, 0.21]
	var obstacle_colors: Array[Color] = [Color("#d18d54"), Color("#5c8d9b"), Color("#b84d42"), Color("#6e7180")]
	var damage_values: Array[float] = [7.0, 4.0, 12.0, 16.0]
	for i: int in range(generated_obstacles.size()):
		if StylePackManager.is_downloaded_only_mode() and not StylePackManager.has_obstacle_asset(i % ObstacleModels.KIND_COUNT):
			continue
		var point: Vector3 = generated_obstacles[i]
		var radius: float = obstacle_radii[i % obstacle_radii.size()]
		var height: float = obstacle_heights[i % obstacle_heights.size()]
		point.y = height * 0.5
		var body := RigidBody3D.new()
		body.name = "OkraglaPrzeszkoda_%02d" % i
		body.set_script(load("res://scripts/tracks/DestructibleTrackObject.gd") as Script)
		body.mass = 0.85
		body.collision_layer = 1
		body.collision_mask = 3
		body.gravity_scale = 1.0
		body.position = point
		var collision := CollisionShape3D.new()
		var cylinder_shape := CylinderShape3D.new()
		cylinder_shape.radius = radius
		cylinder_shape.height = height
		collision.shape = cylinder_shape
		body.add_child(collision)
		_build_obstacle_appearance(body, i, radius, height, obstacle_colors[i % obstacle_colors.size()])
		# Bez dekoracyjnego pierścienia/poświaty wokół przeszkód.
		var physics_material := PhysicsMaterial.new()
		physics_material.friction = 0.22
		physics_material.bounce = 0.12
		body.physics_material_override = physics_material
		body.set("damage_amount", damage_values[i % damage_values.size()])
		add_child(body)
		if i == preview_selected_obstacle_index:
			_add_preview_object_marker(Vector3(point.x, 0.0, point.z), i)
		register_obstacle(point, radius)
		var bounds_size := Vector3(radius * 2.0, height, radius * 2.0)
		nav_obstacle_bounds.append(AABB(point - bounds_size * 0.5, bounds_size))


func _build_obstacle_appearance(parent: Node3D, index: int, radius: float, height: float, base_color: Color) -> void:
	# Kolizja pozostaje okrągła (walec w _build_obstacles), a wygląd to pięć
	# rozpoznawalnych modeli: puf, puszka, klocek, pachołek i bęben (ObstacleModels.gd).
	var visual: Node3D = TrackModelLibrary.make_obstacle(index, radius, height, base_color)
	visual.name = "ModelPrzeszkody"
	parent.add_child(visual)


func _build_checkpoint_gates() -> void:
	if route_length <= 1.0:
		return
	var fractions: Array[float] = [0.25, 0.5, 0.75]
	if not route_closed:
		fractions.append(1.0)
	var gate_material := StandardMaterial3D.new()
	gate_material.albedo_color = Color("#20e8ff")
	gate_material.emission_enabled = true
	gate_material.emission = Color("#08a9c5")
	gate_material.emission_energy_multiplier = 1.6
	gate_material.metallic = 0.35
	for checkpoint_index: int in range(fractions.size()):
		var distance: float = route_length * fractions[checkpoint_index]
		var center: Vector3 = get_point_at(distance)
		var tangent: Vector3 = get_tangent_at(distance)
		var side: Vector3 = Vector3(-tangent.z, 0.0, tangent.x)
		var gate := Node3D.new()
		var is_finish_gate: bool = not route_closed and checkpoint_index == fractions.size() - 1
		gate.name = "Meta" if is_finish_gate else "Checkpoint_%02d" % (checkpoint_index + 1)
		gate.position = center
		gate.rotation.y = atan2(-tangent.x, -tangent.z)
		add_child(gate)
		for side_sign: float in [-1.0, 1.0]:
			var post := MeshInstance3D.new()
			var post_mesh := BoxMesh.new()
			post_mesh.size = Vector3(0.12, 2.15, 0.12)
			post.mesh = post_mesh
			post.material_override = gate_material
			post.position = Vector3(side_sign * (track_width * 0.5 - 0.08), 1.075, 0.0)
			gate.add_child(post)
		var top := MeshInstance3D.new()
		var top_mesh := BoxMesh.new()
		top_mesh.size = Vector3(track_width, 0.10, 0.12)
		top.mesh = top_mesh
		top.material_override = gate_material
		top.position = Vector3.UP * 2.15
		gate.add_child(top)
		var label := Label3D.new()
		label.text = "META" if is_finish_gate else "CHECKPOINT %d" % (checkpoint_index + 1)
		label.font_size = 48
		label.outline_size = 8
		label.modulate = Color("#b8faff")
		label.position = Vector3.UP * 2.35
		label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		gate.add_child(label)
		if is_finish_gate:
			var finish_line := MeshInstance3D.new()
			finish_line.name = "LiniaMety"
			var finish_mesh := BoxMesh.new()
			finish_mesh.size = Vector3(track_width * 0.96, 0.018, 0.18)
			finish_line.mesh = finish_mesh
			var finish_material := StandardMaterial3D.new()
			finish_material.albedo_color = Color.WHITE
			finish_material.emission_enabled = true
			finish_material.emission = Color("#bdeeff")
			finish_line.material_override = finish_material
			finish_line.position = Vector3(0.0, 0.085, 0.0)
			gate.add_child(finish_line)


func _build_decorations() -> void:
	for index: int in range(generated_decorations.size()):
		var item: Dictionary = generated_decorations[index]
		var kind: String = str(item.get("kind", "box"))
		var position: Vector3 = item.get("position", Vector3.ZERO)
		var is_animal: bool = kind in ["cat", "dog", "rabbit", "bearded_dragon", "parrot", "hamster", "guinea_pig", "turtle", "hedgehog", "ferret"]
		if StylePackManager.is_downloaded_only_mode() and not is_animal and not StylePackManager.has_kind_asset(kind):
			continue
		var root: Node3D = Node3D.new() if is_animal else RigidBody3D.new()
		if is_animal:
			root.set_script(load("res://scripts/tracks/TrackAnimal.gd") as Script)
			root.set("species", kind)
			root.set("crossing_direction", item.get("animal_crossing_direction", Vector3.ZERO))
			root.set("crossing_distance", float(item.get("animal_crossing_distance", track_width + 1.0)))
		root.name = "Dekoracja_%02d_%s" % [index, kind]
		root.position = position
		root.rotation.y = float(item.get("rotation", 0.0))
		var scale_value: float = clampf(float(item.get("scale", 1.0)), 0.25, 2.4) * realism_scale(kind)
		# Zaznaczony element jest celowo powiększany tylko w podglądzie edytora,
		# aby dało się go rozpoznać na dużych mapach. Rozmiar zapisany pozostaje bez zmian.
		if index == preview_selected_decoration_index:
			scale_value *= 1.35
		root.scale = Vector3.ONE * scale_value
		if not is_animal:
			root.set_script(load("res://scripts/tracks/TrackDestructibleObject.gd") as Script)
			root.set("durability", _decoration_durability(kind))
			root.set("collision_damage", _decoration_damage(kind))
			root.set("hitbox_size", _decoration_hitbox(kind))
			root.set("movable", true)
		add_child(root)
		if is_animal:
			_add_animal_model(root, kind, int(item.get("variant", 0)))
		else:
			_add_furniture_model(root, kind, int(item.get("variant", 0)))
			_add_tabletop_details(root, kind, int(item.get("variant", 0)))
		if index == preview_selected_decoration_index:
			_add_preview_object_marker(position, index)


## Umeblowanie pokoi: meble są stabilne przed wyścigiem, ale reagują na uderzenia robotów.
func _build_room_furnishings() -> void:
	if room_builder == null or not room_builder.has_rooms():
		return
	generated_furnishings = RoomFurnisher.furnish(generated_data)
	for index: int in range(generated_furnishings.size()):
		var item: Dictionary = generated_furnishings[index]
		var kind: String = str(item.get("kind", "box"))
		if StylePackManager.is_downloaded_only_mode() and not StylePackManager.has_kind_asset(kind):
			continue
		# Całe umeblowanie reaguje fizycznie na uderzenie robota. Ciężar
		# i opór obiektu są obsługiwane przez wspólny skrypt fizyki.
		var can_move: bool = true
		var holder: Node3D = RigidBody3D.new() if can_move else Node3D.new()
		holder.name = "Wyposazenie_%03d_%s" % [index, kind]
		holder.position = item.get("position", Vector3.ZERO)
		holder.rotation.y = float(item.get("rotation", 0.0))
		holder.scale = Vector3.ONE * (float(item.get("scale", 1.0)) * realism_scale(kind))
		if can_move:
			holder.set_script(load("res://scripts/tracks/TrackDestructibleObject.gd") as Script)
			holder.set("durability", _decoration_durability(kind))
			holder.set("collision_damage", _decoration_damage(kind))
			holder.set("hitbox_size", _decoration_hitbox(kind))
			holder.set("movable", true)
		add_child(holder)
		_add_furniture_model(holder, kind, int(item.get("variant", 0)))
		_add_tabletop_details(holder, kind, int(item.get("variant", 0)), str(item.get("role", "")))
		_add_object_promo_surface(holder, kind)
	_build_room_wall_promotions()
	room_builder.build_furniture_lights(generated_decorations, generated_furnishings)


## Małe przedmioty są dziećmi mebla, więc pozostają na blacie także wtedy,
## gdy stół lub szafka zostaną przesunięte. Wysokości odpowiadają geometrii FurnitureModels.
func _add_tabletop_details(parent: Node3D, furniture_kind: String, variant: int, role: String = "") -> void:
	var props: Array[Dictionary] = []
	match furniture_kind:
		"table":
			props = [
				{"kind": "book", "position": Vector3(0.08, 0.805, -0.25), "scale": 0.34},
				{"kind": "mug", "position": Vector3(-0.52, 0.805, 0.20), "scale": 0.34}
			]
		"cabinet":
			props = [
				{"kind": "vase", "position": Vector3(-0.42, 1.55, 0.10), "scale": 0.42},
				{"kind": "candle", "position": Vector3(0.40, 1.55, 0.10), "scale": 0.42}
			]
		"kitchen_counter":
			props = [
				{"kind": "fruit_bowl", "position": Vector3(0.43, 1.315, 0.08), "scale": 0.48},
				{"kind": "kettle", "position": Vector3(-0.43, 1.315, 0.08), "scale": 0.48}
			]
		"nightstand":
			props = [{"kind": "lamp", "position": Vector3(0.16, 0.955, 0.08), "scale": 0.34}]
		"coffee_table":
			props = [
				{"kind": "book", "position": Vector3(-0.30, 0.405, 0.02), "scale": 0.32},
				{"kind": "remote", "position": Vector3(0.30, 0.405, 0.02), "scale": 0.38}
			]
		"side_table":
			props = [{"kind": "mug", "position": Vector3(0.0, 0.615, 0.0), "scale": 0.34}]
	if role == "office_desk":
		return
	for prop_index: int in range(props.size()):
		var prop: Dictionary = props[prop_index]
		var prop_root := Node3D.new()
		prop_root.name = "PrzedmiotNaBlacie_%s_%d" % [str(prop.get("kind", "item")), prop_index]
		prop_root.position = prop.get("position", Vector3.ZERO)
		prop_root.scale = Vector3.ONE * float(prop.get("scale", 0.4))
		parent.add_child(prop_root)
		prop_root.add_child(TrackModelLibrary.make_furniture(str(prop.get("kind", "book")), posmod(variant + prop_index, 4)))


## Nieinwazyjne powierzchnie promocyjne na ekranach i wyposażeniu.
## Nakładki są osobnymi siatkami — nie zmieniają geometrii modeli mebli.
func _add_object_promo_surface(holder: Node3D, kind: String) -> void:
	if not ["tv", "tv_wall", "table", "coffee_table", "side_table", "nightstand", "bookshelf", "cabinet", "wardrobe"].has(kind):
		return
	var panel := MeshInstance3D.new()
	var quad := QuadMesh.new()
	var material := _new_channel_promo_material()
	match kind:
		"tv":
			quad.size = Vector2(1.40, 0.72)
			panel.position = Vector3(0.0, 1.10, 0.024)
			panel.rotation.y = PI
		"tv_wall":
			quad.size = Vector2(1.66, 0.98)
			panel.position = Vector3(0.0, 1.10, -0.074)
			panel.rotation.y = PI
		"table":
			quad.size = Vector2(0.52, 0.34)
			panel.position = Vector3(0.0, 0.805, 0.0)
			panel.rotation.x = -PI * 0.5
		"coffee_table":
			quad.size = Vector2(0.42, 0.25)
			panel.position = Vector3(0.0, 0.405, 0.0)
			panel.rotation.x = -PI * 0.5
		"side_table", "nightstand":
			quad.size = Vector2(0.30, 0.20)
			panel.position = Vector3(0.0, 0.93, 0.0) if kind == "nightstand" else Vector3(0.0, 0.61, 0.0)
			panel.rotation.x = -PI * 0.5
		"wardrobe":
			quad.size = Vector2(0.42, 0.52)
			panel.position = Vector3(0.0, 1.20, -0.37)
			panel.rotation.y = PI
		"bookshelf":
			quad.size = Vector2(0.46, 0.32)
			panel.position = Vector3(0.0, 1.22, -0.045)
			panel.rotation.y = PI
		"cabinet":
			quad.size = Vector2(0.42, 0.30)
			panel.position = Vector3(0.0, 1.02, -0.45)
			panel.rotation.y = PI
	panel.name = "PowierzchniaPromocyjna_%s" % kind
	panel.mesh = quad
	panel.material_override = material
	panel.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	holder.add_child(panel)


func _build_room_wall_promotions() -> void:
	# Ramki trafiają na ściany wewnętrzne, z dala od okien i otworów drzwiowych.
	var rooms: Array = generated_data.get("room_bounds", [])
	if rooms.is_empty():
		return
	var min_x: float = INF
	var max_x: float = -INF
	var min_z: float = INF
	var max_z: float = -INF
	for room_value: Variant in rooms:
		var bounds: Dictionary = room_value
		min_x = minf(min_x, float(bounds["min_x"]))
		max_x = maxf(max_x, float(bounds["max_x"]))
		min_z = minf(min_z, float(bounds["min_z"]))
		max_z = maxf(max_z, float(bounds["max_z"]))
	for room_index: int in range(0, rooms.size(), 2):
		var room: Dictionary = rooms[room_index]
		var side_candidates: Array[int] = []
		if float(room["min_z"]) > min_z + 0.1:
			side_candidates.append(0)
		if float(room["max_z"]) < max_z - 0.1:
			side_candidates.append(1)
		if float(room["min_x"]) > min_x + 0.1:
			side_candidates.append(2)
		if float(room["max_x"]) < max_x - 0.1:
			side_candidates.append(3)
		if side_candidates.is_empty():
			continue
		var side_index: int = side_candidates[room_index % side_candidates.size()]
		var vertical: bool = side_index >= 2
		var axis_value: float = float(room["min_x"]) if side_index == 2 else float(room["max_x"]) if side_index == 3 else float(room["min_z"]) if side_index == 0 else float(room["max_z"])
		var extent_min: float = float(room["min_z"]) if vertical else float(room["min_x"])
		var extent_max: float = float(room["max_z"]) if vertical else float(room["max_x"])
		var openings: Array[Vector2] = TrackGeneratorScript.get_room_partition_openings(generated_route, vertical, axis_value, track_width, extent_min, extent_max, route_closed)
		var along: float = lerpf(extent_min, extent_max, 0.72 if room_index % 4 == 0 else 0.28)
		for opening: Vector2 in openings:
			if along >= opening.x - 1.6 and along <= opening.y + 1.6:
				along = opening.y + 2.0 if opening.y + 3.0 < extent_max else opening.x - 2.0
		if along < extent_min + 2.0 or along > extent_max - 2.0:
			continue
		var frame := MeshInstance3D.new()
		var frame_mesh := BoxMesh.new()
		frame_mesh.size = Vector3(2.6, 1.65, 0.12)
		frame.mesh = frame_mesh
		var frame_material := StandardMaterial3D.new()
		frame_material.albedo_color = Color("#26313b")
		frame_material.metallic = 0.35
		frame.material_override = frame_material
		var image := MeshInstance3D.new()
		var image_mesh := QuadMesh.new()
		image_mesh.size = Vector2(2.42, 1.46)
		image.mesh = image_mesh
		image.material_override = _new_channel_promo_material()
		image.position = Vector3(0.0, 0.0, -0.066)
		frame.add_child(image)
		match side_index:
			0:
				frame.position = Vector3(along, 6.2, float(room["min_z"]) + 0.32)
			1:
				frame.position = Vector3(along, 6.2, float(room["max_z"]) - 0.32)
				frame.rotation.y = PI
			2:
				frame.position = Vector3(float(room["min_x"]) + 0.32, 6.2, along)
				frame.rotation.y = PI * 0.5
			3:
				frame.position = Vector3(float(room["max_x"]) - 0.32, 6.2, along)
				frame.rotation.y = -PI * 0.5
		frame.name = "ObrazPromocyjnyPokoj_%02d" % room_index
		add_child(frame)


func _new_channel_promo_material() -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = Color("#12334a")
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.roughness = 1.0
	_billboard_materials.append(material)
	return material


## Wszystkie wymiary modeli mebli i drobnych przedmiotów są już zapisane w metrach.
## Nie wolno mnożyć ich ponownie przez 2–3,5. Zwierzęta mają osobne mnożniki,
## aby odpowiadały typowym gabarytom gatunku względem robota 30–35 cm.
static func realism_scale(kind: String) -> float:
	match kind:
		"toy": return 0.48
		"cat": return 0.38
		"dog": return 0.62
		"rabbit": return 0.34
		"bearded_dragon": return 0.24
		"parrot": return 0.42
		"hamster": return 0.16
		"guinea_pig": return 0.20
		"turtle": return 0.22
		"hedgehog": return 0.16
		"ferret": return 0.30
	return 1.0

func _add_preview_object_marker(world_position: Vector3, index: int) -> void:
	# Widoczny znacznik edycji: żółty pierścień na ziemi i wysoki świecący słupek.
	var marker := Node3D.new()
	marker.name = "ZaznaczeniePrzedmiotu_%02d" % index
	marker.position = world_position
	add_child(marker)
	var ring := MeshInstance3D.new()
	var ring_mesh := TorusMesh.new()
	ring_mesh.inner_radius = 0.45
	ring_mesh.outer_radius = 0.55
	ring_mesh.rings = 8
	ring_mesh.ring_segments = 32
	ring.mesh = ring_mesh
	var glow := StandardMaterial3D.new()
	glow.albedo_color = Color("#fff02a")
	glow.emission_enabled = true
	glow.emission = Color("#ffcc00")
	glow.emission_energy_multiplier = 2.2
	glow.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	ring.material_override = glow
	ring.position.y = 0.08
	marker.add_child(ring)
	var beacon := MeshInstance3D.new()
	var beacon_mesh := CylinderMesh.new()
	beacon_mesh.top_radius = 0.09
	beacon_mesh.bottom_radius = 0.18
	beacon_mesh.height = 1.2
	beacon.mesh = beacon_mesh
	beacon.material_override = glow
	beacon.position.y = 0.62
	marker.add_child(beacon)
	var caption := Label3D.new()
	caption.text = "WYBRANY PRZEDMIOT %d" % (index + 1)
	caption.font_size = 24
	caption.outline_size = 5
	caption.modulate = Color("#fffbd2")
	caption.position = Vector3(0.0, 1.35, 0.0)
	caption.pixel_size = 0.004
	caption.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	caption.no_depth_test = true
	marker.add_child(caption)


func _build_channel_billboards() -> void:
	# Więcej dwustronnych banerów przy trasie. Napisy billboardowe zawsze
	# zwracają się do kamery, więc nie są odwrócone od strony przeciwnej.
	var fractions: Array[float] = [0.10, 0.28, 0.46, 0.64, 0.82]
	if smooth_route.size() < 20:
		fractions.clear()
	for board_index: int in range(fractions.size()):
		var route_index: int = clampi(int(float(smooth_route.size()) * fractions[board_index]), 3, smooth_route.size() - 2)
		var point: Vector3 = smooth_route[route_index]
		var side: Vector3 = get_side_at_index(route_index) * (-1.0 if board_index % 2 == 0 else 1.0)
		var board_position: Vector3 = point + side * (track_width * 0.5 + 1.25)
		board_position.y = 1.55
		var approach_direction: Vector3 = -get_tangent_at(route_index)
		approach_direction.y = 0.0
		if approach_direction.length() < 0.001:
			approach_direction = Vector3.FORWARD
		var root := Node3D.new()
		root.name = "BillboardSzakalPCAndroid_%d" % board_index
		root.position = board_position
		root.basis = Basis.looking_at(approach_direction.normalized(), Vector3.UP)
		add_child(root)
		var panel := MeshInstance3D.new()
		var panel_mesh := BoxMesh.new()
		panel_mesh.size = Vector3(2.2, 0.72, 0.08)
		panel.mesh = panel_mesh
		var panel_material := StandardMaterial3D.new()
		panel_material.albedo_color = Color("#071a2a")
		panel_material.metallic = 0.28
		panel_material.roughness = 0.42
		panel.material_override = panel_material
		root.add_child(panel)
		var image_panel := MeshInstance3D.new()
		var image_mesh := QuadMesh.new()
		image_mesh.size = Vector2(2.05, 0.60)
		image_panel.mesh = image_mesh
		var image_material := StandardMaterial3D.new()
		image_material.albedo_color = Color("#15384c")
		image_material.cull_mode = BaseMaterial3D.CULL_DISABLED
		image_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		image_material.roughness = 1.0
		image_panel.material_override = image_material
		image_panel.position = Vector3(0.0, 0.0, -0.137)
		image_panel.rotation.y = PI
		root.add_child(image_panel)
		var image_panel_back := MeshInstance3D.new()
		var image_mesh_back := QuadMesh.new()
		image_mesh_back.size = Vector2(2.05, 0.60)
		image_panel_back.mesh = image_mesh_back
		image_panel_back.material_override = image_material
		image_panel_back.position = Vector3(0.0, 0.0, 0.137)
		root.add_child(image_panel_back)
		_billboard_materials.append(image_material)
		var label := Label3D.new()
		label.text = "SZAKAL • PC ON ANDROID  |  YOUTUBE"
		label.font_size = 18
		label.outline_size = 4
		label.modulate = Color.WHITE
		label.position = Vector3(0.0, -0.22, -0.05)
		label.pixel_size = 0.003
		label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		label.no_depth_test = false
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		root.add_child(label)
		var label_back := Label3D.new()
		label_back.text = label.text
		label_back.font_size = label.font_size
		label_back.outline_size = label.outline_size
		label_back.modulate = label.modulate
		label_back.position = Vector3(0.0, -0.22, 0.05)
		label_back.pixel_size = label.pixel_size
		label_back.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		label_back.no_depth_test = false
		label_back.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		root.add_child(label_back)
		var top_trim := MeshInstance3D.new()
		var trim_mesh := BoxMesh.new()
		trim_mesh.size = Vector3(8.35, 0.10, 0.31)
		top_trim.mesh = trim_mesh
		var trim_material := StandardMaterial3D.new()
		trim_material.albedo_color = Color("#00d9d0")
		trim_material.emission_enabled = true
		trim_material.emission = Color("#00a9a8")
		trim_material.emission_energy_multiplier = 0.85
		top_trim.material_override = trim_material
		top_trim.position.y = 1.18
		root.add_child(top_trim)
	_request_channel_thumbnails()


func _request_channel_thumbnails() -> void:
	# Rozwiązujemy ID kanału z publicznej strony, a potem pobieramy najnowsze
	# pozycje z kanału YouTube. Feed obejmuje ostatnie publikacje; obrazy są
	# pobierane dopiero poza logiką wyścigu i służą wyłącznie banerom.
	var request := HTTPRequest.new()
	request.timeout = 12.0
	add_child(request)
	_youtube_requests.append(request)
	request.request_completed.connect(_on_channel_page_loaded)
	var error: Error = request.request("https://www.youtube.com/@szakalpcandroid")
	if error != OK:
		request.queue_free()


func _on_channel_page_loaded(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300:
		return
	var html: String = body.get_string_from_utf8()
	var channel_regex := RegEx.new()
	channel_regex.compile("\"(?:channelId|externalId)\"\\s*:\\s*\"(UC[A-Za-z0-9_-]{22})\"")
	var channel_match: RegExMatch = channel_regex.search(html)
	if channel_match == null:
		var feed_regex := RegEx.new()
		feed_regex.compile("videos\\.xml\\?channel_id=(UC[A-Za-z0-9_-]{22})")
		channel_match = feed_regex.search(html)
	if channel_match == null:
		return
	var channel_id: String = channel_match.get_string(1)
	var feed_request := HTTPRequest.new()
	feed_request.timeout = 12.0
	add_child(feed_request)
	_youtube_requests.append(feed_request)
	feed_request.request_completed.connect(_on_channel_feed_loaded)
	feed_request.request("https://www.youtube.com/feeds/videos.xml?channel_id=" + channel_id)


func _on_channel_feed_loaded(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300:
		return
	var feed_text: String = body.get_string_from_utf8()
	var video_regex := RegEx.new()
	video_regex.compile("<yt:videoId>([^<]+)</yt:videoId>")
	var matches: Array[RegExMatch] = video_regex.search_all(feed_text)
	if matches.is_empty():
		return
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	var video_ids: Array[String] = []
	for video_match: RegExMatch in matches:
		video_ids.append(video_match.get_string(1))
	video_ids.shuffle()
	var available_count: int = mini(video_ids.size(), _billboard_materials.size())
	for i: int in range(available_count):
		var video_id: String = video_ids[i]
		var image_request := HTTPRequest.new()
		image_request.timeout = 12.0
		add_child(image_request)
		_youtube_requests.append(image_request)
		image_request.request_completed.connect(_on_video_thumbnail_loaded.bind(_billboard_materials[i]))
		image_request.request("https://i.ytimg.com/vi/" + video_id + "/hqdefault.jpg")


func _on_video_thumbnail_loaded(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray, target_material: StandardMaterial3D) -> void:
	if result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300 or body.is_empty():
		return
	var thumbnail := Image.new()
	if thumbnail.load_jpg_from_buffer(body) != OK:
		return
	var texture: ImageTexture = ImageTexture.create_from_image(thumbnail)
	target_material.albedo_texture = texture
	# Jedna poprawnie pobrana miniatura wypełnia pozostałe powierzchnie,
	# a kolejne odpowiedzi podmieniają wybrane materiały na inne filmy.
	for material: StandardMaterial3D in _billboard_materials:
		if material.albedo_texture == null:
			material.albedo_texture = texture


func _decoration_durability(kind: String) -> float:
	# Różna wytrzymałość: papier i drobiazgi pękają szybko, ciężkie meble
	# wymagają kilku mocnych uderzeń. Wartości są niezależne od obrażeń robota.
	match kind:
		"paper_scrap", "food_scraps", "sock": return 22.0
		"mug", "fish_tank", "tv", "vase": return 45.0
		"pillow", "rug", "toy", "yarn", "tennis_ball", "toy_car": return 55.0
		"candle": return 22.0
		"plant", "pet_bowl", "pet_bed", "shoe", "book", "remote": return 75.0
		"chair", "lamp", "box", "robot_toy", "cable", "backpack": return 95.0
		"table", "cabinet", "scratching_post": return 145.0
		"sofa", "bed", "bookshelf": return 190.0
	return 85.0


func _decoration_damage(kind: String) -> float:
	match kind:
		"pillow", "rug", "toy": return 2.0
		"plant", "pet_bowl", "pet_bed": return 4.0
		"chair", "lamp", "box", "robot_toy": return 7.0
		"table", "cabinet", "tv", "scratching_post": return 10.0
		"sofa", "bed", "bookshelf": return 13.0
		"fish_tank": return 16.0
	return 6.0


func _decoration_hitbox(kind: String) -> Vector3:
	# Hitboxy odpowiadają gabarytom modeli FurnitureModels / RoomFurnisher.
	# Skala rodzica jest nakładana na model i kolizję identycznie.
	match kind:
		"sock", "paper_scrap", "food_scraps": return Vector3(0.52, 0.16, 0.34)
		"shoe": return Vector3(0.8, 0.3, 0.4)
		"mug": return Vector3(0.14, 0.18, 0.14)
		"book": return Vector3(0.5, 0.2, 0.35)
		"remote": return Vector3(0.24, 0.08, 0.12)
		"tennis_ball": return Vector3(0.3, 0.3, 0.3)
		"toy_car": return Vector3(0.52, 0.22, 0.3)
		"candle": return Vector3(0.18, 0.24, 0.18)
		"vase": return Vector3(0.38, 0.72, 0.38)
		"yarn": return Vector3(0.42, 0.4, 0.42)
		"cable": return Vector3(0.78, 0.14, 0.24)
		"pet_bowl": return Vector3(0.5, 0.2, 0.5)
		"box": return Vector3(0.9, 0.8, 0.9)
		"pillow", "pet_bed": return Vector3(0.9, 0.4, 0.9)
		"toy", "robot_toy": return Vector3(0.8, 0.9, 0.8)
		"rug": return Vector3(2.2, 0.1, 1.5)
		"sofa": return Vector3(2.1, 1.5, 0.95)
		"bed": return Vector3(2.05, 1.1, 1.45)
		"table": return Vector3(1.7, 0.95, 1.05)
		"chair": return Vector3(0.7, 1.2, 0.7)
		"cabinet": return Vector3(1.55, 1.6, 0.85)
		"nightstand": return Vector3(0.85, 0.95, 0.72)
		"bookshelf": return Vector3(1.6, 2.0, 0.8)
		"tv": return Vector3(1.56, 1.6, 0.65)
		"fridge": return Vector3(1.12, 2.1, 0.88)
		"bathtub": return Vector3(1.85, 0.8, 1.0)
		"sink": return Vector3(1.3, 1.4, 1.0)
		"kitchen_counter": return Vector3(1.85, 1.3, 0.9)
		"lamp": return Vector3(0.7, 1.9, 0.7)
		"plant": return Vector3(0.8, 1.6, 0.8)
		"scratching_post": return Vector3(0.7, 1.6, 0.7)
		"fish_tank": return Vector3(1.45, 1.2, 0.9)
		"washing_machine": return Vector3(0.72, 0.92, 0.68)
		"shower": return Vector3(0.9, 1.95, 0.9)
		"toilet": return Vector3(0.52, 0.78, 0.72)
		"floor_fan": return Vector3(0.62, 1.45, 0.62)
		"radiator": return Vector3(1.25, 0.72, 0.18)
		"water_dispenser": return Vector3(0.48, 1.15, 0.48)
		"monitor": return Vector3(0.72, 0.58, 0.28)
		"speaker": return Vector3(0.48, 0.9, 0.42)
		"coat_rack": return Vector3(0.52, 1.65, 0.52)
		"umbrella_stand": return Vector3(0.38, 0.62, 0.38)
		"pet_tunnel": return Vector3(0.92, 0.48, 0.92)
		"wardrobe": return Vector3(1.65, 2.25, 0.78)
		"coffee_table": return Vector3(1.3, 0.55, 0.78)
		"side_table": return Vector3(0.75, 0.65, 0.65)
		"shoe_rack": return Vector3(1.1, 1.05, 0.45)
		"ottoman": return Vector3(1.0, 0.62, 1.0)
		"laundry_basket": return Vector3(0.9, 0.85, 0.9)
		"floor_mirror": return Vector3(0.9, 2.1, 0.35)
		"trash_bin": return Vector3(0.62, 0.85, 0.62)
		"wall_clock": return Vector3(0.58, 0.58, 0.16)
		"game_console": return Vector3(0.62, 0.18, 0.42)
		"laptop": return Vector3(0.52, 0.06, 0.38)
		"microwave": return Vector3(0.62, 0.42, 0.42)
		"toaster": return Vector3(0.38, 0.32, 0.28)
		"kettle": return Vector3(0.32, 0.42, 0.32)
		"fruit_bowl": return Vector3(0.62, 0.22, 0.62)
		"dish_rack": return Vector3(0.72, 0.48, 0.38)
		"towel_rack": return Vector3(0.82, 1.05, 0.22)
		"hanging_plant": return Vector3(0.62, 0.85, 0.62)
	return Vector3(1.0, 1.0, 1.0)


## Publiczny punkt wejścia dla edytora: buduje DOKŁADNIE ten model, który trafia na trasę.
func build_model_preview(parent: Node3D, kind: String, variant: int) -> void:
	if kind in ["cat", "dog", "rabbit", "bearded_dragon", "parrot", "hamster", "guinea_pig", "turtle", "hedgehog", "ferret"]:
		_add_animal_model(parent, kind, variant)
	else:
		_add_furniture_model(parent, kind, variant)


func _add_animal_model(parent: Node3D, animal: String, variant: int) -> void:
	# Trasa i edytor pobierają ten sam gotowy model ze wspólnej biblioteki.
	parent.add_child(TrackModelLibrary.make_animal(animal, variant))


func _add_furniture_model(parent: Node3D, kind: String, variant: int) -> void:
	# Trasa i edytor pobierają ten sam gotowy model ze wspólnej biblioteki.
	# Hitboxy i wytrzymałość pozostają obsługiwane przez istniejące skrypty.
	parent.add_child(TrackModelLibrary.make_furniture(kind, variant))


func _make_cone_mesh(radius: float, height: float) -> CylinderMesh:
	# Godot 4 nie posiada ConeMesh. CylinderMesh z górnym promieniem 0
	# tworzy zgodny z silnikiem stożek bez błędu parsera.
	var cone := CylinderMesh.new()
	cone.top_radius = 0.0
	cone.bottom_radius = radius
	cone.height = height
	cone.radial_segments = 12
	return cone


func _make_primitive(mesh: PrimitiveMesh, position: Vector3, mesh_scale: Vector3, color: Color) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	instance.mesh = mesh
	instance.position = position
	instance.scale = mesh_scale
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.68
	material.metallic = 0.04
	material.specular_mode = BaseMaterial3D.SPECULAR_SCHLICK_GGX
	material.clearcoat_enabled = false
	instance.material_override = material
	instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	return instance


func _build_start_line() -> void:
	var point: Vector3 = smooth_route[0]
	var tangent: Vector3 = get_tangent_at(0)
	var line := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = Vector3(track_width, 0.05, 0.35)
	line.mesh = mesh
	var material := StandardMaterial3D.new()
	material.albedo_color = Color("#18d8ee")
	material.emission_enabled = true
	material.emission = Color("#087d91")
	line.material_override = material
	line.position = point + Vector3.UP * 0.07
	line.rotation.y = atan2(-tangent.x, -tangent.z)
	add_child(line)

	# Bez strzałek na starcie: zostaje wyłącznie czytelna linia startowa.


func _make_floor_texture(variant: int, seed_value: int) -> Texture2D:
	# Małe tekstury generowane lokalnie — bez pobierania plików i bez zależności od sieci.
	# Każde losowanie trasy wybiera jeden z pięciu wzorów.
	var image := Image.create(128, 128, false, Image.FORMAT_RGBA8)
	var rng := RandomNumberGenerator.new()
	rng.seed = maxi(seed_value, 1) + variant * 7919
	var base_colors: Array[Color] = [Color("#c6b28e"), Color("#a77b55"), Color("#7d8790"), Color("#a6a8a2"), Color("#263b4a")]
	var base: Color = base_colors[posmod(variant, base_colors.size())]
	for y: int in range(128):
		for x: int in range(128):
			var color: Color = base
			var noise: float = rng.randf_range(-0.055, 0.055)
			if variant == 0: # płytki ceramiczne
				if x % 32 <= 1 or y % 32 <= 1:
					color = base.darkened(0.24)
				elif (x % 32 == 2 and y % 32 == 2):
					color = base.lightened(0.12)
			elif variant == 1: # panele drewniane
				if y % 24 <= 1 or (x + int(y / 24) * 17) % 64 <= 1:
					color = base.darkened(0.22)
				else:
					noise += 0.025 * sin(float(y) * 0.42 + float(x) * 0.08)
			elif variant == 2: # miękka wykładzina
				noise += 0.035 if (x * 13 + y * 7) % 5 == 0 else -0.01
			elif variant == 3: # beton / kamień
				if (x + y * 3) % 47 == 0:
					noise -= 0.12
			elif variant == 4: # futurystyczne panele
				if x % 32 <= 1 or y % 32 <= 1 or (x % 32 == 2 and y % 32 == 2):
					color = Color("#102b3b")
				elif x % 32 <= 3 or y % 32 <= 3:
					noise += 0.035
			color = Color(clampf(color.r + noise, 0.0, 1.0), clampf(color.g + noise, 0.0, 1.0), clampf(color.b + noise, 0.0, 1.0), 1.0)
			image.set_pixel(x, y, color)
	return ImageTexture.create_from_image(image)


func _theme_floor_color() -> Color:
	match str(generated_data.get("theme", "apartment")):
		"kitchen": return Color("#e8e2c8")
		"bedroom": return Color("#e2cfe3")
		"futuristic", "pro_league": return Color("#354b65")
		"office": return Color("#7b8791")
		_: return Color("#ead8b6")
