extends "res://scripts/tracks/ApartmentTrack.gd"
## PROTOTYP: NIE JEST ZAREJESTROWANY W TrackDatabase I NIE JEST GOTOWĄ TRASĄ.
## Wymaga przebudowy startu, przejezdności, ścian z otworami drzwiowymi i sufitów.
## Duża trasa pokazowa Robot Racing v0.3.
## Zachowuje dotychczasową trasę MIESZKANIE jako osobną pozycję w katalogu.
## Wykorzystuje istniejącą bibliotekę modeli bez modyfikowania jej zasobów.

const SHOWCASE_FLOOR_ZONES: Array[Dictionary] = [
	{"name": "PaneleSalon", "position": Vector3(-28.0, -0.006, 5.0), "size": Vector3(38.0, 0.028, 28.0), "color": Color("#9b704d"), "roughness": 0.72},
	{"name": "GresKuchnia", "position": Vector3(28.0, -0.006, 5.0), "size": Vector3(38.0, 0.028, 28.0), "color": Color("#aeb9c0"), "roughness": 0.42},
	{"name": "WykladzinaSypialnia", "position": Vector3(-25.0, -0.006, -26.0), "size": Vector3(42.0, 0.028, 22.0), "color": Color("#77788b"), "roughness": 1.0},
	{"name": "KamienLazienka", "position": Vector3(28.0, -0.006, -25.0), "size": Vector3(38.0, 0.028, 22.0), "color": Color("#777f86"), "roughness": 0.58}
]


func _get_default_route() -> Array[Vector3]:
	# Jedna ciągła pętla: długa prosta startowa, szybkie łuki,
	# ciasny nawrót i techniczna szykana. Geometria pozostaje na jednym poziomie,
	# ponieważ obecny TrackBase i nawigacja AI spłaszczają waypointy do Y=0.
	return [
		Vector3(-39.0, 0.0, 25.0),
		Vector3(-20.0, 0.0, 26.0),
		Vector3(0.0, 0.0, 26.0),
		Vector3(19.0, 0.0, 25.0),
		Vector3(33.0, 0.0, 21.0),
		Vector3(42.0, 0.0, 13.0),
		Vector3(44.0, 0.0, 4.0),
		Vector3(39.0, 0.0, -4.0),
		Vector3(29.0, 0.0, -7.0),
		Vector3(35.0, 0.0, -13.0),
		Vector3(27.0, 0.0, -19.0),
		Vector3(12.0, 0.0, -21.0),
		Vector3(-4.0, 0.0, -20.0),
		Vector3(-20.0, 0.0, -16.0),
		Vector3(-35.0, 0.0, -10.0),
		Vector3(-44.0, 0.0, -1.0),
		Vector3(-43.0, 0.0, 9.0),
		Vector3(-36.0, 0.0, 16.0),
		Vector3(-41.0, 0.0, 20.0)
	]


func _build_base() -> void:
	# Większa przestrzeń niż na podstawowej trasie. Okna i widok zewnętrzny
	# pozostają do osobnej iteracji, aby nie zmieniać istniejącej architektury.
	var floor_visual: MeshInstance3D = _box("PodlogaBazowaShowcase", Vector3(0.0, -0.3, 0.0), Vector3(110.0, 0.6, 90.0), FLOOR_COLOR)
	var floor_material := StandardMaterial3D.new()
	floor_material.albedo_color = FLOOR_COLOR
	floor_material.roughness = 0.9
	floor_visual.material_override = floor_material
	make_glossy(floor_material, 0.35)

	_box("ScianaPolnocShowcase", Vector3(0.0, 2.0, -45.0), Vector3(110.0, 4.0, 0.5), WALL_COLOR)
	_box("ScianaPoludnieShowcase", Vector3(0.0, 2.0, 45.0), Vector3(110.0, 4.0, 0.5), WALL_COLOR)
	_box("ScianaZachodShowcase", Vector3(-55.0, 2.0, 0.0), Vector3(0.5, 4.0, 90.0), WALL_COLOR)
	_box("ScianaWschodShowcase", Vector3(55.0, 2.0, 0.0), Vector3(0.5, 4.0, 90.0), WALL_COLOR)


func _build_apartment() -> void:
	super._build_apartment()
	_build_showcase_floor_zones()
	_build_showcase_decorations()
	_build_showcase_animals()


func _build_showcase_floor_zones() -> void:
	for zone: Dictionary in SHOWCASE_FLOOR_ZONES:
		var visual: MeshInstance3D = _box(
			str(zone["name"]),
			zone["position"],
			zone["size"],
			zone["color"],
			false,
			true,
			float(zone["roughness"])
		)
		visual.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


func _build_showcase_decorations() -> void:
	# Dodatkowe wyposażenie w wolnych strefach mieszkania. Modele pochodzą
	# z istniejącej wspólnej biblioteki i nie są kopiowane ani przerabiane.
	_add_room_model("RoslinaSalonShowcase", "plant", Vector3(-23.0, 0.0, 15.0), Vector3(1.2, 1.2, 1.2), true, Vector3(1.0, 1.8, 1.0), 1)
	_add_room_model("RegałPrzedpokojShowcase", "bookshelf", Vector3(-3.0, 0.0, 13.0), Vector3(1.2, 1.2, 1.2), true, Vector3(1.8, 2.4, 0.8), 2)
	_add_room_model("SzafkaPrzedpokojShowcase", "cabinet", Vector3(4.0, 0.0, 14.0), Vector3(1.0, 1.0, 1.0), true, Vector3(1.5, 1.5, 1.0), 1)
	_add_room_model("LegowiskoShowcase", "pet_bed", Vector3(-22.0, 0.0, -22.0), Vector3(1.2, 1.0, 1.2), false, Vector3.ONE, 2)
	_add_room_model("DrapakShowcase", "scratching_post", Vector3(-29.0, 0.0, -22.0), Vector3(1.0, 1.0, 1.0), true, Vector3(0.9, 1.8, 0.9), 1)
	_add_room_model("MiskaShowcase", "pet_bowl", Vector3(-18.0, 0.0, -22.0), Vector3(0.8, 0.8, 0.8), false)
	_add_room_model("PlecakShowcase", "backpack", Vector3(18.0, 0.0, -30.0), Vector3(1.0, 1.0, 1.0), false, Vector3.ONE, 2)
	_add_room_model("LampaShowcase", "lamp", Vector3(0.0, 0.0, 15.0), Vector3(1.0, 1.0, 1.0), false, Vector3.ONE, 1)
	_add_room_model("AkwariumShowcase", "fish_tank", Vector3(20.0, 0.0, 14.0), Vector3(1.1, 1.1, 1.1), true, Vector3(1.8, 1.5, 1.2), 0)
	_add_room_model("KabelShowcase", "cable", Vector3(0.0, 0.0, 10.0), Vector3(1.0, 1.0, 1.0), false, Vector3.ONE, 2)


func _build_showcase_animals() -> void:
	_add_showcase_animal("KotShowcase", "cat", Vector3(-22.0, 0.0, 17.0), 0, Vector3(1.1, 1.1, 1.1))
	_add_showcase_animal("PiesShowcase", "dog", Vector3(21.0, 0.0, 17.0), 1, Vector3(1.0, 1.0, 1.0))
	_add_showcase_animal("KrolikShowcase", "rabbit", Vector3(-25.0, 0.0, -32.0), 2, Vector3(1.0, 1.0, 1.0))
	_add_showcase_animal("AgamaShowcase", "bearded_dragon", Vector3(42.0, 0.0, -34.0), 0, Vector3(0.9, 0.9, 0.9))
	_add_showcase_animal("PapugaShowcase", "parrot", Vector3(8.0, 0.0, -34.0), 3, Vector3(1.0, 1.0, 1.0))


func _add_showcase_animal(animal_name: String, species: String, animal_position: Vector3, variant: int, model_scale: Vector3) -> void:
	var holder := Node3D.new()
	holder.name = animal_name
	holder.position = animal_position
	holder.set_script(load("res://scripts/tracks/TrackAnimal.gd") as Script)
	holder.set("species", species)
	holder.set("animate_in_place", true)
	var model: Node3D = TrackModelLibrary.make_animal(species, variant)
	model.scale = model_scale
	holder.add_child(model)
	add_child(holder)


func _build_lamps() -> void:
	super._build_lamps()
	add_lamp(Vector3(0.0, 3.6, 8.0), Color(1.0, 0.88, 0.72), 1.0, 14.0)
	add_lamp(Vector3(-28.0, 3.6, -22.0), Color(0.82, 0.88, 1.0), 0.9, 13.0)
	add_lamp(Vector3(30.0, 3.6, -24.0), Color(1.0, 0.88, 0.72), 0.95, 13.0)
