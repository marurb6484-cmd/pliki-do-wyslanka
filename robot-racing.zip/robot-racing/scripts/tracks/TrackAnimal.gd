extends Node3D
## Ruchome zwierzęta: patrol wzdłuż trasy oraz regularne przejścia przez jezdnię.
## Nie są blokowane przez bandy — mogą je przeskakiwać i wracać na zewnątrz.

@export var species: String = "cat"
@export var crossing_direction: Vector3 = Vector3.ZERO
@export var crossing_distance: float = 14.0
@export var animate_in_place: bool = false
var _origin: Vector3
var _phase: float = 0.0
var _hit_cooldowns: Dictionary = {}
var _base_y: float = 0.0
var _cross_direction: Vector3 = Vector3.ZERO
var _crossing_enabled: bool = false

func _ready() -> void:
	_origin = position
	_base_y = position.y
	_phase = float(get_instance_id() % 1000) * 0.013
	_cross_direction = crossing_direction
	_cross_direction.y = 0.0
	_crossing_enabled = _cross_direction.length_squared() > 0.001 and crossing_distance > 1.0
	if _crossing_enabled:
		_cross_direction = _cross_direction.normalized()
	var area := Area3D.new()
	area.name = "AnimalContact"
	area.collision_layer = 0
	area.collision_mask = 2
	area.monitoring = true
	area.monitorable = false
	var shape_node := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 1.3
	shape_node.shape = shape
	area.add_child(shape_node)
	add_child(area)
	area.body_entered.connect(_on_body_entered)

func _process(delta: float) -> void:
	_phase += delta
	var speed: float = _speed_for_species()
	var target: Vector3 = _origin
	var facing: Vector3 = Vector3.FORWARD
	var crossing_progress: float = 0.5
	if _crossing_enabled:
		# Ping-pong od miejsca startu po przeciwległy bok toru i z powrotem.
		crossing_progress = (sin(_phase * speed * 0.48 - PI * 0.5) + 1.0) * 0.5
		var progress: float = crossing_progress
		target += _cross_direction * crossing_distance * progress
		facing = _cross_direction * (1.0 if cos(_phase * speed * 0.48 - PI * 0.5) >= 0.0 else -1.0)
	elif not animate_in_place:
		target += Vector3(sin(_phase * 0.45) * 2.2, 0.0, cos(_phase * 0.45) * 1.2)
		facing = Vector3(cos(_phase * 0.45), 0.0, -sin(_phase * 0.45))
	
	# Gatunkowe różnice ruchu i skoków.
	var hop: float = 0.0
	match species:
		"cat":
			hop = pow(absf(sin(_phase * 3.1)), 10.0) * 0.42
		"dog":
			hop = pow(absf(sin(_phase * 2.2)), 8.0) * 0.22
		"rabbit":
			hop = pow(maxf(0.0, sin(_phase * 4.2)), 2.0) * 1.05
		"bearded_dragon":
			hop = pow(absf(sin(_phase * 1.4)), 12.0) * 0.12
		"parrot":
			hop = 0.55 + absf(sin(_phase * 2.1)) * 0.8
		"hamster":
			hop = pow(absf(sin(_phase * 3.8)), 8.0) * 0.18
		"guinea_pig":
			hop = pow(absf(sin(_phase * 1.9)), 8.0) * 0.10
		"turtle":
			hop = 0.0
		"hedgehog":
			hop = pow(absf(sin(_phase * 2.0)), 10.0) * 0.16
		"ferret":
			hop = pow(absf(sin(_phase * 3.0)), 8.0) * 0.30
	# Dodatkowy skok dokładnie przy obu bandach, gdy zwierzę wchodzi na tor
	# albo z niego zeskakuje. Szczyt skoku przypada tuż przy krawędzi.
	if _crossing_enabled:
		var left_edge_jump: float = 1.0 - clampf(absf(crossing_progress - 0.075) / 0.075, 0.0, 1.0)
		var right_edge_jump: float = 1.0 - clampf(absf(crossing_progress - 0.925) / 0.075, 0.0, 1.0)
		hop += maxf(left_edge_jump, right_edge_jump) * (0.85 if species != "rabbit" else 0.35)
	target.y = _base_y + hop
	
	# Pies może na chwilę zainteresować się robotem, ale wraca do korytarza.
	if species == "dog":
		var nearest: Robot = _nearest_robot(10.0)
		if nearest != null:
			var chase: Vector3 = nearest.global_position - global_position
			chase.y = 0.0
			if chase.length() > 0.1:
				facing = chase.normalized()
				var chase_target: Vector3 = global_position + facing * minf(1.4, chase.length())
				if _crossing_enabled:
					var from_origin: Vector3 = chase_target - _origin
					var along: float = clampf(from_origin.dot(_cross_direction), 0.0, crossing_distance)
					chase_target = _origin + _cross_direction * along
				target.x = chase_target.x
				target.z = chase_target.z
	
	var move_speed: float = _movement_speed()
	if not animate_in_place:
		position = position.move_toward(target, delta * move_speed)
	if facing.length_squared() > 0.001 and not animate_in_place:
		rotation.y = atan2(-facing.x, -facing.z)
	rotation.z = sin(_phase * 2.0) * (0.08 if species != "parrot" else 0.16)
	_animate_model_parts()


func _animate_model_parts() -> void:
	# Modele mają osobne pivoty głowy, ogona, łap i skrzydeł.
	# Animujemy je niezależnie od ruchu całego zwierzęcia, bez deformowania siatek.
	var model: Node3D = get_node_or_null("Model3D") as Node3D
	if model == null:
		return
	var gait: float = _phase * (5.2 if species == "rabbit" else 3.6 if species == "cat" else 2.8)
	var stride: float = sin(gait) * (0.34 if species != "bearded_dragon" else 0.12)
	for part_name: String in ["LegFL", "LegFR", "LegBL", "LegBR"]:
		var leg: Node3D = model.get_node_or_null(part_name) as Node3D
		if leg == null:
			continue
		var is_left: bool = part_name.ends_with("L")
		var is_front: bool = part_name.begins_with("LegF")
		leg.rotation.x = stride * (-1.0 if is_left != is_front else 1.0)
	var head: Node3D = model.get_node_or_null("Head") as Node3D
	if head != null:
		head.rotation.x = sin(_phase * 1.7) * 0.055
		head.rotation.y = sin(_phase * 0.9) * (0.10 if species != "parrot" else 0.18)
	var tail: Node3D = model.get_node_or_null("Tail") as Node3D
	if tail != null:
		tail.rotation.x = sin(_phase * 2.4) * 0.20
		tail.rotation.y = sin(_phase * 2.0) * 0.18
	for wing_name: String in ["WingL", "WingR"]:
		var wing: Node3D = model.get_node_or_null(wing_name) as Node3D
		if wing != null:
			wing.rotation.z = sin(_phase * 5.0) * 0.38 * (-1.0 if wing_name == "WingL" else 1.0)

func _nearest_robot(max_distance: float) -> Robot:
	var nearest: Robot = null
	var best: float = max_distance
	for candidate: Node in get_tree().get_nodes_in_group("racers"):
		if candidate is Robot:
			var distance: float = global_position.distance_to((candidate as Robot).global_position)
			if distance < best:
				best = distance
				nearest = candidate as Robot
	return nearest

func _movement_speed() -> float:
	match species:
		"cat": return 4.2
		"dog": return 3.2
		"rabbit": return 5.0
		"bearded_dragon": return 1.7
		"parrot": return 4.6
		"hamster": return 3.8
		"guinea_pig": return 2.2
		"turtle": return 0.9
		"hedgehog": return 2.0
		"ferret": return 4.4
	return 2.2

func _speed_for_species() -> float:
	match species:
		"cat": return 2.5
		"dog": return 1.55
		"rabbit": return 3.4
		"bearded_dragon": return 0.8
		"parrot": return 2.2
		"hamster": return 2.7
		"guinea_pig": return 1.0
		"turtle": return 0.55
		"hedgehog": return 1.1
		"ferret": return 2.8
	return 1.2

func _on_body_entered(body: Node3D) -> void:
	if not (body is Robot):
		return
	var robot := body as Robot
	var key := str(robot.get_instance_id())
	if float(_hit_cooldowns.get(key, 0.0)) > 0.0:
		return
	_hit_cooldowns[key] = 1.8
	var side := (robot.global_position - global_position).normalized()
	side.y = 0.0
	if side.length() < 0.1:
		side = Vector3.RIGHT
	match species:
		"cat":
			robot.velocity += side * 4.6
			robot.velocity *= 0.84
		"dog":
			robot.velocity *= 0.52
		"rabbit":
			robot.velocity += side * 2.8 + Vector3.UP * 1.2
		"bearded_dragon":
			robot.velocity *= 0.42
		"parrot":
			robot.velocity *= 0.72
			robot.rotate_y(0.28 if side.x >= 0.0 else -0.28)
		"hamster", "guinea_pig", "hedgehog":
			robot.velocity += side * 1.8
		"turtle":
			robot.velocity *= 0.88
		"ferret":
			robot.velocity += side * 3.0

func _physics_process(delta: float) -> void:
	for key: String in _hit_cooldowns.keys():
		_hit_cooldowns[key] = maxf(float(_hit_cooldowns[key]) - delta, 0.0)
