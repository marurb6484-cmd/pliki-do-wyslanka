class_name TrackBase
extends Node3D
## Bazowa klasa każdej trasy.
##
## Trasa dostarcza wszystkim systemom (wyścig, AI, brud, nawigacja, kamera):
##  - waypointy (Marker3D w węźle "Waypoints" - edytowalne w edytorze),
##  - wygładzoną linię trasy z długością, krzywizną i projekcją pozycji,
##  - pola startowe, punkty brudu, przeszkody,
##  - środowisko i oświetlenie reagujące na ustawienia graficzne,
##  - parametry wyścigu (okrążenia, odliczanie, szerokość toru).
##
## Nowa trasa = scena z korzeniem dziedziczącym po TrackBase, nadpisująca
## `_build_geometry()` (i opcjonalnie `_get_default_route()`).

signal track_built

@export_group("Wyścig")
@export var track_id: String = "track"
@export var display_name: String = "Trasa"
@export var default_laps: int = 3
@export var countdown_seconds: float = 5.0
@export var track_width: float = 1.2
@export var max_racers: int = 5

@export_group("Brud")
@export var dirt_pickup_count: int = 12
@export var dirt_respawn_time: float = 9.0

@export_group("Trasa")
@export var spline_steps: int = 6
@export var waypoints_path: NodePath = ^"Waypoints"

@export_group("Środowisko")
@export var background_color: Color = Color(0.55, 0.54, 0.51)
@export var ambient_color: Color = Color(0.85, 0.84, 0.80)
@export var ambient_energy: float = 0.85
@export var sun_color: Color = Color(1.0, 0.96, 0.89)
@export var sun_energy: float = 1.1
@export var sun_rotation_degrees: Vector3 = Vector3(-55, -25, 0)
@export var reflection_extents: Vector3 = Vector3(50, 4, 40)

## Punkty kontrolne trasy (globalne współrzędne).
var route: Array[Vector3] = []
## Wygładzona, zamknięta linia trasy (globalne współrzędne).
var smooth_route: PackedVector3Array = PackedVector3Array()
## Skumulowana odległość wzdłuż trasy dla każdego punktu smooth_route.
var route_cum: PackedFloat32Array = PackedFloat32Array()
## Krzywizna ze znakiem (dodatnia = zakręt w prawo) w każdym punkcie.
var route_curvature: PackedFloat32Array = PackedFloat32Array()
var route_length: float = 0.0
## Czy trasa tworzy pętlę. Odcinki mają osobny początek i koniec.
var route_closed: bool = true

## Przeszkody na torze: {"position", "radius", "distance", "lateral"}.
var obstacles: Array[Dictionary] = []

## Dane nawigacyjne dla minimapy (podłogi i przeszkody jako AABB).
var nav_floor_bounds: Array[AABB] = []
var nav_obstacle_bounds: Array[AABB] = []
var nav_floor_height: float = 0.0

var built: bool = false

var _world_environment: WorldEnvironment
var _environment: Environment
var _sun: DirectionalLight3D
var _reflection_probe: ReflectionProbe
var _lamps: Array[OmniLight3D] = []
var _glossy_materials: Array[StandardMaterial3D] = []
var _glossy_roughness: Dictionary = {}
var _material_cache: Dictionary = {}


func _ready() -> void:
	# Uruchomienie samej sceny trasy (F6) startuje normalny wyścig na tej trasie.
	if get_tree().current_scene == self:
		call_deferred("_launch_as_race")
		return
	build_track()


func _launch_as_race() -> void:
	var index: int = TrackDatabase.find_index_by_scene(scene_file_path)
	GameManager.configure_race(GameManager.GameMode.RACE, maxi(index, 0), default_laps, GameManager.difficulty, 4, false)
	GameManager.launch_race()


func build_track() -> void:
	if built:
		return

	_read_route()
	_compute_smooth_route()
	_build_environment()
	_build_geometry()
	_after_geometry()

	built = true
	apply_graphics()
	GameSettings.graphics_changed.connect(apply_graphics)
	track_built.emit()


func _exit_tree() -> void:
	if GameSettings.graphics_changed.is_connected(apply_graphics):
		GameSettings.graphics_changed.disconnect(apply_graphics)


# =========================================================
# METODY DO NADPISANIA PRZEZ KONKRETNĄ TRASĘ
# =========================================================

## Punkty trasy używane, gdy scena nie ma waypointów (Marker3D).
func _get_default_route() -> Array[Vector3]:
	return []


## Budowa geometrii: podłoga, ściany, tor, bandy, meble, przeszkody.
func _build_geometry() -> void:
	pass


## Wywoływane po geometrii (np. dodatkowe dekoracje).
func _after_geometry() -> void:
	pass


# =========================================================
# TRASA
# =========================================================

func _read_route() -> void:
	route.clear()
	var waypoint_root: Node = get_node_or_null(waypoints_path)

	if waypoint_root != null:
		for child: Node in waypoint_root.get_children():
			if child is Node3D:
				var point: Vector3 = (child as Node3D).global_position
				point.y = 0.0
				route.append(point)

	# Usuwamy zdublowany punkt mety (pierwszy == ostatni).
	if route.size() > 3 and route[0].distance_to(route[route.size() - 1]) < 1.0:
		route.remove_at(route.size() - 1)

	if route.size() < 3:
		route = _get_default_route()

	if route.size() < 3:
		push_error("TrackBase: trasa '%s' ma za mało waypointów." % track_id)


func _compute_smooth_route() -> void:
	smooth_route.clear()
	var count: int = route.size()
	if count < 3:
		return

	var steps: int = maxi(spline_steps, 1)
	var segment_count: int = count if route_closed else count - 1
	for i: int in range(segment_count):
		var p1: Vector3 = route[i]
		var p2: Vector3 = route[(i + 1) % count] if route_closed else route[i + 1]
		var p0: Vector3 = route[(i - 1 + count) % count] if route_closed or i > 0 else p1
		var p3: Vector3 = route[(i + 2) % count] if route_closed else route[mini(i + 2, count - 1)]

		for step: int in range(steps):
			var t: float = float(step) / float(steps)
			var t2: float = t * t
			var t3: float = t2 * t
			var point: Vector3 = 0.5 * (
				2.0 * p1
				+ (-p0 + p2) * t
				+ (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * t2
				+ (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * t3
			)
			smooth_route.append(point)
	if not route_closed:
		smooth_route.append(route[count - 1])

	var n: int = smooth_route.size()
	route_cum.resize(n + 1)
	route_cum[0] = 0.0
	var measured_segments: int = n if route_closed else n - 1
	for i: int in range(measured_segments):
		var a: Vector3 = smooth_route[i]
		var b: Vector3 = smooth_route[(i + 1) % n] if route_closed else smooth_route[i + 1]
		route_cum[i + 1] = route_cum[i] + Vector2(b.x - a.x, b.z - a.z).length()
	if not route_closed:
		route_cum[n] = route_cum[n - 1]
	route_length = route_cum[n]

	route_curvature.resize(n)
	for i: int in range(n):
		var prev: Vector3 = smooth_route[(i - 1 + n) % n] if route_closed or i > 0 else smooth_route[i]
		var cur: Vector3 = smooth_route[i]
		var nxt: Vector3 = smooth_route[(i + 1) % n] if route_closed or i < n - 1 else smooth_route[i]
		var d1 := Vector2(cur.x - prev.x, cur.z - prev.z)
		var d2 := Vector2(nxt.x - cur.x, nxt.z - cur.z)
		var length: float = (d1.length() + d2.length()) * 0.5
		if length < 0.001:
			route_curvature[i] = 0.0
			continue
		var angle: float = atan2(d1.x * d2.y - d1.y * d2.x, d1.dot(d2))
		route_curvature[i] = angle / length


## Wektor "w prawo" (prostopadły do kierunku jazdy) w punkcie smooth_route.
func get_side_at_index(index: int) -> Vector3:
	var n: int = smooth_route.size()
	var previous: Vector3 = smooth_route[(index - 1 + n) % n] if route_closed or index > 0 else smooth_route[index]
	var following: Vector3 = smooth_route[(index + 1) % n] if route_closed or index < n - 1 else smooth_route[index]
	var direction: Vector3 = following - previous
	direction.y = 0.0
	if direction.length() < 0.001:
		return Vector3.RIGHT
	direction = direction.normalized()
	return Vector3(-direction.z, 0.0, direction.x)


func wrap_distance(distance: float) -> float:
	if route_length <= 0.0:
		return 0.0
	return fposmod(distance, route_length) if route_closed else clampf(distance, 0.0, route_length)


func _index_at_distance(distance: float) -> int:
	var d: float = wrap_distance(distance)
	var low: int = 0
	var high: int = smooth_route.size() - 1 if route_closed else smooth_route.size() - 2
	while low < high:
		var middle: int = (low + high + 1) / 2
		if route_cum[middle] <= d:
			low = middle
		else:
			high = middle - 1
	return low


func get_point_at(distance: float) -> Vector3:
	var n: int = smooth_route.size()
	if n == 0:
		return Vector3.ZERO
	var d: float = wrap_distance(distance)
	var i: int = _index_at_distance(d)
	var segment: float = maxf(route_cum[i + 1] - route_cum[i], 0.0001)
	var t: float = clampf((d - route_cum[i]) / segment, 0.0, 1.0)
	var next_index: int = (i + 1) % n if route_closed else mini(i + 1, n - 1)
	return smooth_route[i].lerp(smooth_route[next_index], t)


func get_tangent_at(distance: float) -> Vector3:
	var n: int = smooth_route.size()
	if n == 0:
		return Vector3.FORWARD
	var i: int = _index_at_distance(distance)
	var next_index: int = (i + 1) % n if route_closed else mini(i + 1, n - 1)
	var direction: Vector3 = smooth_route[next_index] - smooth_route[i]
	direction.y = 0.0
	return direction.normalized() if direction.length() > 0.001 else Vector3.FORWARD


func get_side_at(distance: float) -> Vector3:
	var tangent: Vector3 = get_tangent_at(distance)
	return Vector3(-tangent.z, 0.0, tangent.x)


func get_curvature_at(distance: float) -> float:
	if route_curvature.is_empty():
		return 0.0
	var n: int = smooth_route.size()
	var d: float = wrap_distance(distance)
	var i: int = _index_at_distance(d)
	var segment: float = maxf(route_cum[i + 1] - route_cum[i], 0.0001)
	var t: float = clampf((d - route_cum[i]) / segment, 0.0, 1.0)
	return lerpf(route_curvature[i], route_curvature[(i + 1) % n], t)


## Rzutuje pozycję na linię trasy.
## Zwraca: index (segment), distance (wzdłuż trasy), lateral (+ = prawo), point.
## `hint` pozwala przeszukać tylko okolicę ostatniej znanej pozycji (szybko).
func project_point(world_position: Vector3, hint: int = -1) -> Dictionary:
	var n: int = smooth_route.size()
	var result: Dictionary = {"index": 0, "distance": 0.0, "lateral": 0.0, "point": Vector3.ZERO, "offset": INF}
	if n < 2:
		return result

	var last_segment: int = n - 1 if route_closed else n - 2
	var best: Dictionary = _search_segments(world_position, hint - 6, hint + 14) if hint >= 0 else _search_segments(world_position, 0, last_segment)
	if hint >= 0 and float(best["offset"]) > track_width * 0.9:
		best = _search_segments(world_position, 0, last_segment)
	return best


func _search_segments(world_position: Vector3, from_index: int, to_index: int) -> Dictionary:
	var n: int = smooth_route.size()
	var position_2d := Vector2(world_position.x, world_position.z)
	var best_index: int = 0
	var best_t: float = 0.0
	var best_d2: float = INF

	for k: int in range(from_index, to_index + 1):
		var i: int = wrapi(k, 0, n) if route_closed else clampi(k, 0, n - 2)
		var a3: Vector3 = smooth_route[i]
		var b3: Vector3 = smooth_route[(i + 1) % n] if route_closed else smooth_route[i + 1]
		var a := Vector2(a3.x, a3.z)
		var segment := Vector2(b3.x, b3.z) - a
		var length_sq: float = segment.length_squared()
		var t: float = 0.0
		if length_sq > 0.000001:
			t = clampf((position_2d - a).dot(segment) / length_sq, 0.0, 1.0)
		var d2: float = position_2d.distance_squared_to(a + segment * t)
		if d2 < best_d2:
			best_d2 = d2
			best_index = i
			best_t = t

	var p_a: Vector3 = smooth_route[best_index]
	var p_b: Vector3 = smooth_route[(best_index + 1) % n] if route_closed else smooth_route[best_index + 1]
	var closest: Vector3 = p_a.lerp(p_b, best_t)
	var direction: Vector3 = p_b - p_a
	direction.y = 0.0
	direction = direction.normalized() if direction.length() > 0.0001 else Vector3.FORWARD
	var side := Vector3(-direction.z, 0.0, direction.x)
	var offset_vector: Vector3 = world_position - closest
	offset_vector.y = 0.0

	return {
		"index": best_index,
		"distance": route_cum[best_index] + (route_cum[best_index + 1] - route_cum[best_index]) * best_t,
		"lateral": offset_vector.dot(side),
		"point": closest,
		"offset": sqrt(best_d2)
	}


# =========================================================
# START, BRUD, PRZESZKODY
# =========================================================

## Pola startowe za linią startu (dwie kolumny, układ "w jodełkę").
func get_start_transform(slot: int) -> Transform3D:
	var start: Vector3 = get_point_at(0.0)
	var forward: Vector3 = get_tangent_at(0.0)
	var side: Vector3 = Vector3(-forward.z, 0.0, forward.x)

	var row: int = slot / 2
	var column: int = slot % 2
	var lateral: float = -0.24 if column == 0 else 0.24
	var back: float = 0.65 + row * 0.62 + column * 0.22

	var position: Vector3 = start - forward * back + side * lateral
	position.y = 0.06

	var basis := Basis.looking_at(forward, Vector3.UP)
	return Transform3D(basis, position)


## Punkty, w których pojawia się brud. Trasa może nadpisać tę metodę albo
## umieścić Marker3D w grupie "dirt_spawn".
func get_dirt_spawn_points() -> Array[Vector3]:
	var points: Array[Vector3] = []

	for node: Node in get_tree().get_nodes_in_group("dirt_spawn"):
		if node is Node3D and is_ancestor_of(node):
			points.append((node as Node3D).global_position)

	if not points.is_empty() or route_length <= 0.0:
		return points

	var rng := RandomNumberGenerator.new()
	rng.randomize()
	var count: int = maxi(dirt_pickup_count, 0)
	var minimum_gap: float = maxf(0.85, route_length / float(maxi(count, 1)) * 0.42)
	for i: int in range(count):
		var candidate: Vector3 = Vector3.ZERO
		var accepted: bool = false
		for attempt: int in range(36):
			# Losowe położenie wzdłuż trasy i w poprzek jezdni. Pomijamy strefę startową.
			var distance_min: float = minf(3.0, route_length * 0.15)
			var distance_max: float = maxf(distance_min + 0.5, route_length - 2.0)
			var distance: float = rng.randf_range(distance_min, distance_max)
			var lateral: float = rng.randf_range(-track_width * 0.34, track_width * 0.34)
			candidate = get_point_at(distance) + get_side_at(distance) * lateral
			var clear: bool = true
			for existing: Vector3 in points:
				if Vector2(candidate.x - existing.x, candidate.z - existing.z).length() < minimum_gap:
					clear = false
					break
			if not clear:
				continue
			for obstacle: Dictionary in obstacles:
				var obstacle_position: Vector3 = obstacle.get("position", Vector3.ZERO)
				if Vector2(candidate.x - obstacle_position.x, candidate.z - obstacle_position.z).length() < float(obstacle.get("radius", 0.5)) + 0.22:
					clear = false
					break
			if clear:
				accepted = true
				break
		if not accepted:
			var fallback_distance: float = lerpf(minf(3.0, route_length * 0.15), maxf(3.5, route_length - 2.0), float(i + 1) / float(count + 1))
			candidate = get_point_at(fallback_distance) + get_side_at(fallback_distance) * rng.randf_range(-track_width * 0.25, track_width * 0.25)
		candidate.y = 0.08
		points.append(candidate)

	return points


## Rejestruje przeszkodę na torze (AI planuje omijanie, dane trafiają też na minimapę).
func register_obstacle(world_position: Vector3, radius: float) -> void:
	var projection: Dictionary = project_point(world_position)
	obstacles.append({
		"position": world_position,
		"radius": radius,
		"distance": float(projection["distance"]),
		"lateral": float(projection["lateral"])
	})


# =========================================================
# DANE DLA MINIMAPY
# =========================================================

## Jeśli trasa nie dostarczyła danych nawigacyjnych, skanujemy geometrię
## (uniwersalny algorytm z poprzedniej wersji NavigationHUD).
func ensure_nav_data() -> void:
	if not nav_floor_bounds.is_empty():
		return

	var meshes: Array[MeshInstance3D] = []
	_collect_meshes(self, meshes)
	var lowest: float = INF

	for mesh_instance: MeshInstance3D in meshes:
		var bounds: AABB = mesh_instance.global_transform * mesh_instance.get_aabb()
		var top: float = bounds.end.y
		if bounds.size.y <= 0.25 and bounds.size.x >= 1.0 and bounds.size.z >= 1.0 and top > -0.5 and top < 1.0:
			nav_floor_bounds.append(bounds)
			lowest = minf(lowest, top)
		elif bounds.size.y > 0.25:
			nav_obstacle_bounds.append(bounds)

	nav_floor_height = 0.0 if lowest == INF else lowest


func _collect_meshes(node: Node, result: Array[MeshInstance3D]) -> void:
	if node is MeshInstance3D:
		result.append(node as MeshInstance3D)
	for child: Node in node.get_children():
		_collect_meshes(child, result)


# =========================================================
# ŚRODOWISKO I GRAFIKA
# =========================================================

func _build_environment() -> void:
	_environment = Environment.new()
	_environment.background_mode = Environment.BG_COLOR
	_environment.background_color = background_color
	_environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	_environment.ambient_light_color = ambient_color
	_environment.ambient_light_energy = ambient_energy
	_environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	_environment.glow_intensity = 0.6
	_environment.glow_bloom = 0.05
	_environment.glow_hdr_threshold = 1.1

	_world_environment = WorldEnvironment.new()
	_world_environment.name = "WorldEnvironment"
	_world_environment.environment = _environment
	add_child(_world_environment)

	_sun = DirectionalLight3D.new()
	_sun.name = "Sun"
	_sun.rotation_degrees = sun_rotation_degrees
	_sun.light_color = sun_color
	_sun.light_energy = sun_energy
	_sun.shadow_bias = 0.06
	_sun.shadow_blur = 1.0
	add_child(_sun)

	_reflection_probe = ReflectionProbe.new()
	_reflection_probe.name = "ReflectionProbe"
	_reflection_probe.size = reflection_extents * 2.0
	_reflection_probe.position = Vector3(0, reflection_extents.y * 0.5, 0)
	_reflection_probe.update_mode = ReflectionProbe.UPDATE_ONCE
	_reflection_probe.interior = true
	_reflection_probe.box_projection = true
	_reflection_probe.max_distance = 120.0
	_reflection_probe.visible = false
	add_child(_reflection_probe)


## Lampa sufitowa - aktywna od jakości WYSOKIEJ.
func add_lamp(world_position: Vector3, color: Color, energy: float, light_range: float) -> void:
	var lamp := OmniLight3D.new()
	lamp.position = world_position
	lamp.light_color = color
	lamp.light_energy = energy
	lamp.omni_range = light_range
	lamp.omni_attenuation = 1.4
	lamp.shadow_enabled = false
	add_child(lamp)
	_lamps.append(lamp)


## Materiał, który zyskuje połysk przy włączonych odbiciach.
func make_glossy(material: StandardMaterial3D, glossy_roughness: float) -> void:
	_glossy_materials.append(material)
	_glossy_roughness[material.get_instance_id()] = Vector2(material.roughness, glossy_roughness)


## Wspólny materiał dla danego koloru (mniej zasobów, mniej zmian stanu GPU).
func get_material(color: Color, roughness: float = 0.85, metallic: float = 0.0) -> StandardMaterial3D:
	var key: String = "%s_%.2f_%.2f" % [color.to_html(), roughness, metallic]
	if _material_cache.has(key):
		return _material_cache[key]
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = roughness
	material.metallic = metallic
	_material_cache[key] = material
	return material


func apply_graphics() -> void:
	if _environment == null:
		return

	var quality: int = GameSettings.quality

	_environment.glow_enabled = GameSettings.glow_allowed()
	_environment.fog_enabled = GameSettings.depth_fog_allowed()
	_environment.fog_light_color = background_color
	_environment.fog_density = 0.0025
	_environment.ssao_enabled = GameSettings.ssao_allowed()
	_environment.ssil_enabled = GameSettings.ssil_allowed()
	_environment.ssr_enabled = GameSettings.ssr_allowed()
	_environment.sdfgi_enabled = GameSettings.sdfgi_allowed()
	_environment.volumetric_fog_enabled = GameSettings.volumetric_fog_allowed()
	_environment.ssr_max_steps = 64 if quality == GameSettings.Quality.ULTRA else 32
	_environment.ambient_light_energy = ambient_energy + (0.1 if quality == GameSettings.Quality.LOW else 0.0)

	_sun.shadow_enabled = GameSettings.shadows_enabled
	_sun.directional_shadow_max_distance = GameSettings.get_shadow_distance()
	match quality:
		GameSettings.Quality.LOW:
			_sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
		GameSettings.Quality.MEDIUM, GameSettings.Quality.HIGH:
			_sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
		_:
			_sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS

	var lamps_on: bool = quality >= GameSettings.Quality.HIGH
	for lamp: OmniLight3D in _lamps:
		lamp.visible = lamps_on
		lamp.shadow_enabled = false

	var probe_on: bool = GameSettings.reflection_probe_allowed()
	if _reflection_probe.visible != probe_on:
		_reflection_probe.visible = probe_on
	# Na Mobile używamy statycznego capture; UPDATE_ALWAYS byłoby kosztowne na GPU telefonu.
	_reflection_probe.update_mode = ReflectionProbe.UPDATE_ALWAYS if probe_on and quality == GameSettings.Quality.ULTRA and GameSettings.is_forward_plus() else ReflectionProbe.UPDATE_ONCE

	for material: StandardMaterial3D in _glossy_materials:
		var values: Vector2 = _glossy_roughness.get(material.get_instance_id(), Vector2(material.roughness, material.roughness))
		material.roughness = values.y if GameSettings.reflections_enabled else values.x
