extends RigidBody3D
## Meble i rekwizyty są fizycznymi bryłami: pozostają stabilne na starcie,
## ale po uderzeniu robota odmarzają, odpychają się i mogą zostać zniszczone.

@export var durability: float = 85.0
@export var collision_damage: float = 6.0
@export var hitbox_size: Vector3 = Vector3(1.5, 1.35, 1.3)
@export var movable: bool = false

var remaining_durability: float = 85.0
var _robot_cooldowns: Dictionary = {}
var _base_scale: Vector3 = Vector3.ONE
var _feedback_tween: Tween
var _breaking: bool = false


func _ready() -> void:
	remaining_durability = maxf(durability, 1.0)
	_base_scale = scale
	collision_layer = Robot.LAYER_WORLD
	collision_mask = Robot.LAYER_ROBOTS | Robot.LAYER_WORLD
	contact_monitor = true
	max_contacts_reported = 8
	continuous_cd = true
	mass = clampf(hitbox_size.x * hitbox_size.z * 4.0, 1.0, 18.0) if movable else 12.0
	linear_damp = 0.65 if movable else 2.8
	angular_damp = 1.2 if movable else 5.0
	can_sleep = true
	var surface := PhysicsMaterial.new()
	surface.friction = 0.38 if movable else 0.82
	surface.bounce = 0.16
	physics_material_override = surface
	# Wszystkie dekoracje pozostają nieruchome po utworzeniu trasy.
	# Obiekty oznaczone jako movable zostaną odmrożone dopiero po uderzeniu
	# robota w receive_robot_impact(); zapobiega to opadaniu/przemieszczaniu
	# umeblowania podczas budowania sceny i przed rozpoczęciem wyścigu.
	freeze = true
	freeze_mode = RigidBody3D.FREEZE_MODE_STATIC
	if movable:
		can_sleep = true
		sleeping = true
		lock_rotation = false
	var collision := CollisionShape3D.new()
	collision.name = "FizycznaKolizjaPrzedmiotu"
	var shape := BoxShape3D.new()
	shape.size = Vector3(maxf(hitbox_size.x, 0.25), maxf(hitbox_size.y, 0.25), maxf(hitbox_size.z, 0.25))
	collision.shape = shape
	collision.position.y = shape.size.y * 0.5
	add_child(collision)
	body_entered.connect(_on_body_entered)


func _physics_process(delta: float) -> void:
	for key: String in _robot_cooldowns.keys():
		_robot_cooldowns[key] = maxf(float(_robot_cooldowns[key]) - delta, 0.0)


func _on_body_entered(body: Node) -> void:
	if body is Robot:
		var robot := body as Robot
		var speed: float = Vector2(robot.velocity.x, robot.velocity.z).length()
		receive_robot_impact(robot, robot.velocity, speed, global_position)


## Wywoływane również bezpośrednio z Robot._handle_collisions, ponieważ
## CharacterBody3D nie nadaje automatycznie wystarczającego impulsu RigidBody3D.
func receive_robot_impact(robot: Robot, incoming_velocity: Vector3, impact_speed: float, hit_position: Vector3) -> void:
	if _breaking or not movable or not is_instance_valid(robot):
		return
	if freeze:
		freeze = false
		can_sleep = false
		sleeping = false
	var robot_key: String = str(robot.get_instance_id())
	if float(_robot_cooldowns.get(robot_key, 0.0)) > 0.0:
		return
	_robot_cooldowns[robot_key] = 0.42
	remaining_durability = maxf(remaining_durability - 24.0 * clampf(impact_speed / 10.0, 0.35, 1.5), 0.0)
	var push_direction: Vector3 = incoming_velocity
	push_direction.y = 0.0
	if push_direction.length_squared() < 0.04:
		push_direction = hit_position - global_position
		push_direction.y = 0.0
	if push_direction.length_squared() < 0.001:
		push_direction = Vector3.FORWARD
	push_direction = push_direction.normalized()
	# Mocny, widoczny odrzut; impuls jest niezależny od solvera CharacterBody3D.
	var impulse_strength: float = clampf(8.0 + impact_speed * 1.65, 9.0, 26.0)
	var shove: Vector3 = push_direction * impulse_strength + Vector3.UP * 0.65
	apply_central_impulse(shove)
	# Dodatkowe nadanie prędkości zabezpiecza małe przedmioty przed
	# pozostaniem w miejscu przy kolizji CharacterBody3D z RigidBody3D.
	linear_velocity += push_direction * clampf(2.8 + impact_speed * 0.38, 3.5, 9.0)
	sleeping = false
	apply_torque_impulse(Vector3(randf_range(-1.0, 1.0), randf_range(-1.6, 1.6), randf_range(-1.0, 1.0)))
	if remaining_durability <= 0.0:
		_break_object()
	else:
		_play_hit_feedback()

func _play_hit_feedback() -> void:
	if movable:
		return
	if _feedback_tween != null and _feedback_tween.is_running():
		_feedback_tween.kill()
	scale = _base_scale
	_feedback_tween = create_tween()
	_feedback_tween.tween_property(self, "scale", _base_scale * 0.92, 0.07)
	_feedback_tween.tween_property(self, "scale", _base_scale, 0.12)


func _break_object() -> void:
	_breaking = true
	freeze = true
	collision_layer = 0
	collision_mask = 0
	var tween := create_tween()
	tween.tween_property(self, "scale", _base_scale * 0.08, 0.16)
	tween.parallel().tween_property(self, "position:y", position.y + 0.18, 0.16)
	tween.tween_callback(queue_free)
