class_name TrackGenerator
extends RefCounted
## Deterministyczny generator pętli i otwartych odcinków. Ten sam seed i parametry dają
## ten sam układ; wygenerowana trasa może zostać zapisana i odtworzona.

const PROCEDURAL_SCENE: String = "res://scenes/TrackProcedural.tscn"

static func generate(seed_value: int, size_level: int = 1, complexity: int = 2, obstacle_density: int = 1, theme: String = "apartment", custom_name: String = "", animal_count: int = 5, furniture_density: int = 2, obstacle_layout: int = 0, route_type: String = "lap", forced_route_style: int = -1) -> Dictionary:
	var rng := RandomNumberGenerator.new()
	rng.seed = maxi(seed_value, 1)
	var size_value: int = clampi(size_level, 0, 5)
	var complexity_value: int = clampi(complexity, 1, 5)
	var density: int = clampi(obstacle_density, 0, 5)
	var furniture_level: int = maxi(clampi(furniture_density, 0, 4), 2)
	var obstacle_layout_value: int = clampi(obstacle_layout, 0, 2)
	# Sześć swobodnych poziomów skali: od mieszkania po dużą halę.
	# Metraż jest orientacyjny — kształt i proporcje trasy mają pierwszeństwo.
	var scale_factor: float = [0.045, 0.073, 0.102, 0.147, 0.178, 0.210][size_value]
	var gate_half_width: float = maxf(track_width_for_size(size_value) * 0.78, 3.5)
	var start_left := Vector2(-gate_half_width, -30.0 * scale_factor)
	var start_right := Vector2(gate_half_width, -30.0 * scale_factor)
	var route: Array[Vector3] = []
	var minimum_clearance: float = track_width_for_size(size_value) + 0.35
	var attempts: int = 0
	var used_fallback: bool = false
	while attempts < 150:
		attempts += 1
		# Punkty generatora tworzą nieregularną łamaną z prostymi odcinkami.
		# Nie dodajemy drugiego punktu na każdym segmencie: poprzednia wersja
		# przekraczała limit 36 punktów walidatora i blokowała generowanie.
		var candidate: Array[Vector3] = _make_random_route(rng, complexity_value, size_value, scale_factor, start_left, start_right, forced_route_style)
		if _route_has_safe_clearance(candidate, minimum_clearance, complexity_value >= 5):
			route = candidate
			break
	if route.is_empty():
		# Awaryjny wariant również zależy od seeda i poziomu złożoności.
		# Nie może zamieniać każdego nieudanego losowania w identyczny tor.
		used_fallback = true
		route = _make_fallback_route(scale_factor, rng, complexity_value, gate_half_width, size_value, forced_route_style)
	var route_is_closed: bool = route_type != "segment"
	if not route_is_closed:
		# Odcinek wykorzystuje długi, niezamknięty fragment wylosowanej geometrii.
		# Początek i koniec pozostają różnymi punktami, bez sztucznego łączenia.
		var keep_count: int = clampi(int(round(float(route.size()) * 0.72)), 8, route.size() - 1)
		while route.size() > keep_count:
			route.pop_back()
	var point_count: int = route.size()

	var obstacles: Array[Vector3] = []
	var obstacle_count: int = density * (5 + complexity_value * 2)
	var track_width: float = track_width_for_size(size_value)
	var route_bounds: Dictionary = _route_room_bounds(route)
	var room_layout: Dictionary = _generate_room_layout(route_bounds, rng, complexity_value, theme)
	for obstacle_index: int in range(obstacle_count):
		var route_index: int = 2 + int(round(float(obstacle_index + 1) * float(route.size() - 4) / float(obstacle_count + 1)))
		route_index = clampi(route_index, 1, route.size() - 2)
		var next_index: int = (route_index + 1) % route.size()
		var midpoint: Vector3 = (route[route_index] + route[next_index]) * 0.5
		var tangent: Vector3 = (route[next_index] - route[route_index]).normalized()
		var side: Vector3 = Vector3(-tangent.z, 0.0, tangent.x)
		# Przeszkody są elementami pobocza: ich kolizje nie mogą wchodzić
		# w pas jazdy między dwiema liniami krawędziowymi.
		var obstacle_radius: float = [0.16, 0.19, 0.23, 0.27][obstacle_index % 4]
		var lateral_base: float = track_width * 0.5 + obstacle_radius + 0.38
		var lateral_variation: float = rng.randf_range(0.0, 0.45) if obstacle_layout_value == 1 else (0.16 if obstacle_layout_value == 2 else 0.0)
		var lateral: float = (lateral_base + lateral_variation) * (-1.0 if obstacle_index % 2 == 0 else 1.0)
		var longitudinal: float = rng.randf_range(-0.55, 0.55) if obstacle_layout_value != 2 else rng.randf_range(-0.30, 0.30)
		obstacles.append(midpoint + side * lateral + tangent * longitudinal)

	var decorations: Array[Dictionary] = []
	var decoration_kinds: Array[String] = ["plant", "sofa", "table", "lamp", "toy", "fish_tank", "bookshelf", "box", "pillow", "chair", "bed", "cabinet", "pet_bowl", "robot_toy", "rug", "tv", "scratching_post", "pet_bed", "shoe", "sock", "mug", "book", "remote", "tennis_ball", "yarn", "paper_scrap", "food_scraps", "cable", "backpack", "fridge", "bathtub", "sink", "kitchen_counter", "trash_bin", "floor_fan", "speaker", "game_console", "laptop", "monitor", "microwave", "toaster", "kettle", "fruit_bowl", "dish_rack", "washing_machine", "toilet", "shower", "radiator", "coat_rack", "umbrella_stand", "suitcase", "toy_car", "pet_tunnel", "water_dispenser", "vase", "candle", "towel_rack"]
	var animal_kinds: Array[String] = ["cat", "dog", "rabbit", "bearded_dragon", "parrot", "hamster", "guinea_pig", "turtle", "hedgehog", "ferret"]
	var small_extra_kinds: Array[String] = ["toy", "box", "shoe", "sock", "mug", "book", "remote", "tennis_ball", "yarn", "paper_scrap", "food_scraps", "cable", "pillow", "pet_bowl", "robot_toy"]
	var requested_animals: int = clampi(animal_count, 0, animal_kinds.size())
	var placed_animal_count: int = 0
	var animal_order: Array[String] = animal_kinds.duplicate()
	for i: int in range(animal_order.size()):
		var swap_index: int = rng.randi_range(i, animal_order.size() - 1)
		var swap_value: String = animal_order[i]
		animal_order[i] = animal_order[swap_index]
		animal_order[swap_index] = swap_value
	# Zagęszczenie umeblowania jest osobnym parametrem generatora.
	# Każdy poziom zwiększa liczbę dużych, czytelnych elementów otoczenia,
	# a pozostałe miejsca uzupełniają mniejsze przedmioty z biblioteki.
	var core_furniture: Array[String] = _furniture_set_for_theme(theme)
	var furniture_count: int = [12, 30, 48, 64, 80][furniture_level]
	var decoration_target: int = 60 + furniture_level * 32 + complexity_value * 12
	var decoration_count: int = clampi(maxi(decoration_target, requested_animals + furniture_count), requested_animals + 5, 220)
	for decoration_index: int in range(decoration_count):
		var route_index: int = rng.randi_range(3, route.size() - 2)
		var route_point: Vector3 = route[route_index]
		var next_point: Vector3 = route[(route_index + 1) % route.size()]
		var tangent: Vector3 = (next_point - route_point).normalized()
		var side: Vector3 = Vector3(-tangent.z, 0.0, tangent.x)
		var side_sign: float = -1.0 if rng.randf() < 0.5 else 1.0
		var is_furniture_slot: bool = decoration_index < furniture_count
		var is_animal_slot: bool = decoration_index >= furniture_count and decoration_index < furniture_count + requested_animals
		var decoration_kind: String = ""
		if is_furniture_slot:
			decoration_kind = core_furniture[posmod(decoration_index, core_furniture.size())]
		elif is_animal_slot:
			decoration_kind = animal_order[decoration_index - furniture_count]
		else:
			decoration_kind = decoration_kinds[rng.randi_range(0, decoration_kinds.size() - 1)]
		# Najpierw generator rozmieszcza duże meble, potem zwierzęta i drobne rekwizyty.
		# Żaden mały przedmiot nie jest umieszczany na jezdni. Drobiazgi leżą tuż
		# za krawędzią toru, aby były widoczne i osiągalne, ale nie blokowały jazdy.
		var is_small_extra: bool = not is_animal_slot and small_extra_kinds.has(decoration_kind)
		var place_on_track: bool = false
		var distance_from_track: float = track_width * 0.5 + (rng.randf_range(0.28, 0.72) if is_small_extra else (rng.randf_range(0.55, 1.0) if is_animal_slot else rng.randf_range(0.65, 1.2) + _furniture_clearance_for_kind(decoration_kind)))
		var position: Vector3 = route_point + side * side_sign * distance_from_track + tangent * rng.randf_range(-0.65, 0.65)
		var required_track_gap: float = track_width * 0.5 + maxf(0.55, _furniture_spacing_for_kind(decoration_kind) * 0.32)
		# Ograniczamy nakładanie się mebli i zwierząt. Jeśli losowanie trafi
		# zbyt blisko istniejącego obiektu, próbujemy kolejnych punktów trasy.
		var placement_attempt: int = 0
		while placement_attempt < 28 and (_distance_to_route_xz(position, route, route_is_closed) < required_track_gap or not _decoration_position_is_clear(decorations, position, 1.65 if not is_animal_slot else 1.20, decoration_kind) or not _position_clear_of_room_walls(position, room_layout, _furniture_spacing_for_kind(decoration_kind) * 0.5 + 0.18)):
			route_index = rng.randi_range(3, route.size() - 2)
			route_point = route[route_index]
			next_point = route[(route_index + 1) % route.size()]
			tangent = (next_point - route_point).normalized()
			side = Vector3(-tangent.z, 0.0, tangent.x)
			side_sign = -1.0 if rng.randf() < 0.5 else 1.0
			distance_from_track = track_width * 0.5 + (rng.randf_range(0.28, 0.72) if is_small_extra else (rng.randf_range(0.55, 1.0) if is_animal_slot else rng.randf_range(0.65, 1.2) + _furniture_clearance_for_kind(decoration_kind)))
			position = route_point + side * side_sign * distance_from_track + tangent * rng.randf_range(-0.65, 0.65)
			place_on_track = false
			placement_attempt += 1
		if _distance_to_route_xz(position, route, route_is_closed) < required_track_gap:
			continue
		if not _decoration_position_is_clear(decorations, position, 1.65 if not is_animal_slot else 1.20, decoration_kind):
			continue
		if not _position_clear_of_room_walls(position, room_layout, _furniture_spacing_for_kind(decoration_kind) * 0.5 + 0.18):
			continue
		var animal_crossing: Vector3 = -side * side_sign if is_animal_slot else Vector3.ZERO
		var animal_crossing_distance: float = track_width_for_size(size_value) + rng.randf_range(0.8, 1.4) if is_animal_slot else 0.0
		decorations.append({"kind": decoration_kind, "position": position, "rotation": rng.randf_range(0.0, TAU), "variant": rng.randi_range(0, 3), "scale": rng.randf_range(0.72, 0.88) if is_small_extra else (rng.randf_range(0.90, 1.05) if not is_animal_slot else rng.randf_range(0.95, 1.15)), "animal_behavior": _animal_behavior_for(decoration_kind) if animal_kinds.has(decoration_kind) else "", "animal_crossing_direction": animal_crossing, "animal_crossing_distance": animal_crossing_distance, "destructible": not animal_kinds.has(decoration_kind), "on_track": place_on_track})
		if is_animal_slot:
			placed_animal_count += 1

	# Drobne rekwizyty są generowane wyłącznie poza krawędzią jezdni.


	# Dodatkowe zagospodarowanie sztucznie utworzonych pokoi poza jezdnią.
	# Rozmieszczamy meble na obrzeżach planszy, z kontrolą odległości od toru.
	var room_furniture: Array[String] = _room_furniture_for_theme(theme)
	var min_x: float = INF
	var max_x: float = -INF
	var min_z: float = INF
	var max_z: float = -INF
	for route_point: Vector3 in route:
		min_x = minf(min_x, route_point.x)
		max_x = maxf(max_x, route_point.x)
		min_z = minf(min_z, route_point.z)
		max_z = maxf(max_z, route_point.z)
	var room_candidates: Array[Vector3] = []
	for x_step: int in range(8):
		for z_step: int in range(8):
			var room_x: float = lerpf(min_x - 3.0, max_x + 3.0, float(x_step) / 7.0)
			var room_z: float = lerpf(min_z - 3.0, max_z + 3.0, float(z_step) / 7.0)
			room_candidates.append(Vector3(room_x, 0.0, room_z))
	for candidate_index: int in range(room_candidates.size()):
		if decorations.size() >= 260:
			break
		var candidate: Vector3 = room_candidates[candidate_index]
		var room_kind: String = room_furniture[candidate_index % room_furniture.size()]
		var furniture_route_clearance: float = track_width * 0.5 + 1.5 + _furniture_spacing_for_kind(room_kind) * 0.5
		if _distance_to_route_xz(candidate, route, route_is_closed) < furniture_route_clearance:
			continue
		if not _position_clear_of_room_walls(candidate, room_layout, _furniture_spacing_for_kind(room_kind) * 0.5 + 0.22):
			continue
		if not _decoration_position_is_clear(decorations, candidate, 1.0, room_kind):
			continue
		decorations.append({"kind": room_kind, "position": candidate, "rotation": rng.randf_range(0.0, TAU), "variant": rng.randi_range(0, 3), "scale": rng.randf_range(0.90, 1.05), "animal_behavior": "", "animal_crossing_direction": Vector3.ZERO, "animal_crossing_distance": 0.0, "destructible": true, "room_fill": true})

	# Stabilna kolejność budowania: najpierw meble wypełniające pomieszczenia,
	# następnie pozostałe duże elementy, zwierzęta i na końcu drobne rekwizyty.
	var ordered_furniture: Array[Dictionary] = []
	var ordered_animals: Array[Dictionary] = []
	var ordered_extras: Array[Dictionary] = []
	for decoration: Dictionary in decorations:
		var kind: String = str(decoration.get("kind", ""))
		if bool(decoration.get("room_fill", false)) or (core_furniture.has(kind) and not small_extra_kinds.has(kind)):
			ordered_furniture.append(decoration)
		elif animal_kinds.has(kind):
			ordered_animals.append(decoration)
		else:
			ordered_extras.append(decoration)
	decorations.clear()
	decorations.append_array(ordered_furniture)
	decorations.append_array(ordered_animals)
	decorations.append_array(ordered_extras)

	# Cztery stacje startowe są po prawej stronie długiej prostej startowej.
	# Ich front (lokalne -Z) jest zawsze skierowany do jezdni, a zielona mata
	# najazdowa pozostaje po stronie toru. Wspólny helper jest używany także
	# przy migracji starych zapisów i budowie podglądu 3D.
	var docking_stations: Array[Dictionary] = make_docking_stations(route, track_width_for_size(size_value))
	var start_room_bounds: Dictionary = _make_start_room_bounds(route, docking_stations, track_width_for_size(size_value))
	# Strefa startowa jest osobnym, pustym pomieszczeniem. Nie pozwalamy, aby
	# losowe meble, rekwizyty lub zwierzęta pojawiały się przy stacjach i robotach.
	if not start_room_bounds.is_empty():
		var clear_decorations: Array[Dictionary] = []
		for decoration: Dictionary in decorations:
			var decoration_position: Vector3 = decoration.get("position", Vector3.ZERO)
			if not _point_inside_bounds_xz(decoration_position, start_room_bounds, 0.85):
				clear_decorations.append(decoration)
		decorations = clear_decorations
	var midpoint_station: Dictionary = {}

	# Układ pomieszczeń został obliczony przed rozmieszczaniem obiektów,
	# aby meble i dekoracje mogły omijać ściany oraz narożniki.
	var track_id: String = "generated_v40_%d_%d_%d_%d_%d_%d_%d_%s_%s" % [absi(seed_value), size_value, complexity_value, density, furniture_level, obstacle_layout_value, requested_animals, theme, "lap" if route_is_closed else "segment"]
	var final_name: String = custom_name.strip_edges()
	if final_name.is_empty():
		final_name = "Trasa %d" % absi(seed_value)
	return {"id": track_id, "track_id": track_id, "name": final_name, "display_name": final_name, "description": "Losowa trasa wielokształtna • seed %d • %d punktów" % [seed_value, point_count], "scene": PROCEDURAL_SCENE, "generated": true, "generator_version": 43, "route_style": forced_route_style, "route_fallback": used_fallback, "route_closed": route_is_closed, "route_type": "lap" if route_is_closed else "segment", "room_partitions": room_layout.get("partitions", []), "room_bounds": room_layout.get("rooms", []), "start_room_bounds": start_room_bounds, "seed": seed_value, "floor_texture": rng.randi_range(0, 4), "floor_texture_seed": seed_value, "size_level": size_value, "complexity": complexity_value, "obstacle_density": density, "furniture_density": furniture_level, "obstacle_layout": obstacle_layout_value, "furniture_count": furniture_count, "animal_count": placed_animal_count, "theme": theme, "route": route, "obstacles": obstacles, "decorations": decorations, "docking_stations": docking_stations, "midpoint_station": midpoint_station, "track_width": track_width_for_size(size_value), "default_laps": 3 if route_is_closed else 1, "max_racers": 5, "dirt_pickup_count": 9 + complexity_value}


## Osobna strefa startowa rozszerza fizyczną powierzchnię mieszkania, ale nie jest
## dopisywana do room_bounds, więc nie zwiększa liczby ani metrażu pokoi użytkowych.
static func _point_inside_bounds_xz(point: Vector3, bounds: Dictionary, margin: float = 0.0) -> bool:
	return point.x >= float(bounds.get("min_x", INF)) - margin and point.x <= float(bounds.get("max_x", -INF)) + margin and point.z >= float(bounds.get("min_z", INF)) - margin and point.z <= float(bounds.get("max_z", -INF)) + margin


static func _make_start_room_bounds(route: Array, stations: Array[Dictionary], track_width: float) -> Dictionary:
	if route.size() < 2:
		return {}
	var start: Vector3 = route[0]
	var tangent: Vector3 = (route[1] - route[0]).normalized()
	tangent.y = 0.0
	if tangent.length_squared() < 0.001:
		return {}
	tangent = tangent.normalized()
	var side: Vector3 = Vector3(-tangent.z, 0.0, tangent.x)
	# Pokój startowy kończy się PRZED pierwszym zakrętem. Pierwszy odcinek
	# trasy jest prostą drogą wyjazdową; ściana końcowa pokoju nie jest budowana,
	# a koniec strefy wypada z zapasem przed punktem pierwszego skrętu.
	var first_segment_length: float = start.distance_to(route[1])
	var longitudinal_min: float = -2.8
	var longitudinal_max: float = maxf(5.2, first_segment_length - 1.4)
	for station: Dictionary in stations:
		var station_point: Vector3 = station.get("position", Vector3.ZERO)
		longitudinal_max = maxf(longitudinal_max, (station_point - start).dot(tangent) + 1.0)
	# Szeroka strefa mieści cztery stacje ustawione w jednym rzędzie po prawej
	# stronie oraz wolny pas jazdy.
	var half_width: float = maxf(track_width * 0.5 + 1.35 + 3.0 * 0.91 + 1.25, 10.0)
	var center: Vector3 = start + tangent * ((longitudinal_min + longitudinal_max) * 0.5)
	var corners: Array[Vector3] = [
		start + tangent * longitudinal_min - side * half_width,
		start + tangent * longitudinal_max - side * half_width,
		start + tangent * longitudinal_min + side * half_width,
		start + tangent * longitudinal_max + side * half_width
	]
	var min_x: float = INF
	var max_x: float = -INF
	var min_z: float = INF
	var max_z: float = -INF
	for point: Vector3 in corners:
		min_x = minf(min_x, point.x)
		max_x = maxf(max_x, point.x)
		min_z = minf(min_z, point.z)
		max_z = maxf(max_z, point.z)
	return {"min_x": min_x, "max_x": max_x, "min_z": min_z, "max_z": max_z, "is_start_room": true, "center": center, "tangent": tangent, "side": side, "length": longitudinal_max - longitudinal_min, "width": half_width * 2.0, "half_width": half_width, "longitudinal_min": longitudinal_min, "longitudinal_max": longitudinal_max}


## Granice mieszkania są wspólne dla podłogi, ścian i podglądu 2D.
static func _route_room_bounds(route: Array) -> Dictionary:
	var min_x: float = INF
	var max_x: float = -INF
	var min_z: float = INF
	var max_z: float = -INF
	for value: Variant in route:
		if not (value is Vector3):
			continue
		var point: Vector3 = value
		min_x = minf(min_x, point.x)
		max_x = maxf(max_x, point.x)
		min_z = minf(min_z, point.z)
		max_z = maxf(max_z, point.z)
	# Ściany zewnętrzne są bliżej trasy, co ogranicza puste pasy mieszkania.
	return {"min_x": min_x - 3.0, "max_x": max_x + 3.0, "min_z": min_z - 3.0, "max_z": max_z + 3.0}


## Dzieli mieszkanie na kilka mniejszych pomieszczeń o zróżnicowanych proporcjach.
## Podział jest deterministyczny dla seedu i składa się z odcinków, a nie dwóch pełnych osi.
static func _generate_room_layout(bounds: Dictionary, rng: RandomNumberGenerator, complexity: int, theme: String = "apartment") -> Dictionary:
	# Hala do sprzątania pozostaje jedną otwartą przestrzenią: bez ścian działowych i przypadkowych słupków.
	if theme == "cleaning_hall":
		return {"partitions": [], "rooms": [bounds.duplicate(true)]}
	# Dzielimy dopiero duże strefy przekraczające ok. 110 m².
	# Salon z aneksem może pozostać jednym większym pomieszczeniem.
	var rooms: Array[Dictionary] = [bounds.duplicate(true)]
	var partitions: Array[Dictionary] = []
	var split_guard: int = 0
	while split_guard < 2000 and rooms.size() < 8:
		split_guard += 1
		var selected_index: int = -1
		var largest_area: float = 110.0
		for room_index: int in range(rooms.size()):
			var room: Dictionary = rooms[room_index]
			var width: float = float(room["max_x"]) - float(room["min_x"])
			var depth: float = float(room["max_z"]) - float(room["min_z"])
			var area: float = width * depth
			if area > largest_area and (width >= 4.0 or depth >= 4.0):
				selected_index = room_index
				largest_area = area
		if selected_index < 0:
			break
		var selected: Dictionary = rooms[selected_index]
		var width: float = float(selected["max_x"]) - float(selected["min_x"])
		var depth: float = float(selected["max_z"]) - float(selected["min_z"])
		# Wybór osi zależy od proporcji, ale z losową domieszką, żeby układ
		# nie składał się z samych niemal kwadratowych pomieszczeń.
		var vertical: bool = width >= depth
		if rng.randf() < 0.28:
			vertical = not vertical
		if vertical and width < 4.0:
			vertical = false
		elif not vertical and depth < 4.0:
			vertical = true
		var split_ratio: float = rng.randf_range(0.30, 0.70)
		var first: Dictionary = selected.duplicate(true)
		var second: Dictionary = selected.duplicate(true)
		var area_a: float = 0.0
		var area_b: float = 0.0
		if vertical:
			var axis_x: float = lerpf(float(selected["min_x"]), float(selected["max_x"]), split_ratio)
			area_a = (axis_x - float(selected["min_x"])) * depth
			area_b = (float(selected["max_x"]) - axis_x) * depth
			if area_a < 8.0 or area_b < 8.0:
				break
			first["max_x"] = axis_x
			second["min_x"] = axis_x
			partitions.append({"vertical": true, "axis": axis_x, "min": float(selected["min_z"]), "max": float(selected["max_z"])})
		else:
			var axis_z: float = lerpf(float(selected["min_z"]), float(selected["max_z"]), split_ratio)
			area_a = width * (axis_z - float(selected["min_z"]))
			area_b = width * (float(selected["max_z"]) - axis_z)
			if area_a < 8.0 or area_b < 8.0:
				break
			first["max_z"] = axis_z
			second["min_z"] = axis_z
			partitions.append({"vertical": false, "axis": axis_z, "min": float(selected["min_x"]), "max": float(selected["max_x"])})
		rooms.remove_at(selected_index)
		rooms.append(first)
		rooms.append(second)
	# Krótkie, losowe wnęki dodajemy tylko w pokojach o wystarczającym metrażu.
	var alcove_count: int = 1 if rooms.size() >= 4 else 0
	for alcove_index: int in range(alcove_count):
		var alcove_candidates: Array[int] = []
		for room_index: int in range(rooms.size()):
			var room: Dictionary = rooms[room_index]
			var area: float = (float(room["max_x"]) - float(room["min_x"])) * (float(room["max_z"]) - float(room["min_z"]))
			if area >= 12.0:
				alcove_candidates.append(room_index)
		if alcove_candidates.is_empty():
			break
		var alcove_room: Dictionary = rooms[alcove_candidates[rng.randi_range(0, alcove_candidates.size() - 1)]]
		var alcove_vertical: bool = rng.randf() < 0.5
		var alcove_axis: float
		var alcove_depth: float
		var alcove_min: float
		if alcove_vertical:
			alcove_axis = lerpf(float(alcove_room["min_x"]), float(alcove_room["max_x"]), rng.randf_range(0.34, 0.66))
			alcove_depth = (float(alcove_room["max_z"]) - float(alcove_room["min_z"])) * rng.randf_range(0.22, 0.30)
			alcove_min = float(alcove_room["min_z"]) if rng.randf() < 0.5 else float(alcove_room["max_z"]) - alcove_depth
			partitions.append({"vertical": true, "axis": alcove_axis, "min": alcove_min, "max": alcove_min + alcove_depth, "alcove": true})
		else:
			alcove_axis = lerpf(float(alcove_room["min_z"]), float(alcove_room["max_z"]), rng.randf_range(0.34, 0.66))
			alcove_depth = (float(alcove_room["max_x"]) - float(alcove_room["min_x"])) * rng.randf_range(0.22, 0.30)
			alcove_min = float(alcove_room["min_x"]) if rng.randf() < 0.5 else float(alcove_room["max_x"]) - alcove_depth
			partitions.append({"vertical": false, "axis": alcove_axis, "min": alcove_min, "max": alcove_min + alcove_depth, "alcove": true})
	return {"partitions": partitions, "rooms": rooms}


## Zwraca przedziały otworów drzwiowych w ścianie dzielącej mieszkanie.
## vertical=true oznacza ścianę x=axis_value (przedziały w osi Z),
## vertical=false oznacza ścianę z=axis_value (przedziały w osi X).
static func get_room_partition_openings(route: Array, vertical: bool, axis_value: float, track_width: float, extent_min: float, extent_max: float, route_closed: bool = true) -> Array[Vector2]:
	# Otwór wycina cały fragment ściany, którego pas bezpieczeństwa zbliża się
	# do trasy. Uwzględnia przecięcia pod kątem oraz przejazdy równoległe.
	var raw_openings: Array[Vector2] = []
	if route.size() < 2:
		return raw_openings
	var segment_count: int = route.size() if route_closed else route.size() - 1
	# Otwór jest szerszy od samego pasa jazdy: obejmuje obrys robota,
	# margines prowadzenia i grubość ściany/listwy.
	# Twardy korytarz bez ścian: obejmuje szerokość jezdni, obrys robota,
	# margines prowadzenia oraz zapas na grubość ściany i listwy.
	# Duży zapas jest celowy — ściana ma zostać przerwana wyraźnie przed
	# torem, a nie dopiero dokładnie na jego krawędzi.
	var corridor_radius: float = track_width * 0.5 + 5.0
	var along_safety: float = 4.0
	for i: int in range(segment_count):
		var next_index: int = (i + 1) % route.size() if route_closed else i + 1
		if not (route[i] is Vector3) or not (route[next_index] is Vector3):
			continue
		var a: Vector3 = route[i]
		var b: Vector3 = route[next_index]
		var dx: float = b.x - a.x
		var dz: float = b.z - a.z
		var segment_length: float = Vector2(dx, dz).length()
		if segment_length < 0.001:
			continue
		var along_start: float = 0.0
		var along_end: float = 0.0
		if vertical:
			# Ściana x=const, przedział otworu leży w osi Z.
			if axis_value < minf(a.x, b.x) - corridor_radius or axis_value > maxf(a.x, b.x) + corridor_radius:
				continue
			if absf(dx) < 0.001:
				if absf(axis_value - a.x) > corridor_radius:
					continue
				along_start = minf(a.z, b.z) - corridor_radius
				along_end = maxf(a.z, b.z) + corridor_radius
			else:
				var center_along: float = a.z + dz * (axis_value - a.x) / dx
				var half_along: float = corridor_radius * segment_length / absf(dx)
				along_start = maxf(center_along - half_along, minf(a.z, b.z) - corridor_radius)
				along_end = minf(center_along + half_along, maxf(a.z, b.z) + corridor_radius)
		else:
			# Ściana z=const, przedział otworu leży w osi X.
			if axis_value < minf(a.z, b.z) - corridor_radius or axis_value > maxf(a.z, b.z) + corridor_radius:
				continue
			if absf(dz) < 0.001:
				if absf(axis_value - a.z) > corridor_radius:
					continue
				along_start = minf(a.x, b.x) - corridor_radius
				along_end = maxf(a.x, b.x) + corridor_radius
			else:
				var center_along: float = a.x + dx * (axis_value - a.z) / dz
				var half_along: float = corridor_radius * segment_length / absf(dz)
				along_start = maxf(center_along - half_along, minf(a.x, b.x) - corridor_radius)
				along_end = minf(center_along + half_along, maxf(a.x, b.x) + corridor_radius)
		along_start -= along_safety
		along_end += along_safety
		var opening := Vector2(maxf(along_start, extent_min), minf(along_end, extent_max))
		if opening.y - opening.x > 0.2:
			raw_openings.append(opening)
	if raw_openings.is_empty():
		return raw_openings
	raw_openings.sort_custom(func(a: Vector2, b: Vector2) -> bool: return a.x < b.x)
	var merged: Array[Vector2] = []
	for opening: Vector2 in raw_openings:
		if merged.is_empty() or opening.x > merged[merged.size() - 1].y + 0.5:
			merged.append(opening)
		else:
			var previous: Vector2 = merged.pop_back()
			previous.y = maxf(previous.y, opening.y)
			merged.append(previous)
	return merged

static func _room_furniture_for_theme(theme: String) -> Array[String]:
	match theme:
		"kitchen":
			return ["fridge", "kitchen_counter", "sink", "table", "chair", "cabinet", "plant", "lamp", "microwave", "toaster", "kettle", "fruit_bowl", "dish_rack", "trash_bin", "washing_machine"]
		"bedroom":
			return ["bed", "cabinet", "lamp", "rug", "bookshelf", "chair", "pet_bed", "plant", "laptop", "monitor", "speaker", "suitcase"]
		"futuristic":
			return ["tv", "lamp", "cabinet", "table", "chair", "plant", "fish_tank", "robot_toy", "game_console", "speaker", "floor_fan", "water_dispenser", "vase", "candle"]
		"office":
			return ["table", "chair", "cabinet", "bookshelf", "monitor", "laptop", "speaker", "plant", "trash_bin", "water_dispenser", "cable", "lamp"]
		"pro_league":
			return ["tv_wall", "speaker", "monitor", "cabinet", "lamp", "plant", "water_dispenser", "floor_fan", "trash_bin"]
		"cleaning_hall":
			return ["cabinet", "bookshelf", "table", "chair", "trash_bin", "water_dispenser", "floor_fan", "box", "washing_machine", "kitchen_counter", "plant"]
	return ["sofa", "table", "chair", "cabinet", "lamp", "bookshelf", "tv", "plant", "trash_bin", "floor_fan", "speaker", "game_console", "coat_rack", "umbrella_stand", "toy_car", "pet_tunnel", "vase", "candle"]


## Twarda osłona geometrii: sprawdza całą linię ściany względem całej trasy.
## Jeśli choć fragment ściany wchodzi w korytarz jazdy, odrzucamy cały jej segment.
## To celowo bardziej zachowawcze niż samo wycinanie drzwi — może zostawić
## krótszą ścianę, ale nie pozwoli postawić jej na jezdni.
static func wall_line_segment_clear_of_route(route: Array, wall_a: Vector3, wall_b: Vector3, track_width: float, route_closed: bool = true, extra_clearance: float = 1.5) -> bool:
	if route.size() < 2:
		return true
	var wall_delta: Vector2 = Vector2(wall_b.x - wall_a.x, wall_b.z - wall_a.z)
	var wall_length: float = wall_delta.length()
	var sample_count: int = maxi(2, ceili(wall_length / 0.20))
	var clearance: float = maxf(1.0, track_width * 0.5 + extra_clearance)
	var segment_count: int = route.size() if route_closed else route.size() - 1
	for sample_index: int in range(sample_count + 1):
		var t: float = float(sample_index) / float(sample_count)
		var sample_x: float = lerpf(wall_a.x, wall_b.x, t)
		var sample_z: float = lerpf(wall_a.z, wall_b.z, t)
		var sample_point := Vector2(sample_x, sample_z)
		for route_index: int in range(segment_count):
			var next_index: int = (route_index + 1) % route.size() if route_closed else route_index + 1
			if not (route[route_index] is Vector3) or not (route[next_index] is Vector3):
				continue
			var route_a: Vector3 = route[route_index]
			var route_b: Vector3 = route[next_index]
			var a := Vector2(route_a.x, route_a.z)
			var b := Vector2(route_b.x, route_b.z)
			var delta: Vector2 = b - a
			var denominator: float = delta.length_squared()
			var projection: float = 0.0 if denominator <= 0.0001 else clampf((sample_point - a).dot(delta) / denominator, 0.0, 1.0)
			if sample_point.distance_to(a + delta * projection) < clearance:
				return false
	return true


static func wall_segment_clear_of_route(route: Array, vertical: bool, axis_value: float, from_along: float, to_along: float, track_width: float, route_closed: bool = true, extra_clearance: float = 1.5) -> bool:
	var wall_a: Vector3 = Vector3(axis_value, 0.0, from_along) if vertical else Vector3(from_along, 0.0, axis_value)
	var wall_b: Vector3 = Vector3(axis_value, 0.0, to_along) if vertical else Vector3(to_along, 0.0, axis_value)
	return wall_line_segment_clear_of_route(route, wall_a, wall_b, track_width, route_closed, extra_clearance)


static func _distance_to_route_xz(point: Vector3, route: Array[Vector3], route_closed: bool = true) -> float:
	var minimum_distance: float = INF
	var p := Vector2(point.x, point.z)
	var segment_count: int = route.size() if route_closed else route.size() - 1
	for i: int in range(segment_count):
		var next_index: int = (i + 1) % route.size() if route_closed else i + 1
		var a := Vector2(route[i].x, route[i].z)
		var b := Vector2(route[next_index].x, route[next_index].z)
		var segment := b - a
		var denominator: float = segment.length_squared()
		var t: float = 0.0 if denominator <= 0.0001 else clampf((p - a).dot(segment) / denominator, 0.0, 1.0)
		minimum_distance = minf(minimum_distance, p.distance_to(a + segment * t))
	return minimum_distance


static func _furniture_set_for_theme(theme: String) -> Array[String]:
	match theme:
		"kitchen":
			return ["fridge", "kitchen_counter", "sink", "table", "chair", "cabinet", "lamp", "plant", "bookshelf", "tv", "rug", "fish_tank", "box", "mug", "food_scraps", "pet_bowl", "robot_toy", "microwave", "toaster", "kettle", "fruit_bowl", "dish_rack", "trash_bin"]
		"bedroom":
			return ["bed", "cabinet", "lamp", "rug", "bookshelf", "chair", "table", "plant", "pet_bed", "pillow", "tv", "box", "backpack", "shoe", "sock", "toy", "robot_toy", "laptop", "monitor", "speaker", "suitcase", "vase", "candle"]
		"futuristic":
			return ["tv", "lamp", "cabinet", "table", "chair", "plant", "fish_tank", "bookshelf", "robot_toy", "box", "rug", "kitchen_counter", "fridge", "pet_bed", "toy", "cable", "backpack", "game_console", "speaker", "floor_fan", "water_dispenser", "vase"]
		"office":
			return ["table", "chair", "cabinet", "bookshelf", "monitor", "laptop", "speaker", "plant", "trash_bin", "water_dispenser", "cable", "lamp"]
		"pro_league":
			return ["tv_wall", "speaker", "monitor", "cabinet", "lamp", "plant", "water_dispenser", "floor_fan", "trash_bin"]
		"cleaning_hall":
			return ["cabinet", "bookshelf", "table", "chair", "trash_bin", "water_dispenser", "floor_fan", "box", "washing_machine", "kitchen_counter", "plant"]
	return ["plant", "sofa", "table", "chair", "cabinet", "lamp", "bookshelf", "tv", "bed", "fridge", "kitchen_counter", "fish_tank", "bathtub", "sink", "scratching_post", "pet_bed", "rug", "trash_bin", "floor_fan", "speaker", "game_console", "coat_rack", "umbrella_stand", "toy_car", "pet_tunnel", "vase", "candle"]


static func _furniture_clearance_for_kind(kind: String) -> float:
	match kind:
		"sofa", "bed", "fridge", "bathtub", "kitchen_counter", "washing_machine", "shower", "wardrobe", "shoe_rack", "floor_mirror", "laundry_basket": return 0.85
		"bookshelf", "cabinet", "fish_tank", "tv", "sink", "microwave", "monitor", "water_dispenser", "floor_fan", "coat_rack", "radiator", "toilet", "trash_bin", "speaker": return 0.6
		"table", "chair", "scratching_post", "pet_bed", "nightstand", "coffee_table", "side_table", "ottoman", "pet_tunnel": return 0.4
	return 0.18


static func _position_clear_of_room_walls(position: Vector3, room_layout: Dictionary, margin: float) -> bool:
	var rooms: Array = room_layout.get("rooms", [])
	var inside_room: bool = false
	for room_value: Variant in rooms:
		if not (room_value is Dictionary):
			continue
		var room: Dictionary = room_value
		if position.x >= float(room.get("min_x", -INF)) + margin and position.x <= float(room.get("max_x", INF)) - margin and position.z >= float(room.get("min_z", -INF)) + margin and position.z <= float(room.get("max_z", INF)) - margin:
			inside_room = true
			break
	if not inside_room:
		return false
	for partition_value: Variant in room_layout.get("partitions", []):
		if not (partition_value is Dictionary):
			continue
		var partition: Dictionary = partition_value
		var axis: float = float(partition.get("axis", 0.0))
		var extent_min: float = float(partition.get("min", 0.0))
		var extent_max: float = float(partition.get("max", 0.0))
		if bool(partition.get("vertical", false)):
			if absf(position.x - axis) < margin and position.z >= extent_min - margin and position.z <= extent_max + margin:
				return false
		else:
			if absf(position.z - axis) < margin and position.x >= extent_min - margin and position.x <= extent_max + margin:
				return false
	return true


static func _decoration_position_is_clear(existing: Array[Dictionary], candidate: Vector3, minimum_distance: float, candidate_kind: String = "") -> bool:
	for item: Dictionary in existing:
		var other: Vector3 = item.get("position", Vector3.ZERO)
		var other_kind: String = str(item.get("kind", ""))
		var required_distance: float = maxf(minimum_distance, maxf(_furniture_spacing_for_kind(candidate_kind), _furniture_spacing_for_kind(other_kind))) + 0.45
		if Vector2(candidate.x - other.x, candidate.z - other.z).length() < required_distance:
			return false
	return true


static func _furniture_spacing_for_kind(kind: String) -> float:
	if ["cat", "dog", "rabbit", "bearded_dragon", "parrot", "hamster", "guinea_pig", "turtle", "hedgehog", "ferret"].has(kind):
		return 0.7
	match kind:
		"sofa", "bed", "fridge", "bathtub", "kitchen_counter", "washing_machine", "shower", "wardrobe", "shoe_rack", "floor_mirror", "laundry_basket": return 3.0
		"bookshelf", "cabinet", "fish_tank", "tv", "sink", "microwave", "monitor", "water_dispenser", "floor_fan", "coat_rack", "radiator", "toilet", "trash_bin", "speaker": return 2.25
		"table", "chair", "scratching_post", "pet_bed", "nightstand", "coffee_table", "side_table", "ottoman", "pet_tunnel": return 1.7
	return 0.95


static func make_docking_stations(route: Array, track_width: float) -> Array[Dictionary]:
	var stations: Array[Dictionary] = []
	if route.size() < 2 or not (route[0] is Vector3) or not (route[1] is Vector3):
		return stations
	var first_point: Vector3 = route[0]
	var second_point: Vector3 = route[1]
	var tangent: Vector3 = second_point - first_point
	tangent.y = 0.0
	if tangent.length_squared() < 0.001:
		return stations
	tangent = tangent.normalized()
	# Zgodne z TrackBase.get_side_at(): dodatni znak to prawa strona toru.
	var side: Vector3 = Vector3(-tangent.z, 0.0, tangent.x).normalized()
	var center: Vector3 = (first_point + second_point) * 0.5
	# Cztery stacje stoją niemal stykając się w jednej linii po prawej stronie jezdni.
	# Nie ustawiamy ich jedna za drugą wzdłuż toru, dzięki czemu nie wydłużają
	# pokoju i nie wymuszają zakrętu przy wyjeździe.
	var longitudinal_offset: float = 2.0
	var first_lateral: float = track_width * 0.5 + 1.10
	for station_index: int in range(4):
		var lateral_offset: float = first_lateral + float(station_index) * 0.58
		var station_position: Vector3 = first_point + side * lateral_offset + tangent * longitudinal_offset
		var facing: Vector3 = -side
		var station_rotation: float = atan2(-facing.x, -facing.z)
		stations.append({
			"position": station_position,
			"rotation": station_rotation,
			"side": "start_right",
			"station_index": station_index,
			"start_group": 0,
			"facing": facing,
			"approach_clearance": 1.6
		})
	return stations


static func make_midpoint_station(_route: Array, _track_width: float) -> Dictionary:
	# Zachowane dla zgodności ze starszymi zapisami i wywołaniami.
	# W aktualnym projekcie stacje ładowania istnieją wyłącznie przy starcie.
	return {}


static func _make_random_route(rng: RandomNumberGenerator, complexity_value: int, size_value: int, scale_factor: float, start_left: Vector2, start_right: Vector2, forced_route_style: int = -1) -> Array[Vector3]:
	# Generujemy profil toru z kilku płynnych rodzin układów. Losowość jest
	# filtrowana między sąsiednimi punktami, żeby Catmull-Rom nie tworzył
	# przypadkowych, ostrych załamań, w których AI traci linię jazdy.
	# Część losowań świadomie prowadzi trasę bliżej środka układu pomieszczeń,
	# zamiast zawsze rozciągać ją po obwodzie. Nadal walidujemy kolizje i
	# przecięcia, ale sam centralny przebieg nie jest powodem odrzucenia trasy.
	var style: int = rng.randi_range(0, 9)
	if complexity_value >= 5:
		style = rng.randi_range(10, 14)
	if forced_route_style >= 0:
		style = clampi(forced_route_style, 10, 14) if complexity_value >= 5 else posmod(forced_route_style, 10)
	# Każdy archetyp ma inny dominujący obrys (szeroki, wysoki, zwarty,
	# wydłużony lub asymetryczny). Wcześniej różniły się głównie drobną falą
	# promienia, więc nawet inne seedy wyglądały niemal identycznie.
	var archetype_rx: Array[float] = [70.0, 44.0, 60.0, 76.0, 48.0, 66.0, 42.0, 72.0, 54.0, 64.0]
	var archetype_rz: Array[float] = [44.0, 70.0, 60.0, 48.0, 76.0, 42.0, 66.0, 54.0, 72.0, 58.0]
	var geometry_style: int = style - 10 if style >= 10 else style
	var geometry_style_map: Array[int] = [0, 3, 4, 7, 8]
	if style >= 10:
		geometry_style = geometry_style_map[clampi(style - 10, 0, 4)]
	var base_rx: float = archetype_rx[geometry_style] * rng.randf_range(0.94, 1.06)
	var base_rz: float = archetype_rz[geometry_style] * rng.randf_range(0.94, 1.06)
	var central_route: bool = geometry_style in [1, 4, 6, 8]
	if complexity_value >= 5:
		base_rx *= 1.08
		base_rz *= 1.08
	# Małe mapy potrzebują mniejszej liczby punktów, aby odcinki nie były
	# krótsze niż szerokość robota i nie tworzyły mikrozakrętów. Duże mapy
	# mogą bezpiecznie otrzymać więcej sekcji technicznych.
	var count_min: int = [6, 8, 10, 12, 14, 16][clampi(size_value, 0, 5)]
	var count_max: int = [8, 10, 13, 16, 20, 24][clampi(size_value, 0, 5)]
	var complexity_bonus: int = int(round(float(complexity_value - 1) * float(size_value) / 4.0))
	var style_count_bonus: int = [0, 3, 1, 5, 2, 4, 1, 6, 3, 5][geometry_style]
	var count: int = rng.randi_range(count_min + complexity_bonus + style_count_bonus, count_max + complexity_bonus + style_count_bonus)
	var left_angle: float = atan2(start_left.y / scale_factor / base_rz, start_left.x / scale_factor / base_rx)
	var right_angle: float = atan2(start_right.y / scale_factor / base_rz, start_right.x / scale_factor / base_rx)
	if left_angle < 0.0:
		left_angle += TAU
	if right_angle < 0.0:
		right_angle += TAU
	var sweep: float = TAU - (right_angle - left_angle)
	var step: float = sweep / float(count + 1)
	var raw_profile: Array[Vector2] = []
	var profile_min: float = 0.70 if complexity_value <= 2 else 0.68
	var profile_max: float = 1.30 if complexity_value <= 2 else 1.32
	if central_route:
		profile_min = 0.68 if complexity_value >= 4 else 0.70
		profile_max = 1.30
	if complexity_value >= 5 and not central_route:
		profile_min = 0.90
		profile_max = 1.10
	for i: int in range(count + 2):
		raw_profile.append(Vector2(rng.randf_range(profile_min, profile_max), rng.randf_range(profile_min, profile_max)))
	var phase: float = rng.randf_range(0.0, TAU)
	var result: Array[Vector3] = [Vector3(start_left.x, 0.0, start_left.y), Vector3(start_right.x, 0.0, start_right.y)]
	for i: int in range(1, count + 1):
		var angle: float = right_angle + step * float(i)
		var before: Vector2 = raw_profile[i - 1]
		var current: Vector2 = raw_profile[i]
		var after: Vector2 = raw_profile[i + 1]
		var smoothing_weight: float = 0.22 if complexity_value <= 2 else 0.14
		if complexity_value >= 5:
			smoothing_weight = 0.08
		var filtered: Vector2 = before * smoothing_weight + current * (1.0 - smoothing_weight * 2.0) + after * smoothing_weight
		var radial_amplitude: float = 0.12 if complexity_value <= 2 else 0.13
		if complexity_value >= 5:
			radial_amplitude = 0.10
		var radial: float = 1.0 + radial_amplitude * sin(angle * float(2 + style % 3) + phase) + radial_amplitude * 0.62 * cos(angle * float(3 + style % 2) - phase)
		var rx_factor: float = filtered.x
		var rz_factor: float = filtered.y
		match style:
			0: # płynny tor z szerokimi łukami
				rx_factor *= 1.10
			1: # asymetryczny układ z ciasnym nawrotem
				if sin(angle + phase) > 0.55:
					radial *= 0.78
			2: # szykana: dwa przeciwne, łagodne załamania
				radial *= 1.0 + 0.13 * sin(angle * 3.0 + phase)
			3: # szeroka sekcja po jednej stronie toru
				if cos(angle - phase) > 0.15:
					rx_factor *= 1.22
			4: # wydłużony łuk i mocniejsze zwężenie na końcu
				rz_factor *= 1.0 + 0.18 * sin(angle * 2.0 + phase)
			5: # techniczna sekwencja zakrętów o różnym promieniu
				radial *= 1.0 + 0.10 * sin(angle * 4.0 + phase)
			6: # podwójny nawrót z przejściem o zmiennym promieniu
				radial *= 1.0 + 0.15 * sin(angle * 2.0 + phase) + 0.06 * sin(angle * 5.0 - phase)
			7: # asymetryczna sekcja S z przesuniętym środkiem ciężkości
				radial *= 1.0 + 0.13 * sin(angle * 2.0 + phase)
				rx_factor *= 1.0 + 0.12 * cos(angle * 3.0 - phase)
			8: # seria szybkich łuków o naprzemiennym promieniu
				radial *= 1.0 + 0.11 * sin(angle * 5.0 + phase) + 0.05 * cos(angle * 7.0 - phase)
			9: # szeroki łuk, ciasny nawrót i wyjście w przeciwnym rytmie
				radial *= 1.0 + 0.17 * sin(angle * 2.0 + phase)
				if sin(angle * 2.0 + phase) > 0.58:
					rz_factor *= 0.82
			10, 11, 12, 13, 14: # ekstremalna: ciasne, naprzemienne szykany
				var technical_wave: float = sin(angle * 4.0 + phase)
				var short_wave: float = sin(angle * 6.0 - phase * 0.7)
				radial *= 1.0 + 0.16 * technical_wave + 0.06 * short_wave
				if technical_wave > 0.10:
					rx_factor *= 0.88
					rz_factor *= 1.05
				else:
					rx_factor *= 1.07
					rz_factor *= 0.90
		var point := Vector2(cos(angle) * base_rx * radial * rx_factor, sin(angle) * base_rz * radial * rz_factor) * scale_factor
		result.append(Vector3(point.x, 0.0, point.y))
	return result

static func _make_orthogonal_route(source: Array[Vector3], rng: RandomNumberGenerator) -> Array[Vector3]:
	# Zmieniamy przebieg na nieregularną łamaną z prostymi odcinkami
	# poziomymi i pionowymi. Każdy narożnik pozostaje osobnym punktem.
	if source.size() < 4:
		return source
	var result: Array[Vector3] = []
	var prefer_horizontal: bool = rng.randf() < 0.5
	for index: int in range(source.size()):
		var current: Vector3 = source[index]
		var next: Vector3 = source[(index + 1) % source.size()]
		result.append(current)
		var dx: float = next.x - current.x
		var dz: float = next.z - current.z
		if absf(dx) > 0.35 and absf(dz) > 0.35:
			var corner: Vector3
			if prefer_horizontal:
				corner = Vector3(next.x, 0.0, current.z)
			else:
				corner = Vector3(current.x, 0.0, next.z)
			if corner.distance_to(current) > 0.5 and corner.distance_to(next) > 0.5:
				result.append(corner)
				prefer_horizontal = not prefer_horizontal
	return result


static func _make_fallback_route(scale_factor: float, rng: RandomNumberGenerator, complexity_value: int, gate_half_width: float, size_value: int, forced_route_style: int = -1) -> Array[Vector3]:
	var points: Array[Vector2] = [Vector2(-gate_half_width / scale_factor, -30), Vector2(gate_half_width / scale_factor, -30), Vector2(125, 50), Vector2(100, 112), Vector2(0, 138), Vector2(-153, 50), Vector2(-153, -69), Vector2(-98, -125)]
	var result: Array[Vector3] = [Vector3(points[0].x * scale_factor, 0.0, points[0].y * scale_factor), Vector3(points[1].x * scale_factor, 0.0, points[1].y * scale_factor)]
	var variation: float = [0.02, 0.025, 0.03, 0.035, 0.04][clampi(complexity_value - 1, 0, 4)]
	var fallback_shape_scale: float = [0.90, 0.65, 0.50, 0.43, 0.39, 0.36][clampi(size_value, 0, 5)]
	var fallback_style_map: Array[int] = [0, 3, 4, 7, 8]
	var fallback_style: int = rng.randi_range(0, 9)
	if forced_route_style >= 10:
		fallback_style = fallback_style_map[posmod(forced_route_style - 10, 5)]
	elif forced_route_style >= 0:
		fallback_style = posmod(forced_route_style, 10)
	var fallback_x: Array[float] = [1.30, 0.78, 1.0, 1.42, 0.82, 1.22, 0.74, 1.34, 0.92, 1.16]
	var fallback_z: Array[float] = [0.82, 1.30, 1.0, 0.86, 1.42, 0.76, 1.22, 0.94, 1.34, 1.08]
	var phase: float = rng.randf_range(0.0, TAU)
	for i: int in range(2, points.size()):
		var point: Vector2 = Vector2(points[i].x * fallback_x[fallback_style], points[i].y * fallback_z[fallback_style]) * fallback_shape_scale
		var angle: float = atan2(point.y, point.x)
		var wave: float = sin(angle * 2.0 + phase) * variation * 0.45
		var x_factor: float = rng.randf_range(1.0 - variation, 1.0 + variation) + wave
		var z_factor: float = rng.randf_range(1.0 - variation, 1.0 + variation) - wave
		result.append(Vector3(point.x * x_factor * scale_factor, 0.0, point.y * z_factor * scale_factor))
	return result


static func _route_has_safe_clearance(route: Array, minimum_distance: float, _allow_tight_turns: bool = false) -> bool:
	if route.size() < 8:
		return false
	for i: int in range(route.size()):
		var a: Vector2 = Vector2(route[i].x, route[i].z)
		var b: Vector2 = Vector2(route[(i + 1) % route.size()].x, route[(i + 1) % route.size()].z)
		if a.distance_to(b) < 1.0:
			return false
		for j: int in range(i + 1, route.size()):
			if j == i or j == (i + 1) % route.size() or (j + 1) % route.size() == i:
				continue
			var c: Vector2 = Vector2(route[j].x, route[j].z)
			var d: Vector2 = Vector2(route[(j + 1) % route.size()].x, route[(j + 1) % route.size()].z)
			if _segments_cross(a, b, c, d):
				return false
			if _segment_distance(a, b, c, d) < minimum_distance:
				return false
	return true


static func _segment_distance(a: Vector2, b: Vector2, c: Vector2, d: Vector2) -> float:
	return minf(minf(_point_segment_distance(a, c, d), _point_segment_distance(b, c, d)), minf(_point_segment_distance(c, a, b), _point_segment_distance(d, a, b)))


static func _point_segment_distance(point: Vector2, a: Vector2, b: Vector2) -> float:
	var segment: Vector2 = b - a
	var length_squared: float = segment.length_squared()
	if length_squared < 0.0001:
		return point.distance_to(a)
	var t: float = clampf((point - a).dot(segment) / length_squared, 0.0, 1.0)
	return point.distance_to(a + segment * t)


static func _animal_behavior_for(kind: String) -> String:
	match kind:
		"cat": return "dart_across_track"
		"dog": return "chase_and_slow"
		"rabbit": return "short_hops"
		"bearded_dragon": return "slow_patrol_block"
		"parrot": return "overhead_swoop"
		"hamster": return "quick_scurry"
		"guinea_pig": return "slow_patrol_block"
		"turtle": return "slow_patrol_block"
		"hedgehog": return "short_hops"
		"ferret": return "dart_across_track"
	return ""


static func track_width_for_size(size_value: int) -> float:
	return [1.65, 1.80, 1.95, 2.10, 2.25, 2.45][clampi(size_value, 0, 5)]


static func _segments_cross(a: Vector2, b: Vector2, c: Vector2, d: Vector2) -> bool:
	var ab := b - a
	var cd := d - c
	var cross_1: float = ab.cross(c - a)
	var cross_2: float = ab.cross(d - a)
	var cross_3: float = cd.cross(a - c)
	var cross_4: float = cd.cross(b - c)
	return ((cross_1 > 0.001 and cross_2 < -0.001) or (cross_1 < -0.001 and cross_2 > 0.001)) and ((cross_3 > 0.001 and cross_4 < -0.001) or (cross_3 < -0.001 and cross_4 > 0.001))


static func normalize_legacy_data(source: Dictionary) -> Dictionary:
	# Migracja zapisanych tras z wcześniejszej, wielokrotnie większej skali.
	var data: Dictionary = source.duplicate(true)
	var previous_generator_version: int = int(data.get("generator_version", 1))
	if previous_generator_version < 40:
		data["dirt_pickup_count"] = 9 + int(data.get("complexity", 2))
		data["furniture_density"] = maxi(int(data.get("furniture_density", 2)), 2)
	var old_width: float = float(data.get("track_width", 1.2))
	if old_width > 3.0:
		old_width *= 0.1
	data["track_width"] = clampf(old_width, 0.8, 2.45)
	var route_value: Variant = data.get("route", [])
	if typeof(route_value) != TYPE_ARRAY or (route_value as Array).size() < 2:
		return data
	var legacy_route: Array = route_value
	if previous_generator_version < 24:
		var compact_route: Array[Vector3] = []
		for point_value: Variant in legacy_route:
			if point_value is Vector3:
				compact_route.append(point_value * 0.3)
		legacy_route = compact_route
		data["route"] = legacy_route
		# Stare przeszkody miały pozycje względem szerokiej jezdni; odtwarzamy
		# je na nowej szerokości, zamiast tylko zmniejszać ich odległość od osi.
		var obstacle_rng := RandomNumberGenerator.new()
		obstacle_rng.seed = int(data.get("seed", 1)) * 7919 + 2024
		var density: int = clampi(int(data.get("obstacle_density", 1)), 0, 5)
		var complexity_value: int = clampi(int(data.get("complexity", 2)), 1, 5)
		var layout_value: int = clampi(int(data.get("obstacle_layout", 1)), 0, 2)
		var width: float = float(data["track_width"])
		var migrated_obstacles: Array[Vector3] = []
		var obstacle_count: int = density * (5 + complexity_value * 2)
		for obstacle_index: int in range(obstacle_count):
			if legacy_route.size() < 4:
				break
			var route_index: int = 2 + int(round(float(obstacle_index + 1) * float(legacy_route.size() - 4) / float(obstacle_count + 1)))
			route_index = clampi(route_index, 1, legacy_route.size() - 2)
			var next_index: int = (route_index + 1) % legacy_route.size()
			var midpoint: Vector3 = (legacy_route[route_index] + legacy_route[next_index]) * 0.5
			var tangent: Vector3 = (legacy_route[next_index] - legacy_route[route_index]).normalized()
			var side: Vector3 = Vector3(-tangent.z, 0.0, tangent.x)
			var lateral: float = 0.0
			match layout_value:
				0: lateral = width * 0.30 * (-1.0 if obstacle_index % 2 == 0 else 1.0)
				1: lateral = obstacle_rng.randf_range(-width * 0.24, width * 0.24)
				2: lateral = width * 0.25 * (-1.0 if obstacle_index % 2 == 0 else 1.0)
			var longitudinal: float = obstacle_rng.randf_range(-0.35, 0.35) if layout_value != 2 else obstacle_rng.randf_range(-0.18, 0.18)
			migrated_obstacles.append(midpoint + side * lateral + tangent * longitudinal)
		data["obstacles"] = migrated_obstacles
		var migrated_decorations: Array[Dictionary] = []
		var old_decorations: Variant = data.get("decorations", [])
		if typeof(old_decorations) == TYPE_ARRAY:
			for decoration_value: Variant in old_decorations:
				if not (decoration_value is Dictionary):
					continue
				var decoration: Dictionary = decoration_value.duplicate(true)
				if decoration.get("position", null) is Vector3:
					decoration["position"] = decoration["position"] * 0.3
				decoration["scale"] = clampf(float(decoration.get("scale", 1.0)), 0.90, 1.10)
				var kind: String = str(decoration.get("kind", ""))
				if kind in ["cat", "dog", "rabbit", "bearded_dragon", "parrot", "hamster", "guinea_pig", "turtle", "hedgehog", "ferret"]:
					decoration["animal_crossing_distance"] = width + 1.0
				migrated_decorations.append(decoration)
		data["decorations"] = migrated_decorations
		data["dirt_pickup_count"] = 9 + complexity_value
	var refresh_generated_layout: bool = (previous_generator_version == 28 or previous_generator_version < 40) and bool(data.get("generated", false)) and not bool(data.get("manual_editor", false))
	if previous_generator_version >= 24 and previous_generator_version < 28 and bool(data.get("generated", false)) and not bool(data.get("manual_editor", false)):
		var size_index: int = clampi(int(data.get("size_level", 1)), 0, 5)
		var old_scale: float = [0.028, 0.034, 0.040, 0.046, 0.051, 0.056][size_index]
		var new_scale: float = [0.045, 0.073, 0.102, 0.147, 0.178, 0.210][size_index]
		var scale_ratio: float = new_scale / old_scale
		for point_index: int in range(legacy_route.size()):
			if legacy_route[point_index] is Vector3:
				legacy_route[point_index] = (legacy_route[point_index] as Vector3) * scale_ratio
		if legacy_route.size() >= 2 and legacy_route[0] is Vector3 and legacy_route[1] is Vector3:
			var start_tangent: Vector3 = ((legacy_route[1] as Vector3) - (legacy_route[0] as Vector3)).normalized()
			var start_center: Vector3 = ((legacy_route[0] as Vector3) + (legacy_route[1] as Vector3)) * 0.5
			legacy_route[0] = start_center - start_tangent * 3.5
			legacy_route[1] = start_center + start_tangent * 3.5
		data["route"] = legacy_route
		var old_obstacles: Array = data.get("obstacles", [])
		var resized_obstacles: Array[Vector3] = []
		for obstacle_value: Variant in old_obstacles:
			if obstacle_value is Vector3:
				resized_obstacles.append((obstacle_value as Vector3) * scale_ratio)
		data["obstacles"] = resized_obstacles
		var old_decorations: Array = data.get("decorations", [])
		var resized_decorations: Array[Dictionary] = []
		for decoration_value: Variant in old_decorations:
			if not (decoration_value is Dictionary):
				continue
			var decoration: Dictionary = decoration_value.duplicate(true)
			if decoration.get("position", null) is Vector3:
				decoration["position"] = (decoration["position"] as Vector3) * scale_ratio
			resized_decorations.append(decoration)
		data["decorations"] = resized_decorations
		data["track_width"] = track_width_for_size(size_index)
		legacy_route = data["route"]
		refresh_generated_layout = true
	# Stacje zawsze odtwarzamy z geometrii startu, nie ufamy starym pozycjom.
	data["docking_stations"] = make_docking_stations(legacy_route, float(data.get("track_width", 1.2)))
	data["start_room_bounds"] = _make_start_room_bounds(legacy_route, data["docking_stations"], float(data.get("track_width", 1.2)))
	data["midpoint_station"] = {}
	# Stare zapisane drobiazgi, które leżały na trasie, przenosimy obok jej krawędzi.
	var migrated_decorations: Array = data.get("decorations", [])
	for decoration_value: Variant in migrated_decorations:
		if not (decoration_value is Dictionary):
			continue
		var decoration: Dictionary = decoration_value
		if decoration.get("position", null) is Vector3 and legacy_route.size() >= 2:
			var old_position: Vector3 = decoration["position"]
			var required_gap: float = float(data.get("track_width", 1.2)) * 0.5 + maxf(0.55, _furniture_spacing_for_kind(str(decoration.get("kind", ""))) * 0.32)
			var route_typed: Array[Vector3] = []
			for route_point_value: Variant in legacy_route:
				if route_point_value is Vector3:
					route_typed.append(route_point_value)
			if _distance_to_route_xz(old_position, route_typed, bool(data.get("route_closed", true))) < required_gap:
				var best_index: int = 0
				var best_distance: float = INF
				for route_index: int in range(legacy_route.size() - (0 if bool(data.get("route_closed", true)) else 1)):
					var route_point: Vector3 = legacy_route[route_index]
					var distance: float = Vector2(old_position.x - route_point.x, old_position.z - route_point.z).length()
					if distance < best_distance:
						best_distance = distance
						best_index = route_index
				var next_index: int = (best_index + 1) % legacy_route.size()
				var tangent: Vector3 = (legacy_route[next_index] - legacy_route[best_index]).normalized()
				var side: Vector3 = Vector3(-tangent.z, 0.0, tangent.x)
				var sign_value: float = 1.0 if (old_position - legacy_route[best_index]).dot(side) >= 0.0 else -1.0
				decoration["position"] = legacy_route[best_index] + side * sign_value * required_gap
		decoration["on_track"] = false
	data["decorations"] = migrated_decorations
	data["midpoint_station"] = {}
	# Przenosimy stare przeszkody z pasa jazdy na pobocze.
	if previous_generator_version < 39 and legacy_route.size() >= 2:
		var old_obstacles_for_migration: Array = data.get("obstacles", [])
		var moved_obstacles: Array[Vector3] = []
		for obstacle_value: Variant in old_obstacles_for_migration:
			if not (obstacle_value is Vector3):
				continue
			var obstacle_position: Vector3 = obstacle_value
			var nearest_index: int = 0
			var nearest_distance: float = INF
			var route_limit: int = legacy_route.size() if bool(data.get("route_closed", true)) else legacy_route.size() - 1
			for route_index: int in range(route_limit):
				var next_index: int = (route_index + 1) % legacy_route.size()
				var segment: Vector3 = (legacy_route[next_index] - legacy_route[route_index]).normalized()
				var projection: float = clampf((obstacle_position - legacy_route[route_index]).dot(segment), 0.0, legacy_route[route_index].distance_to(legacy_route[next_index]))
				var closest: Vector3 = legacy_route[route_index] + segment * projection
				var distance_to_segment: float = Vector2(obstacle_position.x - closest.x, obstacle_position.z - closest.z).length()
				if distance_to_segment < nearest_distance:
					nearest_distance = distance_to_segment
					nearest_index = route_index
			var obstacle_next_index: int = (nearest_index + 1) % legacy_route.size()
			var tangent: Vector3 = (legacy_route[obstacle_next_index] - legacy_route[nearest_index]).normalized()
			var side: Vector3 = Vector3(-tangent.z, 0.0, tangent.x)
			var sign_value: float = 1.0 if (obstacle_position - legacy_route[nearest_index]).dot(side) >= 0.0 else -1.0
			var radius: float = [0.16, 0.19, 0.23, 0.27][moved_obstacles.size() % 4]
			var lateral: float = float(data.get("track_width", 1.2)) * 0.5 + radius + 0.38
			var moved: Vector3 = legacy_route[nearest_index] + side * sign_value * lateral
			moved_obstacles.append(moved)
		data["obstacles"] = moved_obstacles
		data["dirt_pickup_count"] = 9 + int(data.get("complexity", 2))
	data["generator_version"] = maxi(previous_generator_version, 43)
	if previous_generator_version < 24 or refresh_generated_layout or not data.has("room_partitions") or not data.has("room_bounds") or bool(data.get("manual_editor", false)):
		var room_rng := RandomNumberGenerator.new()
		room_rng.seed = int(data.get("seed", 1)) + 91421
		var room_layout: Dictionary = _generate_room_layout(_route_room_bounds(legacy_route), room_rng, int(data.get("complexity", 2)), str(data.get("theme", "apartment")))
		data["room_partitions"] = room_layout.get("partitions", [])
		data["room_bounds"] = room_layout.get("rooms", [])
	if not data.has("decorations") or typeof(data["decorations"]) != TYPE_ARRAY:
		data["decorations"] = []
	if not data.has("dirt_pickup_count"):
		data["dirt_pickup_count"] = 9 + int(data.get("complexity", 2))
	data["dirt_pickup_count"] = mini(maxi(int(data.get("dirt_pickup_count", 12)), 0), 12)
	return data

static func validate(data: Dictionary) -> Dictionary:
	var route_value: Variant = data.get("route", [])
	if typeof(route_value) != TYPE_ARRAY:
		return {"valid": false, "reason": "Brak listy punktów trasy."}
	var route: Array = route_value
	var route_is_closed: bool = bool(data.get("route_closed", true))
	if route.size() < 6 or route.size() > 36:
		return {"valid": false, "reason": "Nieprawidłowa liczba punktów trasy."}
	for point_value: Variant in route:
		if typeof(point_value) != TYPE_VECTOR3:
			return {"valid": false, "reason": "Nieprawidłowy punkt trasy."}
	var segment_count: int = route.size() if route_is_closed else route.size() - 1
	var lane_clearance: float = float(data.get("track_width", 1.2)) + 0.35
	for i: int in range(segment_count):
		var next_index: int = (i + 1) % route.size() if route_is_closed else i + 1
		if route[i].distance_to(route[next_index]) < (1.0 if int(data.get("generator_version", 1)) >= 24 else 5.0):
			return {"valid": false, "reason": "Punkty są zbyt blisko siebie — wygeneruj ponownie."}
	for i: int in range(segment_count):
		var next_i: int = (i + 1) % route.size() if route_is_closed else i + 1
		var a: Vector2 = Vector2(route[i].x, route[i].z)
		var b: Vector2 = Vector2(route[next_i].x, route[next_i].z)
		for j: int in range(i + 1, segment_count):
			if j == i + 1 or (route_is_closed and i == 0 and j == segment_count - 1):
				continue
			var next_j: int = (j + 1) % route.size() if route_is_closed else j + 1
			var c: Vector2 = Vector2(route[j].x, route[j].z)
			var d: Vector2 = Vector2(route[next_j].x, route[next_j].z)
			if _segments_cross(a, b, c, d):
				return {"valid": false, "reason": "Trasa przecina samą siebie — wygeneruj ponownie."}
			if int(data.get("generator_version", 1)) >= 25 and _segment_distance(a, b, c, d) < lane_clearance:
				return {"valid": false, "reason": "Pasy toru nachodzą na siebie lub są zbyt blisko — wygeneruj inny układ."}
	if int(data.get("generator_version", 1)) >= 2:
		var start_vector: Vector3 = route[1] - route[0]
		var minimum_start_length: float = 3.0 if int(data.get("generator_version", 1)) >= 24 else (10.0 if int(data.get("generator_version", 1)) >= 23 else (32.0 if int(data.get("generator_version", 1)) >= 6 else 20.0))
		if start_vector.length() < minimum_start_length or absf(start_vector.z) > 0.05:
			return {"valid": false, "reason": "Odcinek startowy musi być prosty i mieć odpowiednią długość."}
	if not route_is_closed:
		var minimum_endpoint_gap: float = 2.5 if int(data.get("generator_version", 1)) >= 24 else (6.0 if int(data.get("generator_version", 1)) >= 23 else 20.0)
		if route[0].distance_to(route[route.size() - 1]) < minimum_endpoint_gap:
			return {"valid": false, "reason": "Odcinek musi mieć wyraźnie oddzielony początek i koniec."}

	var obstacle_value: Variant = data.get("obstacles", [])
	if typeof(obstacle_value) != TYPE_ARRAY or (obstacle_value as Array).size() > 60:
		return {"valid": false, "reason": "Nieprawidłowa lista przeszkód."}
	for obstacle: Variant in obstacle_value:
		if typeof(obstacle) != TYPE_VECTOR3:
			return {"valid": false, "reason": "Nieprawidłowe położenie przeszkody."}
	var theme: String = str(data.get("theme", "apartment"))
	if not ["apartment", "kitchen", "bedroom", "futuristic", "office", "pro_league", "cleaning_hall"].has(theme):
		return {"valid": false, "reason": "Nieznany motyw trasy."}
	var width: float = float(data.get("track_width", 1.2))
	if width < 0.8 or width > 2.45:
		return {"valid": false, "reason": "Nieprawidłowa szerokość trasy."}
	if route_is_closed:
		var route_clearance: float = width + 0.35
		if int(data.get("generator_version", 1)) >= 4 and not _route_has_safe_clearance(route, route_clearance):
			return {"valid": false, "reason": "Ściany trasy byłyby zbyt blisko siebie — wygeneruj inny układ."}
	var stations_value: Variant = data.get("docking_stations", [])
	if typeof(stations_value) != TYPE_ARRAY or (stations_value as Array).size() != 4:
		return {"valid": false, "reason": "Trasa musi mieć cztery stacje dokujące obok siebie przy starcie."}
	var station_sides: Array[String] = []
	var start_tangent: Vector3 = (route[1] - route[0]).normalized()
	var start_side: Vector3 = Vector3(-start_tangent.z, 0.0, start_tangent.x).normalized()
	var start_center: Vector3 = (route[0] + route[1]) * 0.5
	var station_lateral_signs: Array[float] = []
	var station_longitudinal_positions: Array[float] = []
	for station: Variant in stations_value:
		if typeof(station) != TYPE_DICTIONARY or not (station as Dictionary).has("position") or typeof((station as Dictionary)["position"]) != TYPE_VECTOR3:
			return {"valid": false, "reason": "Nieprawidłowe położenie stacji dokującej."}
		var station_position: Vector3 = (station as Dictionary)["position"]
		var lateral_signed: float = (station_position - start_center).dot(start_side)
		var longitudinal_signed: float = (station_position - start_center).dot(start_tangent)
		if lateral_signed < width * 0.5 + 0.45 or longitudinal_signed < -3.5 or longitudinal_signed > 2.1:
			return {"valid": false, "reason": "Stacje muszą stać po prawej stronie, poza jezdnią i w obrębie prostej startowej."}
		station_lateral_signs.append(lateral_signed)
		station_longitudinal_positions.append(longitudinal_signed)
		var side_name: String = str((station as Dictionary).get("side", ""))
		if side_name != "start_right":
			return {"valid": false, "reason": "Wszystkie cztery stacje muszą należeć do prawej strefy startowej."}
		station_sides.append(side_name)
		var expected_facing: Vector3 = -start_side * signf(lateral_signed)
		var station_rotation: float = float((station as Dictionary).get("rotation", 0.0))
		var actual_facing := Vector3(-sin(station_rotation), 0.0, -cos(station_rotation))
		if actual_facing.dot(expected_facing) < 0.90:
			return {"valid": false, "reason": "Front stacji musi być skierowany w stronę toru."}
	if station_sides.size() != 4 or station_lateral_signs.size() != 4:
		return {"valid": false, "reason": "Trasa musi mieć cztery stacje startowe."}
	for station_index: int in range(4):
		if station_sides[station_index] != "start_right" or station_lateral_signs[station_index] <= 0.0:
			return {"valid": false, "reason": "Wszystkie cztery stacje muszą stać po prawej stronie prostej startowej."}
	if station_longitudinal_positions.size() != 4:
		return {"valid": false, "reason": "Nieprawidłowa liczba stacji startowych."}
	for longitudinal_value: float in station_longitudinal_positions:
		if absf(longitudinal_value - station_longitudinal_positions[0]) > 0.25:
			return {"valid": false, "reason": "Cztery stacje muszą stać w jednej linii prostej."}
	for station_index: int in range(1, 4):
		if station_lateral_signs[station_index] <= station_lateral_signs[station_index - 1]:
			return {"valid": false, "reason": "Stacje muszą stać obok siebie w równym rzędzie."}
	if int(data.get("generator_version", 1)) >= 11:
		if int(data.get("furniture_density", 2)) not in range(5) or int(data.get("obstacle_layout", 1)) not in range(3):
			return {"valid": false, "reason": "Nieprawidłowe ustawienia rozmieszczenia mebli lub przeszkód."}
		if int(data.get("furniture_count", 0)) < 5 or int(data.get("furniture_count", 0)) > 80:
			return {"valid": false, "reason": "Nieprawidłowa liczba mebli."}
	var decorations_value: Variant = data.get("decorations", [])
	if typeof(decorations_value) != TYPE_ARRAY or (decorations_value as Array).size() > 300:
		return {"valid": false, "reason": "Nieprawidłowa lista dekoracji."}
	for decoration: Variant in decorations_value:
		if typeof(decoration) != TYPE_DICTIONARY or not (decoration as Dictionary).has("kind") or not (decoration as Dictionary).has("position") or typeof((decoration as Dictionary)["position"]) != TYPE_VECTOR3:
			return {"valid": false, "reason": "Nieprawidłowa pozycja dekoracji."}
		var decoration_data: Dictionary = decoration as Dictionary
		if bool(decoration_data.get("on_track", false)) and ["plant", "sofa", "table", "lamp", "bookshelf", "chair", "bed", "cabinet", "fridge", "bathtub", "sink", "kitchen_counter", "washing_machine", "shower", "wardrobe", "nightstand", "coffee_table", "side_table", "shoe_rack", "ottoman", "floor_mirror", "rug", "pet_bed", "pet_tunnel", "scratching_post", "fish_tank", "tv", "tv_wall", "trash_bin", "floor_fan", "coat_rack", "radiator", "toilet", "umbrella_stand", "water_dispenser", "speaker", "monitor", "laptop", "microwave", "toaster", "kettle", "fruit_bowl", "dish_rack", "towel_rack", "hanging_plant", "wall_clock", "vase", "candle", "backpack", "suitcase", "toy_car", "pet_bowl"].has(str(decoration_data.get("kind", ""))):
			return {"valid": false, "reason": "Meble nie mogą być umieszczane na jezdni."}
	var animal_total: int = 0
	for decoration: Dictionary in decorations_value:
		if ["cat", "dog", "rabbit", "bearded_dragon", "parrot", "hamster", "guinea_pig", "turtle", "hedgehog", "ferret"].has(str(decoration.get("kind", ""))):
			animal_total += 1
	if animal_total != clampi(int(data.get("animal_count", animal_total)), 0, 10):
		return {"valid": false, "reason": "Liczba zwierząt nie zgadza się z ustawieniami generatora."}
	return {"valid": true, "reason": "Trasa ma poprawny układ, cztery stacje startowe i %d dekoracji." % (decorations_value as Array).size()}
