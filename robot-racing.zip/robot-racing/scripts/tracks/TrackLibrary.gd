class_name TrackLibrary
extends RefCounted

const TrackGeneratorScript = preload("res://scripts/tracks/TrackGenerator.gd")
## Lokalna biblioteka tras wygenerowanych. Zapisuje wyłącznie dane i parametry,
## nigdy kod ani wykonywalne skrypty dostarczane przez dodatki.

const SAVE_SECTION: String = "custom_tracks"
const SAVE_KEY: String = "saved"
const MAX_SAVED: int = 40

static func get_saved_tracks() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for entry: Variant in SaveManager.get_array(SAVE_SECTION, SAVE_KEY):
		if typeof(entry) == TYPE_DICTIONARY:
			var data: Dictionary = TrackGeneratorScript.normalize_legacy_data(entry)
			if bool(data.get("generated", false)) and bool(TrackGeneratorScript.validate(data).get("valid", false)):
				data["scene"] = TrackGeneratorScript.PROCEDURAL_SCENE
				var saved_width: float = float(data.get("track_width", 1.2))
				if saved_width > 3.0:
					saved_width *= 0.1
				data["track_width"] = clampf(saved_width, 0.8, 1.8)
				data["max_racers"] = clampi(int(data.get("max_racers", 5)), 2, 5)
				result.append(data)
	return result


static func save_track(data: Dictionary) -> bool:
	var clean: Dictionary = TrackGeneratorScript.normalize_legacy_data(data)
	var validation: Dictionary = TrackGeneratorScript.validate(clean)
	if not bool(validation.get("valid", false)):
		return false
	var tracks: Array[Dictionary] = get_saved_tracks()
	clean["generated"] = true
	clean["scene"] = TrackGeneratorScript.PROCEDURAL_SCENE
	# Zapisana trasa staje się stałym projektem, a nie sesją losowania.
	clean.erase("random_route_session")
	var track_id: String = str(clean.get("id", ""))
	if track_id.is_empty():
		return false
	var replaced: bool = false
	for i: int in range(tracks.size()):
		if str(tracks[i].get("id", "")) == track_id:
			tracks[i] = clean
			replaced = true
			break
	if not replaced:
		tracks.append(clean)
	while tracks.size() > MAX_SAVED:
		tracks.pop_front()
	SaveManager.set_value(SAVE_SECTION, SAVE_KEY, tracks)
	SaveManager.save_now()
	return true


static func get_rating(track_id: String) -> Dictionary:
	var ratings: Dictionary = SaveManager.get_dict("custom_track_ratings", "ratings")
	var value: Variant = ratings.get(track_id, {})
	return value.duplicate(true) if value is Dictionary else {}


static func rate_track(track_id: String, rating: int) -> bool:
	if track_id.is_empty() or rating < 1 or rating > 5:
		return false
	var ratings: Dictionary = SaveManager.get_dict("custom_track_ratings", "ratings")
	var entry: Dictionary = ratings.get(track_id, {})
	var total: int = int(entry.get("total", 0))
	var count: int = int(entry.get("count", 0))
	var previous_rating: int = int(entry.get("user_rating", 0))
	if previous_rating > 0:
		total -= previous_rating
	else:
		count += 1
	total += rating
	ratings[track_id] = {"total": total, "count": count, "average": float(total) / float(maxi(count, 1)), "user_rating": rating}
	SaveManager.set_value("custom_track_ratings", "ratings", ratings)
	SaveManager.save_now()
	return true


static func get_track(track_id: String) -> Dictionary:
	for data: Dictionary in get_saved_tracks():
		if str(data.get("id", "")) == track_id:
			return data
	return {}


static func delete_track(track_id: String) -> bool:
	var tracks: Array[Dictionary] = get_saved_tracks()
	var kept: Array[Dictionary] = []
	for data: Dictionary in tracks:
		if str(data.get("id", "")) != track_id:
			kept.append(data)
	if kept.size() == tracks.size():
		return false
	tracks = kept
	SaveManager.set_value(SAVE_SECTION, SAVE_KEY, tracks)
	SaveManager.save_now()
	return true
