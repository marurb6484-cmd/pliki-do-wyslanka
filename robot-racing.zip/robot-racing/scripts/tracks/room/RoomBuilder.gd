class_name RoomBuilder
extends RefCounted

const TrackGeneratorScript = preload("res://scripts/tracks/TrackGenerator.gd")
## Buduje wygląd pomieszczeń: ściany z listwami i panelami, okna z widokiem,
## sufit z lampami, plamy światła i światła meblowe. Styl każdego pokoju bierze
## z RoomStyleCatalog, a porę dnia z data["time_of_day"].
##
## Zasady oświetlenia:
##  - DZIEŃ: lampy zgaszone, równe światło otoczenia; okna pokazują tylko widok
##    (światło nie wylewa się z okien),
##  - WIECZÓR: lampy świecą częściowo, ciepłe światło otoczenia,
##  - NOC: świecą lampy sufitowe, stojące i na szafkach; jeden pokój jest ciemny
##    (bez lamp) i oświetla go tylko robot.
## Światła rzeczywiste (OmniLight3D) działają od jakości ŚREDNIEJ; na NISKIEJ
## zostają świecące korpusy lamp i plamy światła na podłodze.

const WALL_HEIGHT: float = 2.75
const SKIN_OFFSET: float = 0.025
const DOOR_HEIGHT: float = 2.05

var host: Node3D
var data: Dictionary = {}
var rooms: Array = []
var styles: Array[Dictionary] = []
var tod_id: String = "day"
var tod: Dictionary = {}
var lamp_strength: float = 0.0
var preview_mode: bool = false
var track_width: float = 1.2
var route: Array = []

var lights: Array[OmniLight3D] = []
var negative_lights: Array[OmniLight3D] = []

var _bounds: Rect2 = Rect2()
var _trim_material: StandardMaterial3D
var _fixture_materials: Dictionary = {}
var _light_budget: int = 10
var _partition_openings: Array[Dictionary] = []


static func create(host_node: Node3D, track_data: Dictionary, preview: bool) -> RoomBuilder:
	var builder := RoomBuilder.new()
	builder.host = host_node
	builder.data = track_data
	builder.preview_mode = preview
	builder._prepare()
	return builder


func _prepare() -> void:
	RoomStyleCatalog.ensure_defaults(data)
	rooms = data.get("room_bounds", [])
	styles = RoomStyleCatalog.assign_room_styles(data)
	tod_id = str(data.get("time_of_day", "day"))
	tod = RoomStyleCatalog.get_time_of_day(tod_id)
	lamp_strength = float(tod.get("lamps", 0.0))
	track_width = float(data.get("track_width", 1.2))
	route = data.get("route", [])
	var min_x: float = INF
	var max_x: float = -INF
	var min_z: float = INF
	var max_z: float = -INF
	for room: Dictionary in rooms:
		min_x = minf(min_x, float(room["min_x"]))
		max_x = maxf(max_x, float(room["max_x"]))
		min_z = minf(min_z, float(room["min_z"]))
		max_z = maxf(max_z, float(room["max_z"]))
	if not rooms.is_empty():
		_bounds = Rect2(min_x, min_z, max_x - min_x, max_z - min_z)
	_trim_material = StandardMaterial3D.new()
	_trim_material.albedo_color = Color("#efece4")
	_trim_material.roughness = 0.5
	_collect_partition_openings()


func has_rooms() -> bool:
	return not rooms.is_empty() and styles.size() == rooms.size()


func floor_style_for(room_index: int) -> String:
	if room_index < styles.size():
		return str(styles[room_index].get("floor", "oak_planks"))
	return "oak_planks"


## Parametry środowiska dla TrackBase (ustawiane przed _build_environment).
func apply_environment(track: TrackBase) -> void:
	track.ambient_color = tod.get("ambient_color", track.ambient_color)
	track.ambient_energy = float(tod.get("ambient_energy", track.ambient_energy))
	track.sun_energy = float(tod.get("sun_energy", track.sun_energy))
	track.sun_color = tod.get("sun_color", track.sun_color)
	track.background_color = tod.get("background", track.background_color)


func ceiling_color() -> Color:
	return tod.get("ceiling_tint", Color(0.95, 0.93, 0.88))


# =========================================================
# ŚCIANY
# =========================================================

func _collect_partition_openings() -> void:
	for partition: Dictionary in data.get("room_partitions", []):
		var vertical: bool = bool(partition.get("vertical", true))
		var axis: float = float(partition.get("axis", 0.0))
		var from_value: float = float(partition.get("min", 0.0))
		var to_value: float = float(partition.get("max", 0.0))
		var openings: Array[Vector2] = TrackGeneratorScript.get_room_partition_openings(route, vertical, axis, track_width, from_value, to_value, bool(data.get("route_closed", data.get("generated", true))))
		_partition_openings.append({"vertical": vertical, "axis": axis, "min": from_value, "max": to_value, "openings": openings})


func build_walls() -> void:
	if not has_rooms():
		return
	var root := Node3D.new()
	root.name = "WykonczenieScian"
	host.add_child(root)
	for room_index: int in range(rooms.size()):
		var room: Dictionary = rooms[room_index]
		var style: Dictionary = styles[room_index]
		for side: int in range(4):
			_build_room_side(root, room_index, room, style, side)


func _build_room_side(root: Node3D, room_index: int, room: Dictionary, style: Dictionary, side: int) -> void:
	var vertical_line: bool = side >= 2          # ściana x = const
	var line_value: float = 0.0
	var range_from: float = 0.0
	var range_to: float = 0.0
	var normal := Vector3.ZERO
	match side:
		0:
			line_value = float(room["min_z"])
			range_from = float(room["min_x"])
			range_to = float(room["max_x"])
			normal = Vector3(0, 0, 1)
		1:
			line_value = float(room["max_z"])
			range_from = float(room["min_x"])
			range_to = float(room["max_x"])
			normal = Vector3(0, 0, -1)
		2:
			line_value = float(room["min_x"])
			range_from = float(room["min_z"])
			range_to = float(room["max_z"])
			normal = Vector3(1, 0, 0)
		_:
			line_value = float(room["max_x"])
			range_from = float(room["min_z"])
			range_to = float(room["max_z"])
			normal = Vector3(-1, 0, 0)
	var is_outer: bool = _is_outer_line(vertical_line, line_value)
	# Każda ściana (także zewnętrzna i granica pokoju) musi respektować
	# rzeczywisty przebieg jezdni. Wcześniej pomijaliśmy ściany zewnętrzne,
	# a część ścian nie była identyczna z wpisem w room_partitions.
	var openings: Array[Vector2] = _openings_on_line(vertical_line, line_value, range_from, range_to)
	var route_openings: Array[Vector2] = TrackGeneratorScript.get_room_partition_openings(
		route, vertical_line, line_value, track_width, range_from, range_to,
		bool(data.get("route_closed", data.get("generated", true)))
	)
	openings.append_array(route_openings)
	openings = _merge_openings(openings, range_from, range_to)

	var wall_id: String = str(style.get("wall", "paint_warm_white"))
	var dado_id: String = str(style.get("dado", ""))
	var segments: Array[Vector2] = _segments_without(range_from, range_to, openings)
	segments = _segments_outside_start_room(vertical_line, line_value, segments)
	# Ostateczna kontrola każdej bryły ściany: jeśli choć fragment segmentu
	# zbliża się do jezdni, cały segment znika (razem z listwą i nadprożem).
	var route_is_closed: bool = bool(data.get("route_closed", data.get("generated", true)))
	var safe_segments: Array[Vector2] = []
	for segment: Vector2 in segments:
		if TrackGeneratorScript.wall_segment_clear_of_route(route, vertical_line, line_value, segment.x, segment.y, track_width, route_is_closed, 1.65):
			safe_segments.append(segment)
	segments = safe_segments
	for segment: Vector2 in segments:
		_add_wall_band(root, vertical_line, line_value, normal, segment.x, segment.y, 0.0, WALL_HEIGHT, wall_id, dado_id)
		_add_baseboard(root, vertical_line, line_value, normal, segment.x, segment.y)
	# Nie budujemy nadproża w otworze wyznaczonym przez tor.
	# Z góry nawet ściana pozostawiona tylko nad wysokością drzwi wyglądała
	# jak przeszkoda przecinająca trasę.
	var start_bounds: Dictionary = data.get("start_room_bounds", {})
	var crown_crosses_start: bool = _line_crosses_start_room(vertical_line, line_value, start_bounds)
	if not crown_crosses_start:
		# Listwa przy suficie również musi mieć przerwę nad przejazdem.
		# Pełna listwa wyglądała z kamery z góry jak ściana pozostawiona na torze.
		for crown_segment: Vector2 in segments:
			_add_crown(root, vertical_line, line_value, normal, crown_segment.x, crown_segment.y)
	if is_outer:
		_add_windows(root, room_index, room, style, vertical_line, line_value, normal, range_from, range_to)


func _merge_openings(source: Array[Vector2], range_from: float, range_to: float) -> Array[Vector2]:
	var clipped: Array[Vector2] = []
	for opening: Vector2 in source:
		var a: float = maxf(range_from, opening.x)
		var b: float = minf(range_to, opening.y)
		if b - a > 0.08:
			clipped.append(Vector2(a, b))
	clipped.sort_custom(func(a: Vector2, b: Vector2) -> bool: return a.x < b.x)
	var merged: Array[Vector2] = []
	for opening: Vector2 in clipped:
		if merged.is_empty() or opening.x > merged[merged.size() - 1].y + 0.12:
			merged.append(opening)
		else:
			var previous: Vector2 = merged.pop_back()
			previous.y = maxf(previous.y, opening.y)
			merged.append(previous)
	return merged


## Rozcina wizualne ściany pomieszczeń na granicy chronionego pokoju startowego.
## Dzięki temu ani ściana, ani nadproże/listwa nie mogą przebiegać przez start.
func _segments_outside_start_room(vertical_line: bool, line_value: float, source: Array[Vector2]) -> Array[Vector2]:
	var result: Array[Vector2] = []
	var bounds: Dictionary = data.get("start_room_bounds", {})
	if bounds.is_empty() or not _line_crosses_start_room(vertical_line, line_value, bounds):
		return source.duplicate()
	var protected_min: float = float(bounds.get("min_z", INF)) if vertical_line else float(bounds.get("min_x", INF))
	var protected_max: float = float(bounds.get("max_z", -INF)) if vertical_line else float(bounds.get("max_x", -INF))
	for segment: Vector2 in source:
		if segment.y <= protected_min or segment.x >= protected_max:
			result.append(segment)
			continue
		if segment.x < protected_min:
			result.append(Vector2(segment.x, minf(segment.y, protected_min)))
		if segment.y > protected_max:
			result.append(Vector2(maxf(segment.x, protected_max), segment.y))
	return result


func _line_crosses_start_room(vertical_line: bool, line_value: float, bounds: Dictionary) -> bool:
	if bounds.is_empty():
		return false
	if vertical_line:
		return line_value >= float(bounds.get("min_x", INF)) - 0.08 and line_value <= float(bounds.get("max_x", -INF)) + 0.08
	return line_value >= float(bounds.get("min_z", INF)) - 0.08 and line_value <= float(bounds.get("max_z", -INF)) + 0.08


func _is_outer_line(vertical_line: bool, line_value: float) -> bool:
	if vertical_line:
		return absf(line_value - _bounds.position.x) < 0.05 or absf(line_value - _bounds.end.x) < 0.05
	return absf(line_value - _bounds.position.y) < 0.05 or absf(line_value - _bounds.end.y) < 0.05


func _openings_on_line(vertical_line: bool, line_value: float, range_from: float, range_to: float) -> Array[Vector2]:
	var result: Array[Vector2] = []
	for partition: Dictionary in _partition_openings:
		if bool(partition["vertical"]) != vertical_line or absf(float(partition["axis"]) - line_value) > 0.05:
			continue
		for opening: Vector2 in partition["openings"]:
			if opening.y > range_from and opening.x < range_to:
				result.append(opening)
	result.sort_custom(func(a: Vector2, b: Vector2) -> bool: return a.x < b.x)
	return result


func _segments_without(range_from: float, range_to: float, openings: Array[Vector2]) -> Array[Vector2]:
	var result: Array[Vector2] = []
	var cursor: float = range_from
	for opening: Vector2 in openings:
		var opening_start: float = maxf(opening.x, range_from)
		var opening_end: float = minf(opening.y, range_to)
		if opening_start - cursor > 0.08:
			result.append(Vector2(cursor, opening_start))
		cursor = maxf(cursor, opening_end)
	if range_to - cursor > 0.08:
		result.append(Vector2(cursor, range_to))
	return result


func _line_point(vertical_line: bool, line_value: float, normal: Vector3, along: float, y: float) -> Vector3:
	var point: Vector3 = Vector3(line_value, y, along) if vertical_line else Vector3(along, y, line_value)
	return point + normal * SKIN_OFFSET


func _add_wall_band(root: Node3D, vertical_line: bool, line_value: float, normal: Vector3, from_along: float, to_along: float, y_from: float, y_to: float, wall_id: String, dado_id: String) -> void:
	if not dado_id.is_empty() and y_from < 0.01:
		var dado_height: float = 0.95
		_add_quad(root, vertical_line, line_value, normal, from_along, to_along, 0.0, dado_height, dado_id)
		_add_quad(root, vertical_line, line_value, normal, from_along, to_along, dado_height, y_to, wall_id)
		# Listwa nad panelem.
		var rail := MeshInstance3D.new()
		var rail_mesh := BoxMesh.new()
		var length: float = to_along - from_along
		rail_mesh.size = Vector3(0.05, 0.04, length) if vertical_line else Vector3(length, 0.04, 0.05)
		rail.mesh = rail_mesh
		rail.material_override = _trim_material
		rail.position = _line_point(vertical_line, line_value, normal, (from_along + to_along) * 0.5, dado_height) + normal * 0.025
		rail.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(rail)
	else:
		_add_quad(root, vertical_line, line_value, normal, from_along, to_along, y_from, y_to, wall_id)


func _add_quad(root: Node3D, vertical_line: bool, line_value: float, normal: Vector3, from_along: float, to_along: float, y_from: float, y_to: float, material_id: String) -> void:
	var p0: Vector3 = _line_point(vertical_line, line_value, normal, from_along, y_from)
	var p1: Vector3 = _line_point(vertical_line, line_value, normal, to_along, y_from)
	var p2: Vector3 = _line_point(vertical_line, line_value, normal, to_along, y_to)
	var p3: Vector3 = _line_point(vertical_line, line_value, normal, from_along, y_to)
	var tile: float = RoomTextures.wall_tile_size(material_id)
	var uv_w: float = (to_along - from_along) / tile
	var uv_h: float = (y_to - y_from) / tile
	var instance := MeshInstance3D.new()
	instance.mesh = _make_quad(p0, p1, p2, p3, normal, uv_w, uv_h)
	instance.material_override = _wall_material_for(material_id)
	instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(instance)


func _wall_material_for(material_id: String) -> StandardMaterial3D:
	# Ściany w nocy i wieczorem są ciemniejsze (mniej światła ogólnego).
	var dim: float = float(tod.get("wall_dim", 1.0))
	if is_equal_approx(dim, 1.0):
		return RoomTextures.wall_material(material_id)
	var key: String = "dim_%s_%s" % [material_id, tod_id]
	if _fixture_materials.has(key):
		return _fixture_materials[key]
	var material: StandardMaterial3D = RoomTextures.wall_material(material_id).duplicate() as StandardMaterial3D
	material.albedo_color = Color(dim, dim, dim)
	_fixture_materials[key] = material
	return material


## Czworokąt z poprawną kolejnością wierzchołków (przód Godota = zgodnie z ruchem wskazówek zegara).
func _make_quad(p0: Vector3, p1: Vector3, p2: Vector3, p3: Vector3, normal: Vector3, uv_w: float, uv_h: float) -> ArrayMesh:
	var verts := PackedVector3Array([p0, p1, p2, p3])
	var uvs := PackedVector2Array([Vector2(0, uv_h), Vector2(uv_w, uv_h), Vector2(uv_w, 0), Vector2(0, 0)])
	var norms := PackedVector3Array([normal, normal, normal, normal])
	var indices := PackedInt32Array()
	if (p1 - p0).cross(p2 - p0).dot(normal) < 0.0:
		indices.append_array([0, 1, 2, 0, 2, 3])
	else:
		indices.append_array([0, 2, 1, 0, 3, 2])
	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = norms
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = indices
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return mesh


func _add_baseboard(root: Node3D, vertical_line: bool, line_value: float, normal: Vector3, from_along: float, to_along: float) -> void:
	var length: float = to_along - from_along
	var board := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = Vector3(0.08, 0.10, length) if vertical_line else Vector3(length, 0.10, 0.08)
	board.mesh = mesh
	board.material_override = _trim_material
	board.position = _line_point(vertical_line, line_value, normal, (from_along + to_along) * 0.5, 0.05) + normal * 0.03
	board.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(board)


func _add_crown(root: Node3D, vertical_line: bool, line_value: float, normal: Vector3, from_along: float, to_along: float) -> void:
	var length: float = to_along - from_along
	var crown := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = Vector3(0.08, 0.12, length) if vertical_line else Vector3(length, 0.12, 0.08)
	crown.mesh = mesh
	crown.material_override = _trim_material
	crown.position = _line_point(vertical_line, line_value, normal, (from_along + to_along) * 0.5, WALL_HEIGHT - 0.06) + normal * 0.04
	crown.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(crown)


# =========================================================
# OKNA
# =========================================================

func _add_windows(root: Node3D, room_index: int, room: Dictionary, style: Dictionary, vertical_line: bool, line_value: float, normal: Vector3, range_from: float, range_to: float) -> void:
	var wall_start: float = _bounds.position.y if vertical_line else _bounds.position.x
	var wall_length: float = _bounds.size.y if vertical_line else _bounds.size.x
	for fraction: float in RoomFurnisher.WINDOW_FRACTIONS:
		var along: float = wall_start + wall_length * fraction
		if along < range_from + 0.95 or along > range_to - 0.95:
			continue
		if not TrackGeneratorScript.wall_segment_clear_of_route(route, vertical_line, line_value, along - 1.0, along + 1.0, track_width, bool(data.get("route_closed", data.get("generated", true))), 1.65):
			continue
		_build_window(root, style, vertical_line, line_value, normal, along)


func _build_window(root: Node3D, style: Dictionary, vertical_line: bool, line_value: float, normal: Vector3, along: float) -> void:
	var width: float = 1.65
	var height: float = 1.15
	var center_y: float = 1.45
	var window := Node3D.new()
	window.name = "Okno"
	root.add_child(window)

	# Widok za oknem (nieoświetlany - to świat na zewnątrz).
	var view_material := StandardMaterial3D.new()
	view_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	view_material.albedo_texture = RoomTextures.window_view(str(tod.get("window_view", "day")))
	var view := MeshInstance3D.new()
	var view_mesh := QuadMesh.new()
	view_mesh.size = Vector2(width, height)
	view.mesh = view_mesh
	view.material_override = view_material
	view.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	view.position = Vector3(0, 0, 0.012)
	window.add_child(view)

	# Szyba: delikatnie przyciemniona, z lekkim odbiciem.
	var glass_material := StandardMaterial3D.new()
	glass_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	glass_material.albedo_color = Color(0.75, 0.88, 1.0, 0.10 if tod_id == "day" else 0.18)
	glass_material.roughness = 0.05
	glass_material.metallic = 0.2
	glass_material.cull_mode = BaseMaterial3D.CULL_DISABLED
	var glass := MeshInstance3D.new()
	var glass_mesh := QuadMesh.new()
	glass_mesh.size = Vector2(width, height)
	glass.mesh = glass_mesh
	glass.material_override = glass_material
	glass.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	glass.position = Vector3(0, 0, 0.03)
	window.add_child(glass)

	# Rama, szprosy i parapet (z lokalnym +Z skierowanym do wnętrza pokoju).
	var frame_depth: float = 0.06
	var frame_t: float = 0.055
	var parts: Array[Array] = [
		[Vector3(width + frame_t * 2.0, frame_t, frame_depth), Vector3(0, height * 0.5 + frame_t * 0.5, 0.08)],
		[Vector3(width + frame_t * 2.0, frame_t, frame_depth), Vector3(0, -height * 0.5 - frame_t * 0.5, 0.08)],
		[Vector3(frame_t, height, frame_depth), Vector3(-width * 0.5 - frame_t * 0.5, 0, 0.08)],
		[Vector3(frame_t, height, frame_depth), Vector3(width * 0.5 + frame_t * 0.5, 0, 0.08)],
		[Vector3(0.035, height, 0.04), Vector3(0, 0, 0.06)],
		[Vector3(width, 0.035, 0.04), Vector3(0, 0.2, 0.06)],
		[Vector3(width + 0.18, 0.045, 0.16), Vector3(0, -height * 0.5 - frame_t - 0.07, 0.25)],
	]
	for part: Array in parts:
		var piece := MeshInstance3D.new()
		var box := BoxMesh.new()
		box.size = part[0]
		piece.mesh = box
		piece.material_override = _trim_material
		piece.position = part[1]
		piece.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		window.add_child(piece)

	# Zasłony w salonie, sypialni i pokoju dziecięcym.
	if str(style.get("type", "")) in ["living", "bedroom", "kids", "playroom"]:
		var curtain_material := StandardMaterial3D.new()
		var wall_def: Dictionary = RoomStyleCatalog.WALLS.get(str(style.get("wall", "paint_sand")), RoomStyleCatalog.WALLS["paint_sand"])
		curtain_material.albedo_color = (wall_def.get("accent", wall_def.get("color", Color("#c8b89c"))) as Color).darkened(0.12)
		curtain_material.roughness = 0.95
		for sign_value: float in [-1.0, 1.0]:
			var curtain := MeshInstance3D.new()
			var curtain_mesh := BoxMesh.new()
			curtain_mesh.size = Vector3(0.22, height + 0.18, 0.06)
			curtain.mesh = curtain_mesh
			curtain.material_override = curtain_material
			curtain.position = Vector3(sign_value * (width * 0.5 + 0.18), 0.0, 0.08)
			curtain.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			window.add_child(curtain)
		var rod := MeshInstance3D.new()
		var rod_mesh := BoxMesh.new()
		rod_mesh.size = Vector3(width + 0.36, 0.025, 0.025)
		rod.mesh = rod_mesh
		rod.material_override = _trim_material
		rod.position = Vector3(0, height * 0.5 + 0.10, 0.28)
		window.add_child(rod)

	# Ustawienie okna na ścianie: lokalne +Z = normalna do wnętrza.
	var base: Vector3 = _line_point(vertical_line, line_value, normal, along, center_y)
	window.position = base
	window.rotation.y = atan2(normal.x, normal.z)


# =========================================================
# ŚWIATŁA SUFITOWE I PLAMY ŚWIATŁA
# =========================================================

func _lamp_color(light_id: String) -> Color:
	return RoomStyleCatalog.LAMP_KELVIN.get(light_id, RoomStyleCatalog.LAMP_KELVIN["warm"])


func _fixture_material(color: Color, strength: float) -> StandardMaterial3D:
	var key: String = "fixture_%s_%.2f" % [color.to_html(), strength]
	if _fixture_materials.has(key):
		return _fixture_materials[key]
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(0.95, 0.94, 0.9)
	material.roughness = 0.4
	material.emission_enabled = strength > 0.01
	material.emission = color
	material.emission_energy_multiplier = 0.2 + strength * 3.2
	_fixture_materials[key] = material
	return material


func build_ceiling_lights() -> void:
	if not has_rooms():
		return
	var root := Node3D.new()
	root.name = "OswietlenieSufitowe"
	host.add_child(root)
	for room_index: int in range(rooms.size()):
		var room: Dictionary = rooms[room_index]
		var style: Dictionary = styles[room_index]
		var width: float = float(room["max_x"]) - float(room["min_x"])
		var depth: float = float(room["max_z"]) - float(room["min_z"])
		var count: int = clampi(int(round(width * depth / 750.0)), 1, 3)
		var along_x: bool = width >= depth
		var is_dark: bool = bool(style.get("dark", false))
		for k: int in range(count):
			var fraction: float = (float(k) + 1.0) / float(count + 1)
			var position_value := Vector3(
				lerpf(float(room["min_x"]), float(room["max_x"]), fraction if along_x else 0.5),
				WALL_HEIGHT,
				lerpf(float(room["min_z"]), float(room["max_z"]), 0.5 if along_x else fraction))
			_build_ceiling_fixture(root, room, style, position_value, is_dark)
		if is_dark and tod_id == "night":
			_add_darkness(root, room)


func _build_ceiling_fixture(root: Node3D, room: Dictionary, style: Dictionary, position_value: Vector3, is_dark: bool) -> void:
	var strength: float = 0.0 if is_dark else lamp_strength * float(style.get("brightness", 1.0))
	var color: Color = _lamp_color(str(style.get("light", "warm")))
	var material: StandardMaterial3D = _fixture_material(color, minf(strength, 1.4))
	var fixture := Node3D.new()
	fixture.name = "Lampa_%s" % str(style.get("lamp", "flush"))
	fixture.position = position_value
	root.add_child(fixture)
	match str(style.get("lamp", "flush")):
		"pendant":
			var cord := MeshInstance3D.new()
			var cord_mesh := CylinderMesh.new()
			cord_mesh.top_radius = 0.03
			cord_mesh.bottom_radius = 0.03
			cord_mesh.height = 0.28
			cord.mesh = cord_mesh
			cord.material_override = _trim_material
			cord.position.y = -0.14
			fixture.add_child(cord)
			var shade := MeshInstance3D.new()
			var shade_mesh := CylinderMesh.new()
			shade_mesh.top_radius = 0.10
			shade_mesh.bottom_radius = 0.38
			shade_mesh.height = 0.22
			shade_mesh.radial_segments = 24
			shade.mesh = shade_mesh
			shade.material_override = material
			shade.position.y = -0.32
			fixture.add_child(shade)
		"panel":
			var panel := MeshInstance3D.new()
			var panel_mesh := BoxMesh.new()
			panel_mesh.size = Vector3(0.9, 0.045, 0.45)
			panel.mesh = panel_mesh
			panel.material_override = material
			panel.position.y = -0.06
			fixture.add_child(panel)
		_:
			var disc := MeshInstance3D.new()
			var disc_mesh := CylinderMesh.new()
			disc_mesh.top_radius = 0.36
			disc_mesh.bottom_radius = 0.36
			disc_mesh.height = 0.05
			disc_mesh.radial_segments = 28
			disc.mesh = disc_mesh
			disc.material_override = material
			disc.position.y = -0.08
			fixture.add_child(disc)
	if strength > 0.02:
		var room_min: float = minf(float(room["max_x"]) - float(room["min_x"]), float(room["max_z"]) - float(room["min_z"]))
		var light_range: float = clampf(room_min * 0.9, 2.2, 4.8)
		add_light(root, position_value + Vector3(0, -0.25, 0), color, 1.5 * strength, light_range)
		add_pool(root, Vector3(position_value.x, 0.035, position_value.z), color, strength, minf(light_range * 1.2, room_min * 0.9))


## Rzeczywiste światło (OmniLight3D); widoczność zależy od jakości grafiki.
func add_light(parent: Node3D, world_position: Vector3, color: Color, energy: float, light_range: float) -> OmniLight3D:
	if _light_budget <= 0:
		return null
	_light_budget -= 1
	var light := OmniLight3D.new()
	light.position = world_position
	light.light_color = color
	light.light_energy = energy
	light.omni_range = light_range
	light.omni_attenuation = 1.3
	light.shadow_enabled = false
	light.distance_fade_enabled = true
	light.distance_fade_begin = 18.0
	light.distance_fade_length = 5.0
	parent.add_child(light)
	lights.append(light)
	return light


## Plama światła na podłodze: tania, działa także na niskiej jakości.
func add_pool(parent: Node3D, world_position: Vector3, color: Color, strength: float, size: float) -> void:
	var pool := MeshInstance3D.new()
	var quad := QuadMesh.new()
	quad.size = Vector2(size, size)
	pool.mesh = quad
	var material := StandardMaterial3D.new()
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_texture = RoomTextures.light_pool()
	material.albedo_color = Color(color.r, color.g, color.b, clampf(0.32 * strength, 0.0, 0.55))
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	pool.material_override = material
	pool.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	pool.position = world_position
	pool.rotation.x = -PI * 0.5
	parent.add_child(pool)


## Ciemny pokój: ujemne światło usuwa przeciek światła z sąsiednich pokoi.
func _add_darkness(root: Node3D, room: Dictionary) -> void:
	var light := OmniLight3D.new()
	light.light_negative = true
	light.light_energy = 1.1
	var width: float = float(room["max_x"]) - float(room["min_x"])
	var depth: float = float(room["max_z"]) - float(room["min_z"])
	light.omni_range = maxf(width, depth) * 0.62
	light.omni_attenuation = 0.8
	light.position = Vector3((float(room["min_x"]) + float(room["max_x"])) * 0.5, 1.35, (float(room["min_z"]) + float(room["max_z"])) * 0.5)
	light.shadow_enabled = false
	root.add_child(light)
	negative_lights.append(light)


# =========================================================
# LAMPY MEBLOWE (stojące i na szafkach)
# =========================================================

## Dodaje świecenie do lamp stojących i stawia małe lampki na szafkach.
## `items` to listy słowników z kluczami kind, position, scale.
func build_furniture_lights(decorations: Array, furnishings: Array) -> void:
	if lamp_strength <= 0.01:
		return
	var root := Node3D.new()
	root.name = "SwiatlaMeblowe"
	host.add_child(root)
	var all_items: Array = []
	all_items.append_array(decorations)
	all_items.append_array(furnishings)
	var cabinet_count: int = 0
	for item: Variant in all_items:
		if not (item is Dictionary):
			continue
		var entry: Dictionary = item
		var kind: String = str(entry.get("kind", ""))
		var position_value: Vector3 = entry.get("position", Vector3.ZERO)
		var room_index: int = RoomStyleCatalog.room_index_at(rooms, position_value)
		if room_index >= 0 and room_index < styles.size() and bool(styles[room_index].get("dark", false)):
			continue
		var style_light: String = str(styles[room_index].get("light", "warm")) if room_index >= 0 and room_index < styles.size() else "warm"
		var color: Color = _lamp_color("warm" if style_light == "cool" else style_light)
		var total_scale: float = float(entry.get("scale", 1.0)) * ProceduralTrack.realism_scale(kind)
		if kind == "lamp":
			var shade_position: Vector3 = position_value + Vector3(0, 1.25 * total_scale, 0)
			_add_lamp_glow(root, shade_position, color, 1.0, 1.6 * total_scale)
		elif kind == "cabinet" and (str(entry.get("role", "")) == "nightstand" or cabinet_count % 3 == 0):
			cabinet_count += 1
			var top: Vector3 = position_value + Vector3(0, 1.15 * total_scale, 0)
			var lamp_root := Node3D.new()
			lamp_root.name = "LampkaNaSzafce"
			lamp_root.position = top
			lamp_root.scale = Vector3.ONE * 0.4
			root.add_child(lamp_root)
			lamp_root.add_child(TrackModelLibrary.make_furniture("lamp", int(entry.get("variant", 0))))
			_add_lamp_glow(root, top + Vector3(0, 0.22, 0), color, 0.8, 1.1)
		elif kind == "cabinet":
			cabinet_count += 1


func _add_lamp_glow(root: Node3D, world_position: Vector3, color: Color, strength: float, size: float) -> void:
	var s: float = strength * lamp_strength
	add_light(root, world_position, color, 1.1 * s, 2.8)
	var glow := MeshInstance3D.new()
	var quad := QuadMesh.new()
	quad.size = Vector2(size, size)
	glow.mesh = quad
	var material := StandardMaterial3D.new()
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	material.albedo_texture = RoomTextures.light_pool()
	material.albedo_color = Color(color.r, color.g, color.b, clampf(0.55 * s, 0.0, 0.8))
	glow.material_override = material
	glow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	glow.position = world_position
	root.add_child(glow)
	add_pool(root, Vector3(world_position.x, 0.04, world_position.z), color, 0.7 * s, 1.8)
