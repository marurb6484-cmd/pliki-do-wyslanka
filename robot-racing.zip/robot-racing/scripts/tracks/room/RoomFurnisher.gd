class_name RoomFurnisher
extends RefCounted

const TrackGeneratorScript = preload("res://scripts/tracks/TrackGenerator.gd")
## Umeblowanie pomieszczeń wg zasad aranżacji wnętrz:
##  - strefy funkcjonalne (salon: kanapa naprzeciw TV na dywanie, stolik pomiędzy,
##    fotele i lampa; kuchnia: zabudowa wzdłuż ściany + stół z krzesłami; sypialnia:
##    łóżko wezgłowiem do ściany z szafkami nocnymi; łazienka, gabinet, przedpokój,
##    pokój dziecięcy),
##  - meble wolnostojące (kanapa, fotele) odsunięte od ścian, a szafy i regały przy ścianach,
##  - nic nie stoi na torze, w drzwiach ani przed oknami (wysokie meble),
##  - po zasadniczym planie pokój jest dopełniany roślinami, lampami i drobiazgami.
## Wynik to lista słowników {kind, position, rotation, variant, scale, room, role}
## budowana deterministycznie z danych trasy (seed), więc nie trzeba jej zapisywać.

const DIMS: Dictionary = {
	"sofa": Vector3(2.1, 1.5, 0.95), "bed": Vector3(2.05, 1.1, 1.45), "table": Vector3(1.7, 0.95, 1.05),
	"chair": Vector3(0.7, 1.2, 0.7), "cabinet": Vector3(1.55, 1.6, 0.85), "bookshelf": Vector3(1.6, 2.0, 0.8),
	"tv": Vector3(1.56, 1.6, 0.65), "tv_wall": Vector3(1.82, 1.25, 0.15), "fridge": Vector3(1.12, 2.1, 0.88), "bathtub": Vector3(1.85, 0.8, 1.0),
	"sink": Vector3(1.3, 1.4, 1.0), "kitchen_counter": Vector3(1.85, 1.3, 0.9), "fish_tank": Vector3(1.45, 1.2, 0.9),
	"lamp": Vector3(0.7, 1.9, 0.7), "plant": Vector3(0.8, 1.6, 0.8), "rug": Vector3(2.2, 0.1, 1.5),
	"pet_bed": Vector3(0.9, 0.4, 0.9), "scratching_post": Vector3(0.7, 1.6, 0.7), "toy": Vector3(0.8, 0.8, 0.8),
	"box": Vector3(0.9, 0.8, 0.9), "pillow": Vector3(0.9, 0.4, 0.9), "robot_toy": Vector3(0.8, 0.9, 0.8),
	"shoe": Vector3(0.8, 0.3, 0.4), "backpack": Vector3(0.8, 0.9, 0.5), "book": Vector3(0.5, 0.2, 0.35),
	"pet_bowl": Vector3(0.5, 0.2, 0.5), "mug": Vector3(0.14, 0.18, 0.14),
	"remote": Vector3(0.24, 0.04, 0.08), "candle": Vector3(0.18, 0.24, 0.18),
	"trash_bin": Vector3(0.62, 0.85, 0.62), "floor_fan": Vector3(0.62, 1.45, 0.62), "wall_clock": Vector3(0.58, 0.58, 0.16),
	"speaker": Vector3(0.48, 0.9, 0.42), "game_console": Vector3(0.62, 0.18, 0.42), "laptop": Vector3(0.52, 0.06, 0.38),
	"monitor": Vector3(0.72, 0.58, 0.28), "microwave": Vector3(0.62, 0.42, 0.42), "toaster": Vector3(0.38, 0.32, 0.28),
	"kettle": Vector3(0.32, 0.42, 0.32), "fruit_bowl": Vector3(0.62, 0.22, 0.62), "dish_rack": Vector3(0.72, 0.48, 0.38),
	"washing_machine": Vector3(0.72, 0.92, 0.68), "toilet": Vector3(0.52, 0.78, 0.72), "shower": Vector3(0.9, 1.95, 0.9),
	"radiator": Vector3(1.25, 0.72, 0.18), "coat_rack": Vector3(0.52, 1.65, 0.52), "umbrella_stand": Vector3(0.38, 0.62, 0.38),
	"suitcase": Vector3(0.72, 0.62, 0.34), "toy_car": Vector3(0.52, 0.22, 0.3), "pet_tunnel": Vector3(0.92, 0.48, 0.92),
	"water_dispenser": Vector3(0.48, 1.15, 0.48), "vase": Vector3(0.38, 0.72, 0.38),
	"towel_rack": Vector3(0.82, 1.05, 0.22), "hanging_plant": Vector3(0.62, 0.85, 0.62),
	"nightstand": Vector3(0.85, 0.95, 0.72), "wardrobe": Vector3(1.65, 2.25, 0.78),
	"coffee_table": Vector3(1.3, 0.55, 0.78), "side_table": Vector3(0.75, 0.65, 0.65),
	"shoe_rack": Vector3(1.1, 1.05, 0.45), "ottoman": Vector3(1.0, 0.62, 1.0),
	"laundry_basket": Vector3(0.9, 0.85, 0.9), "floor_mirror": Vector3(0.9, 2.1, 0.35),
}

const WINDOW_FRACTIONS: Array[float] = [0.2, 0.8]
const MAX_ITEMS: int = 880

var _data: Dictionary = {}
var _route: Array = []
var _route3: Array[Vector3] = []
var _track_width: float = 1.2
var _route_closed: bool = true
var _rng := RandomNumberGenerator.new()
var _placed: Array[Dictionary] = []          # {rect: Rect2, kind, flat}
var _out: Array[Dictionary] = []
var _door_zones: Array[Rect2] = []
var _window_zones: Array[Rect2] = []
var _existing: Array[Dictionary] = []
var _bounds: Rect2 = Rect2()


static func furnish(data: Dictionary) -> Array[Dictionary]:
	var furnisher := RoomFurnisher.new()
	return furnisher._run(data)


func _run(data: Dictionary) -> Array[Dictionary]:
	_data = data
	_route = data.get("route", [])
	for point: Variant in _route:
		if point is Vector3:
			_route3.append(point)
	_track_width = float(data.get("track_width", 1.2))
	_route_closed = bool(data.get("route_closed", data.get("generated", true)))
	_rng.seed = int(data.get("seed", 1)) * 31 + 977
	var rooms: Array = data.get("room_bounds", [])
	if rooms.is_empty() or _route.size() < 4:
		return []
	var styles: Array[Dictionary] = RoomStyleCatalog.assign_room_styles(data)
	for decoration: Variant in data.get("decorations", []):
		if decoration is Dictionary:
			_existing.append(decoration)
	_compute_global_bounds(rooms)
	_compute_door_zones()
	_compute_window_zones()
	for room_index: int in range(rooms.size()):
		if _out.size() >= MAX_ITEMS:
			break
		var room: Dictionary = rooms[room_index]
		var style: Dictionary = styles[room_index] if room_index < styles.size() else {"type": "living"}
		_furnish_room(room_index, room, str(style.get("type", "living")))
	return _out


# =========================================================
# GEOMETRIA POMOCNICZA
# =========================================================

func _compute_global_bounds(rooms: Array) -> void:
	var min_x: float = INF
	var max_x: float = -INF
	var min_z: float = INF
	var max_z: float = -INF
	for room: Dictionary in rooms:
		min_x = minf(min_x, float(room["min_x"]))
		max_x = maxf(max_x, float(room["max_x"]))
		min_z = minf(min_z, float(room["min_z"]))
		max_z = maxf(max_z, float(room["max_z"]))
	_bounds = Rect2(min_x, min_z, max_x - min_x, max_z - min_z)


func _compute_door_zones() -> void:
	for partition: Dictionary in _data.get("room_partitions", []):
		var vertical: bool = bool(partition.get("vertical", true))
		var axis: float = float(partition.get("axis", 0.0))
		var from_value: float = float(partition.get("min", 0.0))
		var to_value: float = float(partition.get("max", 0.0))
		var openings: Array[Vector2] = TrackGeneratorScript.get_room_partition_openings(_route, vertical, axis, _track_width, from_value, to_value, bool(_data.get("route_closed", _data.get("generated", true))))
		for opening: Vector2 in openings:
			if vertical:
				_door_zones.append(Rect2(axis - 0.8, opening.x - 0.15, 1.6, opening.y - opening.x + 0.3))
			else:
				_door_zones.append(Rect2(opening.x - 0.15, axis - 0.8, opening.y - opening.x + 0.3, 1.6))


## Strefy przed oknami na ścianach zewnętrznych - nie stawiamy tam wysokich mebli.
func _compute_window_zones() -> void:
	for fraction: float in WINDOW_FRACTIONS:
		var x_pos: float = _bounds.position.x + _bounds.size.x * fraction
		var z_pos: float = _bounds.position.y + _bounds.size.y * fraction
		_window_zones.append(Rect2(x_pos - 0.9, _bounds.position.y, 1.8, 1.5))
		_window_zones.append(Rect2(x_pos - 0.9, _bounds.end.y - 1.5, 1.8, 1.5))
		_window_zones.append(Rect2(_bounds.position.x, z_pos - 0.9, 1.5, 1.8))
		_window_zones.append(Rect2(_bounds.end.x - 1.5, z_pos - 0.9, 1.5, 1.8))


func _total_scale(kind: String, scale_value: float) -> float:
	return scale_value * ProceduralTrack.realism_scale(kind)


func _half_extents(kind: String, scale_value: float, rotation_y: float) -> Vector2:
	var dims: Vector3 = DIMS.get(kind, Vector3(1.0, 1.0, 1.0))
	var total: float = _total_scale(kind, scale_value)
	var local_half_x: float = dims.x * 0.5 * total
	var local_half_z: float = dims.z * 0.5 * total
	# Pełny rzut obróconego prostokąta na osie świata; działa także dla obrotów 45°.
	var cosine: float = absf(cos(rotation_y))
	var sine: float = absf(sin(rotation_y))
	return Vector2(cosine * local_half_x + sine * local_half_z, sine * local_half_x + cosine * local_half_z)


func _height_of(kind: String, scale_value: float) -> float:
	var dims: Vector3 = DIMS.get(kind, Vector3(1.0, 1.0, 1.0))
	return dims.y * _total_scale(kind, scale_value)


## Czy mebel o danym śladzie mieści się w pokoju, poza torem, drzwiami i innymi meblami.
func _fits(room: Dictionary, kind: String, position_value: Vector3, rotation_y: float, scale_value: float) -> bool:
	var half: Vector2 = _half_extents(kind, scale_value, rotation_y)
	var rect := Rect2(position_value.x - half.x, position_value.z - half.y, half.x * 2.0, half.y * 2.0)
	var inset: float = 0.12
	if rect.position.x < float(room["min_x"]) + inset or rect.end.x > float(room["max_x"]) - inset:
		return false
	if rect.position.y < float(room["min_z"]) + inset or rect.end.y > float(room["max_z"]) - inset:
		return false
	var radius: float = half.length()
	var flat: bool = kind == "rug"
	if TrackGeneratorScript._distance_to_route_xz(position_value, _route3, _route_closed) < _track_width * 0.5 + 0.22 + radius:
		return false
	for zone: Rect2 in _door_zones:
		if zone.intersects(rect):
			return false
	if _height_of(kind, scale_value) > 1.5 or kind in ["wall_clock", "hanging_plant"]:
		for zone: Rect2 in _window_zones:
			if zone.intersects(rect):
				return false
	var padded: Rect2 = rect.grow(0.18)
	for placed: Dictionary in _placed:
		var other_flat: bool = bool(placed["flat"])
		if flat != other_flat:
			continue
		if (placed["rect"] as Rect2).intersects(padded):
			return false
	if not flat:
		for existing: Dictionary in _existing:
			var existing_position: Vector3 = existing.get("position", Vector3.ZERO)
			var existing_kind: String = str(existing.get("kind", ""))
			var existing_scale: float = float(existing.get("scale", 1.0))
			var existing_rotation: float = float(existing.get("rotation", 0.0))
			var existing_half: Vector2
			if DIMS.has(existing_kind):
				existing_half = _half_extents(existing_kind, existing_scale, existing_rotation)
			else:
				var existing_radius: float = 0.95 if existing_kind in ["sofa", "bed", "fridge", "bathtub", "kitchen_counter", "table", "cabinet", "bookshelf", "tv", "tv_wall", "fish_tank", "washing_machine", "shower", "floor_fan", "coat_rack", "radiator", "toilet", "water_dispenser", "monitor", "microwave"] else 0.55
				existing_half = Vector2.ONE * existing_radius
			var existing_rect := Rect2(existing_position.x - existing_half.x, existing_position.z - existing_half.y, existing_half.x * 2.0, existing_half.y * 2.0)
			if existing_rect.grow(0.18).intersects(rect.grow(0.18)):
				return false
	return true


func _add(room_index: int, room: Dictionary, kind: String, position_value: Vector3, rotation_y: float, scale_value: float, role: String = "") -> bool:
	if _out.size() >= MAX_ITEMS or not _fits(room, kind, position_value, rotation_y, scale_value):
		return false
	if kind == "wall_clock":
		position_value.y = 1.35
	elif kind == "hanging_plant":
		position_value.y = 2.25
	var half: Vector2 = _half_extents(kind, scale_value, rotation_y)
	_placed.append({"rect": Rect2(position_value.x - half.x, position_value.z - half.y, half.x * 2.0, half.y * 2.0), "kind": kind, "flat": kind == "rug"})
	_out.append({"kind": kind, "position": position_value, "rotation": rotation_y, "variant": _rng.randi_range(0, 3), "scale": scale_value, "room": room_index, "role": role})
	return true


## Drobny rekwizyt ustawiony na blacie. Nie zajmuje miejsca na podłodze i nie blokuje przejazdu robota.
func _add_surface_prop(room_index: int, room: Dictionary, kind: String, position_value: Vector3, rotation_y: float, scale_value: float, role: String = "tabletop") -> bool:
	if _out.size() >= MAX_ITEMS:
		return false
	var margin: float = 0.08
	if position_value.x < float(room["min_x"]) + margin or position_value.x > float(room["max_x"]) - margin:
		return false
	if position_value.z < float(room["min_z"]) + margin or position_value.z > float(room["max_z"]) - margin:
		return false
	_out.append({"kind": kind, "position": position_value, "rotation": rotation_y, "variant": _rng.randi_range(0, 3), "scale": scale_value, "room": room_index, "role": role})
	return true


# --- ustawianie przy ścianie -------------------------------------------------
# side: 0 = ściana min_z (górna), 1 = max_z, 2 = min_x, 3 = max_x.

func _wall_normal(side: int) -> Vector3:
	match side:
		0:
			return Vector3(0, 0, 1)
		1:
			return Vector3(0, 0, -1)
		2:
			return Vector3(1, 0, 0)
	return Vector3(-1, 0, 0)


func _wall_length(room: Dictionary, side: int) -> float:
	if side < 2:
		return float(room["max_x"]) - float(room["min_x"])
	return float(room["max_z"]) - float(room["min_z"])


## Pozycja przy ścianie: `along` to odległość od początku ściany, `gap` - odstęp od ściany do
## tylnej krawędzi mebla. Tył mebla (lokalne +Z) jest zwrócony do ściany.
func _wall_slot(room: Dictionary, side: int, along: float, depth_half: float, gap: float) -> Dictionary:
	var normal: Vector3 = _wall_normal(side)
	var position_value := Vector3.ZERO
	match side:
		0:
			position_value = Vector3(float(room["min_x"]) + along, 0.0, float(room["min_z"]))
		1:
			position_value = Vector3(float(room["min_x"]) + along, 0.0, float(room["max_z"]))
		2:
			position_value = Vector3(float(room["min_x"]), 0.0, float(room["min_z"]) + along)
		_:
			position_value = Vector3(float(room["max_x"]), 0.0, float(room["min_z"]) + along)
	position_value += normal * (depth_half + gap + 0.04)
	var toward_wall: Vector3 = -normal
	# Front modeli jest w lokalnym -Z i ma być skierowany od ściany, do wnętrza pokoju.
	return {"position": position_value, "rotation": atan2(toward_wall.x, toward_wall.z)}


func _place_at_wall(room_index: int, room: Dictionary, kind: String, side: int, along_fraction: float, scale_value: float, gap: float = 0.55, role: String = "") -> bool:
	var dims: Vector3 = DIMS.get(kind, Vector3.ONE)
	var total: float = _total_scale(kind, scale_value)
	# Na ścianach X=const mebel jest obrócony o 90°: jego lokalna głębokość
	# leży wzdłuż ściany, a lokalna szerokość odstaje od ściany.
	var along_half: float = dims.x * 0.5 * total
	var depth_half: float = dims.z * 0.5 * total
	var length: float = _wall_length(room, side)
	var min_along: float = along_half + 0.16
	var max_along: float = length - along_half - 0.16
	if max_along <= min_along:
		return false
	var along: float = lerpf(min_along, max_along, clampf(along_fraction, 0.0, 1.0))
	var slot: Dictionary = _wall_slot(room, side, along, depth_half, gap)
	return _add(room_index, room, kind, slot["position"], float(slot["rotation"]), scale_value, role)


## Rząd mebli ustawiony obok siebie przy ścianie; zwraca liczbę ustawionych.
func _wall_run(room_index: int, room: Dictionary, kinds: Array, side: int, start_fraction: float, scale_value: float, role: String = "") -> int:
	var length: float = _wall_length(room, side)
	var cursor: float = lerpf(0.18, length * 0.22, clampf(start_fraction, 0.0, 1.0))
	var count: int = 0
	for kind_value: Variant in kinds:
		var kind: String = str(kind_value)
		var dims: Vector3 = DIMS.get(kind, Vector3.ONE)
		var total: float = _total_scale(kind, scale_value)
		var width: float = dims.x * total
		var depth: float = dims.z * total
		var slot: Dictionary = _wall_slot(room, side, cursor + width * 0.5, depth * 0.5, 0.48)
		if _add(room_index, room, kind, slot["position"], float(slot["rotation"]), scale_value, role):
			count += 1
		cursor += width + 0.15
	return count


func _sides_by_length(room: Dictionary, longest_first: bool = true) -> Array[int]:
	var sides: Array[int] = [0, 1, 2, 3]
	sides.sort_custom(func(a: int, b: int) -> bool:
		var la: float = _wall_length(room, a)
		var lb: float = _wall_length(room, b)
		return la > lb if longest_first else la < lb)
	return sides


func _random_side(exclude: Array[int] = []) -> int:
	var options: Array[int] = []
	for side: int in range(4):
		if not exclude.has(side):
			options.append(side)
	return options[_rng.randi_range(0, options.size() - 1)]


func _center_of(room: Dictionary) -> Vector3:
	return Vector3((float(room["min_x"]) + float(room["max_x"])) * 0.5, 0.0, (float(room["min_z"]) + float(room["max_z"])) * 0.5)


func _face(from_position: Vector3, target: Vector3) -> float:
	# Front modelu to -Z: rotation_y tak, by lokalne -Z wskazywało na cel.
	var direction: Vector3 = target - from_position
	return atan2(-direction.x, -direction.z)


# =========================================================
# PLANY POKOI
# =========================================================

func _furnish_room(room_index: int, room: Dictionary, room_type: String) -> void:
	match room_type:
		"living":
			_plan_living(room_index, room)
		"kitchen":
			_plan_kitchen(room_index, room)
		"bedroom":
			_plan_bedroom(room_index, room, 1.0)
		"kids":
			_plan_bedroom(room_index, room, 0.75)
			_scatter_toys(room_index, room)
		"playroom":
			_plan_playroom(room_index, room)
			_scatter_toys(room_index, room)
		"bathroom":
			_plan_bathroom(room_index, room)
		"study":
			_plan_study(room_index, room)
		"office":
			_plan_office(room_index, room)
		"arena":
			_plan_arena(room_index, room)
		"hall":
			_plan_hall(room_index, room)
	_fill_room(room_index, room, room_type)


func _plan_living(room_index: int, room: Dictionary) -> void:
	# Zestaw wypoczynkowy: TV przy ścianie, kanapa naprzeciw (odsunięta od ściany),
	# stolik pomiędzy, dywan pod całością, fotele i lampa dopełniają układ.
	var sides: Array[int] = _sides_by_length(room)
	for attempt: int in range(8):
		var tv_side: int = sides[attempt % 4] if attempt < 4 else _random_side()
		var fraction: float = _rng.randf_range(0.3, 0.7)
		var normal: Vector3 = _wall_normal(tv_side)
		var tv_ok: bool = _place_at_wall(room_index, room, "tv_wall", tv_side, fraction, 1.0, 0.5, "tv")
		if not tv_ok:
			continue
		var tv_item: Dictionary = _out[_out.size() - 1]
		var tv_position: Vector3 = tv_item["position"]
		var room_depth: float = float(room["max_z"]) - float(room["min_z"]) if tv_side < 2 else float(room["max_x"]) - float(room["min_x"])
		var distance: float = clampf(room_depth * 0.38, 1.15, 1.75)
		var sofa_position: Vector3 = tv_position + normal * distance
		var facing: float = _face(sofa_position, tv_position)
		if not _add(room_index, room, "sofa", sofa_position, facing, 1.05, "sofa"):
			# Kanapa bliżej TV, jeśli pokój jest wąski.
			sofa_position = tv_position + normal * (distance * 0.75)
			facing = _face(sofa_position, tv_position)
			if not _add(room_index, room, "sofa", sofa_position, facing, 1.0, "sofa"):
				continue
		var table_position: Vector3 = tv_position + normal * (distance * 0.5)
		_add(room_index, room, "rug", table_position + normal * 0.4, facing, 1.0, "rug")
		_add(room_index, room, "coffee_table", table_position, facing, 1.0, "coffee_table")
		var tabletop_x := Vector3(cos(facing), 0.0, -sin(facing))
		var tabletop_z := Vector3(sin(facing), 0.0, cos(facing))
		_add_surface_prop(room_index, room, "remote", table_position + tabletop_x * -0.34 + tabletop_z * -0.12 + Vector3(0.0, 0.40, 0.0), facing, 0.9, "coffee_table_remote")
		_add_surface_prop(room_index, room, "book", table_position + tabletop_x * 0.28 + tabletop_z * 0.13 + Vector3(0.0, 0.40, 0.0), facing + 0.08, 0.62, "coffee_table_book")
		_add_surface_prop(room_index, room, "mug", table_position + tabletop_x * 0.35 + tabletop_z * -0.22 + Vector3(0.0, 0.40, 0.0), facing, 0.85, "coffee_table_mug")
		var side_dir := Vector3(-normal.z, 0.0, normal.x)
		for sign_value: float in [-1.0, 1.0]:
			var armchair_position: Vector3 = table_position + side_dir * sign_value * 0.72
			if _rng.randf() < 0.75:
				_add(room_index, room, "chair", armchair_position, _face(armchair_position, table_position), 1.0, "armchair")
		var lamp_position: Vector3 = sofa_position + side_dir * 0.72
		_add(room_index, room, "lamp", lamp_position, 0.0, 1.0, "floor_lamp")
		break
	# Regał i szafka przy innych ścianach.
	_place_at_wall(room_index, room, "bookshelf", _random_side(), _rng.randf(), 1.0, 0.45, "bookshelf")
	_place_at_wall(room_index, room, "cabinet", _random_side(), _rng.randf(), 1.0, 0.45, "cabinet")
	_place_at_wall(room_index, room, "fish_tank", _random_side(), _rng.randf(), 0.9, 0.45, "aquarium")
	_place_corner_plants(room_index, room, 2)


func _plan_kitchen(room_index: int, room: Dictionary) -> void:
	var sides: Array[int] = _sides_by_length(room)
	var run_side: int = sides[0]
	_wall_run(room_index, room, ["fridge", "kitchen_counter", "sink"], run_side, _rng.randf_range(0.0, 0.4), 1.0, "kitchen_run")
	var second_side: int = sides[1]
	if second_side == run_side:
		second_side = sides[2]
	_wall_run(room_index, room, ["cabinet", "kitchen_counter"], second_side, _rng.randf_range(0.0, 0.5), 1.0, "kitchen_run")
	# Wyspa jadalniana ze stołem i krzesłami w środku pokoju.
	var center: Vector3 = _center_of(room)
	var table_ok: bool = false
	var table_position: Vector3 = center
	for offset: Vector3 in [Vector3.ZERO, Vector3(0.35, 0, 0), Vector3(-0.35, 0, 0), Vector3(0, 0, 0.35), Vector3(0, 0, -0.35)]:
		table_position = center + offset
		if _add(room_index, room, "table", table_position, 0.0, 1.2, "dining_table"):
			table_ok = true
			for chair_offset: Vector3 in [Vector3(-0.95, 0, 0), Vector3(0.95, 0, 0), Vector3(0, 0, -0.72), Vector3(0, 0, 0.72)]:
				var chair_position: Vector3 = table_position + chair_offset * 1.0
				_add(room_index, room, "chair", chair_position, _face(chair_position, table_position), 0.9, "chair")
			break
	if table_ok:
		var dining_top_y: float = 0.80 * 1.2 + 0.01
		_add_surface_prop(room_index, room, "book", table_position + Vector3(-0.42, dining_top_y, -0.18), 0.12, 0.62, "dining_table_book")
		_add_surface_prop(room_index, room, "mug", table_position + Vector3(0.48, dining_top_y, 0.18), 0.0, 0.9, "dining_table_mug")
		_add(room_index, room, "pet_bowl", center + Vector3(0.8, 0, 0.65), 0.0, 1.0, "pet_bowl")
	_place_corner_plants(room_index, room, 1)


func _plan_bedroom(room_index: int, room: Dictionary, bed_scale: float) -> void:
	var sides: Array[int] = _sides_by_length(room, false)
	for attempt: int in range(8):
		var bed_side: int = sides[attempt % 4] if attempt < 4 else _random_side()
		var fraction: float = _rng.randf_range(0.35, 0.65)
		if not _place_at_wall(room_index, room, "bed", bed_side, fraction, bed_scale, 0.3, "bed"):
			continue
		var bed_item: Dictionary = _out[_out.size() - 1]
		var bed_position: Vector3 = bed_item["position"]
		var normal: Vector3 = _wall_normal(bed_side)
		var side_dir := Vector3(-normal.z, 0.0, normal.x)
		var bed_half: float = DIMS["bed"].x * 0.5 * _total_scale("bed", bed_scale)
		for sign_value: float in [-1.0, 1.0]:
			var stand_position: Vector3 = bed_position + side_dir * sign_value * (bed_half + 0.22) - normal * 0.0
			var nightstand_added: bool = _add(room_index, room, "nightstand", stand_position, float(bed_item["rotation"]), 0.85 * bed_scale, "nightstand")
			if nightstand_added and _rng.randf() < 0.8:
				_add_surface_prop(room_index, room, "lamp", stand_position + Vector3(0.0, 0.96 * 0.85 * bed_scale, 0.0), 0.0, 0.38, "bedside_lamp_on_nightstand")
		_add(room_index, room, "rug", bed_position + normal * 0.65, float(bed_item["rotation"]), 1.0 * bed_scale, "rug")
		break
	_place_at_wall(room_index, room, "wardrobe", _random_side(), _rng.randf(), 1.0, 0.45, "wardrobe")
	_place_at_wall(room_index, room, "bookshelf", _random_side(), _rng.randf(), 1.0, 0.45, "bookshelf")
	_place_at_wall(room_index, room, "table", _random_side(), _rng.randf(), 0.8, 0.45, "desk")
	var desk: Variant = _last_of("desk")
	if desk != null:
		var desk_position: Vector3 = (desk as Dictionary)["position"]
		var in_front: Vector3 = -_wall_normal_from_rotation(float((desk as Dictionary)["rotation"]))
		var chair_position: Vector3 = desk_position + in_front * 0.72
		_add(room_index, room, "chair", chair_position, _face(chair_position, desk_position), 0.9, "desk_chair")
	_place_corner_plants(room_index, room, 1)


func _plan_playroom(room_index: int, room: Dictionary) -> void:
	var center: Vector3 = _center_of(room)
	_add(room_index, room, "rug", center, 0.0, 1.25, "playroom_rug")
	var sides: Array[int] = _sides_by_length(room)
	_place_at_wall(room_index, room, "bookshelf", sides[0], 0.5, 1.0, 0.45, "toy_shelf")
	_place_at_wall(room_index, room, "cabinet", sides[1], 0.5, 0.9, 0.45, "toy_storage")
	var table_position: Vector3 = center + Vector3(0.0, 0.0, 0.75)
	if _add(room_index, room, "table", table_position, 0.0, 0.7, "kids_table"):
		_add_surface_prop(room_index, room, "toy_car", table_position + Vector3(0.0, 0.56, -0.12), 0.35, 0.7, "kids_table_toy")
		for chair_offset: Vector3 in [Vector3(-0.62, 0, 0), Vector3(0.62, 0, 0)]:
			var chair_position: Vector3 = table_position + chair_offset
			_add(room_index, room, "chair", chair_position, _face(chair_position, table_position), 0.65, "kids_chair")
	_place_corner_plants(room_index, room, 1)


func _plan_bathroom(room_index: int, room: Dictionary) -> void:
	var sides: Array[int] = _sides_by_length(room)
	_place_at_wall(room_index, room, "bathtub", sides[0], _rng.randf_range(0.2, 0.8), 1.0, 0.35, "bathtub")
	var other: int = sides[1] if sides[1] != sides[0] else sides[2]
	_wall_run(room_index, room, ["sink", "cabinet"], other, _rng.randf_range(0.0, 0.6), 1.0, "vanity")
	var center: Vector3 = _center_of(room)
	_add(room_index, room, "rug", center, 0.0, 0.9, "bath_mat")
	_place_corner_plants(room_index, room, 1)


func _plan_study(room_index: int, room: Dictionary) -> void:
	var sides: Array[int] = _sides_by_length(room)
	_place_at_wall(room_index, room, "table", sides[0], _rng.randf_range(0.3, 0.7), 1.0, 0.45, "desk")
	var desk: Variant = _last_of("desk")
	if desk != null:
		var desk_position: Vector3 = (desk as Dictionary)["position"]
		var in_front: Vector3 = -_wall_normal_from_rotation(float((desk as Dictionary)["rotation"]))
		var chair_position: Vector3 = desk_position + in_front * 0.72
		_add(room_index, room, "chair", chair_position, _face(chair_position, desk_position), 1.0, "desk_chair")
		_add(room_index, room, "rug", desk_position + in_front * 0.72, float((desk as Dictionary)["rotation"]), 1.0, "rug")
		_add_surface_prop(room_index, room, "lamp", desk_position + Vector3(-0.48, 0.80 * 0.8 + 0.01, 0.0), 0.0, 0.38, "desk_lamp_on_desk")
	for side: int in range(4):
		if side != sides[0]:
			_place_at_wall(room_index, room, "bookshelf", side, _rng.randf(), 1.0, 0.45, "bookshelf")
	_place_at_wall(room_index, room, "cabinet", _random_side(), _rng.randf(), 1.0, 0.45, "cabinet")
	_place_at_wall(room_index, room, "sofa", _random_side(), _rng.randf(), 0.85, 0.5, "sofa")
	_place_corner_plants(room_index, room, 1)


func _plan_office(room_index: int, room: Dictionary) -> void:
	var sides: Array[int] = _sides_by_length(room)
	var room_area: float = (float(room.get("max_x", 0.0)) - float(room.get("min_x", 0.0))) * (float(room.get("max_z", 0.0)) - float(room.get("min_z", 0.0)))
	var workstation_count: int = 2 if room_area >= 13.0 else 1
	for station_index: int in range(workstation_count):
		var side: int = sides[station_index % sides.size()]
		var fraction: float = 0.30 if station_index == 0 else 0.70
		if not _place_at_wall(room_index, room, "table", side, fraction, 0.95, 0.42, "office_desk"):
			continue
		var desk: Variant = _last_of("office_desk")
		if desk == null:
			continue
		var desk_position: Vector3 = (desk as Dictionary)["position"]
		var front: Vector3 = -_wall_normal_from_rotation(float((desk as Dictionary)["rotation"]))
		var chair_position: Vector3 = desk_position + front * 0.82
		_add(room_index, room, "chair", chair_position, _face(chair_position, desk_position), 0.92, "office_chair")
		var office_top_y: float = 0.80 * 0.95 + 0.01
		_add_surface_prop(room_index, room, "monitor", desk_position + Vector3(0.0, office_top_y, 0.0), float((desk as Dictionary)["rotation"]), 0.9, "office_monitor_on_desk")
		_add_surface_prop(room_index, room, "laptop", desk_position + Vector3(0.42, office_top_y, 0.22), float((desk as Dictionary)["rotation"]), 0.85, "office_laptop_on_desk")
	for side: int in range(4):
		if side != sides[0]:
			_place_at_wall(room_index, room, "cabinet", side, _rng.randf_range(0.25, 0.75), 0.9, 0.4, "office_cabinet")
	_place_at_wall(room_index, room, "bookshelf", sides[2], 0.78, 0.9, 0.4, "office_archive")
	_place_corner_plants(room_index, room, 1)


func _plan_arena(room_index: int, room: Dictionary) -> void:
	var sides: Array[int] = _sides_by_length(room)
	_place_at_wall(room_index, room, "tv_wall", sides[0], 0.5, 0.9, 0.35, "arena_scoreboard")
	_place_at_wall(room_index, room, "speaker", sides[1], 0.22, 0.9, 0.35, "arena_speaker")
	_place_at_wall(room_index, room, "speaker", sides[2], 0.78, 0.9, 0.35, "arena_speaker")
	_place_at_wall(room_index, room, "cabinet", sides[3], 0.5, 0.75, 0.35, "arena_equipment")
	_place_at_wall(room_index, room, "lamp", sides[1], 0.72, 1.0, 0.25, "arena_light")


func _plan_hall(room_index: int, room: Dictionary) -> void:
	var sides: Array[int] = _sides_by_length(room)
	_place_at_wall(room_index, room, "shoe_rack", sides[0], _rng.randf_range(0.2, 0.8), 1.0, 0.4, "shoe_rack")
	_place_at_wall(room_index, room, "lamp", sides[1], _rng.randf_range(0.2, 0.8), 0.9, 0.5, "floor_lamp")
	_place_at_wall(room_index, room, "bookshelf", sides[2], _rng.randf_range(0.2, 0.8), 0.9, 0.45, "shelf")
	var center: Vector3 = _center_of(room)
	_add(room_index, room, "rug", center, 0.0, 1.0, "runner")
	var cabinet: Variant = _last_of("shoe_rack")
	if cabinet != null:
		var base_position: Vector3 = (cabinet as Dictionary)["position"]
		var forward: Vector3 = -_wall_normal_from_rotation(float((cabinet as Dictionary)["rotation"]))
		_add(room_index, room, "shoe", base_position + forward * 0.55, _rng.randf_range(0.0, TAU), 1.0, "shoe")
		_add(room_index, room, "shoe", base_position + forward * 0.55 + Vector3(0.8, 0, 0.3), _rng.randf_range(0.0, TAU), 1.0, "shoe")
		_add(room_index, room, "backpack", base_position + forward * 0.72 + Vector3(-0.35, 0, 0), _rng.randf_range(0.0, TAU), 1.0, "backpack")
	_place_corner_plants(room_index, room, 1)


func _scatter_toys(room_index: int, room: Dictionary) -> void:
	var toy_kinds: Array[String] = ["toy", "robot_toy", "box", "pillow", "toy"]
	var center: Vector3 = _center_of(room)
	for kind: String in toy_kinds:
		for attempt: int in range(6):
			var offset := Vector3(_rng.randf_range(-0.75, 0.75), 0.0, _rng.randf_range(-0.75, 0.75))
			if _add(room_index, room, kind, center + offset, _rng.randf_range(0.0, TAU), 1.0, "toy"):
				break


## Dopełnienie: rośliny w narożnikach, lampy i drobne przedmioty przy ścianach,
## aż pokój osiągnie docelowe zapełnienie zależne od powierzchni.
func _fill_room(room_index: int, room: Dictionary, room_type: String) -> void:
	var area: float = (float(room["max_x"]) - float(room["min_x"])) * (float(room["max_z"]) - float(room["min_z"]))
	var route_distance: float = TrackGeneratorScript._distance_to_route_xz(_center_of(room), _route3, _route_closed)
	var near_track_bonus: int = 4 if route_distance < _track_width * 0.5 + 2.0 else 0
	var density_level: int = clampi(int(_data.get("furniture_density", 2)), 0, 4)
	var density_bonus: int = (density_level - 1) * 4
	var target: int = clampi(int(area / 2.8) + mini(near_track_bonus, 1) + density_bonus + 3, 3, 14)
	var current: int = 0
	for placed: Dictionary in _out:
		if int(placed["room"]) == room_index:
			current += 1
	var filler_kinds: Array[String] = ["cabinet", "bookshelf", "wardrobe", "side_table", "ottoman", "sofa", "chair", "table", "plant", "lamp", "cabinet", "bookshelf", "floor_mirror", "trash_bin", "floor_fan", "speaker", "game_console", "monitor", "microwave", "washing_machine", "pet_bed", "scratching_post", "box", "pillow", "toy", "robot_toy", "book", "mug", "remote", "shoe", "pet_bowl", "fish_tank", "rug", "laundry_basket", "suitcase", "toy_car", "pet_tunnel", "water_dispenser", "vase", "candle", "towel_rack", "hanging_plant"]
	if room_type == "bathroom":
		filler_kinds = ["plant", "box", "cabinet", "toilet", "shower", "towel_rack", "washing_machine", "trash_bin"]
	elif room_type == "kitchen":
		filler_kinds = ["plant", "box", "cabinet", "pet_bowl", "microwave", "toaster", "kettle", "fruit_bowl", "dish_rack", "trash_bin"]
	var attempts: int = 0
	while current < target and attempts < 180:
		attempts += 1
		var kind: String = filler_kinds[_rng.randi_range(0, filler_kinds.size() - 1)]
		var scale_value: float = _rng.randf_range(0.88, 1.02)
		var side: int = _random_side()
		var small: bool = kind in ["book", "backpack", "box", "pet_bowl", "laundry_basket", "ottoman"]
		var placed_ok: bool = false
		if small:
			var center: Vector3 = _center_of(room)
			var position_value := Vector3(_rng.randf_range(float(room["min_x"]) + 0.25, float(room["max_x"]) - 0.25), 0.0, _rng.randf_range(float(room["min_z"]) + 0.25, float(room["max_z"]) - 0.25))
			placed_ok = _add(room_index, room, kind, position_value, _rng.randf_range(0.0, TAU), scale_value, "filler")
		else:
			placed_ok = _place_at_wall(room_index, room, kind, side, _rng.randf(), scale_value, 0.5, "filler")
		if placed_ok:
			current += 1


func _place_corner_plants(room_index: int, room: Dictionary, count: int) -> void:
	var corners: Array[Vector3] = [
		Vector3(float(room["min_x"]) + 0.55, 0.0, float(room["min_z"]) + 0.55),
		Vector3(float(room["max_x"]) - 0.55, 0.0, float(room["min_z"]) + 0.55),
		Vector3(float(room["min_x"]) + 0.55, 0.0, float(room["max_z"]) - 0.55),
		Vector3(float(room["max_x"]) - 0.55, 0.0, float(room["max_z"]) - 0.55),
	]
	for i: int in range(corners.size()):
		var swap_index: int = _rng.randi_range(i, corners.size() - 1)
		var swap_value: Vector3 = corners[i]
		corners[i] = corners[swap_index]
		corners[swap_index] = swap_value
	var placed_count: int = 0
	for corner: Vector3 in corners:
		if placed_count >= count:
			break
		if _add(room_index, room, "plant", corner, _rng.randf_range(0.0, TAU), _rng.randf_range(0.9, 1.2), "plant"):
			placed_count += 1


func _last_of(role: String) -> Variant:
	for i: int in range(_out.size() - 1, -1, -1):
		if str(_out[i]["role"]) == role:
			return _out[i]
	return null


## Kierunek "do ściany" dla modelu o danej rotacji (lokalne +Z).
func _wall_normal_from_rotation(rotation_y: float) -> Vector3:
	return Vector3(sin(rotation_y), 0.0, cos(rotation_y))
