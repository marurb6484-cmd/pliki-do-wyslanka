class_name RoomStyleCatalog
extends RefCounted
## KATALOG STYLÓW POMIESZCZEŃ - wszystko, co wygląda "z pokoju", jest tu opisane
## danymi. Żeby dodać nową podłogę, ścianę albo porę dnia, wystarczy dopisać
## wpis do odpowiedniego słownika - nie trzeba ruszać kodu budującego pokoje.
##
## WŁASNE TEKSTURY: połóż pliki w res://assets/textures/rooms/ o nazwach
##   <id>_albedo.png   (kolor, wymagany)
##   <id>_normal.png   (mapa normalnych, opcjonalna)
##   <id>_rough.png    (szorstkość, opcjonalna)
## gdzie <id> to klucz z FLOORS lub WALLS (np. oak_planks_albedo.png).
## Plik zastępuje teksturę proceduralną tego wpisu. Rozmiar jednego kafla
## w świecie gry ustawia pole "tile" (w jednostkach świata).
##
## Dziedziny: FLOORS (podłogi), WALLS (ściany i panele dolne), ROOM_TYPES
## (rodzaje pokoi), TIMES_OF_DAY (pory dnia), LAMP_KELVIN (barwy świateł).

const TEXTURE_DIR: String = "res://assets/textures/rooms/"

## kind: planks | parquet | tiles | checker | carpet | concrete | marble
const FLOORS: Dictionary = {
	"oak_planks": {"name": "Deski dębowe", "kind": "planks", "colors": [Color("#b98b57"), Color("#a97b49"), Color("#c99d68"), Color("#b08150")], "count": 6, "tile": 2.4, "roughness": 0.55, "normal": 0.6},
	"walnut_planks": {"name": "Deski orzechowe", "kind": "planks", "colors": [Color("#6e4a33"), Color("#5f3f2b"), Color("#7a5239")], "count": 5, "tile": 2.4, "roughness": 0.5, "normal": 0.6},
	"parquet": {"name": "Parkiet", "kind": "parquet", "colors": [Color("#c29056"), Color("#b3804b"), Color("#cf9f68")], "count": 4, "tile": 2.2, "roughness": 0.45, "normal": 0.5},
	"tiles_light": {"name": "Płytki jasne", "kind": "tiles", "colors": [Color("#dedad2"), Color("#d3cfc6"), Color("#e6e2da")], "grout": Color("#9c978d"), "count": 3, "tile": 2.4, "roughness": 0.28, "normal": 0.5},
	"tiles_dark": {"name": "Płytki grafitowe", "kind": "tiles", "colors": [Color("#4b4f57"), Color("#42464e"), Color("#545861")], "grout": Color("#2b2d31"), "count": 3, "tile": 2.4, "roughness": 0.3, "normal": 0.5},
	"tiles_checker": {"name": "Szachownica", "kind": "checker", "colors": [Color("#ece8df"), Color("#2f3338")], "grout": Color("#8d8a82"), "count": 4, "tile": 2.4, "roughness": 0.25, "normal": 0.4},
	"carpet_grey": {"name": "Wykładzina szara", "kind": "carpet", "colors": [Color("#8b8e93")], "tile": 2.4, "roughness": 1.0, "normal": 0.0},
	"carpet_beige": {"name": "Wykładzina beżowa", "kind": "carpet", "colors": [Color("#c8b89c")], "tile": 2.4, "roughness": 1.0, "normal": 0.0},
	"carpet_blue": {"name": "Wykładzina niebieska", "kind": "carpet", "colors": [Color("#5d7894")], "tile": 2.4, "roughness": 1.0, "normal": 0.0},
	"concrete": {"name": "Beton", "kind": "concrete", "colors": [Color("#8f9196")], "tile": 3.0, "roughness": 0.75, "normal": 0.3},
	"marble": {"name": "Marmur", "kind": "marble", "colors": [Color("#e9e6e1"), Color("#8f98a3")], "tile": 3.0, "roughness": 0.18, "normal": 0.0},
}

## kind: paint | wallpaper | stripes | subway | brick | wood_panel
const WALLS: Dictionary = {
	"paint_warm_white": {"name": "Biel ciepła", "kind": "paint", "color": Color("#e8e0d2"), "tile": 10.0, "roughness": 0.92},
	"paint_sage": {"name": "Szałwia", "kind": "paint", "color": Color("#a9b8a0"), "tile": 10.0, "roughness": 0.92},
	"paint_sand": {"name": "Piaskowa", "kind": "paint", "color": Color("#d6c3a3"), "tile": 10.0, "roughness": 0.92},
	"paint_blue_grey": {"name": "Szaroniebieska", "kind": "paint", "color": Color("#9fb0bf"), "tile": 10.0, "roughness": 0.92},
	"paint_rose": {"name": "Pudrowy róż", "kind": "paint", "color": Color("#dcb7ae"), "tile": 10.0, "roughness": 0.92},
	"paint_graphite": {"name": "Grafit", "kind": "paint", "color": Color("#5b6068"), "tile": 10.0, "roughness": 0.9},
	"wallpaper_floral": {"name": "Tapeta w kwiaty", "kind": "wallpaper", "color": Color("#d9cdb8"), "accent": Color("#8aa07a"), "tile": 6.0, "roughness": 0.9},
	"stripes_cream": {"name": "Pasy kremowe", "kind": "stripes", "color": Color("#e4dac6"), "accent": Color("#cdbfa4"), "tile": 6.0, "roughness": 0.9},
	"subway_white": {"name": "Kafelki białe", "kind": "subway", "color": Color("#eceeef"), "accent": Color("#b9bec2"), "tile": 6.0, "roughness": 0.25},
	"subway_green": {"name": "Kafelki zielone", "kind": "subway", "color": Color("#7fa493"), "accent": Color("#5d7e6f"), "tile": 6.0, "roughness": 0.25},
	"brick_red": {"name": "Cegła", "kind": "brick", "color": Color("#a45a45"), "accent": Color("#c9bfae"), "tile": 6.0, "roughness": 0.85},
	"wood_panel": {"name": "Boazeria", "kind": "wood_panel", "color": Color("#9a6c46"), "accent": Color("#7d5535"), "tile": 6.0, "roughness": 0.6},
}

## Pory dnia. window_view: nazwa widoku za oknem (RoomTextures.make_window_view).
## lamps: 0 = lampy zgaszone, 1 = świecą. Światło NIE wylewa się z okien -
## w dzień pokój oświetla równe światło otoczenia, a okno pokazuje tylko widok.
const TIMES_OF_DAY: Dictionary = {
	"day": {"name": "Dzień", "ambient_color": Color(0.93, 0.95, 1.0), "ambient_energy": 1.05, "sun_energy": 0.7, "sun_color": Color(1.0, 0.97, 0.9), "background": Color(0.62, 0.78, 0.95), "lamps": 0.0, "window_view": "day", "ceiling_tint": Color(0.97, 0.95, 0.9), "wall_dim": 1.0, "glow": 0.0},
	"evening": {"name": "Wieczór", "ambient_color": Color(0.95, 0.78, 0.66), "ambient_energy": 0.55, "sun_energy": 0.25, "sun_color": Color(1.0, 0.6, 0.35), "background": Color(0.95, 0.55, 0.35), "lamps": 0.7, "window_view": "evening", "ceiling_tint": Color(0.85, 0.78, 0.7), "wall_dim": 0.85, "glow": 0.5},
	"night": {"name": "Noc", "ambient_color": Color(0.30, 0.36, 0.58), "ambient_energy": 0.20, "sun_energy": 0.0, "sun_color": Color(0.6, 0.7, 1.0), "background": Color(0.02, 0.03, 0.08), "lamps": 1.0, "window_view": "night", "ceiling_tint": Color(0.55, 0.55, 0.6), "wall_dim": 0.8, "glow": 1.0},
}

## Barwy świateł wg temperatury (sugestie projektantów oświetlenia: salon i sypialnia
## 2700-3000 K, kuchnia i łazienka 4000 K, biuro 4000 K).
const LAMP_KELVIN: Dictionary = {
	"warm": Color(1.0, 0.72, 0.42),
	"soft": Color(1.0, 0.79, 0.52),
	"neutral": Color(1.0, 0.88, 0.72),
	"cool": Color(0.92, 0.95, 1.0),
}

## Rodzaje pokoi: dozwolone podłogi/ściany, panel dolny, światło i plan umeblowania.
## plan: nazwa funkcji planu w RoomFurnisher. lamp: styl lampy sufitowej.
const ROOM_TYPES: Dictionary = {
	"living": {"name": "Salon", "floors": ["oak_planks", "parquet", "walnut_planks"], "walls": ["paint_warm_white", "paint_sage", "paint_blue_grey", "wallpaper_floral"], "dado": "", "light": "warm", "lamp": "pendant", "brightness": 1.0, "plan": "living"},
	"kitchen": {"name": "Kuchnia", "floors": ["tiles_light", "tiles_checker", "tiles_dark"], "walls": ["paint_warm_white", "paint_sand", "paint_sage"], "dado": "subway_white", "light": "cool", "lamp": "panel", "brightness": 1.25, "plan": "kitchen"},
	"bedroom": {"name": "Sypialnia", "floors": ["carpet_beige", "carpet_grey", "oak_planks"], "walls": ["paint_rose", "paint_blue_grey", "stripes_cream", "wallpaper_floral"], "dado": "", "light": "warm", "lamp": "flush", "brightness": 0.8, "plan": "bedroom"},
	"bathroom": {"name": "Łazienka", "floors": ["tiles_dark", "tiles_light", "marble"], "walls": ["subway_white", "subway_green"], "dado": "", "light": "cool", "lamp": "panel", "brightness": 1.2, "plan": "bathroom"},
	"study": {"name": "Gabinet", "floors": ["walnut_planks", "carpet_grey", "parquet"], "walls": ["paint_graphite", "paint_blue_grey", "wood_panel"], "dado": "wood_panel", "light": "neutral", "lamp": "flush", "brightness": 0.95, "plan": "study"},
	"office": {"name": "Biuro", "floors": ["concrete", "tiles_dark", "marble"], "walls": ["paint_graphite", "paint_blue_grey", "subway_white"], "dado": "", "light": "cool", "lamp": "panel", "brightness": 1.1, "plan": "office"},
	"arena": {"name": "Arena Pro League", "floors": ["concrete", "tiles_dark", "marble"], "walls": ["paint_graphite", "paint_blue_grey", "paint_warm_white"], "dado": "", "light": "cool", "lamp": "panel", "brightness": 1.2, "plan": "arena"},
	"hall": {"name": "Przedpokój", "floors": ["tiles_checker", "concrete", "tiles_light"], "walls": ["paint_sand", "paint_warm_white", "stripes_cream"], "dado": "", "light": "soft", "lamp": "flush", "brightness": 0.9, "plan": "hall"},
	"kids": {"name": "Pokój dziecięcy", "floors": ["carpet_blue", "carpet_beige", "oak_planks"], "walls": ["paint_sage", "paint_rose", "stripes_cream"], "dado": "", "light": "soft", "lamp": "flush", "brightness": 1.0, "plan": "kids"},
	"playroom": {"name": "Bawialnia", "floors": ["carpet_blue", "carpet_beige", "carpet_grey"], "walls": ["paint_sage", "paint_rose", "wallpaper_floral"], "dado": "", "light": "soft", "lamp": "flush", "brightness": 1.05, "plan": "playroom"},
}

const FUTURISTIC_FLOORS: Array[String] = ["concrete", "tiles_dark", "marble"]
const FUTURISTIC_WALLS: Array[String] = ["paint_graphite", "paint_blue_grey", "paint_warm_white"]


static func get_time_of_day(id: String) -> Dictionary:
	return TIMES_OF_DAY.get(id, TIMES_OF_DAY["day"])


static func time_of_day_ids() -> Array[String]:
	return ["day", "evening", "night"]


## Dopisuje do danych trasy pola, których brakuje (starsze zapisy, trasy ręczne).
static func ensure_defaults(data: Dictionary) -> void:
	if not TIMES_OF_DAY.has(str(data.get("time_of_day", "day"))):
		data["time_of_day"] = "day"
	if not data.has("dark_room"):
		data["dark_room"] = true


## Przydziela każdemu pokojowi rodzaj, podłogę, ścianę i światło.
## Wynik zależy tylko od danych trasy (seed), więc jest powtarzalny.
## Zwraca tablicę słowników, indeks odpowiada room_bounds.
static func assign_room_styles(data: Dictionary) -> Array[Dictionary]:
	var rooms: Array = data.get("room_bounds", [])
	var result: Array[Dictionary] = []
	if rooms.is_empty():
		return result
	var rng := RandomNumberGenerator.new()
	rng.seed = int(data.get("seed", 1)) * 7 + 4242
	var theme: String = str(data.get("theme", "apartment"))

	# Kolejność od największego pokoju: największy = salon (lub kuchnia w motywie kuchennym).
	var order: Array[int] = []
	for i: int in range(rooms.size()):
		order.append(i)
	order.sort_custom(func(a: int, b: int) -> bool: return _room_area(rooms[a]) > _room_area(rooms[b]))

	var plan_types: Array[String] = ["living", "kitchen", "bedroom", "bedroom", "bathroom", "study", "hall", "kids", "playroom"]
	match theme:
		"kitchen":
			plan_types = ["kitchen", "living", "bedroom", "bedroom", "bathroom", "hall", "study", "kids", "playroom"]
		"bedroom":
			plan_types = ["bedroom", "bedroom", "living", "kids", "playroom", "bathroom", "study", "kitchen", "hall"]
		"futuristic":
			plan_types = ["living", "study", "kitchen", "hall", "bedroom", "bedroom", "bathroom", "kids", "playroom"]
		"office":
			plan_types = ["office", "office", "office", "hall", "office", "study"]
		"pro_league":
			plan_types = ["arena", "arena", "arena", "hall", "arena"]
		"cleaning_hall":
			# Otwarta hala używa przemysłowej podłogi i wyposażenia biurowo-serwisowego.
			plan_types = ["office"]

	result.resize(rooms.size())
	for rank: int in range(order.size()):
		var room_index: int = order[rank]
		var type_id: String = plan_types[rank % plan_types.size()]
		var type_data: Dictionary = ROOM_TYPES[type_id]
		var floors: Array = type_data["floors"]
		var walls: Array = type_data["walls"]
		var floor_id: String = str(floors[rng.randi_range(0, floors.size() - 1)])
		var wall_id: String = str(walls[rng.randi_range(0, walls.size() - 1)])
		if theme == "futuristic" or theme == "pro_league":
			floor_id = FUTURISTIC_FLOORS[rng.randi_range(0, FUTURISTIC_FLOORS.size() - 1)]
			wall_id = FUTURISTIC_WALLS[rng.randi_range(0, FUTURISTIC_WALLS.size() - 1)]
		elif theme == "office":
			floor_id = ["concrete", "tiles_dark", "marble"][rng.randi_range(0, 2)]
			wall_id = ["paint_graphite", "paint_blue_grey", "subway_white"][rng.randi_range(0, 2)]
		result[room_index] = {
			"type": type_id,
			"floor": floor_id,
			"wall": wall_id,
			"dado": str(type_data["dado"]),
			"light": str(type_data["light"]),
			"lamp": str(type_data["lamp"]),
			"brightness": float(type_data["brightness"]),
			"dark": false,
		}

	# Jeden pokój bez lamp w nocy: nie ten ze startem trasy i nie najmniejszy.
	if bool(data.get("dark_room", true)) and str(data.get("time_of_day", "day")) == "night" and rooms.size() >= 3:
		var route: Array = data.get("route", [])
		var start_room: int = -1
		if not route.is_empty() and route[0] is Vector3:
			start_room = room_index_at(rooms, route[0])
		var candidates: Array[int] = []
		for i: int in range(rooms.size()):
			if i != start_room and i != order[order.size() - 1]:
				candidates.append(i)
		if candidates.is_empty():
			candidates.append(order[order.size() - 1])
		var dark_index: int = candidates[rng.randi_range(0, candidates.size() - 1)]
		result[dark_index]["dark"] = true
	return result


static func room_index_at(rooms: Array, point: Vector3) -> int:
	for i: int in range(rooms.size()):
		var room: Dictionary = rooms[i]
		if point.x >= float(room.get("min_x", 0.0)) and point.x <= float(room.get("max_x", 0.0)) and point.z >= float(room.get("min_z", 0.0)) and point.z <= float(room.get("max_z", 0.0)):
			return i
	return -1


static func _room_area(room: Dictionary) -> float:
	return (float(room.get("max_x", 0.0)) - float(room.get("min_x", 0.0))) * (float(room.get("max_z", 0.0)) - float(room.get("min_z", 0.0)))
