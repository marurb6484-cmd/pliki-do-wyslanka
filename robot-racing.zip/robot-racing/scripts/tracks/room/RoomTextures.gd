class_name RoomTextures
extends RefCounted
## Proceduralne tekstury pomieszczeń (podłogi, ściany, widoki za oknem).
## Każda tekstura powstaje raz i trafia do pamięci podręcznej. Jeśli w
## res://assets/textures/rooms/ leży plik <id>_albedo.png (+ _normal / _rough),
## używany jest on zamiast generatora - patrz RoomStyleCatalog.
## Wszystkie wzory są bezszwowe (mieszanie próbek szumu 2D), więc nie widać siatki kafli.

const SIZE: int = 160

static var _cache: Dictionary = {}
static var _pending: Dictionary = {}
static var _mutex: Mutex = Mutex.new()
static var _thread: Thread = null


static func clear_cache() -> void:
	_await_prewarm()
	_cache.clear()


# =========================================================
# GENEROWANIE W TLE (żeby start wyścigu się nie zacinał)
# =========================================================

## Uruchamia w osobnym wątku generowanie wszystkich tekstur potrzebnych tej trasie.
## Wołane zaraz po wygenerowaniu trasy; do startu wyścigu zwykle jest już gotowe.
static func prewarm(data: Dictionary) -> void:
	if _thread != null:
		if _thread.is_alive():
			return
		_thread.wait_to_finish()
		_thread = null
	var styles: Array[Dictionary] = RoomStyleCatalog.assign_room_styles(data)
	var jobs: Array = []
	var seen: Dictionary = {}
	for style: Dictionary in styles:
		var floor_id: String = str(style.get("floor", ""))
		var wall_id: String = str(style.get("wall", ""))
		var dado_id: String = str(style.get("dado", ""))
		if not floor_id.is_empty() and RoomStyleCatalog.FLOORS.has(floor_id):
			_queue_job(jobs, seen, "floor_" + floor_id, floor_id, RoomStyleCatalog.FLOORS[floor_id])
		if not wall_id.is_empty() and RoomStyleCatalog.WALLS.has(wall_id):
			_queue_job(jobs, seen, "wall_" + wall_id, wall_id, RoomStyleCatalog.WALLS[wall_id])
		if not dado_id.is_empty() and RoomStyleCatalog.WALLS.has(dado_id):
			_queue_job(jobs, seen, "wall_" + dado_id, dado_id, RoomStyleCatalog.WALLS[dado_id])
	var view_kind: String = str(RoomStyleCatalog.get_time_of_day(str(data.get("time_of_day", "day"))).get("window_view", "day"))
	if not _cache.has("view_" + view_kind):
		jobs.append({"key": "view_" + view_kind, "view": view_kind})
	if jobs.is_empty():
		return
	_thread = Thread.new()
	_thread.start(_prewarm_worker.bind(jobs))


static func _queue_job(jobs: Array, seen: Dictionary, key: String, id: String, def: Dictionary) -> void:
	if _cache.has(key) or seen.has(key):
		return
	if ResourceLoader.exists(RoomStyleCatalog.TEXTURE_DIR + id + "_albedo.png"):
		return
	seen[key] = true
	jobs.append({"key": key, "id": id, "def": def})


static func _prewarm_worker(jobs: Array) -> void:
	for job: Dictionary in jobs:
		var result: Dictionary = {}
		if job.has("view"):
			result = {"view_image": _build_view_image(str(job["view"]))}
		else:
			result = _generate(str(job["id"]), job["def"])
			var def: Dictionary = job["def"]
			if result.has("height") and float(def.get("normal", 0.5)) > 0.01:
				result["normal_image"] = _normal_from_height(result["height"], SIZE)
		_mutex.lock()
		_pending[str(job["key"])] = result
		_mutex.unlock()


## Czeka na zakończenie wątku (jeśli jeszcze działa) - zwykle wraca natychmiast.
static func _await_prewarm() -> void:
	if _thread != null:
		_thread.wait_to_finish()
		_thread = null


static func _take_pending(key: String) -> Dictionary:
	_await_prewarm()
	_mutex.lock()
	var result: Dictionary = _pending.get(key, {})
	_pending.erase(key)
	_mutex.unlock()
	return result


# =========================================================
# MATERIAŁY
# =========================================================

## Materiał podłogi dla prostokąta o wymiarach width x depth (jednostki świata).
static func floor_material(floor_id: String, width: float, depth: float, external_texture_path: String = "") -> StandardMaterial3D:
	var def: Dictionary = RoomStyleCatalog.FLOORS.get(floor_id, RoomStyleCatalog.FLOORS["oak_planks"])
	var maps: Dictionary = _maps_for(floor_id, def, true)
	var material := StandardMaterial3D.new()
	material.albedo_texture = maps["albedo"]
	var external_texture_applied: bool = false
	if not external_texture_path.is_empty() and FileAccess.file_exists(external_texture_path):
		var external_image := Image.new()
		if external_image.load(external_texture_path) == OK:
			external_image.generate_mipmaps()
			material.albedo_texture = ImageTexture.create_from_image(external_image)
			external_texture_applied = true
	var floor_kind: String = str(def.get("kind", "paint"))
	material.roughness = float(def.get("roughness", 0.7))
	material.metallic = 0.0
	material.specular = 0.42 if floor_kind in ["tiles", "checker", "marble"] else 0.28
	# Delikatny lakier na płytkach i marmurze daje czytelne refleksy,
	# ale nie zamienia podłogi w lustro i nie wymaga kosztownego SSR.
	material.clearcoat_enabled = floor_kind in ["tiles", "checker", "marble"]
	if material.clearcoat_enabled:
		material.clearcoat = 0.18 if floor_kind != "marble" else 0.28
		material.clearcoat_roughness = 0.42 if floor_kind != "marble" else 0.30
	if not external_texture_applied and maps.has("normal") and maps["normal"] != null:
		material.normal_enabled = true
		material.normal_texture = maps["normal"]
		material.normal_scale = float(def.get("normal", 0.5))
	if not external_texture_applied and maps.has("rough") and maps["rough"] != null:
		material.roughness_texture = maps["rough"]
	var tile: float = float(def.get("tile", 9.0))
	material.uv1_scale = Vector3(maxf(width / tile, 0.5), maxf(depth / tile, 0.5), 1.0)
	material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	return material


## Materiał ściany; UV siatek ścian są liczone w kaflach, więc uv1_scale = 1.
static func wall_material(wall_id: String) -> StandardMaterial3D:
	var key: String = "wallmat_" + wall_id
	if _cache.has(key):
		return _cache[key]
	var def: Dictionary = RoomStyleCatalog.WALLS.get(wall_id, RoomStyleCatalog.WALLS["paint_warm_white"])
	var maps: Dictionary = _maps_for(wall_id, def, false)
	var material := StandardMaterial3D.new()
	material.albedo_texture = maps["albedo"]
	material.roughness = float(def.get("roughness", 0.9))
	if maps.has("normal") and maps["normal"] != null:
		material.normal_enabled = true
		material.normal_texture = maps["normal"]
		material.normal_scale = 0.5
	material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	_cache[key] = material
	return material


static func wall_tile_size(wall_id: String) -> float:
	var def: Dictionary = RoomStyleCatalog.WALLS.get(wall_id, RoomStyleCatalog.WALLS["paint_warm_white"])
	return float(def.get("tile", 8.0))


## Zwraca {"albedo": Texture2D, "normal": Texture2D|null, "rough": Texture2D|null}.
static func _maps_for(id: String, def: Dictionary, is_floor: bool) -> Dictionary:
	var key: String = ("floor_" if is_floor else "wall_") + id
	if _cache.has(key):
		return _cache[key]
	var maps: Dictionary = {}
	var albedo_path: String = RoomStyleCatalog.TEXTURE_DIR + id + "_albedo.png"
	if ResourceLoader.exists(albedo_path):
		maps["albedo"] = load(albedo_path)
		var normal_path: String = RoomStyleCatalog.TEXTURE_DIR + id + "_normal.png"
		var rough_path: String = RoomStyleCatalog.TEXTURE_DIR + id + "_rough.png"
		maps["normal"] = load(normal_path) if ResourceLoader.exists(normal_path) else null
		maps["rough"] = load(rough_path) if ResourceLoader.exists(rough_path) else null
	else:
		var generated: Dictionary = _take_pending(key)
		if generated.is_empty():
			generated = _generate(id, def)
			if generated.has("height") and float(def.get("normal", 0.5)) > 0.01:
				generated["normal_image"] = _normal_from_height(generated["height"], SIZE)
		var albedo_image: Image = generated["albedo"]
		albedo_image.generate_mipmaps()
		maps["albedo"] = ImageTexture.create_from_image(albedo_image)
		maps["normal"] = null
		if generated.has("normal_image"):
			var normal_image: Image = generated["normal_image"]
			normal_image.generate_mipmaps()
			maps["normal"] = ImageTexture.create_from_image(normal_image)
		maps["rough"] = null
	_cache[key] = maps
	return maps


# =========================================================
# GENERATORY
# =========================================================

static func _generate(id: String, def: Dictionary) -> Dictionary:
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(id)
	var noise := FastNoiseLite.new()
	noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise.frequency = 1.0
	noise.seed = int(rng.randi() % 100000)
	var kind: String = str(def.get("kind", "paint"))
	match kind:
		"planks":
			return _gen_planks(def, rng, noise, false)
		"wood_panel":
			return _gen_planks({"colors": [def.get("color", Color("#9a6c46")), def.get("accent", Color("#7d5535"))], "count": 5}, rng, noise, true)
		"parquet":
			return _gen_parquet(def, rng, noise)
		"tiles", "checker":
			return _gen_tiles(def, rng, noise, kind == "checker")
		"carpet":
			return _gen_carpet(def, rng, noise)
		"concrete":
			return _gen_concrete(def, rng, noise)
		"marble":
			return _gen_marble(def, rng, noise)
		"wallpaper":
			return _gen_wallpaper(def, rng, noise)
		"stripes":
			return _gen_stripes(def, rng, noise)
		"subway":
			return _gen_brick_like(def, rng, noise, true)
		"brick":
			return _gen_brick_like(def, rng, noise, false)
	return _gen_paint(def, rng, noise)


## Szum bezszwowy (powtarzalny co kafel): miesza cztery próbki szumu 2D przesunięte
## o okres kafla, więc krawędzie kafli idealnie do siebie pasują.
static func _tn(noise: FastNoiseLite, x: int, y: int, fx: float, fy: float) -> float:
	var period_u: float = fx * 1.5
	var period_v: float = fy * 1.5
	var wx: float = float(x) / float(SIZE)
	var wy: float = float(y) / float(SIZE)
	var u: float = wx * period_u
	var v: float = wy * period_v
	var n00: float = noise.get_noise_2d(u, v)
	var n10: float = noise.get_noise_2d(u - period_u, v)
	var n01: float = noise.get_noise_2d(u, v - period_v)
	var n11: float = noise.get_noise_2d(u - period_u, v - period_v)
	return n00 * (1.0 - wx) * (1.0 - wy) + n10 * wx * (1.0 - wy) + n01 * (1.0 - wx) * wy + n11 * wx * wy


static func _new_image() -> Image:
	return Image.create(SIZE, SIZE, false, Image.FORMAT_RGB8)


static func _gen_paint(def: Dictionary, rng: RandomNumberGenerator, noise: FastNoiseLite) -> Dictionary:
	var image: Image = _new_image()
	var base: Color = def.get("color", Color("#e8e0d2"))
	for y: int in range(SIZE):
		for x: int in range(SIZE):
			var n: float = _tn(noise, x, y, 1.6, 1.6)
			var grain: float = (rng.randf() - 0.5) * 0.025
			image.set_pixel(x, y, base * (1.0 + n * 0.035 + grain))
	return {"albedo": image}


static func _gen_planks(def: Dictionary, rng: RandomNumberGenerator, noise: FastNoiseLite, vertical: bool) -> Dictionary:
	var image: Image = _new_image()
	var height := PackedFloat32Array()
	height.resize(SIZE * SIZE)
	var colors: Array = def.get("colors", [Color("#b98b57")])
	var count: int = int(def.get("count", 6))
	var plank_w: float = float(SIZE) / float(count)
	var piece_len: int = SIZE / 2
	var plank_color: Array[Color] = []
	var plank_offset: Array[int] = []
	for i: int in range(count):
		plank_color.append((colors[rng.randi_range(0, colors.size() - 1)] as Color) * rng.randf_range(0.92, 1.08))
		plank_offset.append(rng.randi_range(0, SIZE - 1))
	for y: int in range(SIZE):
		for x: int in range(SIZE):
			var across: int = y if vertical else x
			var along: int = x if vertical else y
			var plank: int = clampi(int(float(across) / plank_w), 0, count - 1)
			var local_across: float = float(across) - float(plank) * plank_w
			var shifted: int = (along + plank_offset[plank]) % SIZE
			var piece: int = shifted / piece_len
			var piece_pos: int = shifted % piece_len
			var piece_tint: float = 0.94 + 0.12 * float(hash(Vector2i(plank, piece)) % 100) / 100.0
			var grain: float = _tn(noise, x, y, 1.2 if vertical else 5.0, 5.0 if vertical else 1.2)
			var rings: float = 0.5 + 0.5 * sin(local_across * 0.55 + grain * 7.0)
			var color: Color = plank_color[plank] * piece_tint
			color = color.lerp(color * 0.80, rings * 0.35 + (grain * 0.5 + 0.5) * 0.25)
			var h: float = 1.0
			if local_across < 1.6 or local_across > plank_w - 1.6 or piece_pos < 1 or piece_pos > piece_len - 2:
				color *= 0.42
				h = 0.0
			image.set_pixel(x, y, color)
			height[y * SIZE + x] = h + grain * 0.04
	return {"albedo": image, "height": height}


static func _gen_parquet(def: Dictionary, rng: RandomNumberGenerator, noise: FastNoiseLite) -> Dictionary:
	var image: Image = _new_image()
	var height := PackedFloat32Array()
	height.resize(SIZE * SIZE)
	var colors: Array = def.get("colors", [Color("#c29056")])
	var cells: int = int(def.get("count", 4))
	var cell: float = float(SIZE) / float(cells)
	var strips: int = 3
	for y: int in range(SIZE):
		for x: int in range(SIZE):
			var cx: int = int(float(x) / cell)
			var cy: int = int(float(y) / cell)
			var horizontal: bool = (cx + cy) % 2 == 0
			var lx: float = float(x) - float(cx) * cell
			var ly: float = float(y) - float(cy) * cell
			var across: float = ly if horizontal else lx
			var strip: int = clampi(int(across / (cell / float(strips))), 0, strips - 1)
			var strip_local: float = across - float(strip) * cell / float(strips)
			var base: Color = (colors[hash(Vector3i(cx, cy, strip)) % colors.size()] as Color)
			var grain: float = _tn(noise, x, y, 4.0 if horizontal else 1.0, 1.0 if horizontal else 4.0)
			var color: Color = base * (0.92 + 0.12 * (grain * 0.5 + 0.5))
			var h: float = 1.0
			if strip_local < 1.4 or strip_local > cell / float(strips) - 1.4 or lx < 1.0 or ly < 1.0:
				color *= 0.45
				h = 0.0
			image.set_pixel(x, y, color)
			height[y * SIZE + x] = h
	return {"albedo": image, "height": height}


static func _gen_tiles(def: Dictionary, rng: RandomNumberGenerator, noise: FastNoiseLite, checker: bool) -> Dictionary:
	var image: Image = _new_image()
	var height := PackedFloat32Array()
	height.resize(SIZE * SIZE)
	var colors: Array = def.get("colors", [Color("#dedad2")])
	var grout: Color = def.get("grout", Color("#9c978d"))
	var count: int = int(def.get("count", 3)) * 2
	var cell: float = float(SIZE) / float(count)
	for y: int in range(SIZE):
		for x: int in range(SIZE):
			var cx: int = int(float(x) / cell)
			var cy: int = int(float(y) / cell)
			var lx: float = float(x) - float(cx) * cell
			var ly: float = float(y) - float(cy) * cell
			var pick: int = (cx + cy) % 2 if checker else hash(Vector2i(cx, cy)) % colors.size()
			var base: Color = colors[pick % colors.size()]
			var n: float = _tn(noise, x, y, 2.5, 2.5)
			var color: Color = base * (0.96 + 0.07 * n + (rng.randf() - 0.5) * 0.015)
			var edge: float = minf(minf(lx, cell - lx), minf(ly, cell - ly))
			var h: float = 1.0
			if edge < 1.7:
				color = grout * (0.9 + 0.1 * n)
				h = 0.0
			elif edge < 3.0:
				h = (edge - 1.7) / 1.3
			image.set_pixel(x, y, color)
			height[y * SIZE + x] = h
	return {"albedo": image, "height": height}


static func _gen_carpet(def: Dictionary, rng: RandomNumberGenerator, noise: FastNoiseLite) -> Dictionary:
	var image: Image = _new_image()
	var base: Color = (def.get("colors", [Color("#8b8e93")]) as Array)[0]
	for y: int in range(SIZE):
		for x: int in range(SIZE):
			var fiber: float = rng.randf()
			var blotch: float = _tn(noise, x, y, 2.0, 2.0)
			image.set_pixel(x, y, base * (0.84 + 0.22 * fiber + 0.05 * blotch))
	return {"albedo": image}


static func _gen_concrete(def: Dictionary, rng: RandomNumberGenerator, noise: FastNoiseLite) -> Dictionary:
	var image: Image = _new_image()
	var height := PackedFloat32Array()
	height.resize(SIZE * SIZE)
	var base: Color = (def.get("colors", [Color("#8f9196")]) as Array)[0]
	for y: int in range(SIZE):
		for x: int in range(SIZE):
			var low: float = _tn(noise, x, y, 1.4, 1.4)
			var fine: float = _tn(noise, x, y, 9.0, 9.0)
			var pore: float = 1.0 if rng.randf() > 0.994 else 0.0
			var value: float = 1.0 + low * 0.10 + fine * 0.05 - pore * 0.25
			image.set_pixel(x, y, base * value)
			height[y * SIZE + x] = fine * 0.5 - pore
	return {"albedo": image, "height": height}


static func _gen_marble(def: Dictionary, rng: RandomNumberGenerator, noise: FastNoiseLite) -> Dictionary:
	var image: Image = _new_image()
	var colors: Array = def.get("colors", [Color("#e9e6e1"), Color("#8f98a3")])
	var base: Color = colors[0]
	var vein: Color = colors[1]
	for y: int in range(SIZE):
		for x: int in range(SIZE):
			var warp: float = _tn(noise, x, y, 1.3, 1.3)
			var phase: float = (float(x) + float(y) * 0.6) / float(SIZE) * TAU * 2.0 + warp * 4.5
			var line: float = pow(1.0 - absf(sin(phase)), 14.0)
			var fine: float = pow(1.0 - absf(sin(phase * 3.1 + warp * 9.0)), 24.0) * 0.4
			var cloud: float = 0.96 + 0.05 * _tn(noise, x, y, 3.0, 3.0)
			image.set_pixel(x, y, (base * cloud).lerp(vein, clampf(line * 0.65 + fine, 0.0, 0.8)))
	return {"albedo": image}


static func _gen_wallpaper(def: Dictionary, rng: RandomNumberGenerator, noise: FastNoiseLite) -> Dictionary:
	var image: Image = _new_image()
	var base: Color = def.get("color", Color("#d9cdb8"))
	var accent: Color = def.get("accent", Color("#8aa07a"))
	var cells: int = 4
	var cell: float = float(SIZE) / float(cells)
	for y: int in range(SIZE):
		for x: int in range(SIZE):
			var row: int = int(float(y) / cell)
			var offset_x: float = cell * 0.5 if row % 2 == 1 else 0.0
			var lx: float = fposmod(float(x) + offset_x, cell) - cell * 0.5
			var ly: float = fposmod(float(y), cell) - cell * 0.5
			var angle: float = atan2(ly, lx)
			var radius: float = Vector2(lx, ly).length()
			# Kwiat: płatki jako modulacja promienia.
			var petal: float = 9.0 + 4.0 * absf(sin(angle * 3.0))
			var flower: float = smoothstep(petal, petal - 2.0, radius)
			var core: float = smoothstep(3.5, 2.5, radius)
			var n: float = _tn(noise, x, y, 3.0, 3.0)
			var color: Color = base * (0.97 + 0.04 * n)
			color = color.lerp(accent, flower * 0.75)
			color = color.lerp(accent.lightened(0.45), core)
			image.set_pixel(x, y, color)
	return {"albedo": image}


static func _gen_stripes(def: Dictionary, rng: RandomNumberGenerator, noise: FastNoiseLite) -> Dictionary:
	var image: Image = _new_image()
	var base: Color = def.get("color", Color("#e4dac6"))
	var accent: Color = def.get("accent", Color("#cdbfa4"))
	var stripes: int = 8
	var width: float = float(SIZE) / float(stripes)
	for y: int in range(SIZE):
		for x: int in range(SIZE):
			var stripe: int = int(float(x) / width)
			var local: float = float(x) - float(stripe) * width
			var color: Color = base if stripe % 2 == 0 else accent
			if local < 1.5:
				color = color.darkened(0.06)
			var n: float = _tn(noise, x, y, 3.0, 3.0)
			image.set_pixel(x, y, color * (0.98 + 0.03 * n))
	return {"albedo": image}


static func _gen_brick_like(def: Dictionary, rng: RandomNumberGenerator, noise: FastNoiseLite, glossy_tile: bool) -> Dictionary:
	var image: Image = _new_image()
	var height := PackedFloat32Array()
	height.resize(SIZE * SIZE)
	var base: Color = def.get("color", Color("#a45a45"))
	var mortar: Color = def.get("accent", Color("#c9bfae"))
	var rows: int = 12 if glossy_tile else 8
	var columns: int = 4 if glossy_tile else 3
	var row_h: float = float(SIZE) / float(rows)
	var col_w: float = float(SIZE) / float(columns)
	for y: int in range(SIZE):
		for x: int in range(SIZE):
			var row: int = int(float(y) / row_h)
			var shift: float = col_w * 0.5 if row % 2 == 1 else 0.0
			var shifted_x: float = fposmod(float(x) + shift, float(SIZE))
			var col: int = int(shifted_x / col_w)
			var lx: float = shifted_x - float(col) * col_w
			var ly: float = float(y) - float(row) * row_h
			var tint: float = 0.9 + 0.2 * float(hash(Vector2i(col, row)) % 100) / 100.0
			var n: float = _tn(noise, x, y, 4.0, 4.0)
			var color: Color = base * (tint + n * 0.05)
			var h: float = 1.0
			var edge: float = minf(minf(lx, col_w - lx), minf(ly, row_h - ly))
			if edge < 1.6:
				color = mortar * (0.92 + 0.08 * n)
				h = 0.0
			image.set_pixel(x, y, color)
			height[y * SIZE + x] = h
	return {"albedo": image, "height": height}


static func _normal_from_height(height: PackedFloat32Array, size: int) -> Image:
	var image: Image = Image.create(size, size, false, Image.FORMAT_RGB8)
	var strength: float = 2.2
	for y: int in range(size):
		for x: int in range(size):
			var left: float = height[y * size + posmod(x - 1, size)]
			var right: float = height[y * size + posmod(x + 1, size)]
			var up: float = height[posmod(y - 1, size) * size + x]
			var down: float = height[posmod(y + 1, size) * size + x]
			var normal := Vector3((left - right) * strength, (down - up) * strength, 1.0).normalized()
			image.set_pixel(x, y, Color(normal.x * 0.5 + 0.5, normal.y * 0.5 + 0.5, normal.z * 0.5 + 0.5))
	return image


# =========================================================
# WIDOK ZA OKNEM I PLAMY ŚWIATŁA
# =========================================================

## Panorama widoczna przez okno: dzień (niebo, chmury, budynki, drzewa),
## wieczór (zachód słońca) albo noc (gwiazdy, księżyc, światła miasta).
static func window_view(kind: String) -> Texture2D:
	var key: String = "view_" + kind
	if _cache.has(key):
		return _cache[key]
	var pending: Dictionary = _take_pending(key)
	var image: Image = pending.get("view_image", null) as Image
	if image == null:
		image = _build_view_image(kind)
	image.generate_mipmaps()
	var texture: ImageTexture = ImageTexture.create_from_image(image)
	_cache[key] = texture
	return texture


static func _build_view_image(kind: String) -> Image:
	var width: int = 288
	var view_height: int = 144
	var image: Image = Image.create(width, view_height, false, Image.FORMAT_RGB8)
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(kind)
	var noise := FastNoiseLite.new()
	noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise.fractal_type = FastNoiseLite.FRACTAL_FBM
	noise.frequency = 0.012
	noise.seed = rng.randi() % 10000

	var sky_top: Color = Color(0.30, 0.55, 0.88)
	var sky_bottom: Color = Color(0.82, 0.91, 0.98)
	var building: Color = Color(0.55, 0.62, 0.70)
	var building_far: Color = Color(0.68, 0.76, 0.84)
	match kind:
		"evening":
			sky_top = Color(0.25, 0.22, 0.45)
			sky_bottom = Color(1.0, 0.62, 0.35)
			building = Color(0.18, 0.14, 0.2)
			building_far = Color(0.42, 0.30, 0.38)
		"night":
			sky_top = Color(0.01, 0.02, 0.07)
			sky_bottom = Color(0.08, 0.10, 0.20)
			building = Color(0.025, 0.03, 0.05)
			building_far = Color(0.05, 0.06, 0.11)

	# Sylwety budynków: wysokości w kolumnach.
	var heights_far := PackedInt32Array()
	var heights_near := PackedInt32Array()
	var x_cursor: int = 0
	while x_cursor < width:
		var block_w: int = rng.randi_range(10, 28)
		var h_far: int = rng.randi_range(30, 58)
		var h_near: int = rng.randi_range(14, 40)
		for i: int in range(block_w):
			heights_far.append(h_far)
			heights_near.append(h_near)
		x_cursor += block_w
	var ground_line: int = view_height - 18
	for y: int in range(view_height):
		var t: float = float(y) / float(ground_line)
		var sky: Color = sky_top.lerp(sky_bottom, clampf(pow(t, 1.4), 0.0, 1.0))
		for x: int in range(width):
			var color: Color = sky
			if kind == "day":
				var cloud: float = smoothstep(0.12, 0.45, noise.get_noise_2d(float(x), float(y) * 2.2))
				color = color.lerp(Color(1, 1, 1), cloud * 0.8 * (1.0 - t))
			elif kind == "evening":
				var sun_dist: float = Vector2(float(x) - width * 0.68, float(y) - ground_line * 0.92).length()
				color = color.lerp(Color(1.0, 0.9, 0.55), clampf(1.0 - sun_dist / 70.0, 0.0, 1.0) * 0.85)
				if sun_dist < 13.0:
					color = Color(1.0, 0.97, 0.8)
				var streak: float = smoothstep(0.1, 0.5, noise.get_noise_2d(float(x), float(y) * 4.5))
				color = color.lerp(Color(0.95, 0.45, 0.4), streak * 0.35 * (1.0 - t))
			else:
				if rng.randf() > 0.9965 and t < 0.8:
					var star: float = rng.randf_range(0.5, 1.0)
					color = Color(star, star, star)
				var moon_dist: float = Vector2(float(x) - width * 0.25, float(y) - 32.0).length()
				color = color.lerp(Color(0.8, 0.85, 1.0), clampf(1.0 - moon_dist / 48.0, 0.0, 1.0) * 0.25)
				if moon_dist < 11.0:
					color = Color(0.93, 0.95, 1.0)
			# Budynki daleko, blisko, korony drzew.
			var far_top: int = ground_line - heights_far[x]
			var near_top: int = ground_line - heights_near[x]
			if y >= far_top and y < ground_line:
				color = building_far
				if kind == "night" and (x % 5 == 2) and (y % 7 == 3) and ((x * 31 + y * 17) % 3 != 0):
					color = Color(1.0, 0.85, 0.5) * 0.65
			if y >= near_top and y < ground_line:
				color = building
				if kind == "night" and (x % 6 == 3) and (y % 6 == 2) and ((x * 13 + y * 7) % 4 != 0):
					color = Color(1.0, 0.8, 0.42)
				elif kind == "day" and (x % 6 == 3) and (y % 6 == 2):
					color = building.lightened(0.25)
			if y >= ground_line:
				var tree: float = noise.get_noise_2d(float(x) * 3.0, 40.0)
				var tree_top: int = ground_line + int(6.0 + tree * 8.0)
				if y >= tree_top - 6:
					color = Color(0.20, 0.42, 0.22) if kind == "day" else (Color(0.12, 0.10, 0.12) if kind == "evening" else Color(0.015, 0.03, 0.025))
			image.set_pixel(x, y, color)
	return image


## Miękka plama światła na podłodze (mieszanie addytywne).
static func light_pool() -> Texture2D:
	if _cache.has("light_pool"):
		return _cache["light_pool"]
	var gradient := Gradient.new()
	gradient.set_color(0, Color(1, 1, 1, 1))
	gradient.set_color(1, Color(1, 1, 1, 0))
	gradient.add_point(0.35, Color(1, 1, 1, 0.55))
	var texture := GradientTexture2D.new()
	texture.gradient = gradient
	texture.fill = GradientTexture2D.FILL_RADIAL
	texture.fill_from = Vector2(0.5, 0.5)
	texture.fill_to = Vector2(1.0, 0.5)
	texture.width = 128
	texture.height = 128
	_cache["light_pool"] = texture
	return texture
