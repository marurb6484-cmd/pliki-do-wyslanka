extends ScrollContainer
## Przewijanie zawartości gestem przesunięcia palca, także rozpoczętym na etykiecie.

var _active_touch: int = -1
var _last_touch_position: Vector2 = Vector2.ZERO


func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var touch := event as InputEventScreenTouch
		if touch.pressed:
			_active_touch = touch.index
			_last_touch_position = touch.position
		else:
			if touch.index == _active_touch:
				_active_touch = -1
			accept_event()
	elif event is InputEventScreenDrag and _active_touch == (event as InputEventScreenDrag).index:
		var drag := event as InputEventScreenDrag
		var delta_y: float = drag.position.y - _last_touch_position.y
		_last_touch_position = drag.position
		var scroll_limit: int = maxi(0, int(ceil(get_v_scroll_bar().max_value - get_v_scroll_bar().page)))
		scroll_vertical = clampi(scroll_vertical - roundi(delta_y), 0, scroll_limit)
		accept_event()
