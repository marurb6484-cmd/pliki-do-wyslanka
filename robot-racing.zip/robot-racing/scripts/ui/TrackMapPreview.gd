class_name TrackMapPreview
extends Control

const TrackGeneratorScript = preload("res://scripts/tracks/TrackGenerator.gd")
## Czytelny, dotykowy podgląd 2D tras. Współrzędne świata: X/Z.

signal world_pressed(world_position: Vector3)
signal world_dragged(world_position: Vector3)
signal world_released()
signal zoom_changed(value: float)

var map_data: Dictionary = {}
var selected_decoration: int = -1
var selected_obstacle: int = -1
var pan_mode: bool = false
var zoom: float = 1.0
var _base_scale: float = 1.0
var _center_world: Vector2 = Vector2.ZERO
var _pan_offset: Vector2 = Vector2.ZERO
var _active_touch_positions: Dictionary = {}
var _last_touch_position: Vector2 = Vector2.ZERO
var _last_pinch_distance: float = 0.0
var _last_pinch_center: Vector2 = Vector2.ZERO
var _pinch_active: bool = false
var _dragging_map: bool = false
var _last_pointer_position: Vector2 = Vector2.ZERO


func _is_route_closed() -> bool:
	if map_data.has("route_closed"):
		return bool(map_data["route_closed"])
	if map_data.has("route_type"):
		return str(map_data["route_type"]) != "segment"
	if map_data.has("manual_route_closed"):
		return bool(map_data["manual_route_closed"])
	return not bool(map_data.get("segment", false))

func set_map_data(data: Dictionary, decoration_index: int = -1, obstacle_index: int = -1) -> void:
	map_data = data
	selected_decoration = decoration_index
	selected_obstacle = obstacle_index
	fit_map()
	queue_redraw()

func refresh_map_data(data: Dictionary, decoration_index: int = -1, obstacle_index: int = -1) -> void:
	map_data = data
	selected_decoration = decoration_index
	selected_obstacle = obstacle_index
	queue_redraw()

func set_zoom_level(value: float) -> void:
	zoom = clampf(value, 0.35, 4.0)
	zoom_changed.emit(zoom)
	queue_redraw()

func set_selection(decoration_index: int, obstacle_index: int) -> void:
	selected_decoration = decoration_index
	selected_obstacle = obstacle_index
	queue_redraw()

func set_pan_mode(enabled: bool) -> void:
	pan_mode = enabled
	_dragging_map = false
	_pinch_active = false

func fit_map() -> void:
	var points: Array[Vector2] = []
	for value: Variant in map_data.get("route", []):
		if value is Vector3:
			points.append(Vector2(value.x, value.z))
	for value: Variant in map_data.get("docking_stations", []):
		if value is Dictionary and value.get("position") is Vector3:
			var p: Vector3 = value["position"]
			points.append(Vector2(p.x, p.z))
	for value: Variant in map_data.get("decorations", []):
		if value is Dictionary and value.get("position") is Vector3:
			var p: Vector3 = value["position"]
			points.append(Vector2(p.x, p.z))
	for value: Variant in map_data.get("obstacles", []):
		if value is Vector3:
			points.append(Vector2(value.x, value.z))
	for room_value: Variant in map_data.get("room_bounds", []):
		if room_value is Dictionary:
			var room: Dictionary = room_value
			points.append(Vector2(float(room.get("min_x", 0.0)), float(room.get("min_z", 0.0))))
			points.append(Vector2(float(room.get("max_x", 0.0)), float(room.get("max_z", 0.0))))
	var start_bounds: Dictionary = map_data.get("start_room_bounds", {})
	if not start_bounds.is_empty():
		points.append(Vector2(float(start_bounds.get("min_x", 0.0)), float(start_bounds.get("min_z", 0.0))))
		points.append(Vector2(float(start_bounds.get("max_x", 0.0)), float(start_bounds.get("max_z", 0.0))))
	if points.is_empty():
		return
	var min_point := Vector2(INF, INF)
	var max_point := Vector2(-INF, -INF)
	for p: Vector2 in points:
		min_point.x = minf(min_point.x, p.x)
		min_point.y = minf(min_point.y, p.y)
		max_point.x = maxf(max_point.x, p.x)
		max_point.y = maxf(max_point.y, p.y)
	_center_world = (min_point + max_point) * 0.5
	var world_size: Vector2 = (max_point - min_point) + Vector2(12.0, 12.0)
	var available: Vector2 = size - Vector2(28.0, 28.0)
	if available.x <= 0.0 or available.y <= 0.0:
		return
	_base_scale = minf(available.x / maxf(world_size.x, 1.0), available.y / maxf(world_size.y, 1.0))
	_base_scale = maxf(_base_scale, 0.01)
	zoom = 1.0
	_pan_offset = Vector2.ZERO
	zoom_changed.emit(zoom)

func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED and not map_data.is_empty():
		fit_map()
		queue_redraw()

func _world_to_screen(point: Vector2) -> Vector2:
	return size * 0.5 + _pan_offset + (point - _center_world) * _base_scale * zoom * Vector2(1.0, -1.0)

func screen_to_world(point: Vector2) -> Vector3:
	var scale_value: float = maxf(_base_scale * zoom, 0.0001)
	var world: Vector2 = (point - size * 0.5 - _pan_offset) / scale_value * Vector2(1.0, -1.0) + _center_world
	return Vector3(world.x, 0.0, world.y)

func get_world_units_per_pixel() -> float:
	return 1.0 / maxf(_base_scale * zoom, 0.0001)

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color("#111923"), true)
	_draw_grid()
	_draw_room_zones()
	var route: Array = map_data.get("route", [])
	if route.size() >= 2:
		var centerline := PackedVector2Array()
		for point: Variant in route:
			if point is Vector3:
				centerline.append(_world_to_screen(Vector2(point.x, point.z)))
		if _is_route_closed() and centerline.size() > 2:
			centerline.append(centerline[0])
		var width_world: float = float(map_data.get("track_width", 1.2))
		var width_px: float = clampf(width_world * _base_scale * zoom, 8.0, 110.0)
		# Delikatna strefa bezpieczeństwa pokazuje, gdzie nie należy stawiać ścian ani dużych mebli.
		var clearance_px: float = maxf(width_px + 4.0, (width_world + 1.8) * _base_scale * zoom)
		draw_polyline(centerline, Color("#35c6bd", 0.16), clearance_px, true)
		draw_polyline(centerline, Color("#263744"), width_px + 12.0, true)
		draw_polyline(centerline, Color("#8998a2"), width_px, true)
		draw_polyline(centerline, Color("#d4d9dc"), 2.0, true)
		for i: int in range(centerline.size()):
			draw_circle(centerline[i], 4.0, Color("#f2f4f5"))
		if centerline.size() >= 2:
			var start_mid: Vector2 = (centerline[0] + centerline[1]) * 0.5
			var tangent: Vector2 = (centerline[1] - centerline[0]).normalized()
			var normal := Vector2(-tangent.y, tangent.x)
			draw_line(start_mid - normal * width_px * 0.48, start_mid + normal * width_px * 0.48, Color("#f7d34a"), 5.0, true)
		# Widoczne checkpointy w podglądzie 2D, w tej samej kolejności co bramki 3D.
		var closed_route: bool = _is_route_closed()
		var checkpoint_fractions: Array[float] = []
		checkpoint_fractions.append(0.25)
		checkpoint_fractions.append(0.5)
		checkpoint_fractions.append(0.75)
		if not closed_route:
			checkpoint_fractions.append(1.0)
		var route_segment_count: int = centerline.size() - 1
		var route_distances: PackedFloat32Array = PackedFloat32Array([0.0])
		for segment_index: int in range(route_segment_count):
			var next_index: int = (segment_index + 1) % centerline.size()
			route_distances.append(route_distances[route_distances.size() - 1] + centerline[segment_index].distance_to(centerline[next_index]))
		var route_total: float = route_distances[route_distances.size() - 1]
		for checkpoint_index: int in range(checkpoint_fractions.size()):
			var target: float = route_total * checkpoint_fractions[checkpoint_index]
			var checkpoint_point: Vector2 = centerline[centerline.size() - 1]
			for segment_index: int in range(route_segment_count):
				if route_distances[segment_index + 1] >= target:
					var segment_length: float = maxf(route_distances[segment_index + 1] - route_distances[segment_index], 0.001)
					var t: float = clampf((target - route_distances[segment_index]) / segment_length, 0.0, 1.0)
					checkpoint_point = centerline[segment_index].lerp(centerline[(segment_index + 1) % centerline.size()], t)
					break
			draw_circle(checkpoint_point, 10.0, Color("#0b1d28"))
			draw_circle(checkpoint_point, 7.0, Color("#21e8ff"))
			draw_arc(checkpoint_point, 10.0, 0.0, TAU, 24, Color.WHITE, 2.0)
			var checkpoint_label: String = "META" if not closed_route and checkpoint_index == checkpoint_fractions.size() - 1 else "CP%d" % (checkpoint_index + 1)
			draw_string(ThemeDB.fallback_font, checkpoint_point + Vector2(10.0, -8.0), checkpoint_label, HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("#c8faff"))
	# Ściany rysujemy ponownie NA trasie, żeby nie znikały pod szerokim pasem jezdni.
	_draw_room_walls_overlay()
	_draw_stations()
	_draw_obstacles()
	_draw_decorations()
	_draw_object_legend()
	_draw_compass_and_hint()

func _draw_room_zones() -> void:
	var route: Array = map_data.get("route", [])
	if route.size() < 2:
		return
	var min_x: float = INF
	var max_x: float = -INF
	var min_z: float = INF
	var max_z: float = -INF
	for value: Variant in route:
		if not (value is Vector3):
			continue
		var point: Vector3 = value
		min_x = minf(min_x, point.x)
		max_x = maxf(max_x, point.x)
		min_z = minf(min_z, point.z)
		max_z = maxf(max_z, point.z)
	# Podgląd używa tych samych granic co generator; duży zapas 23 m
	# powodował rysowanie pokoju daleko poza właściwą mapą.
	var room_min := Vector2(min_x - 3.0, min_z - 3.0)
	var room_max := Vector2(max_x + 3.0, max_z + 3.0)
	var top_left: Vector2 = _world_to_screen(Vector2(room_min.x, room_max.y))
	var bottom_right: Vector2 = _world_to_screen(Vector2(room_max.x, room_min.y))
	var room_rect := Rect2(top_left, bottom_right - top_left).abs()
	draw_rect(room_rect, Color("#263b48", 0.42), true)
	draw_rect(room_rect, Color("#7c9aa8", 0.72), false, 1.5)
	if str(map_data.get("theme", "apartment")) != "futuristic":
		var route_width: float = float(map_data.get("track_width", 1.2))
		var route_data: Array = map_data.get("route", [])
		var partitions: Array = map_data.get("room_partitions", [])
		if partitions.is_empty() and str(map_data.get("theme", "apartment")) != "cleaning_hall":
			var middle_x: float = (room_min.x + room_max.x) * 0.5
			var middle_z: float = (room_min.y + room_max.y) * 0.5
			partitions = [{"vertical": true, "axis": middle_x, "min": room_min.y, "max": room_max.y}, {"vertical": false, "axis": middle_z, "min": room_min.x, "max": room_max.x}]
		for partition: Dictionary in partitions:
			var vertical: bool = bool(partition.get("vertical", true))
			var axis_value: float = float(partition.get("axis", 0.0))
			var extent_min: float = float(partition.get("min", 0.0))
			var extent_max: float = float(partition.get("max", 0.0))
			var openings: Array[Vector2] = TrackGeneratorScript.get_room_partition_openings(route_data, vertical, axis_value, route_width, extent_min, extent_max, _is_route_closed())
			_draw_partition_preview(vertical, axis_value, extent_min, extent_max, openings)
	var room_bounds: Array = map_data.get("room_bounds", [])
	var room_names: Array[String] = ["SALON", "KUCHNIA", "SYPIALNIA", "POKÓJ", "GABINET", "ŁAZIENKA", "KORYTARZ", "JADALNIA", "POKÓJ GOŚCINNY"]
	if room_bounds.is_empty():
		room_bounds = [{"min_x": room_min.x, "max_x": (room_min.x + room_max.x) * 0.5, "min_z": room_min.y, "max_z": (room_min.y + room_max.y) * 0.5}, {"min_x": (room_min.x + room_max.x) * 0.5, "max_x": room_max.x, "min_z": room_min.y, "max_z": (room_min.y + room_max.y) * 0.5}, {"min_x": room_min.x, "max_x": (room_min.x + room_max.x) * 0.5, "min_z": (room_min.y + room_max.y) * 0.5, "max_z": room_max.y}, {"min_x": (room_min.x + room_max.x) * 0.5, "max_x": room_max.x, "min_z": (room_min.y + room_max.y) * 0.5, "max_z": room_max.y}]
	for room_index: int in range(room_bounds.size()):
		var room: Dictionary = room_bounds[room_index]
		var center_x: float = (float(room.get("min_x", 0.0)) + float(room.get("max_x", 0.0))) * 0.5
		var center_z: float = (float(room.get("min_z", 0.0)) + float(room.get("max_z", 0.0))) * 0.5
		var label_position: Vector2 = _world_to_screen(Vector2(center_x, center_z))
		if room_index < room_names.size():
			draw_string(ThemeDB.fallback_font, label_position, room_names[room_index], HORIZONTAL_ALIGNMENT_CENTER, -1, 12, Color(1.0, 1.0, 1.0, 0.48))
	var start_bounds: Dictionary = map_data.get("start_room_bounds", {})
	if not start_bounds.is_empty():
		var start_center := Vector2((float(start_bounds.get("min_x", 0.0)) + float(start_bounds.get("max_x", 0.0))) * 0.5, (float(start_bounds.get("min_z", 0.0)) + float(start_bounds.get("max_z", 0.0))) * 0.5)
		draw_string(ThemeDB.fallback_font, _world_to_screen(start_center), "START / STACJE", HORIZONTAL_ALIGNMENT_CENTER, -1, 13, Color("#72ff9a"))


func _draw_room_walls_overlay() -> void:
	var route: Array = map_data.get("route", [])
	var width: float = float(map_data.get("track_width", 1.2))
	var partitions: Array = map_data.get("room_partitions", [])
	var room_bounds: Array = map_data.get("room_bounds", [])
	# Zewnętrzny obrys mieszkania jest rysowany ponownie na wierzchu mapy.
	if not room_bounds.is_empty():
		var min_x: float = INF
		var max_x: float = -INF
		var min_z: float = INF
		var max_z: float = -INF
		for room_value: Variant in room_bounds:
			if not (room_value is Dictionary):
				continue
			var room: Dictionary = room_value
			min_x = minf(min_x, float(room.get("min_x", 0.0)))
			max_x = maxf(max_x, float(room.get("max_x", 0.0)))
			min_z = minf(min_z, float(room.get("min_z", 0.0)))
			max_z = maxf(max_z, float(room.get("max_z", 0.0)))
		var start_bounds: Dictionary = map_data.get("start_room_bounds", {})
		if not start_bounds.is_empty():
			min_x = minf(min_x, float(start_bounds.get("min_x", min_x)))
			max_x = maxf(max_x, float(start_bounds.get("max_x", max_x)))
			min_z = minf(min_z, float(start_bounds.get("min_z", min_z)))
			max_z = maxf(max_z, float(start_bounds.get("max_z", max_z)))
		if min_x < max_x and min_z < max_z:
			var corners: PackedVector2Array = PackedVector2Array([
				_world_to_screen(Vector2(min_x, min_z)),
				_world_to_screen(Vector2(max_x, min_z)),
				_world_to_screen(Vector2(max_x, max_z)),
				_world_to_screen(Vector2(min_x, max_z)),
				_world_to_screen(Vector2(min_x, min_z))
			])
			draw_polyline(corners, Color("#081018"), 7.0, true)
			draw_polyline(corners, Color("#f0f4f7"), 3.0, true)
	if partitions.is_empty() and not room_bounds.is_empty():
		var center_x: float = 0.0
		var center_z: float = 0.0
		var min_x_fallback: float = INF
		var max_x_fallback: float = -INF
		var min_z_fallback: float = INF
		var max_z_fallback: float = -INF
		for room_value: Variant in room_bounds:
			if room_value is Dictionary:
				var room_fallback: Dictionary = room_value
				min_x_fallback = minf(min_x_fallback, float(room_fallback.get("min_x", 0.0)))
				max_x_fallback = maxf(max_x_fallback, float(room_fallback.get("max_x", 0.0)))
				min_z_fallback = minf(min_z_fallback, float(room_fallback.get("min_z", 0.0)))
				max_z_fallback = maxf(max_z_fallback, float(room_fallback.get("max_z", 0.0)))
		center_x = (min_x_fallback + max_x_fallback) * 0.5
		center_z = (min_z_fallback + max_z_fallback) * 0.5
		partitions = [
			{"vertical": true, "axis": center_x, "min": min_z_fallback, "max": max_z_fallback},
			{"vertical": false, "axis": center_z, "min": min_x_fallback, "max": max_x_fallback}
		]
	for partition_value: Variant in partitions:
		if not (partition_value is Dictionary):
			continue
		var partition: Dictionary = partition_value
		var vertical: bool = bool(partition.get("vertical", true))
		var axis_value: float = float(partition.get("axis", 0.0))
		var extent_min: float = float(partition.get("min", 0.0))
		var extent_max: float = float(partition.get("max", 0.0))
		var openings: Array[Vector2] = TrackGeneratorScript.get_room_partition_openings(route, vertical, axis_value, width, extent_min, extent_max, _is_route_closed())
		var cursor: float = extent_min
		for opening: Vector2 in openings:
			_draw_partition_overlay_segment(vertical, axis_value, cursor, opening.x)
			cursor = maxf(cursor, opening.y)
		_draw_partition_overlay_segment(vertical, axis_value, cursor, extent_max)


func _draw_partition_overlay_segment(vertical: bool, axis_value: float, from_value: float, to_value: float) -> void:
	if to_value - from_value < 0.5:
		return
	var a: Vector2 = Vector2(axis_value, from_value) if vertical else Vector2(from_value, axis_value)
	var b: Vector2 = Vector2(axis_value, to_value) if vertical else Vector2(to_value, axis_value)
	draw_line(_world_to_screen(a), _world_to_screen(b), Color("#0a1118"), 9.0, true)
	draw_line(_world_to_screen(a), _world_to_screen(b), Color("#e6edf2"), 5.0, true)

func _draw_partition_preview(vertical: bool, axis_value: float, extent_min: float, extent_max: float, openings: Array[Vector2]) -> void:
	# Ściany w podglądzie 2D mają przerwy w miejscach rzeczywistych drzwi.
	var cursor: float = extent_min
	for opening: Vector2 in openings:
		_draw_partition_segment(vertical, axis_value, cursor, opening.x)
		_draw_door_gap_marker(vertical, axis_value, opening)
		cursor = maxf(cursor, opening.y)
	_draw_partition_segment(vertical, axis_value, cursor, extent_max)


func _draw_partition_segment(vertical: bool, axis_value: float, from_value: float, to_value: float) -> void:
	if to_value - from_value < 0.5:
		return
	var a: Vector2 = Vector2(axis_value, from_value) if vertical else Vector2(from_value, axis_value)
	var b: Vector2 = Vector2(axis_value, to_value) if vertical else Vector2(to_value, axis_value)
	draw_line(_world_to_screen(a), _world_to_screen(b), Color("#17232d", 0.95), 7.0, true)
	draw_line(_world_to_screen(a), _world_to_screen(b), Color("#c2d0d8", 0.9), 4.0, true)


func _draw_door_gap_marker(vertical: bool, axis_value: float, opening: Vector2) -> void:
	var half_width: float = 5.0
	var first: Vector2 = Vector2(axis_value, opening.x) if vertical else Vector2(opening.x, axis_value)
	var second: Vector2 = Vector2(axis_value, opening.y) if vertical else Vector2(opening.y, axis_value)
	var first_screen: Vector2 = _world_to_screen(first)
	var second_screen: Vector2 = _world_to_screen(second)
	var perpendicular: Vector2 = Vector2(half_width, 0.0) if vertical else Vector2(0.0, half_width)
	draw_line(first_screen - perpendicular, first_screen + perpendicular, Color("#d6b17a"), 3.0, true)
	draw_line(second_screen - perpendicular, second_screen + perpendicular, Color("#d6b17a"), 3.0, true)


func _draw_grid() -> void:
	var grid_step: float = 40.0 * _base_scale * zoom
	if grid_step < 12.0:
		return
	var x_count: int = int(ceil(size.x / grid_step)) + 1
	var y_count: int = int(ceil(size.y / grid_step)) + 1
	var origin := Vector2(fposmod(_pan_offset.x, grid_step), fposmod(_pan_offset.y, grid_step))
	for x: int in range(x_count):
		var px: float = origin.x + float(x) * grid_step
		draw_line(Vector2(px, 0.0), Vector2(px, size.y), Color(1, 1, 1, 0.045), 1.0)
	for y: int in range(y_count):
		var py: float = origin.y + float(y) * grid_step
		draw_line(Vector2(0.0, py), Vector2(size.x, py), Color(1, 1, 1, 0.045), 1.0)

func _draw_stations() -> void:
	for station: Variant in map_data.get("docking_stations", []):
		if not (station is Dictionary) or not (station.get("position") is Vector3):
			continue
		var p: Vector3 = station["position"]
		var at: Vector2 = _world_to_screen(Vector2(p.x, p.z))
		var rect := Rect2(at - Vector2(13.0, 9.0), Vector2(26.0, 18.0))
		draw_rect(rect, Color("#43b879"), true)
		draw_rect(rect, Color("#c5ffe0"), false, 2.0)
		draw_string(ThemeDB.fallback_font, at + Vector2(-4.0, 4.0), "S", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color.WHITE)
	_draw_ai_docking_stations()


func _draw_ai_docking_stations() -> void:
	var route: Array = map_data.get("route", [])
	if route.size() < 2:
		return
	var track_width: float = float(map_data.get("track_width", 1.2))
	var segment_count: int = route.size() if _is_route_closed() else route.size() - 1
	var lengths: PackedFloat32Array = PackedFloat32Array([0.0])
	for i: int in range(segment_count):
		var next_index: int = (i + 1) % route.size() if _is_route_closed() else i + 1
		var current_point: Vector3 = route[i]
		var next_point: Vector3 = route[next_index]
		lengths.append(lengths[lengths.size() - 1] + current_point.distance_to(next_point))
	var total: float = lengths[lengths.size() - 1]
	if total <= 1.0:
		return
	# Cztery punkty odpowiadają domyślnemu limitowi przeciwników AI.
	for ai_index: int in range(4):
		var target: float = total * float(ai_index + 1) / 5.0
		var point: Vector3 = route[route.size() - 1]
		var tangent: Vector3 = Vector3.FORWARD
		for segment_index: int in range(segment_count):
			if lengths[segment_index + 1] >= target:
				var next_index: int = (segment_index + 1) % route.size() if _is_route_closed() else segment_index + 1
				var segment_length: float = maxf(lengths[segment_index + 1] - lengths[segment_index], 0.001)
				var t: float = clampf((target - lengths[segment_index]) / segment_length, 0.0, 1.0)
				var segment_start: Vector3 = route[segment_index]
				var segment_end: Vector3 = route[next_index]
				point = segment_start.lerp(segment_end, t)
				tangent = (segment_end - segment_start).normalized()
				break
		var side := Vector3(-tangent.z, 0.0, tangent.x).normalized()
		var station_point: Vector3 = point + side * (track_width * 0.5 + 0.82)
		var at: Vector2 = _world_to_screen(Vector2(station_point.x, station_point.z))
		draw_circle(at, 10.0, Color("#8b65d8"))
		draw_arc(at, 12.0, 0.0, TAU, 24, Color("#e3d5ff"), 2.0)
		draw_string(ThemeDB.fallback_font, at + Vector2(-5.0, 4.0), "AI", HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color.WHITE)

func _draw_obstacles() -> void:
	var obstacles: Array = map_data.get("obstacles", [])
	for i: int in range(obstacles.size()):
		if not (obstacles[i] is Vector3):
			continue
		var p: Vector3 = obstacles[i]
		var at: Vector2 = _world_to_screen(Vector2(p.x, p.z))
		var radius: float = 7.0 if i != selected_obstacle else 10.0
		draw_circle(at, radius, Color("#e88a42"))
		draw_arc(at, radius + 2.0, 0.0, TAU, 24, Color("#ffe0ad") if i == selected_obstacle else Color("#7b4b2d"), 2.0)

func _draw_decorations() -> void:
	var decorations: Array = map_data.get("decorations", [])
	for i: int in range(decorations.size()):
		if not (decorations[i] is Dictionary):
			continue
		var item: Dictionary = decorations[i]
		if not (item.get("position") is Vector3):
			continue
		var p: Vector3 = item["position"]
		var at: Vector2 = _world_to_screen(Vector2(p.x, p.z))
		var selected: bool = i == selected_decoration
		var radius: float = clampf(7.0 + float(item.get("scale", 1.0)) * 3.0, 9.0, 17.0)
		draw_circle(at, radius + (4.0 if selected else 0.0), Color("#ffe45c") if selected else Color("#45c8d2"))
		draw_circle(at, radius, Color("#1c3541"))
		var kind: String = str(item.get("kind", "?"))
		var glyphs: Dictionary = {"sofa":"SO", "table":"ST", "chair":"KR", "bed":"ŁÓ", "cabinet":"SZ", "bookshelf":"RE", "tv":"TV", "fridge":"LO", "plant":"RO", "lamp":"LA", "shoe":"BU", "sock":"SK", "mug":"KU", "book":"KS", "remote":"PI", "tennis_ball":"PI", "yarn":"WŁ", "paper_scrap":"PA", "food_scraps":"JE", "cable":"KA", "backpack":"PL", "box":"PU", "toy":"ZA", "robot_toy":"RB", "cat":"KT", "dog":"PS", "rabbit":"KR", "parrot":"PA", "bearded_dragon":"AG", "nightstand":"ST", "wardrobe":"SZ", "coffee_table":"ŁW", "side_table":"ST", "shoe_rack":"PR", "ottoman":"PU", "laundry_basket":"KO", "floor_mirror":"LU"}
		var glyph: String = str(glyphs.get(kind, kind.substr(0, 2).to_upper()))
		var font_size: int = 11 if radius < 13.0 else 13
		draw_string(ThemeDB.fallback_font, at + Vector2(-7.0, 4.0), glyph, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color.WHITE)


func _draw_object_legend() -> void:
	var decorations: Array = map_data.get("decorations", [])
	var obstacles: Array = map_data.get("obstacles", [])
	if not decorations.is_empty() or not obstacles.is_empty():
		draw_rect(Rect2(Vector2(10.0, 34.0), Vector2(174.0, 54.0)), Color(0.03, 0.06, 0.09, 0.78), true)
		draw_circle(Vector2(24.0, 51.0), 7.0, Color("#45c8d2"))
		draw_string(ThemeDB.fallback_font, Vector2(38.0, 55.0), "OBIEKTY: %d" % decorations.size(), HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color.WHITE)
		draw_circle(Vector2(24.0, 72.0), 6.0, Color("#e88a42"))
		draw_string(ThemeDB.fallback_font, Vector2(38.0, 76.0), "PRZESZKODY: %d" % obstacles.size(), HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color.WHITE)

func _draw_compass_and_hint() -> void:
	draw_string(ThemeDB.fallback_font, Vector2(14.0, 24.0), "N ↑", HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color("#dbe5eb"))
	var mode_text: String = "PRZESUWANIE MAPY" if pan_mode else "DOTKNIJ OBIEKT, ABY ZAZNACZYĆ"
	draw_string(ThemeDB.fallback_font, Vector2(14.0, size.y - 14.0), mode_text, HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color("#c5d3dc"))

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var mouse := event as InputEventMouseButton
		if mouse.button_index == MOUSE_BUTTON_WHEEL_UP and mouse.pressed:
			_zoom_at(mouse.position, 1.15)
			accept_event()
		elif mouse.button_index == MOUSE_BUTTON_WHEEL_DOWN and mouse.pressed:
			_zoom_at(mouse.position, 1.0 / 1.15)
			accept_event()
		elif mouse.button_index == MOUSE_BUTTON_LEFT:
			if mouse.pressed:
				_last_pointer_position = mouse.position
				_dragging_map = pan_mode
				if not pan_mode:
					world_pressed.emit(screen_to_world(mouse.position))
			else:
				if not pan_mode:
					world_released.emit()
				_dragging_map = false
			accept_event()
	elif event is InputEventMouseMotion:
		var motion := event as InputEventMouseMotion
		if _dragging_map and (motion.button_mask & MOUSE_BUTTON_MASK_LEFT) != 0:
			_pan_offset += motion.position - _last_pointer_position
			_last_pointer_position = motion.position
			queue_redraw()
		elif (motion.button_mask & MOUSE_BUTTON_MASK_LEFT) != 0 and not pan_mode:
			world_dragged.emit(screen_to_world(motion.position))
		accept_event()
	elif event is InputEventScreenTouch:
		var touch := event as InputEventScreenTouch
		if touch.pressed:
			_active_touch_positions[touch.index] = touch.position
			_last_pointer_position = touch.position
			if _active_touch_positions.size() == 1 and not pan_mode:
				world_pressed.emit(screen_to_world(touch.position))
			if _active_touch_positions.size() == 2:
				var positions: Array = _active_touch_positions.values()
				var first_touch: Vector2 = positions[0]
				var second_touch: Vector2 = positions[1]
				_last_pinch_distance = first_touch.distance_to(second_touch)
				_last_pinch_center = (first_touch + second_touch) * 0.5
				_pinch_active = true
				_dragging_map = true
		else:
			_active_touch_positions.erase(touch.index)
			if _active_touch_positions.is_empty():
				world_released.emit()
				_dragging_map = false
				_pinch_active = false
				_last_pinch_distance = 0.0
		accept_event()
	elif event is InputEventScreenDrag:
		var drag := event as InputEventScreenDrag
		_active_touch_positions[drag.index] = drag.position
		if _active_touch_positions.size() >= 2:
			var positions: Array = _active_touch_positions.values()
			var first_touch: Vector2 = positions[0]
			var second_touch: Vector2 = positions[1]
			var distance: float = first_touch.distance_to(second_touch)
			var center: Vector2 = (first_touch + second_touch) * 0.5
			if _last_pinch_distance > 1.0:
				_pan_offset += center - _last_pinch_center
				_zoom_at(center, clampf(distance / _last_pinch_distance, 0.85, 1.18))
			_last_pinch_distance = distance
			_last_pinch_center = center
			_dragging_map = true
		elif _pinch_active:
			# Po geście dwoma palcami ignorujemy pozostały palec do końca gestu.
			pass
		elif pan_mode:
			_pan_offset += drag.position - _last_pointer_position
			_last_pointer_position = drag.position
			queue_redraw()
		else:
			world_dragged.emit(screen_to_world(drag.position))
		accept_event()

func _zoom_at(screen_position: Vector2, factor: float) -> void:
	var before: Vector3 = screen_to_world(screen_position)
	zoom = clampf(zoom * factor, 0.35, 4.0)
	zoom_changed.emit(zoom)
	var after: Vector3 = screen_to_world(screen_position)
	var delta_world := Vector2(before.x - after.x, before.z - after.z) * _base_scale * zoom * Vector2(1.0, -1.0)
	_pan_offset += delta_world
	queue_redraw()
