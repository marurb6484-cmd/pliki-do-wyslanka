class_name UIKit
extends RefCounted
## Wspólne style i fabryki elementów interfejsu (czytelne na telefonie).

const COLOR_BG := Color(0.035, 0.05, 0.085, 0.78)
const COLOR_PANEL := Color(0.065, 0.09, 0.14, 0.96)
const COLOR_SURFACE_HOVER := Color(0.09, 0.14, 0.21, 0.98)
const COLOR_LINE := Color(0.2, 0.5, 0.62, 0.55)
const COLOR_ACCENT := Color(0.0, 0.85, 1.0)
const COLOR_GOOD := Color(0.25, 1.0, 0.5)
const COLOR_WARN := Color(1.0, 0.75, 0.15)
const COLOR_BAD := Color(1.0, 0.3, 0.25)
const COLOR_TEXT := Color(0.94, 0.97, 1.0)
const COLOR_MUTED := Color(0.64, 0.72, 0.8)

## Minimalne rozmiary dla obsługi palcem (w pikselach widoku 2340 x 1080).
const MIN_TOUCH_HEIGHT: float = 72.0
const MIN_FONT_SIZE: int = 20


static func panel_style(bg: Color = COLOR_BG, border: Color = Color(0.0, 0.85, 1.0, 0.45), radius: int = 20, border_width: int = 2, margin: float = 14.0) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = bg
	style.border_color = border
	style.set_border_width_all(border_width)
	style.set_corner_radius_all(radius)
	style.content_margin_left = margin
	style.content_margin_right = margin
	style.content_margin_top = margin * 0.7
	style.content_margin_bottom = margin * 0.7
	style.anti_aliasing = true
	style.shadow_size = 8
	style.shadow_color = Color(0, 0, 0, 0.35)
	style.shadow_offset = Vector2(0, 3)
	return style


static func make_label(text: String, font_size: int = 32, color: Color = COLOR_TEXT, align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT, outline: bool = true) -> Label:
	var simple_mode: bool = GameSettings.is_simple_play_style()	
	font_size = maxi(font_size, 24 if simple_mode else MIN_FONT_SIZE)
	var label := Label.new()
	label.text = LocaleManager.tr_text(text)
	label.horizontal_alignment = align
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	if outline:
		label.add_theme_constant_override("outline_size", maxi(int(font_size * 0.16), 4))
		label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return label


## variant: "" (zwykły), "primary", "success", "danger", "ghost" - warianty z UITheme.
static func make_button(text: String, font_size: int = 34, min_height: float = 96.0, variant: String = "") -> Button:
	var button := Button.new()
	button.text = LocaleManager.tr_text(text)
	var simple_mode: bool = GameSettings.is_simple_play_style()
	button.custom_minimum_size = Vector2(0, maxf(min_height, 90.0 if simple_mode else MIN_TOUCH_HEIGHT))
	button.add_theme_font_size_override("font_size", maxi(font_size, 28 if simple_mode else 24))
	button.focus_mode = Control.FOCUS_NONE
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.clip_text = false
	apply_variant(button, variant)
	button.pressed.connect(_haptic_tick)
	return button


static func apply_variant(button: Button, variant: String) -> void:
	match variant:
		"primary":
			button.theme_type_variation = "ButtonPrimary"
		"success":
			button.theme_type_variation = "ButtonSuccess"
		"danger":
			button.theme_type_variation = "ButtonDanger"
		"ghost":
			button.theme_type_variation = "ButtonGhost"


## Krótka wibracja przy dotknięciu przycisku (jeśli włączona w ustawieniach).
static func _haptic_tick() -> void:
	GameSettings.vibrate(12)


static func make_panel(bg: Color = COLOR_PANEL) -> PanelContainer:
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", panel_style(bg, COLOR_LINE, 22, 2, 20))
	return panel


## Kafelek-przycisk: cała karta jest jednym dużym celem dotyku (łatwo trafić palcem).
## Zawartość dodajemy do kontenera zwróconego przez get_meta("content").
static func make_tile_shell(accent: Color = COLOR_ACCENT, min_height: float = 200.0, muted: bool = false) -> Button:
	var button := Button.new()
	button.focus_mode = Control.FOCUS_NONE
	var simple_mode: bool = GameSettings.is_simple_play_style()
	button.custom_minimum_size = Vector2(0, maxf(min_height, 220.0 if simple_mode else MIN_TOUCH_HEIGHT))
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var edge: Color = Color(accent.r, accent.g, accent.b, 0.45 if muted else 0.85)
	button.add_theme_stylebox_override("normal", panel_style(COLOR_PANEL, edge, 24, 3, 0.0))
	button.add_theme_stylebox_override("hover", panel_style(COLOR_SURFACE_HOVER, accent, 24, 4, 0.0))
	button.add_theme_stylebox_override("pressed", panel_style(Color(accent.r * 0.18, accent.g * 0.18, accent.b * 0.18, 1.0), accent.lightened(0.35), 24, 5, 0.0))
	button.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var side_margin: int = 34 if simple_mode else 28
	var vertical_margin: int = 26 if simple_mode else 22
	for side: String in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, side_margin)
	for side: String in ["top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, vertical_margin)
	button.add_child(margin)
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 10)
	content.mouse_filter = Control.MOUSE_FILTER_IGNORE
	margin.add_child(content)
	button.set_meta("content", content)
	button.pressed.connect(_haptic_tick)
	return button


## Gotowy kafelek menu: symbol, tytuł, opis, opcjonalna plakietka (np. "WKRÓTCE").
static func make_tile(title: String, description: String, accent: Color, callback: Callable, glyph: String = "", badge: String = "", min_height: float = 200.0, title_size: int = 40) -> Button:
	title = LocaleManager.tr_text(title)
	description = LocaleManager.tr_text(description)
	badge = LocaleManager.tr_text(badge)
	var tile: Button = make_tile_shell(accent, min_height, badge == "WKRÓTCE")
	var content: VBoxContainer = tile.get_meta("content")
	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 16)
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	content.add_child(top)
	if not glyph.is_empty():
		top.add_child(make_label(glyph, title_size + 6, accent, HORIZONTAL_ALIGNMENT_CENTER, false))
	var title_label := make_label(title, title_size, accent)
	title_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_label.clip_text = true
	top.add_child(title_label)
	if not badge.is_empty():
		top.add_child(make_badge(badge, COLOR_WARN))
	var text := make_label(description, 26 if GameSettings.is_simple_play_style() else 24, COLOR_TEXT if badge != "WKRÓTCE" else COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false)
	text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(text)
	tile.pressed.connect(callback)
	return tile


## Panel przezroczysty dla HUD w wyścigu (szkło): mały margines, bez ciężkiego cienia.
static func make_hud_panel(accent: Color = COLOR_ACCENT) -> PanelContainer:
	var panel := PanelContainer.new()
	var style: StyleBoxFlat = panel_style(Color(0.03, 0.045, 0.075, 0.74), Color(accent.r, accent.g, accent.b, 0.45), 20, 2, 14.0)
	style.shadow_size = 4
	panel.add_theme_stylebox_override("panel", style)
	return panel


## Karta z kolorowym akcentem: spójny wygląd kafelków menu.
static func make_card(accent: Color = COLOR_ACCENT, margin: float = 22.0) -> PanelContainer:
	var card := PanelContainer.new()
	card.add_theme_stylebox_override("panel", panel_style(COLOR_PANEL, Color(accent.r, accent.g, accent.b, 0.8), 24, 3, margin))
	return card


## Mała pigułka ze stanem, np. "WKRÓTCE".
static func make_badge(text: String, color: Color = COLOR_WARN) -> PanelContainer:
	var badge := PanelContainer.new()
	var style: StyleBoxFlat = panel_style(Color(color.r, color.g, color.b, 0.18), Color(color.r, color.g, color.b, 0.9), 999, 2, 16.0)
	style.shadow_size = 0
	style.content_margin_top = 4.0
	style.content_margin_bottom = 4.0
	badge.add_theme_stylebox_override("panel", style)
	badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	badge.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	var label := make_label(text, 20, color, HORIZONTAL_ALIGNMENT_CENTER, false)
	badge.add_child(label)
	return badge


## Pigułka z wartością (np. waluta) w nagłówku.
static func make_chip(text: String, color: Color = COLOR_GOOD, font_size: int = 30) -> PanelContainer:
	var chip := PanelContainer.new()
	var style: StyleBoxFlat = panel_style(Color(0.04, 0.06, 0.1, 0.9), Color(color.r, color.g, color.b, 0.7), 999, 2, 24.0)
	style.shadow_size = 0
	chip.add_theme_stylebox_override("panel", style)
	chip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	chip.add_child(make_label(text, font_size, color, HORIZONTAL_ALIGNMENT_CENTER, false))
	return chip


## Nagłówek sekcji wewnątrz ekranu (tytuł + cienka linia).
static func make_section_title(text: String, color: Color = COLOR_ACCENT) -> VBoxContainer:
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)
	box.add_child(make_label(text, 34, color))
	var line := ColorRect.new()
	line.color = Color(color.r, color.g, color.b, 0.45)
	line.custom_minimum_size = Vector2(0, 3)
	line.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(line)
	return box


static func make_bar(height: float, fill: Color, background: Color = Color(0.1, 0.13, 0.17, 0.9)) -> ProgressBar:
	var bar := ProgressBar.new()
	bar.custom_minimum_size = Vector2(0, height)
	bar.show_percentage = false
	bar.min_value = 0.0
	bar.max_value = 1.0
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var bg_style := StyleBoxFlat.new()
	bg_style.bg_color = background
	bg_style.set_corner_radius_all(int(height * 0.5))
	var fill_style := StyleBoxFlat.new()
	fill_style.bg_color = fill
	fill_style.set_corner_radius_all(int(height * 0.5))
	bar.add_theme_stylebox_override("background", bg_style)
	bar.add_theme_stylebox_override("fill", fill_style)
	return bar


static func set_bar_color(bar: ProgressBar, color: Color) -> void:
	var fill: StyleBoxFlat = bar.get_theme_stylebox("fill") as StyleBoxFlat
	if fill != null:
		fill.bg_color = color


## Marginesy bezpieczne (wycięcie kamery, zaokrąglone rogi, pasek gestów) w pikselach
## widoku gry: x = lewy, y = górny, z = prawy, w = dolny.
static func safe_area_insets() -> Vector4:
	var window_size: Vector2 = Vector2(DisplayServer.window_get_size())
	var safe: Rect2i = DisplayServer.get_display_safe_area()
	if window_size.x <= 0.0 or window_size.y <= 0.0 or safe.size.x <= 0:
		return Vector4.ZERO
	var viewport_size: Vector2 = Vector2(
		float(ProjectSettings.get_setting("display/window/size/viewport_width", 2340)),
		float(ProjectSettings.get_setting("display/window/size/viewport_height", 1080)))
	var scale_x: float = viewport_size.x / window_size.x
	var scale_y: float = viewport_size.y / window_size.y
	var left: float = maxf(float(safe.position.x), 0.0) * scale_x
	var top: float = maxf(float(safe.position.y), 0.0) * scale_y
	var right: float = maxf(window_size.x - float(safe.position.x + safe.size.x), 0.0) * scale_x
	var bottom: float = maxf(window_size.y - float(safe.position.y + safe.size.y), 0.0) * scale_y
	return Vector4(minf(left, 120.0), minf(top, 80.0), minf(right, 120.0), minf(bottom, 80.0))


## Duży, łatwy do złapania uchwyt suwaka dla palca.
static func _slider_grabber() -> Texture2D:
	var size: int = 56
	var image: Image = Image.create(size, size, false, Image.FORMAT_RGBA8)
	var center: Vector2 = Vector2(size * 0.5, size * 0.5)
	for y: int in range(size):
		for x: int in range(size):
			var d: float = Vector2(x + 0.5, y + 0.5).distance_to(center)
			if d <= 26.0:
				var edge: float = clampf(26.0 - d, 0.0, 1.0)
				var core: Color = Color(0.85, 0.97, 1.0) if d > 15.0 else Color(0.0, 0.8, 0.95)
				image.set_pixel(x, y, Color(core.r, core.g, core.b, edge))
	return ImageTexture.create_from_image(image)


static func slider_grabber_texture() -> Texture2D:
	if _grabber_cache == null:
		_grabber_cache = _slider_grabber()
	return _grabber_cache


static func make_slider(min_value: float, max_value: float, step: float, value: float) -> HSlider:
	var slider := HSlider.new()
	slider.min_value = min_value
	slider.max_value = max_value
	slider.step = step
	slider.value = value
	slider.custom_minimum_size = Vector2(0, 76)
	slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	slider.focus_mode = Control.FOCUS_NONE
	apply_touch_slider(slider)
	return slider


static var _grabber_cache: Texture2D = null


## Powiększa uchwyt suwaka do rozmiaru wygodnego na ekranie dotykowym.
static func apply_touch_slider(slider: HSlider) -> void:
	if _grabber_cache == null:
		_grabber_cache = _slider_grabber()
	slider.add_theme_icon_override("grabber", _grabber_cache)
	slider.add_theme_icon_override("grabber_highlight", _grabber_cache)
	slider.add_theme_icon_override("grabber_disabled", _grabber_cache)


## Pełnoekranowe tło menu: pionowy gradient, poświata u góry i delikatne światło w rogu.
static func add_menu_background(parent: Control) -> void:
	var background := TextureRect.new()
	var base := Gradient.new()
	base.set_color(0, Color(0.06, 0.085, 0.14, 1.0))
	base.set_color(1, Color(0.025, 0.035, 0.06, 1.0))
	var base_texture := GradientTexture2D.new()
	base_texture.gradient = base
	base_texture.fill_from = Vector2(0.5, 0.0)
	base_texture.fill_to = Vector2(0.5, 1.0)
	base_texture.width = 8
	base_texture.height = 256
	background.texture = base_texture
	background.stretch_mode = TextureRect.STRETCH_SCALE
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(background)

	_add_glow(parent, Vector2(0.5, 0.0), Color(0.0, 0.6, 0.8, 0.34))
	_add_glow(parent, Vector2(1.0, 1.0), Color(0.1, 0.35, 0.7, 0.2))


static func _add_glow(parent: Control, from_point: Vector2, color: Color) -> void:
	var glow := TextureRect.new()
	var gradient := Gradient.new()
	gradient.set_color(0, color)
	gradient.set_color(1, Color(color.r, color.g, color.b, 0.0))
	var texture := GradientTexture2D.new()
	texture.gradient = gradient
	texture.fill = GradientTexture2D.FILL_RADIAL
	texture.fill_from = from_point
	texture.fill_to = Vector2(0.5, 0.5) if from_point.y < 0.5 else Vector2(0.4, 0.3)
	texture.width = 256
	texture.height = 256
	glow.texture = texture
	glow.stretch_mode = TextureRect.STRETCH_SCALE
	glow.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	glow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(glow)


## Pasek z tytułem i przyciskiem "Wstecz" na górze ekranu menu. Kolejne dzieci
## dodane przez wywołującego (np. waluta) trafiają na prawą stronę paska.
static func make_header(title: String, back_callback: Callable) -> HBoxContainer:
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 26)
	var back := make_button("‹  WSTECZ", 32, 88, "ghost")
	back.custom_minimum_size = Vector2(290, 88)
	back.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	back.pressed.connect(back_callback)
	header.add_child(back)
	var label := make_label(title, 50, COLOR_ACCENT)
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.add_theme_constant_override("outline_size", 8)
	header.add_child(label)
	return header


## Kontener menu z marginesami bezpiecznymi dla wycięć ekranu.
static func make_screen_margin(parent: Control, margin: int = 40) -> MarginContainer:
	var container := MarginContainer.new()
	container.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var inset: Vector4 = safe_area_insets()
	container.add_theme_constant_override("margin_left", margin + 30 + int(inset.x))
	container.add_theme_constant_override("margin_right", margin + 30 + int(inset.z))
	container.add_theme_constant_override("margin_top", margin + int(inset.y))
	container.add_theme_constant_override("margin_bottom", margin + int(inset.w))
	parent.add_child(container)
	return container


## Duży, czytelny pasek przewijania do obsługi dotykowej. Po dotknięciu
## uchwyt rozszerza się, a po puszczeniu wraca do węższego rozmiaru.
static func configure_touch_scroll(scroll: ScrollContainer) -> void:
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_ALWAYS
	scroll.scroll_deadzone = 7
	if scroll.is_node_ready():
		_style_touch_scrollbar(scroll)
	else:
		scroll.ready.connect(func() -> void: _style_touch_scrollbar(scroll))


static func _style_touch_scrollbar(scroll: ScrollContainer) -> void:
	var bar: VScrollBar = scroll.get_v_scroll_bar()
	if bar == null:
		return
	bar.custom_minimum_size.x = 30.0
	bar.add_theme_constant_override("grabber_min_size", 56)
	var track_style := StyleBoxFlat.new()
	track_style.bg_color = Color("#101a27")
	track_style.set_corner_radius_all(12)
	var grabber_style := StyleBoxFlat.new()
	grabber_style.bg_color = Color("#238fa8")
	grabber_style.set_corner_radius_all(12)
	var hover_style := StyleBoxFlat.new()
	hover_style.bg_color = Color("#31c9df")
	hover_style.set_corner_radius_all(12)
	var pressed_style := StyleBoxFlat.new()
	pressed_style.bg_color = Color("#9af4ff")
	pressed_style.set_corner_radius_all(12)
	bar.add_theme_stylebox_override("scroll", track_style)
	bar.add_theme_stylebox_override("grabber", grabber_style)
	bar.add_theme_stylebox_override("grabber_highlight", hover_style)
	bar.add_theme_stylebox_override("grabber_pressed", pressed_style)
	bar.gui_input.connect(func(event: InputEvent) -> void:
		var pressed := false
		var released := false
		if event is InputEventScreenTouch:
			pressed = (event as InputEventScreenTouch).pressed
			released = not pressed
		elif event is InputEventMouseButton and (event as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT:
			pressed = (event as InputEventMouseButton).pressed
			released = not pressed
		if pressed:
			bar.custom_minimum_size.x = 48.0
			bar.add_theme_constant_override("grabber_min_size", 68)
			scroll.queue_sort()
		elif released:
			bar.custom_minimum_size.x = 30.0
			bar.add_theme_constant_override("grabber_min_size", 56)
			scroll.queue_sort()
	)

static func format_time(value: float) -> String:
	if value < 0.0:
		return "--:--.---"
	var total_ms: int = int(round(value * 1000.0))
	var total_seconds: int = floori(float(total_ms) / 1000.0)
	var minutes: int = floori(float(total_ms) / 60000.0)
	var seconds: int = total_seconds % 60
	return "%02d:%02d.%03d" % [minutes, seconds, total_ms % 1000]


static func format_currency(amount: int) -> String:
	return "%d %s" % [amount, "CR"]
