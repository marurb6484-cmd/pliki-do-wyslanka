class_name UITheme
extends RefCounted
## Jeden, spójny motyw całego interfejsu (menu, HUD, okna dialogowe).
## Budowany w kodzie, więc ikony przełączników, pól wyboru i strzałek rozwijanych
## list są rysowane proceduralnie w rozmiarze wygodnym dla palca.
##
## Warianty przycisków (właściwość theme_type_variation):
##   ButtonPrimary - główna akcja (cyjan), ButtonSuccess - zatwierdzenie (zieleń),
##   ButtonDanger - akcja destrukcyjna (czerwień), ButtonGhost - akcja poboczna.
## Wariant kart: PanelCard (panel z akcentem), PanelFlat (panel bez cienia).
##
## Zmiana wyglądu całej gry = zmiana stałych poniżej i w UIKit.

const SURFACE: Color = Color(0.065, 0.09, 0.14, 0.96)
const SURFACE_HOVER: Color = Color(0.09, 0.14, 0.21, 0.98)
const SURFACE_DEEP: Color = Color(0.035, 0.05, 0.08, 0.98)
const LINE: Color = Color(0.2, 0.5, 0.62, 0.65)
const ACCENT: Color = Color(0.0, 0.85, 1.0)
const ACCENT_DEEP: Color = Color(0.0, 0.48, 0.64)

static var _cache: Dictionary = {}


static func build() -> Theme:
	var theme := Theme.new()
	theme.default_font_size = 30

	# ---------- Przyciski ----------
	_button_styles(theme, "Button", SURFACE, SURFACE_HOVER, ACCENT_DEEP, LINE, Color(0, 0.85, 1, 0.95), Color(0.93, 0.97, 1.0))
	theme.set_font_size("font_size", "Button", 32)
	theme.set_type_variation("ButtonPrimary", "Button")
	_button_styles(theme, "ButtonPrimary", Color(0.0, 0.5, 0.66), Color(0.0, 0.6, 0.78), Color(0.0, 0.36, 0.5), Color(0.45, 0.95, 1.0, 0.9), Color(0.7, 1.0, 1.0), Color.WHITE)
	theme.set_type_variation("ButtonSuccess", "Button")
	_button_styles(theme, "ButtonSuccess", Color(0.1, 0.46, 0.26), Color(0.14, 0.58, 0.32), Color(0.07, 0.34, 0.19), Color(0.5, 1.0, 0.65, 0.85), Color(0.7, 1.0, 0.8), Color.WHITE)
	theme.set_type_variation("ButtonDanger", "Button")
	_button_styles(theme, "ButtonDanger", Color(0.5, 0.13, 0.15), Color(0.62, 0.17, 0.19), Color(0.38, 0.09, 0.11), Color(1.0, 0.5, 0.45, 0.85), Color(1.0, 0.7, 0.65), Color.WHITE)
	theme.set_type_variation("ButtonGhost", "Button")
	_button_styles(theme, "ButtonGhost", Color(0.05, 0.08, 0.12, 0.55), Color(0.09, 0.14, 0.21, 0.85), ACCENT_DEEP, Color(0.3, 0.55, 0.65, 0.6), ACCENT, Color(0.85, 0.93, 1.0))

	# OptionButton wygląda jak przycisk, ze strzałką po prawej.
	_button_styles(theme, "OptionButton", SURFACE, SURFACE_HOVER, ACCENT_DEEP, LINE, Color(0, 0.85, 1, 0.95), Color(0.93, 0.97, 1.0))
	theme.set_font_size("font_size", "OptionButton", 30)
	theme.set_icon("arrow", "OptionButton", _chevron_icon())
	theme.set_constant("arrow_margin", "OptionButton", 24)
	theme.set_constant("h_separation", "OptionButton", 14)

	# ---------- Przełączniki i pola wyboru ----------
	for type_name: String in ["CheckButton", "CheckBox"]:
		theme.set_font_size("font_size", type_name, 30)
		theme.set_color("font_color", type_name, Color(0.93, 0.97, 1.0))
		theme.set_color("font_hover_color", type_name, Color.WHITE)
		theme.set_color("font_pressed_color", type_name, Color.WHITE)
		theme.set_constant("h_separation", type_name, 22)
		theme.set_constant("check_v_offset", type_name, 0)
		var normal: StyleBoxFlat = _flat(Color(0, 0, 0, 0), Color(0, 0, 0, 0), 14, 0, 10, 16)
		var hover: StyleBoxFlat = _flat(Color(1, 1, 1, 0.05), Color(0, 0, 0, 0), 14, 0, 10, 16)
		for state: String in ["normal", "pressed", "disabled", "focus"]:
			theme.set_stylebox(state, type_name, normal)
		theme.set_stylebox("hover", type_name, hover)
		theme.set_stylebox("hover_pressed", type_name, hover)
	theme.set_icon("checked", "CheckButton", _switch_icon(true, false))
	theme.set_icon("unchecked", "CheckButton", _switch_icon(false, false))
	theme.set_icon("checked_disabled", "CheckButton", _switch_icon(true, true))
	theme.set_icon("unchecked_disabled", "CheckButton", _switch_icon(false, true))
	theme.set_icon("checked", "CheckBox", _checkbox_icon(true))
	theme.set_icon("unchecked", "CheckBox", _checkbox_icon(false))
	theme.set_icon("checked_disabled", "CheckBox", _checkbox_icon(true))
	theme.set_icon("unchecked_disabled", "CheckBox", _checkbox_icon(false))

	# ---------- Panele i karty ----------
	var panel: StyleBoxFlat = _flat(SURFACE, Color(0.2, 0.5, 0.62, 0.5), 22, 2, 22, 18, 10)
	theme.set_stylebox("panel", "PanelContainer", panel)
	theme.set_stylebox("panel", "Panel", panel)
	theme.set_type_variation("PanelCard", "PanelContainer")
	theme.set_stylebox("panel", "PanelCard", _flat(SURFACE, Color(0.0, 0.7, 0.9, 0.7), 24, 3, 26, 22, 14))
	theme.set_type_variation("PanelFlat", "PanelContainer")
	theme.set_stylebox("panel", "PanelFlat", _flat(Color(0.05, 0.075, 0.12, 0.9), Color(0.2, 0.5, 0.62, 0.35), 18, 2, 18, 14, 0))

	# ---------- Zakładki ----------
	var tab_selected: StyleBoxFlat = _flat(ACCENT_DEEP, Color(0.4, 0.95, 1.0, 0.8), 16, 2, 30, 18)
	tab_selected.corner_radius_bottom_left = 0
	tab_selected.corner_radius_bottom_right = 0
	var tab_idle: StyleBoxFlat = _flat(Color(0.06, 0.09, 0.14, 0.95), Color(0.2, 0.5, 0.62, 0.4), 16, 2, 30, 18)
	tab_idle.corner_radius_bottom_left = 0
	tab_idle.corner_radius_bottom_right = 0
	var tab_hover: StyleBoxFlat = _flat(Color(0.09, 0.14, 0.21, 0.98), Color(0.0, 0.8, 1.0, 0.6), 16, 2, 30, 18)
	tab_hover.corner_radius_bottom_left = 0
	tab_hover.corner_radius_bottom_right = 0
	theme.set_stylebox("tab_selected", "TabContainer", tab_selected)
	theme.set_stylebox("tab_unselected", "TabContainer", tab_idle)
	theme.set_stylebox("tab_hovered", "TabContainer", tab_hover)
	theme.set_stylebox("tab_focus", "TabContainer", StyleBoxEmpty.new())
	theme.set_stylebox("panel", "TabContainer", _flat(SURFACE, Color(0.2, 0.5, 0.62, 0.5), 20, 2, 20, 16))
	theme.set_font_size("font_size", "TabContainer", 30)
	theme.set_color("font_selected_color", "TabContainer", Color.WHITE)
	theme.set_color("font_unselected_color", "TabContainer", Color(0.72, 0.8, 0.88))
	theme.set_color("font_hovered_color", "TabContainer", Color.WHITE)
	theme.set_constant("side_margin", "TabContainer", 0)

	# ---------- Pole tekstowe ----------
	theme.set_stylebox("normal", "LineEdit", _flat(SURFACE_DEEP, Color(0.2, 0.5, 0.62, 0.7), 16, 2, 22, 16))
	theme.set_stylebox("focus", "LineEdit", _flat(SURFACE_DEEP, ACCENT, 16, 3, 22, 16))
	theme.set_stylebox("read_only", "LineEdit", _flat(Color(0.05, 0.06, 0.08, 0.9), Color(0.25, 0.3, 0.35, 0.6), 16, 2, 22, 16))
	theme.set_font_size("font_size", "LineEdit", 30)
	theme.set_color("font_color", "LineEdit", Color(0.93, 0.97, 1.0))
	theme.set_color("caret_color", "LineEdit", ACCENT)
	theme.set_color("selection_color", "LineEdit", Color(0.0, 0.5, 0.66, 0.6))

	# ---------- Listy rozwijane ----------
	theme.set_stylebox("panel", "PopupMenu", _flat(Color(0.045, 0.065, 0.1, 0.99), LINE, 18, 2, 12, 10, 14))
	theme.set_stylebox("hover", "PopupMenu", _flat(ACCENT_DEEP, Color(0.4, 0.95, 1.0, 0.5), 12, 2, 18, 14))
	theme.set_stylebox("separator", "PopupMenu", _flat(Color(0.2, 0.5, 0.62, 0.4), Color(0, 0, 0, 0), 2, 0, 0, 1))
	theme.set_font_size("font_size", "PopupMenu", 30)
	theme.set_constant("v_separation", "PopupMenu", 24)
	theme.set_constant("item_start_padding", "PopupMenu", 24)
	theme.set_constant("item_end_padding", "PopupMenu", 24)
	theme.set_color("font_color", "PopupMenu", Color(0.93, 0.97, 1.0))
	theme.set_color("font_hover_color", "PopupMenu", Color.WHITE)

	# ---------- Suwak i pasek postępu ----------
	var track: StyleBoxFlat = _flat(Color(0.1, 0.14, 0.2, 1), Color(0.2, 0.4, 0.5, 0.5), 10, 1, 0, 8)
	var fill: StyleBoxFlat = _flat(Color(0.0, 0.7, 0.9, 1), Color(0, 0, 0, 0), 10, 0, 0, 8)
	theme.set_stylebox("slider", "HSlider", track)
	theme.set_stylebox("grabber_area", "HSlider", fill)
	theme.set_stylebox("grabber_area_highlight", "HSlider", fill)
	var grabber: Texture2D = UIKit.slider_grabber_texture()
	for icon_name: String in ["grabber", "grabber_highlight", "grabber_disabled"]:
		theme.set_icon(icon_name, "HSlider", grabber)
	theme.set_stylebox("background", "ProgressBar", _flat(Color(0.08, 0.11, 0.16, 0.95), Color(0.2, 0.4, 0.5, 0.4), 14, 1, 0, 0))
	theme.set_stylebox("fill", "ProgressBar", _flat(Color(0.0, 0.75, 0.95, 1), Color(0, 0, 0, 0), 14, 0, 0, 0))

	# ---------- Paski przewijania ----------
	for bar_type: String in ["VScrollBar", "HScrollBar"]:
		theme.set_stylebox("scroll", bar_type, _flat(Color(0.06, 0.09, 0.14, 0.9), Color(0, 0, 0, 0), 14, 0, 0, 0))
		theme.set_stylebox("grabber", bar_type, _flat(Color(0.14, 0.5, 0.64, 1), Color(0, 0, 0, 0), 14, 0, 0, 0))
		theme.set_stylebox("grabber_highlight", bar_type, _flat(Color(0.19, 0.7, 0.85, 1), Color(0, 0, 0, 0), 14, 0, 0, 0))
		theme.set_stylebox("grabber_pressed", bar_type, _flat(Color(0.6, 0.95, 1.0, 1), Color(0, 0, 0, 0), 14, 0, 0, 0))

	# ---------- Separatory ----------
	theme.set_stylebox("separator", "HSeparator", _flat(Color(0.2, 0.5, 0.62, 0.4), Color(0, 0, 0, 0), 2, 0, 0, 1))
	theme.set_constant("separation", "HSeparator", 18)
	theme.set_stylebox("separator", "VSeparator", _flat(Color(0.2, 0.5, 0.62, 0.4), Color(0, 0, 0, 0), 2, 0, 1, 0))

	# ---------- Okna dialogowe ----------
	theme.set_stylebox("embedded_border", "Window", _flat(Color(0.05, 0.075, 0.12, 0.99), Color(0.0, 0.7, 0.9, 0.8), 24, 3, 24, 20, 18))
	theme.set_stylebox("embedded_unfocused_border", "Window", _flat(Color(0.05, 0.075, 0.12, 0.99), LINE, 24, 3, 24, 20, 18))
	theme.set_font_size("title_font_size", "Window", 32)
	theme.set_color("title_color", "Window", ACCENT)
	theme.set_constant("title_height", "Window", 70)
	theme.set_constant("buttons_min_width", "AcceptDialog", 240)
	theme.set_constant("buttons_min_height", "AcceptDialog", 84)
	theme.set_font_size("font_size", "Label", 30)
	theme.set_color("font_color", "Label", Color(0.93, 0.97, 1.0))
	return theme


# =========================================================
# STYLE
# =========================================================

static func _flat(bg: Color, border: Color, radius: int, border_width: int, margin_x: float, margin_y: float, shadow: int = 0) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = bg
	style.border_color = border
	style.set_border_width_all(border_width)
	style.set_corner_radius_all(radius)
	style.content_margin_left = margin_x
	style.content_margin_right = margin_x
	style.content_margin_top = margin_y
	style.content_margin_bottom = margin_y
	style.anti_aliasing = true
	if shadow > 0:
		style.shadow_size = shadow
		style.shadow_color = Color(0, 0, 0, 0.38)
		style.shadow_offset = Vector2(0, 3)
	return style


static func _button_styles(theme: Theme, type_name: String, normal_bg: Color, hover_bg: Color, pressed_bg: Color, border: Color, hover_border: Color, font_color: Color) -> void:
	theme.set_stylebox("normal", type_name, _flat(normal_bg, border, 20, 2, 26, 14, 8))
	theme.set_stylebox("hover", type_name, _flat(hover_bg, hover_border, 20, 3, 26, 14, 8))
	var pressed: StyleBoxFlat = _flat(pressed_bg, hover_border, 20, 3, 26, 14, 2)
	# Wciśnięty przycisk "zapada się": treść przesuwa się w dół.
	pressed.content_margin_top = 17.0
	pressed.content_margin_bottom = 11.0
	theme.set_stylebox("pressed", type_name, pressed)
	theme.set_stylebox("hover_pressed", type_name, pressed)
	theme.set_stylebox("disabled", type_name, _flat(Color(0.07, 0.08, 0.1, 0.8), Color(0.28, 0.3, 0.34, 0.6), 20, 2, 26, 14))
	theme.set_stylebox("focus", type_name, _flat(Color(0, 0, 0, 0), Color(1, 1, 1, 0.35), 20, 2, 26, 14))
	theme.set_color("font_color", type_name, font_color)
	theme.set_color("font_hover_color", type_name, Color.WHITE)
	theme.set_color("font_pressed_color", type_name, Color.WHITE)
	theme.set_color("font_hover_pressed_color", type_name, Color.WHITE)
	theme.set_color("font_disabled_color", type_name, Color(0.48, 0.52, 0.56))
	theme.set_color("font_focus_color", type_name, font_color)


# =========================================================
# IKONY RYSOWANE PROCEDURALNIE
# =========================================================

static func _coverage(distance: float) -> float:
	return clampf(0.5 - distance, 0.0, 1.0)


static func _blend(under: Color, over: Color, amount: float) -> Color:
	var a: float = clampf(amount * over.a, 0.0, 1.0)
	var out_alpha: float = a + under.a * (1.0 - a)
	if out_alpha <= 0.0001:
		return Color(0, 0, 0, 0)
	var rgb: Vector3 = (Vector3(over.r, over.g, over.b) * a + Vector3(under.r, under.g, under.b) * under.a * (1.0 - a)) / out_alpha
	return Color(rgb.x, rgb.y, rgb.z, out_alpha)


static func _segment_distance(p: Vector2, a: Vector2, b: Vector2) -> float:
	var ab: Vector2 = b - a
	var t: float = clampf((p - a).dot(ab) / maxf(ab.length_squared(), 0.0001), 0.0, 1.0)
	return p.distance_to(a + ab * t)


## Przełącznik (suwak włącz/wyłącz) 104 x 56 px.
static func _switch_icon(on: bool, disabled: bool) -> Texture2D:
	var key: String = "switch_%s_%s" % [on, disabled]
	if _cache.has(key):
		return _cache[key]
	var width: int = 104
	var height: int = 56
	var image: Image = Image.create(width, height, false, Image.FORMAT_RGBA8)
	var track_color: Color = Color(0.0, 0.58, 0.74) if on else Color(0.17, 0.21, 0.28)
	var border_color: Color = Color(0.45, 0.95, 1.0) if on else Color(0.4, 0.5, 0.6)
	var knob_color: Color = Color(0.97, 1.0, 1.0) if on else Color(0.72, 0.78, 0.85)
	if disabled:
		track_color = track_color.darkened(0.45)
		border_color = border_color.darkened(0.5)
		knob_color = knob_color.darkened(0.45)
	var knob_x: float = float(width) - 28.0 if on else 28.0
	for y: int in range(height):
		for x: int in range(width):
			var p := Vector2(float(x) + 0.5, float(y) + 0.5)
			var d_track: float = _segment_distance(p, Vector2(28, 28), Vector2(76, 28)) - 26.0
			var pixel := Color(0, 0, 0, 0)
			pixel = _blend(pixel, border_color, _coverage(d_track))
			pixel = _blend(pixel, track_color, _coverage(d_track + 3.0))
			var d_knob: float = p.distance_to(Vector2(knob_x, 28.0)) - 19.0
			pixel = _blend(pixel, Color(0, 0, 0, 0.35), _coverage(p.distance_to(Vector2(knob_x, 31.0)) - 19.0))
			pixel = _blend(pixel, knob_color, _coverage(d_knob))
			image.set_pixel(x, y, pixel)
	var texture: ImageTexture = ImageTexture.create_from_image(image)
	_cache[key] = texture
	return texture


## Pole wyboru 56 x 56 px z "ptaszkiem".
static func _checkbox_icon(checked: bool) -> Texture2D:
	var key: String = "checkbox_%s" % checked
	if _cache.has(key):
		return _cache[key]
	var size: int = 56
	var image: Image = Image.create(size, size, false, Image.FORMAT_RGBA8)
	var fill_color: Color = Color(0.0, 0.58, 0.74) if checked else Color(0.07, 0.1, 0.15)
	var border_color: Color = Color(0.45, 0.95, 1.0) if checked else Color(0.4, 0.5, 0.6)
	var half: Vector2 = Vector2(size, size) * 0.5
	for y: int in range(size):
		for x: int in range(size):
			var p := Vector2(float(x) + 0.5, float(y) + 0.5)
			var q: Vector2 = (p - half).abs() - (half - Vector2(14, 14))
			var d_box: float = Vector2(maxf(q.x, 0.0), maxf(q.y, 0.0)).length() + minf(maxf(q.x, q.y), 0.0) - 13.0
			var pixel := Color(0, 0, 0, 0)
			pixel = _blend(pixel, border_color, _coverage(d_box))
			pixel = _blend(pixel, fill_color, _coverage(d_box + 3.0))
			if checked:
				var d_tick: float = minf(_segment_distance(p, Vector2(14, 29), Vector2(24, 39)), _segment_distance(p, Vector2(24, 39), Vector2(43, 16))) - 3.2
				pixel = _blend(pixel, Color.WHITE, _coverage(d_tick))
			image.set_pixel(x, y, pixel)
	var texture: ImageTexture = ImageTexture.create_from_image(image)
	_cache[key] = texture
	return texture


## Strzałka listy rozwijanej (szewron w dół).
static func _chevron_icon() -> Texture2D:
	if _cache.has("chevron"):
		return _cache["chevron"]
	var size: int = 44
	var image: Image = Image.create(size, size, false, Image.FORMAT_RGBA8)
	for y: int in range(size):
		for x: int in range(size):
			var p := Vector2(float(x) + 0.5, float(y) + 0.5)
			var d: float = minf(_segment_distance(p, Vector2(9, 15), Vector2(22, 29)), _segment_distance(p, Vector2(22, 29), Vector2(35, 15))) - 3.4
			image.set_pixel(x, y, Color(0.75, 0.95, 1.0, _coverage(d)))
	var texture: ImageTexture = ImageTexture.create_from_image(image)
	_cache["chevron"] = texture
	return texture
