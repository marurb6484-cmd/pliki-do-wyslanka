extends HUDModule
## Wskaźnik energii baterii i stanu pit stopu.

var _player: Robot
var _pit_stop: PitStopSystem
var _bar: ProgressBar
var _value: Label
var _status: Label
var _lap_usage: Label
var _last_ratio: float = -1.0


func _build() -> void:
	var panel := PanelContainer.new()
	panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_theme_stylebox_override("panel", UIKit.panel_style(Color(0.03, 0.045, 0.075, 0.74), Color(0.25, 1.0, 0.5, 0.5), 20, 2, 14.0))
	add_child(panel)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 3)
	panel.add_child(column)
	var row := HBoxContainer.new()
	column.add_child(row)
	var title := UIKit.make_label("BATERIA", 26, UIKit.COLOR_GOOD)
	row.add_child(title)
	_value = UIKit.make_label("100%", 26, Color.WHITE, HORIZONTAL_ALIGNMENT_RIGHT)
	_value.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(_value)
	_bar = UIKit.make_bar(22, UIKit.COLOR_GOOD)
	_bar.max_value = 100.0
	column.add_child(_bar)
	_status = UIKit.make_label("ENERGIA OK", 22, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_CENTER)
	column.add_child(_status)
	_lap_usage = UIKit.make_label("ZUŻYCIE OSTATNIEGO OKRĄŻENIA: —", 18, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT)
	column.add_child(_lap_usage)


func _on_setup() -> void:
	_player = context.get("player") as Robot
	_pit_stop = context.get("pit_stop") as PitStopSystem


func _refresh() -> void:
	if _player == null or not is_instance_valid(_player):
		return
	var ratio: float = _player.energy.get_ratio()
	if absf(ratio - _last_ratio) > 0.005:
		_last_ratio = ratio
		_bar.value = ratio * 100.0
		_value.text = "%d%%" % roundi(ratio * 100.0)
		var color: Color = UIKit.COLOR_GOOD if ratio > 0.5 else (Color(1.0, 0.68, 0.16) if ratio > 0.2 else UIKit.COLOR_BAD)
		UIKit.set_bar_color(_bar, color)
	if _pit_stop != null and _pit_stop.is_in_pit():
		_status.text = _pit_stop.get_status_text()
		_status.add_theme_color_override("font_color", UIKit.COLOR_ACCENT)
	elif PitStrategySystem.should_warn_player(_player.energy):
		_status.text = "SŁABA BATERIA"
		_status.add_theme_color_override("font_color", UIKit.COLOR_BAD)
	else:
		_status.text = "ENERGIA OK"
		_status.add_theme_color_override("font_color", UIKit.COLOR_MUTED)
	var last_use: float = _player.energy.last_lap_consumed
	_lap_usage.text = "ZUŻYCIE OSTATNIEGO OKRĄŻENIA: %.1f%%" % (last_use / maxf(_player.energy.capacity, 0.001) * 100.0) if last_use > 0.01 else "ZUŻYCIE OSTATNIEGO OKRĄŻENIA: —"

func _show_preview() -> void:
	_bar.value = 72.0
	_value.text = "72%"
	_status.text = "ENERGIA OK"
	_lap_usage.text = "ZUŻYCIE OSTATNIEGO OKRĄŻENIA: —"
