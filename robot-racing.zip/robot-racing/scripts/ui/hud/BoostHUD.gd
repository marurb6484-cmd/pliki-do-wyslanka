extends HUDModule
## BoostHUD - poziom brudu w zbiorniku, liczba dostępnych boostów,
## gotowość, czas działania i odnowienie boosta.
##
## Poprzednia wersja miała przyciski wyboru 4 typów boosta, z których działał
## tylko jeden ("PRĘDKOŚĆ") - pozostałe nic nie robiły, więc zostały usunięte.

var _player: Robot
var _title: Label
var _charge_label: Label
var _status_label: Label
var _charge_bar: ProgressBar
var _timer_bar: ProgressBar
var _ticks: Control
var _panel_style: StyleBoxFlat
var _last_state: int = -1
var _last_charge: float = -1.0
var _cost_ratio: float = 0.5
var _next_button: Button


func _build() -> void:
	var panel := PanelContainer.new()
	_panel_style = UIKit.panel_style(Color(0.03, 0.045, 0.075, 0.74), Color(0.0, 0.85, 1.0, 0.7), 20, 3, 14.0)
	panel.add_theme_stylebox_override("panel", _panel_style)
	panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(panel)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 4)
	column.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(column)

	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	column.add_child(row)
	_title = UIKit.make_label("BOOST", 34, UIKit.COLOR_ACCENT)
	row.add_child(_title)
	_next_button = UIKit.make_button("NASTĘPNY ▶", 24, 72, "ghost")
	_next_button.custom_minimum_size.x = 230
	_next_button.pressed.connect(_on_next_boost)
	row.add_child(_next_button)
	_charge_label = UIKit.make_label("BRUD 0/10", 23)
	_charge_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_charge_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	row.add_child(_charge_label)

	var bar_holder := Control.new()
	bar_holder.custom_minimum_size = Vector2(0, 30)
	bar_holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	column.add_child(bar_holder)
	_charge_bar = UIKit.make_bar(30, Color(0.55, 0.42, 0.25))
	_charge_bar.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bar_holder.add_child(_charge_bar)
	_ticks = Control.new()
	_ticks.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_ticks.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ticks.draw.connect(_draw_ticks)
	bar_holder.add_child(_ticks)

	_timer_bar = UIKit.make_bar(10, UIKit.COLOR_ACCENT)
	column.add_child(_timer_bar)


	_status_label = UIKit.make_label("ZBIERAJ BRUD", 28, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_CENTER)
	column.add_child(_status_label)


## Znaczniki kosztu boosta na pasku - widać, ile boostów jest dostępnych.
func _draw_ticks() -> void:
	if _cost_ratio <= 0.0 or _cost_ratio >= 1.0:
		return
	var x: float = _cost_ratio
	while x < 0.999:
		var px: float = x * _ticks.size.x
		_ticks.draw_line(Vector2(px, 3), Vector2(px, _ticks.size.y - 3), Color(1, 1, 1, 0.7), 3.0)
		x += _cost_ratio


func _on_setup() -> void:
	_player = context.get("player") as Robot
	if _player == null:
		return
	_cost_ratio = _player.boost.cost / maxf(_player.tank.capacity, 0.01)
	_ticks.queue_redraw()
	_player.boost.boost_denied.connect(_on_boost_denied)
	_player.boost.selected_changed.connect(func(_id: String) -> void: _refresh())
	if not _player.tank.changed.is_connected(_on_dirt_tank_changed):
		_player.tank.changed.connect(_on_dirt_tank_changed)


func _refresh() -> void:
	if _player == null or not is_instance_valid(_player):
		return
	var boost: BoostSystem = _player.boost
	_title.text = boost.get_selected_short_name()
	var dirt_ratio: float = _player.tank.get_ratio()
	_charge_label.text = "BRUD %.1f/%.1f" % [_player.tank.charge, _player.tank.capacity]
	_charge_bar.value = dirt_ratio
	_cost_ratio = boost.cost / maxf(_player.tank.capacity, 0.01)
	_ticks.queue_redraw()
	var state: int = boost.get_state()
	if state == BoostSystem.State.ACTIVE:
		_timer_bar.value = boost.get_active_ratio()
	elif state == BoostSystem.State.COOLDOWN:
		_timer_bar.value = 1.0 - boost.get_cooldown_ratio()
		_status_label.text = "ODNAWIANIE %.1f s" % boost.get_cooldown_left()
	else:
		_timer_bar.value = 1.0 if state == BoostSystem.State.READY else 0.0
	if state != _last_state:
		_last_state = state
		_apply_state_style(state)


func _on_dirt_tank_changed(_charge: float, _capacity: float) -> void:
	_refresh()


func _on_next_boost() -> void:
	if _player != null and is_instance_valid(_player):
		_player.boost.select_next()
		_refresh()


func get_interaction_controls() -> Array[Control]:
	return [_next_button]


func _apply_state_style(state: int) -> void:
	match state:
		BoostSystem.State.READY:
			_status_label.text = "GOTOWY!"
			_status_label.add_theme_color_override("font_color", UIKit.COLOR_GOOD)
			_panel_style.border_color = UIKit.COLOR_GOOD
			UIKit.set_bar_color(_timer_bar, UIKit.COLOR_GOOD)
		BoostSystem.State.ACTIVE:
			_status_label.text = "BOOST AKTYWNY"
			_status_label.add_theme_color_override("font_color", Color(1.0, 0.7, 0.2))
			_panel_style.border_color = Color(1.0, 0.6, 0.1)
			UIKit.set_bar_color(_timer_bar, Color(1.0, 0.6, 0.1))
		BoostSystem.State.COOLDOWN:
			_status_label.add_theme_color_override("font_color", UIKit.COLOR_MUTED)
			_panel_style.border_color = Color(0.4, 0.45, 0.5, 0.8)
			UIKit.set_bar_color(_timer_bar, Color(0.5, 0.55, 0.6))
		_:
			if _player != null and _player.boost.is_shocked():
				_status_label.text = "PORAŻENIE — BOOSTY ZABLOKOWANE"
			elif _player != null and _player.boost.get_selected_id() == "emergency_repair" and _player.damage.damage <= 0.01:
				_status_label.text = "BRAK USZKODZEŃ"
			elif _player != null and _player.boost.get_selected_id() == "energy_regenerator" and _player.energy.get_ratio() >= 0.999:
				_status_label.text = "BATERIA PEŁNA"
			elif _player != null and not _player.boost.has_enough_dirt():
				_status_label.text = "ZA MAŁO BRUDU"
			else:
				_status_label.text = "ZA MAŁO ENERGII / WARUNKÓW"
			_status_label.add_theme_color_override("font_color", UIKit.COLOR_MUTED)
			_panel_style.border_color = Color(0.0, 0.85, 1.0, 0.5)
			UIKit.set_bar_color(_timer_bar, UIKit.COLOR_ACCENT)


func _on_boost_denied(reason: String) -> void:
	_status_label.text = reason
	_status_label.add_theme_color_override("font_color", UIKit.COLOR_BAD)
	_last_state = -1


func _show_preview() -> void:
	_cost_ratio = 0.5
	_charge_bar.value = 0.7
	_charge_label.text = "BRUD 7/10"
	_timer_bar.value = 1.0
	_apply_state_style(BoostSystem.State.READY)
	_ticks.queue_redraw()
