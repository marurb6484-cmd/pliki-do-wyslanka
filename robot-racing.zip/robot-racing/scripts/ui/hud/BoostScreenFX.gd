class_name BoostScreenFX
extends ColorRect
## Efekt na całym ekranie podczas turbo/overdrive: radialne smugi prędkości,
## winieta o barwie boosta i pulsujący błysk w chwili zapłonu.

const SHADER_CODE: String = """shader_type canvas_item;
render_mode blend_add;

uniform float intensity = 0.0;
uniform vec4 tint : source_color = vec4(0.45, 0.8, 1.0, 1.0);
uniform float aspect = 2.16;

float hash(vec2 p) {
	return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

void fragment() {
	vec2 uv = UV - 0.5;
	uv.x *= aspect;
	float r = length(uv) / (aspect * 0.5);
	float a = atan(uv.y, uv.x);
	float streak = 0.0;
	for (int layer = 0; layer < 2; layer++) {
		float density = 38.0 + float(layer) * 29.0;
		float cell = floor(a / 6.2831 * density);
		float rnd = hash(vec2(cell, float(layer) + floor(TIME * 16.0)));
		float len = smoothstep(0.35 + rnd * 0.25, 1.1, r);
		streak += step(0.66, rnd) * len * (0.6 + 0.4 * hash(vec2(cell, 3.0)));
	}
	float vignette = smoothstep(0.45, 1.05, r);
	float a_out = (streak * 0.45 + vignette * 0.5) * intensity;
	COLOR = vec4(tint.rgb * (0.8 + streak * 0.6), clamp(a_out, 0.0, 0.85));
}
"""

var _player: Robot
var _level: float = 0.0
var _material: ShaderMaterial


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	color = Color.WHITE
	var shader := Shader.new()
	shader.code = SHADER_CODE
	_material = ShaderMaterial.new()
	_material.shader = shader
	material = _material
	visible = false


func setup(player: Robot) -> void:
	_player = player


func _process(delta: float) -> void:
	var target: float = 0.0
	var tint: Color = Color(0.45, 0.8, 1.0)
	if _player != null and is_instance_valid(_player) and _player.boost != null and GameSettings.effects_enabled:
		if _player.boost.is_turbo_active():
			target = 1.0
			tint = Color(0.55, 0.78, 1.0).lerp(Color(1.0, 0.6, 0.25), 0.35)
		elif _player.boost.is_active() and _player.boost.active_id == "overdrive":
			target = 0.55
			tint = Color(1.0, 0.8, 0.3)
	_level = move_toward(_level, target, delta * (8.0 if target > _level else 3.0))
	visible = _level > 0.01
	if visible:
		_material.set_shader_parameter("intensity", _level)
		_material.set_shader_parameter("tint", tint)
		_material.set_shader_parameter("aspect", maxf(size.x / maxf(size.y, 1.0), 1.0))
