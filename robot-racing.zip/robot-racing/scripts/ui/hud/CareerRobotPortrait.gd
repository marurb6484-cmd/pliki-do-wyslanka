class_name CareerRobotPortrait
extends Control
## Kreskówkowy portret robota kampanii, budowany z aktualnej konfiguracji gracza.

var robot_config: Dictionary = {}

func _ready() -> void:
	custom_minimum_size = Vector2(210, 150)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	if robot_config.is_empty():
		robot_config = PlayerProgress.get_player_robot_config()
	queue_redraw()

func set_robot_config(value: Dictionary) -> void:
	robot_config = value.duplicate(true)
	queue_redraw()

func _draw() -> void:
	var primary: Color = robot_config.get("primary_color", Color("#b7b9bd"))
	var secondary: Color = robot_config.get("secondary_color", Color("#252a31"))
	var neon: Color = robot_config.get("neon_color", Color("#00e5ff"))
	var shape: String = str(robot_config.get("shape", "disc"))
	var center := Vector2(size.x * 0.5, size.y * 0.54)
	var body := Rect2(center - Vector2(70, 38), Vector2(140, 76))
	# Cień i obrys komiksowy.
	draw_circle(center + Vector2(0, 39), 17, Color(0.02, 0.025, 0.04, 0.55))
	match shape:
		"model_saros":
			var saros_points := PackedVector2Array([center + Vector2(-73, 18), center + Vector2(-58, -30), center + Vector2(48, -30), center + Vector2(74, -4), center + Vector2(64, 31), center + Vector2(-62, 31)])
			draw_colored_polygon(saros_points, Color.BLACK)
			for i in range(saros_points.size()): saros_points[i] = center + (saros_points[i] - center) * 0.91
			draw_colored_polygon(saros_points, primary)
		"model_roomba":
			draw_circle(center, 76, Color.BLACK)
			draw_circle(center, 68, primary)
			draw_rect(Rect2(center + Vector2(-32, -2), Vector2(64, 27)), secondary, true)
		"model_dreame", "model_xiaomi", "model_narwal", "spider", "slimarm", "roomba", "periscope", "whale":
			draw_circle(center, 76, Color.BLACK)
			draw_circle(center, 68, primary)
		"wedge":
			var points := PackedVector2Array([center + Vector2(-73, 20), center + Vector2(-55, -32), center + Vector2(46, -34), center + Vector2(76, 2), center + Vector2(54, 37), center + Vector2(-54, 37)])
			draw_colored_polygon(points, Color.BLACK)
			for i in range(points.size()): points[i] = center + (points[i] - center) * 0.91
			draw_colored_polygon(points, primary)
		"square":
			draw_rect(body.grow(5), Color.BLACK, true)
			draw_rect(body, primary, true)
		"heavy":
			draw_circle(center, 78, Color.BLACK)
			draw_circle(center, 70, primary)
		_:
			draw_circle(center, 76, Color.BLACK)
			draw_circle(center, 68, primary)
	# Zderzak, panel i pierścień LED.
	if shape == "square" or shape == "model_roomba" or shape == "roomba":
		draw_rect(Rect2(center + Vector2(-50, -17), Vector2(100, 35)), secondary, true)
	else:
		draw_arc(center, 57.0, PI * 0.08, PI * 0.92, 36, secondary, 9.0, true)
		draw_arc(center, 61.0, PI * 1.08, PI * 1.92, 36, neon, 4.0, true)
	draw_circle(center + Vector2(0, -5), 17, secondary)
	draw_circle(center + Vector2(0, -5), 9, neon)
	# LiDAR/kamera zależnie od modelu.
	if shape in ["wedge", "heavy", "model_xiaomi", "periscope"]:
		draw_circle(center + Vector2(0, -45), 18, Color.BLACK)
		draw_circle(center + Vector2(0, -45), 12, secondary)
		draw_circle(center + Vector2(0, -45), 5, neon)
	elif shape in ["model_dreame", "model_saros", "model_narwal", "spider", "slimarm", "whale"]:
		var camera_count: int = 2 if shape != "model_dreame" else 2
		for camera_index in range(camera_count):
			var camera_x: float = -14.0 if camera_index == 0 else 14.0
			draw_circle(center + Vector2(camera_x, -43), 9, Color.BLACK)
			draw_circle(center + Vector2(camera_x, -43), 4, neon)
	elif bool(robot_config.get("camera", false)) or shape == "square":
		draw_circle(center + Vector2(0, -42), 10, Color.BLACK)
		draw_circle(center + Vector2(0, -42), 5, neon)
	# Szczotki boczne.
	var brush_count: int = 2 if shape in ["square", "heavy", "model_saros", "model_narwal", "whale"] else 1
	for side in range(brush_count):
		var bx: float = -82.0 if side == 0 else 82.0
		var brush_center := center + Vector2(bx, 12)
		draw_circle(brush_center, 7, Color.BLACK)
		for arm in range(3):
			var angle: float = TAU * float(arm) / 3.0
			draw_line(brush_center, brush_center + Vector2(cos(angle), sin(angle)) * 15.0, Color("#f5d45c"), 3.0, true)
	# Charakterystyczne dodatki rozpoznawcze nowych platform.
	if shape == "model_saros":
		draw_line(center + Vector2(0, -8), center + Vector2(34, -25), secondary, 7.0, true)
		draw_line(center + Vector2(34, -25), center + Vector2(48, -12), secondary, 6.0, true)
	elif shape == "model_xiaomi":
		draw_circle(center + Vector2(0, -5), 22, secondary)
		draw_circle(center + Vector2(0, -5), 15, Color.BLACK)
	elif shape == "model_narwal":
		for side in [-1.0, 1.0]:
			draw_circle(center + Vector2(side * 30.0, 24), 12, secondary)
	elif shape == "model_dreame":
		draw_circle(center + Vector2(0, 18), 20, secondary)
		draw_circle(center + Vector2(0, 18), 14, Color.BLACK)
	elif shape == "spider":
		draw_circle(center + Vector2(0, -42), 13, secondary)
		draw_line(center + Vector2(-48, 12), center + Vector2(-83, 2), secondary, 7.0, true)
	elif shape == "slimarm":
		draw_line(center + Vector2(0, -15), center + Vector2(0, -58), secondary, 8.0, true)
		draw_line(center + Vector2(0, -58), center + Vector2(20, -48), secondary, 6.0, true)
	elif shape == "roomba":
		draw_rect(Rect2(center + Vector2(-22, 20), Vector2(44, 13)), secondary, true)
	elif shape == "periscope":
		draw_rect(Rect2(center + Vector2(-38, -47), Vector2(76, 8)), Color(1.0, 0.25, 0.2), true)
	elif shape == "whale":
		for side in [-1.0, 1.0]:
			draw_circle(center + Vector2(side * 30.0, 24), 12, secondary)
	# Ulepszenia garażowe są widoczne także w komiksowej wersji robota.
	var upgrades: Dictionary = robot_config.get("upgrade_levels", {})
	var bumper_level: int = int(upgrades.get("bumper", 0))
	if bumper_level > 0:
		draw_rect(Rect2(center + Vector2(-48, 25), Vector2(96, 12 + bumper_level)), Color.BLACK, true)
		draw_rect(Rect2(center + Vector2(-44, 27), Vector2(88, 6 + bumper_level)), secondary, true)
	var battery_level: int = int(upgrades.get("battery", 0))
	for cell in range(mini(battery_level, 5)):
		draw_rect(Rect2(center + Vector2(-26 + cell * 12, -58), Vector2(8, 5)), neon, true)
	var speed_level: int = int(upgrades.get("speed", 0))
	if speed_level >= 3:
		draw_rect(Rect2(center + Vector2(-34, -65), Vector2(68, 5)), secondary, true)
	# Małe oznaczenie jednostki S-01.
	draw_string(ThemeDB.fallback_font, Vector2(center.x - 19, size.y - 3), "S-01", HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color.WHITE)
