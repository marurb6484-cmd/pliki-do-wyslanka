extends HUDModule
## DamageHUD - poziom uszkodzeń robota gracza (%, stopień, ikona robota).

var _player: Robot
var _percent_label: Label
var _stage_label: Label
var _bar: ProgressBar
var _icon: Control
var _damage: float = 0.0
var _flash: float = 0.0
var _last_value: float = -1.0


func _build() -> void:
	var panel := UIKit.make_hud_panel()
	panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(panel)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(row)

	_icon = Control.new()
	_icon.custom_minimum_size = Vector2(76, 76)
	_icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_icon.draw.connect(_draw_icon)
	row.add_child(_icon)

	var column := VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 2)
	column.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(column)

	var top := HBoxContainer.new()
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	column.add_child(top)
	_percent_label = UIKit.make_label("0%", 34)
	top.add_child(_percent_label)
	_stage_label = UIKit.make_label("SPRAWNY", 24, DamageSystem.STAGE_COLORS[0])
	_stage_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_stage_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	top.add_child(_stage_label)

	_bar = UIKit.make_bar(16, DamageSystem.STAGE_COLORS[0])
	column.add_child(_bar)


## Ikona robota z góry: kolor zależny od stopnia uszkodzeń, rysy przy dużych.
func _draw_icon() -> void:
	var center: Vector2 = _icon.size * 0.5
	var radius: float = minf(_icon.size.x, _icon.size.y) * 0.42
	var stage: int = 0
	if _damage >= 75.0:
		stage = 3
	elif _damage >= 50.0:
		stage = 2
	elif _damage >= 25.0:
		stage = 1
	var color: Color = DamageSystem.STAGE_COLORS[stage]
	if _flash > 0.0:
		color = color.lerp(Color.WHITE, _flash)
	_icon.draw_circle(center, radius + 3.0, Color(0, 0, 0, 0.8))
	_icon.draw_circle(center, radius, color.darkened(0.35))
	_icon.draw_arc(center, radius, 0.0, TAU, 32, color, 3.0, true)
	_icon.draw_rect(Rect2(center + Vector2(-radius * 0.45, -radius - 2.0), Vector2(radius * 0.9, 6.0)), color)
	if _damage >= 50.0:
		_icon.draw_line(center + Vector2(-radius * 0.5, -radius * 0.2), center + Vector2(radius * 0.1, radius * 0.4), Color(0, 0, 0, 0.9), 3.0)
	if _damage >= 75.0:
		_icon.draw_line(center + Vector2(radius * 0.4, -radius * 0.5), center + Vector2(-radius * 0.1, radius * 0.1), Color(0, 0, 0, 0.9), 3.0)


func _on_setup() -> void:
	_player = context.get("player") as Robot
	if _player != null:
		_player.damage.damage_changed.connect(_on_damage_changed)
		_on_damage_changed(_player.damage.damage, _player.damage.get_stage())


func _on_damage_changed(value: float, stage: int) -> void:
	if value > _last_value and _last_value >= 0.0:
		_flash = 1.0
	_last_value = value
	_damage = value
	_percent_label.text = "%d%%" % int(round(value))
	_stage_label.text = DamageSystem.STAGE_NAMES[stage]
	_stage_label.add_theme_color_override("font_color", DamageSystem.STAGE_COLORS[stage])
	_bar.value = value / 100.0
	UIKit.set_bar_color(_bar, DamageSystem.STAGE_COLORS[stage])
	_icon.queue_redraw()


func _refresh() -> void:
	if _flash > 0.0:
		_flash = maxf(_flash - update_interval * 2.5, 0.0)
		_icon.queue_redraw()


func _show_preview() -> void:
	_on_damage_changed(42.0, DamageSystem.Stage.LIGHT)
