extends PanelContainer
## Panel trybu TESTUJ GRAFIKĘ: pomiar wydajności (FPS średnie/min/1% low,
## draw calls, obiekty), szybka zmiana ustawień graficznych na żywo,
## autopilot, przełączanie kamery między robotami, zakończenie testu.

var hud: Node
var _stats_label: Label
var _content: VBoxContainer
var _quality_buttons: Array[Button] = []
var _toggle_buttons: Dictionary = {}
var _fps_button: Button
var _autopilot_button: Button
var _collapse_button: Button
var _wizard_box: VBoxContainer
var _wizard_status: Label
var _wizard_question: Label
var _wizard_buttons: HBoxContainer
var _wizard_timer: float = 0.0
var _wizard_waiting: bool = false
var _wizard_initial_sequence: bool = false

var _frame_times: PackedFloat32Array = PackedFloat32Array()
var _all_count: int = 0
var _all_sum: float = 0.0
var _min_frame_time: float = 0.0
var _stats_timer: float = 0.0
var _autopilot: bool = false


func _ready() -> void:
	set_process(false)
	add_theme_stylebox_override("panel", UIKit.panel_style(Color(0.02, 0.04, 0.07, 0.88), Color(1.0, 0.7, 0.1, 0.8)))
	anchor_left = 0.0
	anchor_right = 0.0
	anchor_top = 0.26
	anchor_bottom = 0.26
	offset_left = 20
	offset_top = 0
	custom_minimum_size = Vector2(560, 0)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 8)
	add_child(column)

	var header := HBoxContainer.new()
	column.add_child(header)
	header.add_child(UIKit.make_label("TEST GRAFIKI", 30, Color(1.0, 0.75, 0.2)))
	_collapse_button = UIKit.make_button("▲", 28, 64)
	_collapse_button.custom_minimum_size = Vector2(90, 64)
	_collapse_button.size_flags_horizontal = Control.SIZE_SHRINK_END
	_collapse_button.pressed.connect(_toggle_collapse)
	header.add_child(_collapse_button)

	_stats_label = UIKit.make_label("FPS: --", 24)
	column.add_child(_stats_label)

	_content = VBoxContainer.new()
	_content.add_theme_constant_override("separation", 8)
	column.add_child(_content)

	var quality_row := HBoxContainer.new()
	quality_row.add_theme_constant_override("separation", 6)
	_content.add_child(quality_row)
	for i: int in range(5):
		var button := UIKit.make_button(["VERY LOW", "LOW", "MED", "HIGH", "ULTRA"][i], 24, 66)
		button.toggle_mode = true
		button.pressed.connect(_set_quality.bind(i))
		quality_row.add_child(button)
		_quality_buttons.append(button)

	var toggles := GridContainer.new()
	toggles.columns = 3
	toggles.add_theme_constant_override("h_separation", 6)
	toggles.add_theme_constant_override("v_separation", 6)
	_content.add_child(toggles)
	for key: String in ["Cienie", "Neony", "Światła", "Odbicia", "Efekty", "FPS"]:
		var toggle := UIKit.make_button(key, 22, 62)
		toggle.toggle_mode = true
		toggle.toggled.connect(_on_toggle.bind(key))
		toggles.add_child(toggle)
		_toggle_buttons[key] = toggle

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	_content.add_child(row)
	_fps_button = UIKit.make_button("", 22, 62)
	_fps_button.pressed.connect(_cycle_fps)
	row.add_child(_fps_button)
	_autopilot_button = UIKit.make_button("AUTOPILOT: WYŁ", 22, 62)
	_autopilot_button.pressed.connect(_toggle_autopilot)
	row.add_child(_autopilot_button)

	var row2 := HBoxContainer.new()
	row2.add_theme_constant_override("separation", 6)
	_content.add_child(row2)
	var camera_button := UIKit.make_button("KAMERA ▶", 22, 62)
	camera_button.pressed.connect(func() -> void: _scene_call("cycle_camera_target"))
	row2.add_child(camera_button)
	var end_button := UIKit.make_button("ZAKOŃCZ TEST", 22, 62)
	end_button.pressed.connect(func() -> void: _scene_call("end_test"))
	row2.add_child(end_button)

	_wizard_box = VBoxContainer.new()
	_wizard_box.add_theme_constant_override("separation", 10)
	column.add_child(_wizard_box)
	_wizard_status = UIKit.make_label("Przygotowanie testu…", 25, Color(1.0, 0.85, 0.35))
	_wizard_box.add_child(_wizard_status)
	_wizard_question = UIKit.make_label("", 24, Color.WHITE)
	_wizard_question.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_wizard_box.add_child(_wizard_question)
	_wizard_buttons = HBoxContainer.new()
	_wizard_buttons.add_theme_constant_override("separation", 8)
	_wizard_box.add_child(_wizard_buttons)
	_wizard_box.visible = false

	GameSettings.graphics_changed.connect(_refresh_buttons)
	_refresh_buttons()


func setup(target_hud: Node) -> void:
	hud = target_hud
	_reset_stats()
	if GameSettings.graphics_wizard_active:
		_content.visible = false
		_wizard_box.visible = true
		_wizard_initial_sequence = true
		_begin_wizard_level(GameSettings.Quality.VERY_LOW)
	set_process(true)


func _begin_wizard_level(level: int) -> void:
	GameSettings.set_quality_preset(level, false)
	_reset_stats()
	_wizard_waiting = true
	_wizard_timer = 7.0
	_wizard_question.text = ""
	_wizard_status.text = "Testuję: %s\nPoczekaj 7 sekund, aż pomiar będzie miarodajny…" % GameSettings.QUALITY_NAMES[level]
	_wizard_buttons.visible = false


func _show_wizard_choices() -> void:
	_wizard_waiting = false
	_wizard_status.text = "Wynik dla jakości: %s\n%s" % [GameSettings.QUALITY_NAMES[GameSettings.quality], _benchmark_summary()]
	_wizard_question.text = "Czy chcesz lepszą czy gorszą grafikę, czy akceptujesz ten poziom?"
	for child: Node in _wizard_buttons.get_children():
		child.queue_free()
	var level: int = GameSettings.quality
	if level > GameSettings.Quality.VERY_LOW:
		var lower := UIKit.make_button("GORSZA", 22, 64)
		lower.pressed.connect(func() -> void: _begin_wizard_level(GameSettings.quality - 1))
		_wizard_buttons.add_child(lower)
	var accept := UIKit.make_button("AKCEPTUJ", 22, 64, "primary")
	accept.pressed.connect(_accept_graphics_wizard)
	_wizard_buttons.add_child(accept)
	if level < GameSettings.Quality.ULTRA:
		var higher := UIKit.make_button("LEPSZA", 22, 64)
		higher.pressed.connect(func() -> void: _begin_wizard_level(GameSettings.quality + 1))
		_wizard_buttons.add_child(higher)
	_wizard_buttons.visible = true


func _benchmark_summary() -> String:
	var stats: Dictionary = get_benchmark()
	if stats.is_empty():
		return "Pomiar FPS jest jeszcze zbierany."
	return "Średnio %s FPS • minimum %s FPS • 1%% low %s FPS" % [
		str(stats.get("Średnie FPS", "--")),
		str(stats.get("Minimalne FPS", "--")),
		str(stats.get("1% low FPS", "--"))
	]


func _accept_graphics_wizard() -> void:
	GameSettings.confirm_graphics_quality()
	GameSettings.graphics_wizard_active = false
	_wizard_status.text = "Zapisano: %s" % GameSettings.QUALITY_NAMES[GameSettings.quality]
	_scene_call("quit_to_menu")


func _scene_call(method: String) -> void:
	if hud != null and hud.get("race_scene") != null:
		hud.get("race_scene").call(method)


func _toggle_collapse() -> void:
	_content.visible = not _content.visible
	_collapse_button.text = "▲" if _content.visible else "▼"


func _set_quality(level: int) -> void:
	GameSettings.set_quality_preset(level)
	_reset_stats()


func _on_toggle(pressed: bool, key: String) -> void:
	match key:
		"Cienie":
			if GameSettings.shadows_enabled != pressed:
				GameSettings.set_shadows_enabled(pressed)
		"Neony":
			if GameSettings.neon_enabled != pressed:
				GameSettings.set_neon_enabled(pressed)
		"Światła":
			if GameSettings.headlights_enabled != pressed:
				GameSettings.set_headlights_enabled(pressed)
		"Odbicia":
			if GameSettings.reflections_enabled != pressed:
				GameSettings.set_reflections_enabled(pressed)
		"Efekty":
			if GameSettings.effects_enabled != pressed:
				GameSettings.set_effects_enabled(pressed)
		"FPS":
			if GameSettings.show_fps != pressed:
				GameSettings.set_show_fps(pressed)
	_reset_stats()


func _cycle_fps() -> void:
	var options: Array[int] = GameSettings.FPS_OPTIONS
	GameSettings.set_fps_limit(options[(options.find(GameSettings.fps_limit) + 1) % options.size()])
	_reset_stats()


func _toggle_autopilot() -> void:
	_autopilot = not _autopilot
	_scene_call_arg("enable_player_autopilot", _autopilot)
	_autopilot_button.text = "AUTOPILOT: WŁ" if _autopilot else "AUTOPILOT: WYŁ"


func _scene_call_arg(method: String, value: Variant) -> void:
	if hud != null and hud.get("race_scene") != null:
		hud.get("race_scene").call(method, value)


func _refresh_buttons() -> void:
	for i: int in range(_quality_buttons.size()):
		_quality_buttons[i].set_pressed_no_signal(GameSettings.quality == i)
	var states: Dictionary = {
		"Cienie": GameSettings.shadows_enabled, "Neony": GameSettings.neon_enabled,
		"Światła": GameSettings.headlights_enabled, "Odbicia": GameSettings.reflections_enabled,
		"Efekty": GameSettings.effects_enabled, "FPS": GameSettings.show_fps
	}
	for key: String in states.keys():
		(_toggle_buttons[key] as Button).set_pressed_no_signal(bool(states[key]))
	_fps_button.text = "LIMIT: %s" % ("BRAK" if GameSettings.fps_limit == 0 else str(GameSettings.fps_limit))


func _reset_stats() -> void:
	_frame_times.clear()
	_all_count = 0
	_all_sum = 0.0
	_min_frame_time = 0.0


func _process(delta: float) -> void:
	if get_tree().paused or delta <= 0.0:
		return
	if GameSettings.graphics_wizard_active and _wizard_waiting:
		_wizard_timer -= delta
		if _wizard_timer <= 0.0:
			if _wizard_initial_sequence and GameSettings.quality == GameSettings.Quality.VERY_LOW:
				_wizard_initial_sequence = false
				_begin_wizard_level(GameSettings.Quality.LOW)
			else:
				_wizard_initial_sequence = false
				_show_wizard_choices()
	_frame_times.append(delta)
	if _frame_times.size() > 600:
		_frame_times = _frame_times.slice(_frame_times.size() - 600)
	_all_count += 1
	_all_sum += delta

	if _min_frame_time <= 0.0 or delta > _min_frame_time:
		_min_frame_time = delta
	_stats_timer -= delta
	if _stats_timer > 0.0:
		return
	_stats_timer = 0.5
	var fps: float = Engine.get_frames_per_second()
	var stats: Dictionary = get_benchmark()
	_stats_label.text = "FPS %d | śr. %s | min %s | 1%% low %s\nDraw calls %d | obiekty %d | %s" % [
		int(fps), str(stats.get("Średnie FPS", "--")), str(stats.get("Minimalne FPS", "--")), str(stats.get("1% low FPS", "--")),
		int(Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)),
		int(Performance.get_monitor(Performance.RENDER_TOTAL_OBJECTS_IN_FRAME)),
		GameSettings.get_renderer()
	]


func get_benchmark() -> Dictionary:
	var result: Dictionary = {}
	if _all_count < 10:
		return result
	result["Średnie FPS"] = int(round(_all_count / maxf(_all_sum, 0.001)))
	result["Minimalne FPS"] = int(round(1.0 / maxf(_min_frame_time, 0.0001))) if _min_frame_time > 0.0 else "--"
	var sorted: PackedFloat32Array = _frame_times.duplicate()
	sorted.sort()
	if not sorted.is_empty():
		var worst_count: int = maxi(1, int(ceil(float(sorted.size()) * 0.01)))
		var worst_sum: float = 0.0
		for i: int in range(sorted.size() - worst_count, sorted.size()):
			worst_sum += sorted[i]
		var worst_average: float = worst_sum / float(worst_count)
		result["1% low FPS"] = int(round(1.0 / maxf(worst_average, 0.0001)))
	result["Jakość"] = GameSettings.QUALITY_NAMES[GameSettings.quality]
	result["Renderer"] = GameSettings.get_renderer()
	result["Skala renderowania"] = "%d%%" % int(GameSettings.get_render_scale() * 100.0)
	return result
