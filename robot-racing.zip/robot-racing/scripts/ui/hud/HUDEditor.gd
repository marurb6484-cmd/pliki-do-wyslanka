extends Control
## Edytor układu HUD.
##
## - Przeciąganie modułów (dotyk lub mysz),
## - zmiana rozmiaru: uchwyt w prawym dolnym rogu lub przyciski − / +,
## - ukrywanie modułów, które nie są niezbędne (np. minimapa),
## - blokada zapisu, gdy ważne elementy na siebie nachodzą (czerwone ramki),
## - zapis osobno dla bieżącej proporcji ekranu, przywracanie domyślnych.

const HANDLE_SIZE: float = 56.0

var hud: Node
var modules: Array[HUDModule] = []
var selected: HUDModule

var _drag_mode: int = 0       # 0 = brak, 1 = przesuwanie, 2 = skalowanie
var _drag_pointer_id: int = -999
var _drag_start: Vector2
var _start_position: Vector2
var _start_scale: float = 1.0
var _original_layout: Dictionary = {}
var _overlapping: Dictionary = {}

var _toolbar: PanelContainer
var _info_label: Label
var _warning_label: Label
var _save_button: Button
var _hide_button: Button
var _toolbar_low: bool = false


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	_build_toolbar()


func _build_toolbar() -> void:
	_toolbar = UIKit.make_panel(Color(0.03, 0.05, 0.08, 0.92))
	_toolbar.anchor_left = 0.5
	_toolbar.anchor_right = 0.5
	_toolbar.anchor_top = 0.66
	_toolbar.anchor_bottom = 0.66
	_toolbar.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_toolbar.grow_vertical = Control.GROW_DIRECTION_BOTH
	add_child(_toolbar)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 10)
	_toolbar.add_child(column)

	_info_label = UIKit.make_label("EDYCJA HUD - przeciągnij element", 30, UIKit.COLOR_ACCENT, HORIZONTAL_ALIGNMENT_CENTER)
	column.add_child(_info_label)
	_warning_label = UIKit.make_label("", 26, UIKit.COLOR_BAD, HORIZONTAL_ALIGNMENT_CENTER)
	column.add_child(_warning_label)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	column.add_child(row)

	var smaller := UIKit.make_button("−", 40, 86)
	smaller.custom_minimum_size.x = 100
	smaller.pressed.connect(_change_scale.bind(-0.1))
	row.add_child(smaller)
	var bigger := UIKit.make_button("+", 40, 86)
	bigger.custom_minimum_size.x = 100
	bigger.pressed.connect(_change_scale.bind(0.1))
	row.add_child(bigger)
	_hide_button = UIKit.make_button("UKRYJ", 28, 86)
	_hide_button.pressed.connect(_toggle_hidden)
	row.add_child(_hide_button)
	var move_bar := UIKit.make_button("⇅ PASEK", 28, 86)
	move_bar.pressed.connect(_toggle_toolbar_position)
	row.add_child(move_bar)

	var row2 := HBoxContainer.new()
	row2.add_theme_constant_override("separation", 12)
	column.add_child(row2)
	_save_button = UIKit.make_button("ZAPISZ", 32, 90, "success")
	_save_button.pressed.connect(save)
	row2.add_child(_save_button)
	var defaults := UIKit.make_button("DOMYŚLNE", 32, 90, "ghost")
	defaults.pressed.connect(reset_defaults)
	row2.add_child(defaults)
	var cancel_button := UIKit.make_button("ANULUJ", 32, 90, "danger")
	cancel_button.pressed.connect(cancel)
	row2.add_child(cancel_button)

	var opacity_row := HBoxContainer.new()
	column.add_child(opacity_row)
	opacity_row.add_child(UIKit.make_label("Przezroczystość HUD", 26))
	var opacity := UIKit.make_slider(0.3, 1.0, 0.05, GameSettings.hud_opacity)
	opacity.value_changed.connect(func(value: float) -> void: GameSettings.set_hud_opacity(value))
	opacity_row.add_child(opacity)


func open(target_hud: Node) -> void:
	hud = target_hud
	modules = hud.get("modules")
	_original_layout = hud.call("collect_layout")
	selected = null
	visible = true
	for module: HUDModule in modules:
		module.visible = true
	_update_overlaps()
	_update_info()
	queue_redraw()


func _close() -> void:
	visible = false
	_drag_mode = 0
	_drag_pointer_id = -999
	hud.call("on_editor_closed")


func save() -> void:
	if not _overlapping.is_empty():
		return
	GameSettings.set_hud_layout(hud.call("get_bucket"), hud.call("collect_layout"))
	_close()


func reset_defaults() -> void:
	GameSettings.reset_hud_layout(hud.call("get_bucket"))
	hud.call("apply_layout_dict", {})
	for module: HUDModule in modules:
		module.visible = true
	_update_overlaps()
	_update_info()
	queue_redraw()


func cancel() -> void:
	hud.call("apply_layout_dict", _original_layout)
	_close()


func _change_scale(amount: float) -> void:
	if selected == null:
		return
	_set_module_scale(selected, selected.layout_scale + amount, selected.position)


func _toggle_hidden() -> void:
	if selected == null or not selected.can_hide:
		return
	selected.hidden_by_user = not selected.hidden_by_user
	_update_overlaps()
	_update_info()
	queue_redraw()


func _toggle_toolbar_position() -> void:
	_toolbar_low = not _toolbar_low
	_toolbar.anchor_top = 0.42 if _toolbar_low else 0.66
	_toolbar.anchor_bottom = _toolbar.anchor_top


func _set_module_scale(module: HUDModule, new_scale: float, keep_position: Vector2) -> void:
	var viewport_size: Vector2 = hud.call("get_viewport_size")
	new_scale = clampf(new_scale, 0.6, 1.6)
	var anchor: Vector2 = (keep_position + module.pivot * module.base_size * new_scale) / viewport_size
	module.apply_layout(anchor, new_scale, viewport_size)
	_after_change()


func _set_module_position(module: HUDModule, new_position: Vector2) -> void:
	var viewport_size: Vector2 = hud.call("get_viewport_size")
	var anchor: Vector2 = (new_position + module.pivot * module.get_scaled_size()) / viewport_size
	module.apply_layout(anchor, module.layout_scale, viewport_size)
	_after_change()


func _after_change() -> void:
	hud.get("touch").call("relayout")
	_update_overlaps()
	queue_redraw()


# =========================================================
# WEJŚCIE
# =========================================================

func _input(event: InputEvent) -> void:
	if not visible or not is_visible_in_tree():
		return
	# _input zamiast _gui_input: po rozpoczęciu przeciągania zdarzenia
	# nadal docierają tutaj, nawet gdy palec wyjedzie poza moduł lub ekran
	# przejdzie nad paskiem narzędzi. Obsługujemy także natywny dotyk Androida.
	var pointer_id: int = -999
	var point := Vector2.ZERO
	var pressed := false
	var released := false
	var moved := false
	var touch := event as InputEventScreenTouch
	if touch != null:
		pointer_id = touch.index
		point = _screen_to_local(touch.position)
		pressed = touch.pressed and not touch.canceled
		released = not touch.pressed or touch.canceled
	else:
		var drag := event as InputEventScreenDrag
		if drag != null:
			pointer_id = drag.index
			point = _screen_to_local(drag.position)
			moved = true
		else:
			var mouse_button := event as InputEventMouseButton
			if mouse_button != null and mouse_button.button_index == MOUSE_BUTTON_LEFT:
				pointer_id = -1
				point = _screen_to_local(mouse_button.position)
				pressed = mouse_button.pressed
				released = not mouse_button.pressed
			else:
				var mouse_motion := event as InputEventMouseMotion
				if mouse_motion != null and _drag_pointer_id == -1:
					pointer_id = -1
					point = _screen_to_local(mouse_motion.position)
					moved = true
	if pointer_id == -999:
		return
	if pressed:
		if _toolbar != null and _toolbar.get_rect().has_point(point):
			return # przyciski paska nadal obsługuje GUI
		_begin_drag(point, pointer_id)
		if _drag_mode != 0:
			get_viewport().set_input_as_handled()
		return
	if released and pointer_id == _drag_pointer_id:
		_drag_mode = 0
		_drag_pointer_id = -999
		get_viewport().set_input_as_handled()
		return
	if moved and _drag_mode != 0 and pointer_id == _drag_pointer_id and selected != null:
		var delta: Vector2 = point - _drag_start
		if _drag_mode == 1:
			_set_module_position(selected, _start_position + delta)
		else:
			var base: float = selected.base_size.x + selected.base_size.y
			_set_module_scale(selected, _start_scale * (1.0 + (delta.x + delta.y) / base), _start_position)
		get_viewport().set_input_as_handled()


func _screen_to_local(screen_position: Vector2) -> Vector2:
	return get_global_transform_with_canvas().affine_inverse() * screen_position


func _begin_drag(point: Vector2, pointer_id: int) -> void:
	# Najpierw uchwyt skalowania zaznaczonego modułu.
	if selected != null and _handle_rect(selected).has_point(point):
		_drag_mode = 2
	else:
		var hit: HUDModule = null
		for i: int in range(modules.size() - 1, -1, -1):
			if modules[i].get_screen_rect().has_point(point):
				hit = modules[i]
				break
		selected = hit
		_drag_mode = 1 if hit != null else 0
	if selected != null and _drag_mode != 0:
		_drag_pointer_id = pointer_id
		_drag_start = point
		_start_position = selected.position
		_start_scale = selected.layout_scale
	_update_info()
	queue_redraw()


func _handle_rect(module: HUDModule) -> Rect2:
	var rect: Rect2 = module.get_screen_rect()
	return Rect2(rect.end - Vector2(HANDLE_SIZE, HANDLE_SIZE) * 0.75, Vector2(HANDLE_SIZE, HANDLE_SIZE))


# =========================================================
# KOLIZJE ELEMENTÓW I RYSOWANIE
# =========================================================

func _update_overlaps() -> void:
	_overlapping.clear()
	for i: int in range(modules.size()):
		var a: HUDModule = modules[i]
		if not a.critical or a.hidden_by_user:
			continue
		for j: int in range(i + 1, modules.size()):
			var b: HUDModule = modules[j]
			if not b.critical or b.hidden_by_user:
				continue
			if a.get_screen_rect().grow(-4.0).intersects(b.get_screen_rect().grow(-4.0)):
				_overlapping[a] = true
				_overlapping[b] = true
	_save_button.disabled = not _overlapping.is_empty()
	_warning_label.text = "Ważne elementy nachodzą na siebie - popraw układ" if not _overlapping.is_empty() else ""


func _update_info() -> void:
	if selected == null:
		_info_label.text = "EDYCJA HUD (%s) - dotknij element" % str(hud.call("get_bucket")) if hud != null else "EDYCJA HUD"
		_hide_button.disabled = true
		_hide_button.text = "UKRYJ"
		return
	_info_label.text = "%s  •  skala %d%%" % [selected.display_name, int(round(selected.layout_scale * 100.0))]
	_hide_button.disabled = not selected.can_hide
	_hide_button.text = "POKAŻ" if selected.hidden_by_user else "UKRYJ"


func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 0.25))
	var font: Font = ThemeDB.fallback_font
	for module: HUDModule in modules:
		var rect: Rect2 = module.get_screen_rect()
		var color := Color(1, 1, 1, 0.75)
		if _overlapping.has(module):
			color = UIKit.COLOR_BAD
		elif module == selected:
			color = UIKit.COLOR_ACCENT
		if module.hidden_by_user:
			color.a = 0.35
		draw_rect(rect, Color(color.r, color.g, color.b, 0.12), true)
		draw_rect(rect, color, false, 4.0)
		draw_string_outline(font, rect.position + Vector2(10, 32), module.display_name, HORIZONTAL_ALIGNMENT_LEFT, -1, 26, 6, Color.BLACK)
		draw_string(font, rect.position + Vector2(10, 32), module.display_name, HORIZONTAL_ALIGNMENT_LEFT, -1, 26, color)
		if module == selected:
			var handle: Rect2 = _handle_rect(module)
			draw_rect(handle, UIKit.COLOR_ACCENT, true)
			draw_line(handle.position + Vector2(12, handle.size.y - 12), handle.position + Vector2(handle.size.x - 12, 12), Color.BLACK, 4.0)
