class_name HUDModule
extends Control
## Bazowa klasa niezależnego modułu HUD.
##
## Każdy moduł:
##  - ma własną scenę i skrypt,
##  - dostaje kontekst wyścigu przez setup(context) i sam subskrybuje sygnały,
##  - odświeża się z ograniczoną częstotliwością (update_interval), a nie co klatkę,
##  - może być przesuwany i skalowany w edytorze HUD (pozycja zapisywana
##    jako punkt kotwicy względem ekranu, więc działa na różnych proporcjach),
##  - w podglądzie (edytor HUD z menu) pokazuje przykładowe dane.

@export var module_id: String = ""
@export var display_name: String = ""
## Punkt ekranu (0..1), w którym leży punkt `pivot` modułu.
@export var default_anchor: Vector2 = Vector2(0.02, 0.02)
## Punkt modułu (0..1) przypięty do kotwicy.
@export var pivot: Vector2 = Vector2.ZERO
@export var base_size: Vector2 = Vector2(400, 120)
@export var default_scale: float = 1.0
## Ważne elementy nie mogą na siebie nachodzić (pilnuje edytor HUD).
@export var critical: bool = true
## Czy gracz może ukryć moduł w edytorze.
@export var can_hide: bool = false
@export var update_interval: float = 0.1

var context: Dictionary = {}
var layout_anchor: Vector2 = Vector2.ZERO
var layout_scale: float = 1.0
var hidden_by_user: bool = false
var preview: bool = false

var _timer: float = 0.0


func _ready() -> void:
	add_to_group("hud_module")
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_TOP_LEFT)
	size = base_size
	layout_anchor = default_anchor
	layout_scale = default_scale
	_timer = randf() * update_interval
	_build()


func setup(race_context: Dictionary) -> void:
	context = race_context
	preview = false
	_on_setup()
	_refresh()


func enter_preview() -> void:
	preview = true
	_show_preview()


func _process(delta: float) -> void:
	if preview or context.is_empty() or not is_visible_in_tree():
		return
	_timer -= delta
	if _timer <= 0.0:
		_timer = update_interval
		_refresh()


# --- Metody do nadpisania ---------------------------------

func _build() -> void:
	pass


func _on_setup() -> void:
	pass


func _refresh() -> void:
	pass


func _show_preview() -> void:
	pass


# --- Układ ------------------------------------------------

func get_scaled_size() -> Vector2:
	return base_size * layout_scale


func apply_layout(anchor: Vector2, module_scale: float, viewport_size: Vector2) -> void:
	layout_scale = clampf(module_scale, 0.5, 1.8)
	scale = Vector2(layout_scale, layout_scale)
	size = base_size
	var scaled: Vector2 = get_scaled_size()
	var target: Vector2 = anchor * viewport_size - pivot * scaled
	target.x = clampf(target.x, 0.0, maxf(viewport_size.x - scaled.x, 0.0))
	target.y = clampf(target.y, 0.0, maxf(viewport_size.y - scaled.y, 0.0))
	position = target
	layout_anchor = (position + pivot * scaled) / viewport_size


func get_screen_rect() -> Rect2:
	return Rect2(position, get_scaled_size())


func get_layout_entry() -> Dictionary:
	return {"x": layout_anchor.x, "y": layout_anchor.y, "scale": layout_scale, "visible": not hidden_by_user}
