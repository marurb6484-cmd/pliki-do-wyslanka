extends Control
## Menu pauzy: wznów, restart, powrót na trasę, edycja HUD, szybkie
## ustawienia grafiki i sterowania, wyjście do menu.

var hud: Node
var _quality_button: Button
var _fps_button: Button
var _control_button: Button
var _sensitivity_slider: HSlider
var _sensitivity_label: Label
var _restart_button: Button
var _reset_button: Button


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP

	var dim := ColorRect.new()
	dim.color = Color(0.01, 0.02, 0.04, 0.72)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(dim)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)

	var panel := UIKit.make_card(UIKit.COLOR_ACCENT, 30.0)
	panel.custom_minimum_size = Vector2(1300, 0)
	center.add_child(panel)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 14)
	panel.add_child(column)
	column.add_child(UIKit.make_label("PAUZA", 64, UIKit.COLOR_ACCENT, HORIZONTAL_ALIGNMENT_CENTER))

	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 16)
	grid.add_theme_constant_override("v_separation", 14)
	column.add_child(grid)

	var resume := UIKit.make_button("▶  WZNÓW", 38, 100, "primary")
	resume.pressed.connect(func() -> void: hud.call("close_pause"))
	grid.add_child(resume)
	_restart_button = UIKit.make_button("⟲  RESTART", 34, 100, "ghost")
	_restart_button.pressed.connect(_on_restart)
	grid.add_child(_restart_button)
	_reset_button = UIKit.make_button("WRÓĆ NA TRASĘ", 34, 100, "ghost")
	_reset_button.pressed.connect(_on_reset_to_track)
	grid.add_child(_reset_button)
	var edit_hud := UIKit.make_button("EDYTUJ HUD", 34, 100, "ghost")
	edit_hud.pressed.connect(func() -> void: hud.call("open_editor"))
	grid.add_child(edit_hud)

	_quality_button = UIKit.make_button("", 30, 90)
	_quality_button.pressed.connect(_on_quality)
	grid.add_child(_quality_button)
	_fps_button = UIKit.make_button("", 30, 90)
	_fps_button.pressed.connect(_on_fps)
	grid.add_child(_fps_button)
	_control_button = UIKit.make_button("", 30, 90)
	_control_button.pressed.connect(_on_control_mode)
	grid.add_child(_control_button)

	var sensitivity_box := HBoxContainer.new()
	_sensitivity_label = UIKit.make_label("", 28)
	_sensitivity_label.custom_minimum_size.x = 260
	sensitivity_box.add_child(_sensitivity_label)
	_sensitivity_slider = UIKit.make_slider(0.4, 2.0, 0.05, GameSettings.steering_sensitivity)
	_sensitivity_slider.value_changed.connect(_on_sensitivity)
	sensitivity_box.add_child(_sensitivity_slider)
	grid.add_child(sensitivity_box)

	var menu := UIKit.make_button("MENU GŁÓWNE", 34, 100, "danger")
	menu.pressed.connect(func() -> void: _call_scene("quit_to_menu"))
	column.add_child(menu)


func setup(target_hud: Node) -> void:
	hud = target_hud


func open() -> void:
	visible = true
	var race: RaceManager = hud.get("context").get("race_manager") as RaceManager
	_reset_button.disabled = race == null or not race.is_running()
	_restart_button.text = "⟲  NOWY TEST" if GameManager.is_graphics_test() else "⟲  RESTART"
	_refresh()


func _refresh() -> void:
	_quality_button.text = "GRAFIKA: %s" % GameSettings.QUALITY_NAMES[GameSettings.quality]
	_fps_button.text = "LIMIT FPS: %s" % ("BEZ LIMITU" if GameSettings.fps_limit == 0 else str(GameSettings.fps_limit))
	_control_button.text = "STEROWANIE: %s" % GameSettings.CONTROL_NAMES[GameSettings.control_mode]
	_sensitivity_label.text = "Czułość %.2f" % GameSettings.steering_sensitivity


func _on_quality() -> void:
	GameSettings.set_quality_preset((GameSettings.quality + 1) % 4)
	_refresh()


func _on_fps() -> void:
	var options: Array[int] = GameSettings.FPS_OPTIONS
	var index: int = options.find(GameSettings.fps_limit)
	GameSettings.set_fps_limit(options[(index + 1) % options.size()])
	_refresh()


func _on_control_mode() -> void:
	GameSettings.set_control_mode((GameSettings.control_mode + 1) % 3)
	_refresh()


func _on_sensitivity(value: float) -> void:
	GameSettings.set_steering_sensitivity(value)
	_sensitivity_label.text = "Czułość %.2f" % value


func _on_restart() -> void:
	_call_scene("restart_race")


func _on_reset_to_track() -> void:
	var race: RaceManager = hud.get("context").get("race_manager") as RaceManager
	if race != null:
		race.reset_player_to_track()
	hud.call("close_pause")


func _call_scene(method: String) -> void:
	get_tree().paused = false
	var scene: Node = hud.get("race_scene")
	if scene != null:
		scene.call(method)
	else:
		GameManager.go_to_main_menu()
