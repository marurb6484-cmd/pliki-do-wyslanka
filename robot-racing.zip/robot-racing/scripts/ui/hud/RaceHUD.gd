extends CanvasLayer
## RaceHUD - kontener i menedżer układu modułów HUD.
##
## Nie zawiera logiki wyświetlania danych (to robią moduły). Odpowiada za:
##  - przekazanie kontekstu wyścigu modułom,
##  - zastosowanie zapisanego układu (osobno dla każdej proporcji ekranu),
##  - pauzę, ekran wyników, edytor HUD, panel testu grafiki, licznik FPS.

@onready var root: Control = $Root
@onready var navigation: Control = $Root/Modules/NavigationHUD
@onready var messages: Control = $Root/RaceMessagesHUD
@onready var touch: Control = $Root/TouchControls
@onready var pause_button: Button = $Root/PauseButton
@onready var next_music_button: Button = $Root/NextMusicButton
@onready var reset_button: Button = $Root/ResetPositionButton
@onready var camera_button: Button = $Root/CameraModeButton
@onready var fps_label: Label = $Root/FPSLabel
@onready var pause_menu: Control = $Root/PauseMenu
@onready var results: Control = $Root/RaceResultsHUD
@onready var editor: Control = $Root/HUDEditor
@onready var test_panel: Control = $Root/GraphicsTestPanel

var modules: Array[HUDModule] = []
var context: Dictionary = {}
var preview_mode: bool = false
var race_scene: Node

var _fps_timer: float = 0.0
var _reset_hold_time: float = 0.0
var _reset_is_held: bool = false
var _reset_completed: bool = false
var _reset_countdown_label: Label
var _online_room_label: Label
var _online_room_refresh: float = 0.0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = 5

	for node: Node in root.find_children("*", "Control", true, false):
		if node is HUDModule:
			modules.append(node as HUDModule)

	pause_button.pressed.connect(open_pause)
	next_music_button.text = "♫ MUZYKA"
	next_music_button.tooltip_text = "Następny utwór lub otwarcie ustawień muzyki"
	next_music_button.pressed.connect(func() -> void:
		if MusicManager.has_tracks():
			MusicManager.next_track()
		else:
			GameManager.open_settings(GameManager.SCENE_MAIN_MENU)
	)
	next_music_button.visible = true
	camera_button.pressed.connect(_on_camera_mode_pressed)
	reset_button.button_down.connect(_on_reset_button_down)
	reset_button.button_up.connect(_on_reset_button_up)
	reset_button.focus_mode = Control.FOCUS_NONE
	pause_button.focus_mode = Control.FOCUS_NONE
	for hud_button: Button in [pause_button, reset_button, next_music_button, camera_button]:
		hud_button.theme_type_variation = "ButtonGhost"
	var blockers: Array[Control] = [pause_button, reset_button, next_music_button, camera_button, test_panel]
	var boost_module: Node = $Root/Modules/BoostHUD
	if boost_module.has_method("get_interaction_controls"):
		for control: Control in boost_module.call("get_interaction_controls"):
			blockers.append(control)
	touch.set("blockers", blockers)

	pause_menu.visible = false
	results.visible = false
	editor.visible = false
	test_panel.visible = false

	get_viewport().size_changed.connect(apply_layout)
	GameSettings.hud_layout_changed.connect(apply_layout)
	GameSettings.graphics_changed.connect(_update_fps_visibility)
	_update_fps_visibility()
	apply_layout()


func setup(race_context: Dictionary) -> void:
	context = race_context
	race_scene = context.get("scene")

	var screen_fx := BoostScreenFX.new()
	screen_fx.name = "BoostScreenFX"
	root.add_child(screen_fx)
	root.move_child(screen_fx, 0)
	screen_fx.setup(context.get("player") as Robot)

	navigation.call("setup", context)
	for module: HUDModule in modules:
		module.setup(context)
	messages.call("setup", context)
	touch.call("setup", context)
	reset_button.visible = str(context.get("mode", "")) != "graphics_test"
	reset_button.disabled = true
	pause_menu.call("setup", self)
	results.call("setup", self)
	_reset_countdown_label = UIKit.make_label("", 42, UIKit.COLOR_ACCENT, HORIZONTAL_ALIGNMENT_CENTER)
	_reset_countdown_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	_reset_countdown_label.position = Vector2(-260.0, 92.0)
	_reset_countdown_label.custom_minimum_size = Vector2(520.0, 70.0)
	_reset_countdown_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_reset_countdown_label.visible = false
	root.add_child(_reset_countdown_label)

	_online_room_label = UIKit.make_label("POKÓJ ONLINE", 24, UIKit.COLOR_ACCENT, HORIZONTAL_ALIGNMENT_LEFT, false)
	_online_room_label.custom_minimum_size = Vector2(430.0, 52.0)
	_online_room_label.add_theme_color_override("font_color", Color(0.45, 1.0, 0.72))
	_online_room_label.add_theme_color_override("font_outline_color", Color(0.0, 0.0, 0.0, 0.95))
	_online_room_label.add_theme_constant_override("outline_size", 5)
	_online_room_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_online_room_label.visible = GameManager.online_race_active and CloudflareOnlineSession.connected
	root.add_child(_online_room_label)
	_update_online_room_label()

	if str(context.get("mode", "")) == "graphics_test":
		test_panel.visible = true
		test_panel.call("setup", self)

	var race: RaceManager = context.get("race_manager") as RaceManager
	if race != null:
		race.racer_finished.connect(_on_racer_finished)
		race.reset_lock_changed.connect(_on_reset_lock_changed)


## Tryb podglądu (edytor HUD uruchomiony z menu, bez wyścigu).
func enter_preview() -> void:
	preview_mode = true
	for module: HUDModule in modules:
		module.enter_preview()
	navigation.call("enter_preview")
	touch.call("enter_preview")
	pause_button.visible = false
	reset_button.visible = false
	camera_button.visible = false
	fps_label.visible = false


func _on_camera_mode_pressed() -> void:
	if race_scene != null and race_scene.has_method("cycle_camera_mode"):
		race_scene.call("cycle_camera_mode")
		if race_scene.has_method("get_camera_mode_name"):
			camera_button.text = "KAMERA: %s" % str(race_scene.call("get_camera_mode_name"))


func _on_racer_finished(racer: Dictionary) -> void:
	if bool(racer["is_player"]):
		# Po mecie gracz nie steruje - robot jedzie na autopilocie.
		touch.visible = false
		reset_button.visible = false


# =========================================================
# UKŁAD
# =========================================================

func get_viewport_size() -> Vector2:
	return root.get_viewport_rect().size


func get_bucket() -> String:
	return GameSettings.get_aspect_bucket(get_viewport_size())


func apply_layout() -> void:
	apply_layout_dict(GameSettings.get_hud_layout(get_bucket()))


func apply_layout_dict(layout: Dictionary) -> void:
	var viewport_size: Vector2 = get_viewport_size()
	for module: HUDModule in modules:
		var entry: Dictionary = layout.get(module.module_id, {}) if layout.get(module.module_id, {}) is Dictionary else {}
		var anchor := Vector2(float(entry.get("x", module.default_anchor.x)), float(entry.get("y", module.default_anchor.y)))
		var module_scale: float = float(entry.get("scale", module.default_scale))
		module.hidden_by_user = module.can_hide and not bool(entry.get("visible", true))
		module.apply_layout(anchor, module_scale, viewport_size)
		module.visible = not module.hidden_by_user or editor.visible
		if not module.module_id.begins_with("touch_"):
			module.modulate.a = GameSettings.hud_opacity
	touch.call("relayout")
	pause_button.position = Vector2(viewport_size.x - pause_button.size.x - 24.0, 18.0)
	reset_button.position = Vector2(pause_button.position.x - reset_button.size.x - 14.0, 18.0)
	camera_button.position = Vector2(reset_button.position.x - camera_button.size.x - 14.0, 18.0)
	if _online_room_label != null:
		_online_room_label.position = Vector2(24.0, 122.0)
		_online_room_label.size = Vector2(520.0, 58.0)
	camera_button.size = Vector2(240.0, 96.0)
	# Przycisk muzyki po przeciwnej stronie ekranu niż RESET i PAUZA.
	next_music_button.position = Vector2(24.0, 18.0)
	next_music_button.size = Vector2(250.0, 96.0)


func collect_layout() -> Dictionary:
	var layout: Dictionary = {}
	for module: HUDModule in modules:
		layout[module.module_id] = module.get_layout_entry()
	return layout


# =========================================================
# PAUZA, WYNIKI, EDYTOR
# =========================================================

func open_pause() -> void:
	if preview_mode or results.visible or editor.visible or pause_menu.visible:
		return
	get_tree().paused = true
	touch.call("set_input_enabled", false)
	pause_menu.call("open")


func close_pause() -> void:
	pause_menu.visible = false
	get_tree().paused = false
	touch.call("set_input_enabled", true)


func handle_back() -> void:
	if editor.visible:
		editor.call("cancel")
	elif pause_menu.visible:
		close_pause()
	elif results.visible:
		if race_scene != null:
			race_scene.call("quit_to_menu")
	elif preview_mode:
		GameManager.go_back()
	else:
		open_pause()


func show_results(race_results: Array, rewards: Dictionary, records: Dictionary) -> void:
	touch.visible = false
	pause_button.visible = false
	reset_button.visible = false
	pause_menu.visible = false
	get_tree().paused = false
	var benchmark: Dictionary = {}
	if test_panel.visible:
		benchmark = test_panel.call("get_benchmark")
		test_panel.visible = false
	results.call("show_results", race_results, rewards, records, benchmark)


func open_editor() -> void:
	pause_menu.visible = false
	touch.call("set_input_enabled", false)
	editor.call("open", self)


func on_editor_closed() -> void:
	if preview_mode:
		GameManager.go_back()
		return
	apply_layout()
	pause_menu.call("open")


# =========================================================
# RESET POZYCJI — przytrzymanie 1,5 sekundy
# =========================================================

func _on_reset_lock_changed(seconds_left: int) -> void:
	if _reset_countdown_label == null:
		return
	if seconds_left <= 0:
		_reset_countdown_label.visible = false
		return
	_reset_countdown_label.text = "START ZA %d" % seconds_left
	_reset_countdown_label.visible = true


func _on_reset_button_down() -> void:
	if preview_mode or results.visible or pause_menu.visible or editor.visible:
		return
	_reset_hold_time = 0.0
	_reset_is_held = true
	_reset_completed = false


func _on_reset_button_up() -> void:
	_reset_is_held = false
	_reset_hold_time = 0.0
	_reset_completed = false
	reset_button.text = "RESET\nPRZYTRZYMAJ"


func _process_reset_hold(delta: float) -> void:
	var race: RaceManager = context.get("race_manager") as RaceManager
	var player: Robot = context.get("player") as Robot
	var pit_blocked: bool = player != null and (player.pit_controlled or player.drive_locked)
	reset_button.disabled = preview_mode or results.visible or pause_menu.visible or race == null or race.state != RaceManager.State.RUNNING or pit_blocked
	if reset_button.disabled and _reset_is_held:
		_on_reset_button_up()
		return
	if not _reset_is_held or _reset_completed or reset_button.disabled:
		return
	_reset_hold_time += delta
	var remaining: float = maxf(1.5 - _reset_hold_time, 0.0)
	reset_button.text = "TRZYMAJ\n%.1f s" % remaining
	if _reset_hold_time >= 1.5:
		_reset_completed = true
		_reset_is_held = false
		var success: bool = race.reset_player_to_track()
		reset_button.text = "RESET OK" if success else "NIE MOŻNA"


# =========================================================
# FPS
# =========================================================

func _update_fps_visibility() -> void:
	fps_label.visible = GameSettings.show_fps and not preview_mode


func _process(delta: float) -> void:
	_process_reset_hold(delta)
	if _online_room_label != null and _online_room_label.visible:
		_online_room_refresh -= delta
		if _online_room_refresh <= 0.0:
			_online_room_refresh = 0.5
			_update_online_room_label()
	if Input.is_action_just_pressed("pause") and not preview_mode:
		handle_back()

	if fps_label.visible:
		_fps_timer -= delta
		if _fps_timer <= 0.0:
			_fps_timer = 0.5
			fps_label.text = "%d FPS" % Engine.get_frames_per_second()


func _update_online_room_label() -> void:
	if _online_room_label == null:
		return
	var code := CloudflareOnlineSession.room_code
	var count := CloudflareOnlineSession.get_players().size()
	_online_room_label.visible = GameManager.online_race_active and CloudflareOnlineSession.connected and not code.is_empty()
	if _online_room_label.visible:
		_online_room_label.text = "POKÓJ: %s  •  GRACZE: %d/6" % [code, count]
