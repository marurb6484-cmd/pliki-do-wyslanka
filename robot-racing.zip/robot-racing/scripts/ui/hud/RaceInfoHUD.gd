extends HUDModule
## RaceInfoHUD - pozycja, okrążenie, czas wyścigu, czas okrążenia, rekordy, odstępy.

var _race: RaceManager
var _position_label: Label
var _lap_label: Label
var _time_label: Label
var _lap_time_label: Label
var _extra_label: Label
var _best_record: float = -1.0
var _last_texts: Array[String] = ["", "", "", "", ""]


func _build() -> void:
	var panel := UIKit.make_hud_panel()
	panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(panel)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 0)
	column.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(column)

	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 22)
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	column.add_child(top)

	_position_label = UIKit.make_label("1/5", 64, UIKit.COLOR_ACCENT)
	top.add_child(_position_label)
	_lap_label = UIKit.make_label("OKR 1/3", 36)
	_lap_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_lap_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	top.add_child(_lap_label)

	_time_label = UIKit.make_label("00:00.000", 40)
	column.add_child(_time_label)
	_lap_time_label = UIKit.make_label("Okr.: 00:00.0  Najl.: --", 26, UIKit.COLOR_MUTED)
	column.add_child(_lap_time_label)
	_extra_label = UIKit.make_label("", 24, UIKit.COLOR_MUTED)
	column.add_child(_extra_label)


func _on_setup() -> void:
	_race = context.get("race_manager") as RaceManager
	if _race == null:
		return
	var track: TrackBase = context.get("track") as TrackBase
	if track != null and _race.mode == "time_trial":
		var best: Dictionary = PlayerProgress.get_best(track.track_id, "time_trial", _race.total_laps)
		_best_record = float(best.get("best_lap", -1.0))


func _refresh() -> void:
	if _race == null:
		return
	var player: Dictionary = _race.player_state
	if player.is_empty():
		return

	var position_text: String = "%d/%d" % [_race.get_player_position(), _race.get_racer_count()]
	if _race.mode == "time_trial":
		position_text = "CZAS"
	elif _race.mode == "graphics_test":
		position_text = "TEST %d/%d" % [_race.get_player_position(), _race.get_racer_count()]

	var lap_text: String = "META TRASY" if _race.mode == "time_trial" else ("OKR %d" % _race.get_player_lap() if _race.total_laps <= 0 else "OKR %d/%d" % [_race.get_player_lap(), _race.total_laps])
	var time_text: String = UIKit.format_time(_race.race_time)
	var best_lap: float = float(player["best_lap"])
	var lap_line: String = "Przejazd: %s" % _format_short(_race.get_current_lap_time(player)) if _race.mode == "time_trial" else "Okr.: %s   Najl.: %s" % [_format_short(_race.get_current_lap_time(player)), _format_short(best_lap)]

	var extra: String = ""
	if _race.mode == "time_trial":
		extra = "Rekord tej trasy: %s" % _format_short(_best_record)
	elif _race.mode == "race":
		var gaps: Dictionary = _race.get_player_gaps()
		if float(gaps["ahead"]) >= 0.0:
			extra = "Przed: -%.1f s" % float(gaps["ahead"])
		if float(gaps["behind"]) >= 0.0:
			extra += ("   " if not extra.is_empty() else "") + "Za: +%.1f s" % float(gaps["behind"])

	_set_text(0, _position_label, position_text)
	_set_text(1, _lap_label, lap_text)
	_set_text(2, _time_label, time_text)
	_set_text(3, _lap_time_label, lap_line)
	_set_text(4, _extra_label, extra)


func _set_text(index: int, label: Label, text: String) -> void:
	if _last_texts[index] != text:
		_last_texts[index] = text
		label.text = text


func _format_short(value: float) -> String:
	if value <= 0.0:
		return "--"
	return "%d:%04.1f" % [int(value) / 60, fmod(value, 60.0)]


func _show_preview() -> void:
	_position_label.text = "2/5"
	_lap_label.text = "OKR 2/3"
	_time_label.text = "01:12.480"
	_lap_time_label.text = "Okr.: 0:23.4   Najl.: 0:31.9"
	_extra_label.text = "Przed: -1.2 s   Za: +0.8 s"
