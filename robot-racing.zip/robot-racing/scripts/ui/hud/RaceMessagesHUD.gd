extends Control
## Komunikaty na środku ekranu: odliczanie 5-4-3-2-1-START!, okrążenia,
## ostatnie okrążenie, jazda pod prąd, meta, brak brudu na boost.

var _race: RaceManager
var _big: Label
var _small: Label
var _wrong_way: Label
var _hide_timer: float = 0.0
var _checkpoint_label: Label
var _checkpoint_timer: float = 0.0


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	_big = UIKit.make_label("", 150, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	_big.anchor_left = 0.5
	_big.anchor_right = 0.5
	_big.anchor_top = 0.42
	_big.anchor_bottom = 0.42
	_big.offset_left = -600
	_big.offset_right = 600
	_big.offset_top = -110
	_big.offset_bottom = 110
	add_child(_big)

	_small = UIKit.make_label("", 48, UIKit.COLOR_ACCENT, HORIZONTAL_ALIGNMENT_CENTER)
	_small.anchor_left = 0.5
	_small.anchor_right = 0.5
	_small.anchor_top = 0.42
	_small.anchor_bottom = 0.42
	_small.offset_left = -700
	_small.offset_right = 700
	_small.offset_top = 110
	_small.offset_bottom = 180
	add_child(_small)

	_wrong_way = UIKit.make_label("⟲ ZŁY KIERUNEK", 64, UIKit.COLOR_BAD, HORIZONTAL_ALIGNMENT_CENTER)
	_wrong_way.anchor_left = 0.5
	_wrong_way.anchor_right = 0.5
	_wrong_way.anchor_top = 0.62
	_wrong_way.anchor_bottom = 0.62
	_wrong_way.offset_left = -500
	_wrong_way.offset_right = 500
	_wrong_way.offset_top = -50
	_wrong_way.offset_bottom = 50
	_wrong_way.visible = false
	add_child(_wrong_way)

	_checkpoint_label = UIKit.make_label("", 30, Color("#e9fcff"), HORIZONTAL_ALIGNMENT_LEFT)
	_checkpoint_label.anchor_left = 0.025
	_checkpoint_label.anchor_right = 0.34
	_checkpoint_label.anchor_top = 0.22
	_checkpoint_label.anchor_bottom = 0.22
	_checkpoint_label.offset_left = 0.0
	_checkpoint_label.offset_right = 0.0
	_checkpoint_label.offset_top = 0.0
	_checkpoint_label.offset_bottom = 88.0
	_checkpoint_label.add_theme_color_override("font_outline_color", Color(0.0, 0.02, 0.04, 1.0))
	_checkpoint_label.add_theme_constant_override("outline_size", 7)
	_checkpoint_label.add_theme_color_override("font_color", Color("#e9fcff"))
	var checkpoint_panel := StyleBoxFlat.new()
	checkpoint_panel.bg_color = Color(0.015, 0.08, 0.12, 0.94)
	checkpoint_panel.border_color = Color("#19e6ff")
	checkpoint_panel.set_border_width_all(3)
	checkpoint_panel.set_corner_radius_all(12)
	checkpoint_panel.content_margin_left = 16.0
	checkpoint_panel.content_margin_right = 12.0
	checkpoint_panel.content_margin_top = 8.0
	checkpoint_panel.content_margin_bottom = 8.0
	_checkpoint_label.add_theme_stylebox_override("normal", checkpoint_panel)
	_checkpoint_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_checkpoint_label.visible = false
	add_child(_checkpoint_label)
	set_process(false)


func setup(context: Dictionary) -> void:
	_race = context.get("race_manager") as RaceManager
	if _race == null:
		return
	_race.countdown_changed.connect(_on_countdown)
	_race.lap_completed.connect(_on_lap)
	_race.checkpoint_passed.connect(_on_checkpoint_passed)
	_race.racer_finished.connect(_on_finished)
	_race.wrong_way_changed.connect(func(wrong: bool) -> void: _wrong_way.visible = wrong)

	var player: Robot = context.get("player") as Robot
	if player != null:
		player.boost.boost_started.connect(func() -> void: show_message("", "BOOST!", 0.8))


func show_message(big_text: String, small_text: String, duration: float) -> void:
	_big.text = big_text
	_small.text = small_text
	_hide_timer = duration
	_big.scale = Vector2.ONE
	set_process(true)


func _process(delta: float) -> void:
	_hide_timer -= delta
	_checkpoint_timer -= delta
	if _checkpoint_timer <= 0.0 and _checkpoint_label.visible:
		_checkpoint_label.visible = false
	if _hide_timer <= 0.0:
		_big.text = ""
		_small.text = ""
	if _hide_timer <= 0.0 and _checkpoint_timer <= 0.0:
		set_process(false)


func _on_countdown(seconds: int) -> void:
	if seconds > 0:
		show_message(str(seconds), "PRZYGOTUJ SIĘ", 1.1)
	else:
		show_message("START!", "", 1.0)


func _on_lap(racer: Dictionary, lap: int, lap_time: float) -> void:
	if not bool(racer["is_player"]) or bool(racer["finished"]):
		return
	var text: String = "OKRĄŻENIE %d" % (lap + 1)
	if _race.total_laps > 0 and lap + 1 == _race.total_laps:
		text = "OSTATNIE OKRĄŻENIE!"
	show_message("", "%s   (%s)" % [text, UIKit.format_time(lap_time)], 2.2)


func _on_finished(racer: Dictionary) -> void:
	if bool(racer["is_player"]):
		show_message("META!", "Pozycja %d" % int(racer["position"]) if _race.mode == "race" else "Czas: %s" % UIKit.format_time(float(racer["finish_time"])), 3.0)


func _on_checkpoint_passed(racer: Dictionary, checkpoint_index: int, split_time: float, elapsed_time: float) -> void:
	if not bool(racer.get("is_player", false)):
		return
	var checkpoint_name: String = "META" if not _race.track.route_closed and checkpoint_index == 4 else "CP%d" % checkpoint_index
	_checkpoint_label.text = "CHECKPOINT  %s\nSPLIT  +%s   •   ŁĄCZNIE  %s" % [checkpoint_name, UIKit.format_time(split_time), UIKit.format_time(elapsed_time)]
	_checkpoint_label.visible = true
	_checkpoint_timer = 2.4
	set_process(true)
	# Checkpoint nie zasłania środka ekranu ani widoku drogi.
	_big.text = ""
	_small.text = ""
