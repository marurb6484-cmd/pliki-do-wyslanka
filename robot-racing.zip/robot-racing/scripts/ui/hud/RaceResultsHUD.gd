extends Control

const CareerStoryPanelScript = preload("res://scripts/ui/menus/CareerStoryPanel.gd")
## RaceResultsHUD - ekran wyników (zastępuje osobną scenę RaceResults.tscn,
## zachowując jej funkcje: tabela wyników, PONÓW, MENU GŁÓWNE).
## Dodatkowo: nagrody, rekordy, czasy okrążeń, wyniki testu grafiki.

var hud: Node
var _title: Label
var _table: GridContainer
var _side: VBoxContainer
var _garage_button: Button
var _retry_button: Button
var _rating_selected: int = 5
var _rating_row: HBoxContainer


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP

	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.03, 0.05, 0.78)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(dim)

	var margin := UIKit.make_screen_margin(self, 50)
	var panel := UIKit.make_card(UIKit.COLOR_ACCENT, 28.0)
	margin.add_child(panel)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 18)
	panel.add_child(column)

	_title = UIKit.make_label("WYNIKI WYŚCIGU", 60, UIKit.COLOR_ACCENT, HORIZONTAL_ALIGNMENT_CENTER)
	column.add_child(_title)

	var body := HBoxContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 40)
	column.add_child(body)

	var scroll := ScrollContainer.new()
	UIKit.configure_touch_scroll(scroll)
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_stretch_ratio = 1.6
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	body.add_child(scroll)
	_table = GridContainer.new()
	_table.columns = 5
	_table.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_table.add_theme_constant_override("h_separation", 26)
	_table.add_theme_constant_override("v_separation", 10)
	scroll.add_child(_table)

	var side_scroll := ScrollContainer.new()
	UIKit.configure_touch_scroll(side_scroll)
	side_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	side_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	body.add_child(side_scroll)
	_side = VBoxContainer.new()
	_side.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_side.add_theme_constant_override("separation", 8)
	side_scroll.add_child(_side)

	var buttons := HBoxContainer.new()
	buttons.add_theme_constant_override("separation", 20)
	column.add_child(buttons)
	_retry_button = UIKit.make_button("⟲  PONÓW", 38, 110, "primary")
	_retry_button.pressed.connect(func() -> void: _call_scene("restart_race"))
	buttons.add_child(_retry_button)
	_garage_button = UIKit.make_button("GARAŻ", 38, 110, "ghost")
	_garage_button.pressed.connect(func() -> void: _call_scene("quit_to_garage"))
	buttons.add_child(_garage_button)
	var menu := UIKit.make_button("MENU GŁÓWNE", 38, 110, "ghost")
	menu.pressed.connect(func() -> void: _call_scene("quit_to_menu"))
	buttons.add_child(menu)


func setup(target_hud: Node) -> void:
	hud = target_hud


func show_results(results: Array, rewards: Dictionary, records: Dictionary, benchmark: Dictionary) -> void:
	visible = true
	var mode: String = GameManager.get_mode_id()
	for child: Node in _table.get_children():
		child.queue_free()
	for child: Node in _side.get_children():
		child.queue_free()

	match mode:
		"time_trial":
			_title.text = "JAZDA NA CZAS - WYNIK"
			_retry_button.text = "⟲  NOWA PRÓBA"
			_fill_time_trial(results)
		"graphics_test":
			_title.text = "TEST GRAFIKI ZAKOŃCZONY"
			_retry_button.text = "⟲  NOWY TEST"
			_garage_button.visible = false
			_fill_race_table(results)
		_:
			_title.text = "WYNIKI WYŚCIGU"
			_fill_race_table(results)

	if mode == "graphics_test":
		_add_side("WYDAJNOŚĆ", 38, UIKit.COLOR_ACCENT)
		for key: String in benchmark.keys():
			_add_side("%s: %s" % [key, str(benchmark[key])], 28)
		_add_side("Brak nagród i zapisu wyników w trybie testu.", 26, UIKit.COLOR_MUTED)
		return

	if bool(records.get("new_total", false)):
		_add_side("★ NOWY REKORD CZASU!", 36, UIKit.COLOR_GOOD)
	if bool(records.get("new_lap", false)):
		_add_side("★ NOWE NAJLEPSZE OKRĄŻENIE!", 32, UIKit.COLOR_GOOD)

	_add_side("NAGRODY", 38, UIKit.COLOR_ACCENT)
	var items: Array = rewards.get("items", [])
	if items.is_empty():
		_add_side("Brak nagród", 28, UIKit.COLOR_MUTED)
	for item: Dictionary in items:
		_add_side("%s:  +%d CR" % [str(item["label"]), int(item["amount"])], 30)
	_add_side("RAZEM:  +%d CR" % int(rewards.get("total", 0)), 36, UIKit.COLOR_GOOD)
	_add_side("Saldo: %d CR" % PlayerProgress.currency, 30, UIKit.COLOR_MUTED)

	if GameManager.career_active and GameManager.career_result_event_index >= 0:
		_add_side("ROZDZIAŁ KAMPANII", 34, UIKit.COLOR_ACCENT)
		var story := CareerStoryPanelScript.new()
		story.configure(GameManager.career_result_event_index, "after", GameManager.career_result_advanced)
		story.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		story.sequence_finished.connect(func() -> void: _call_scene("continue_career"))
		_side.add_child(story)

	var player: Robot = hud.get("context").get("player") as Robot
	if player != null:
		var damage: float = player.damage.damage
		_add_side("Uszkodzenia robota: %d%%" % int(damage), 28, DamageSystem.STAGE_COLORS[player.damage.get_stage()])
		if damage >= 25.0:
			_add_side("Napraw robota w garażu.", 26, UIKit.COLOR_MUTED)

	var race_stats: Dictionary = hud.get_meta("race_statistics_summary", {}) if hud.has_meta("race_statistics_summary") else {}
	if not race_stats.is_empty():
		_add_side("STATYSTYKI PIT STOPÓW", 34, UIKit.COLOR_ACCENT)
		_add_side("Łączne zużycie baterii: %.1f%%" % float(race_stats.get("total_energy_used", 0.0)), 26)
		_add_side("Zużycie przez boost: %.1f%%" % float(race_stats.get("boost_energy_used", 0.0)), 26)
		var lap_usage: Array = race_stats.get("lap_energy", [])
		for i: int in range(lap_usage.size()):
			_add_side("Okrążenie %d — %.1f%% baterii" % [i + 1, float(lap_usage[i])], 24)
		_add_side("Postoje: %d" % int(race_stats.get("pit_visits", 0)), 26)
		_add_side("Czas w pit stopie: %s" % UIKit.format_time(float(race_stats.get("pit_time", 0.0))), 26)
		_add_side("Naprawiono uszkodzeń: %.1f%%" % float(race_stats.get("repairs_done", 0.0)), 26)

	var current_track_data: Dictionary = GameManager.get_track_data()
	if bool(current_track_data.get("generated", false)):
		_add_side("TA TRASA JEST LOSOWA — MOŻESZ JĄ ZACHOWAĆ", 30, UIKit.COLOR_ACCENT)
		var download_button := UIKit.make_button("POBIERZ TRASĘ DO MOICH TRAS", 32, 76)
		download_button.pressed.connect(_save_current_track.bind(current_track_data, download_button))
		_side.add_child(download_button)
		var rating_button := UIKit.make_button("OCEŃ TRASĘ", 32, 76)
		rating_button.pressed.connect(_show_rating_controls.bind(current_track_data))
		_side.add_child(rating_button)
		var rating: Dictionary = TrackLibrary.get_rating(str(current_track_data.get("id", "")))
		if int(rating.get("count", 0)) > 0:
			_add_side("Średnia ocena zapisana lokalnie: %.1f/5 (%d ocen)" % [float(rating.get("average", 0.0)), int(rating.get("count", 0))], 24, UIKit.COLOR_MUTED)


func _save_current_track(track_data: Dictionary, button: Button) -> void:
	if TrackLibrary.save_track(track_data):
		button.text = "✓ TRASA ZAPISANA W MOICH TRASACH"
		button.disabled = true
	else:
		button.text = "NIE UDAŁO SIĘ ZAPISAĆ — SPRÓBUJ PONOWNIE"


func _show_rating_controls(track_data: Dictionary) -> void:
	if _rating_row != null and is_instance_valid(_rating_row):
		_rating_row.queue_free()
	_rating_row = HBoxContainer.new()
	_rating_row.add_theme_constant_override("separation", 8)
	_side.add_child(_rating_row)
	_rating_selected = 5
	for score: int in range(1, 6):
		var score_button := UIKit.make_button("★ %d" % score, 26, 64)
		score_button.toggle_mode = true
		score_button.button_pressed = score == _rating_selected
		score_button.pressed.connect(_set_rating.bind(score))
		_rating_row.add_child(score_button)
	var submit := UIKit.make_button("ZAPISZ OCENĘ", 28, 68)
	submit.pressed.connect(_submit_track_rating.bind(track_data))
	_rating_row.add_child(submit)


func _set_rating(score: int) -> void:
	_rating_selected = clampi(score, 1, 5)
	if _rating_row == null:
		return
	for i: int in range(_rating_row.get_child_count()):
		var button: Button = _rating_row.get_child(i) as Button
		button.set_pressed_no_signal(i + 1 == _rating_selected)


func _submit_track_rating(track_data: Dictionary) -> void:
	var track_id: String = str(track_data.get("id", ""))
	if TrackLibrary.rate_track(track_id, _rating_selected):
		var rating: Dictionary = TrackLibrary.get_rating(track_id)
		_add_side("Dziękujemy za ocenę! Średnia lokalna: %.1f/5 (%d ocen)" % [float(rating.get("average", 0.0)), int(rating.get("count", 0))], 26, UIKit.COLOR_GOOD)



func _fill_race_table(results: Array) -> void:
	_table.columns = 5
	for header: String in ["POZ.", "ZAWODNIK", "CZAS", "NAJL. OKR.", "STATUS"]:
		_add_cell(header, 28, UIKit.COLOR_ACCENT)
	for result: Dictionary in results:
		var color: Color = UIKit.COLOR_GOOD if bool(result["is_player"]) else UIKit.COLOR_TEXT
		_add_cell(str(result["position"]), 32, color)
		_add_cell(str(result["name"]), 30, color)
		var time_text: String = UIKit.format_time(float(result["time"]))
		if bool(result.get("estimated", false)):
			time_text = "~" + time_text
		_add_cell(time_text if float(result["time"]) > 0.0 else "--", 30, color)
		_add_cell(UIKit.format_time(float(result["best_lap"])) if float(result["best_lap"]) > 0.0 else "--", 30, color)
		_add_cell("META" if bool(result["finished"]) else "NIE UKOŃCZYŁ", 26, color if bool(result["finished"]) else UIKit.COLOR_MUTED)


func _fill_time_trial(results: Array) -> void:
	_table.columns = 4
	for header: String in ["POZ.", "ZAWODNIK", "CZAS", "STATUS"]:
		_add_cell(header, 28, UIKit.COLOR_ACCENT)
	for result: Dictionary in results:
		var color: Color = UIKit.COLOR_GOOD if bool(result.get("is_player", false)) else UIKit.COLOR_TEXT
		_add_cell(str(result.get("position", "-")), 32, color)
		_add_cell(str(result.get("name", "Zawodnik")), 30, color)
		var time_value: float = float(result.get("time", -1.0))
		var time_text: String = UIKit.format_time(time_value) if time_value > 0.0 else "--"
		_add_cell(time_text, 30, color)
		_add_cell("META" if bool(result.get("finished", false)) else "NIE UKOŃCZYŁ", 26, color if bool(result.get("finished", false)) else UIKit.COLOR_MUTED)
	var track_data: Dictionary = GameManager.get_track_data()
	_add_side("OTWARTY ODCINEK — BEZ OKRĄŻEŃ", 30, UIKit.COLOR_ACCENT)
	if bool(track_data.get("generated", false)):
		_add_side("Seed trasy: %s" % str(track_data.get("seed", "-")), 24, UIKit.COLOR_MUTED)


func _add_cell(text: String, font_size: int, color: Color) -> void:
	var label := UIKit.make_label(text, font_size, color, HORIZONTAL_ALIGNMENT_LEFT, false)
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_table.add_child(label)


func _add_side(text: String, font_size: int, color: Color = UIKit.COLOR_TEXT) -> void:
	var label := UIKit.make_label(text, font_size, color, HORIZONTAL_ALIGNMENT_LEFT, false)
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_side.add_child(label)


func _call_scene(method: String) -> void:
	get_tree().paused = false
	var scene: Node = hud.get("race_scene")
	if scene != null:
		scene.call(method)
	else:
		GameManager.go_to_main_menu()
