extends Control
## Sterowanie dotykowe (zachowuje interfejs poprzedniej wersji: steer,
## gas_pressed, brake_pressed, sygnał boost_pressed, grupa "touch_controls").
##
## Tryby (GameSettings.control_mode):
##  - JOYSTICK  - pływający joystick w lewej strefie,
##  - PRZYCISKI - przyciski ◀ ▶ z płynnym narastaniem skrętu,
##  - ŻYROSKOP  - przechylanie telefonu (+ kalibracja, odwrócenie).
## Prawa strefa: GAZ, HAMULEC (przytrzymany po zatrzymaniu = cofanie), BOOST.
## Wielodotyk: można jednocześnie skręcać, przyspieszać i używać boosta.
## Obie strefy to moduły HUD - można je przesuwać i skalować w edytorze HUD.

signal boost_pressed

const JOY_DEADZONE: float = 0.1
const MOUSE_POINTER: int = 100

var steer: float = 0.0
var gas_pressed: bool = false
var brake_pressed: bool = false
var drift_pressed: bool = false
var boost_active: bool = false
var boost_cooldown_ratio: float = 0.0

var input_enabled: bool = true
## Kontrolki, nad którymi dotyk nie steruje robotem (np. przycisk pauzy).
var blockers: Array[Control] = []

@onready var left_zone: HUDModule = $TouchZoneLeft
@onready var right_zone: HUDModule = $TouchZoneRight

var _mode: int = 0
var _use_mouse: bool = false
var _player: Robot
var _preview: bool = false

var _left_rect: Rect2
var _right_rect: Rect2
var _joy_default: Vector2
var _joy_origin: Vector2
var _joy_radius: float = 120.0
var _joy_vec: Vector2 = Vector2.ZERO
var _joy_pointer: int = -1
var _btn_left: Rect2
var _btn_right: Rect2
var _btn_calibrate: Rect2
var _gas_center: Vector2
var _gas_radius: float = 110.0
var _brake_center: Vector2
var _brake_radius: float = 85.0
var _boost_center: Vector2
var _boost_radius: float = 80.0

var _pointers: Dictionary = {}
var _boost_state: int = BoostSystem.State.NOT_ENOUGH_DIRT
var _redraw_timer: float = 0.0
var _calibrate_flash: float = 0.0


func _ready() -> void:
	add_to_group("touch_controls")
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_use_mouse = not DisplayServer.is_touchscreen_available()
	GameSettings.controls_changed.connect(_on_controls_changed)
	resized.connect(relayout)
	_on_controls_changed()


func setup(context: Dictionary) -> void:
	_player = context.get("player") as Robot


func enter_preview() -> void:
	_preview = true
	input_enabled = false
	_boost_state = BoostSystem.State.READY
	queue_redraw()


func _on_controls_changed() -> void:
	_mode = GameSettings.control_mode
	_release_all()
	relayout()


## Przelicza położenie elementów na podstawie stref (po zmianie układu HUD).
func relayout() -> void:
	if left_zone == null or right_zone == null:
		return
	_left_rect = left_zone.get_screen_rect()
	_right_rect = right_zone.get_screen_rect()

	var s: float = _right_rect.size.y
	_gas_radius = 0.26 * s
	_gas_center = _right_rect.end - Vector2(_gas_radius + 0.04 * s, _gas_radius + 0.04 * s)
	_brake_radius = 0.19 * s
	_brake_center = Vector2(_gas_center.x - _gas_radius - _brake_radius - 0.06 * s, _right_rect.end.y - _brake_radius - 0.06 * s)
	_boost_radius = 0.18 * s
	_boost_center = Vector2(_gas_center.x - 0.05 * s, _gas_center.y - _gas_radius - _boost_radius - 0.08 * s)

	var l: Rect2 = _left_rect
	_joy_radius = 0.3 * l.size.y
	_joy_default = Vector2(l.position.x + 0.38 * l.size.x, l.end.y - 0.45 * l.size.y)
	if _joy_pointer == -1:
		_joy_origin = _joy_default

	var button_size := Vector2(l.size.x * 0.44, l.size.y * 0.55)
	_btn_left = Rect2(Vector2(l.position.x + l.size.x * 0.03, l.end.y - button_size.y - l.size.y * 0.05), button_size)
	_btn_right = Rect2(Vector2(l.position.x + l.size.x * 0.53, l.end.y - button_size.y - l.size.y * 0.05), button_size)
	_btn_calibrate = Rect2(Vector2(l.position.x + l.size.x * 0.15, l.end.y - l.size.y * 0.3), Vector2(l.size.x * 0.7, l.size.y * 0.24))
	queue_redraw()


# =========================================================
# AKTUALIZACJA
# =========================================================

func _process(delta: float) -> void:
	if _preview:
		return

	var sensitivity: float = GameSettings.steering_sensitivity

	match _mode:
		GameSettings.ControlMode.BUTTONS:
			var roles: Array = _pointers.values()
			var target: float = (1.0 if roles.has("right") else 0.0) - (1.0 if roles.has("left") else 0.0)
			var rate: float = 7.0 if target == 0.0 else 3.2 * sensitivity
			if target != 0.0 and signf(target) != signf(steer) and steer != 0.0:
				rate = 9.0   # szybki powrót przy zmianie kierunku
			steer = move_toward(steer, target, rate * delta)
		GameSettings.ControlMode.GYRO:
			var tilt: float = GameSettings.read_raw_tilt() - GameSettings.gyro_neutral
			if GameSettings.gyro_invert:
				tilt = -tilt
			var normalized: float = tilt / maxf(sin(deg_to_rad(GameSettings.gyro_max_tilt)), 0.05)
			if absf(normalized) < 0.06:
				normalized = 0.0
			var wanted: float = clampf(normalized * sensitivity, -1.0, 1.0)
			steer = lerpf(steer, wanted, 1.0 - exp(-14.0 * delta))

	if _player != null and is_instance_valid(_player):
		var state: int = _player.boost.get_state()
		boost_active = state == BoostSystem.State.ACTIVE
		boost_cooldown_ratio = _player.boost.get_cooldown_ratio()
		if state != _boost_state:
			_boost_state = state
			queue_redraw()

	_calibrate_flash = maxf(_calibrate_flash - delta, 0.0)

	# Przerysowanie ~30 razy na sekundę zamiast co klatkę.
	_redraw_timer -= delta
	if _redraw_timer <= 0.0:
		_redraw_timer = 0.033
		queue_redraw()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_APPLICATION_PAUSED:
		_release_all()


func set_input_enabled(enabled: bool) -> void:
	input_enabled = enabled
	if not enabled:
		_release_all()


# =========================================================
# WEJŚCIE
# =========================================================

func _input(event: InputEvent) -> void:
	if not input_enabled or not is_visible_in_tree() or get_tree().paused:
		return

	var touch := event as InputEventScreenTouch
	if touch != null:
		if touch.pressed and not touch.canceled:
			_press(touch.index, touch.position)
		else:
			_release(touch.index)
		return

	var drag := event as InputEventScreenDrag
	if drag != null:
		_move(drag.index, drag.position)
		return

	if not _use_mouse:
		return

	var mouse_button := event as InputEventMouseButton
	if mouse_button != null and mouse_button.button_index == MOUSE_BUTTON_LEFT:
		if mouse_button.pressed:
			_press(MOUSE_POINTER, mouse_button.position)
		else:
			_release(MOUSE_POINTER)
		return

	var motion := event as InputEventMouseMotion
	if motion != null and _pointers.has(MOUSE_POINTER):
		_move(MOUSE_POINTER, motion.position)


func _to_local(screen_position: Vector2) -> Vector2:
	return get_global_transform_with_canvas().affine_inverse() * screen_position


func _is_blocked(point: Vector2) -> bool:
	for blocker: Control in blockers:
		if is_instance_valid(blocker) and blocker.is_visible_in_tree() and blocker.get_global_rect().has_point(point):
			return true
	return false


func _press(id: int, screen_position: Vector2) -> void:
	if _pointers.has(id):
		return
	var pos: Vector2 = _to_local(screen_position)
	if _is_blocked(pos):
		return

	var role: String = ""
	if pos.distance_to(_gas_center) <= _gas_radius * 1.15:
		role = "gas"
	elif pos.distance_to(_brake_center) <= _brake_radius * 1.15:
		role = "brake"
	elif pos.distance_to(_boost_center) <= _boost_radius * 1.15:
		role = "boost"
	else:
		match _mode:
			GameSettings.ControlMode.JOYSTICK:
				if _left_rect.grow(30.0).has_point(pos) and _joy_pointer == -1:
					role = "joy"
			GameSettings.ControlMode.BUTTONS:
				if _btn_left.grow(20.0).has_point(pos):
					role = "left"
				elif _btn_right.grow(20.0).has_point(pos):
					role = "right"
			GameSettings.ControlMode.GYRO:
				if _btn_calibrate.has_point(pos):
					GameSettings.calibrate_gyro()
					_calibrate_flash = 0.6

	if role.is_empty():
		return

	_pointers[id] = role
	if role == "joy":
		_joy_pointer = id
		_joy_origin = Vector2(
			clampf(pos.x, _left_rect.position.x + _joy_radius * 0.6, _left_rect.end.x - _joy_radius * 0.6),
			clampf(pos.y, _left_rect.position.y + _joy_radius * 0.6, _left_rect.end.y - _joy_radius * 0.6)
		)
		_joy_vec = Vector2.ZERO
		steer = 0.0
	elif role == "boost":
		boost_pressed.emit()

	_refresh_buttons()


func _move(id: int, screen_position: Vector2) -> void:
	if id != _joy_pointer or not _pointers.has(id):
		return
	var pos: Vector2 = _to_local(screen_position)
	_joy_vec = ((pos - _joy_origin) / _joy_radius).limit_length(1.0)
	var x: float = _joy_vec.x
	if absf(x) < JOY_DEADZONE:
		steer = 0.0
	else:
		var normalized: float = (absf(x) - JOY_DEADZONE) / (1.0 - JOY_DEADZONE)
		steer = signf(x) * clampf(pow(normalized, 1.25) * GameSettings.steering_sensitivity, 0.0, 1.0)


func _release(id: int) -> void:
	if not _pointers.has(id):
		return
	var role: String = _pointers[id]
	_pointers.erase(id)
	if role == "joy":
		_joy_pointer = -1
		_joy_vec = Vector2.ZERO
		_joy_origin = _joy_default
		steer = 0.0
	_refresh_buttons()


func _release_all() -> void:
	_pointers.clear()
	_joy_pointer = -1
	_joy_vec = Vector2.ZERO
	_joy_origin = _joy_default
	if _mode != GameSettings.ControlMode.GYRO:
		steer = 0.0
	_refresh_buttons()


func _refresh_buttons() -> void:
	var roles: Array = _pointers.values()
	gas_pressed = roles.has("gas")
	brake_pressed = roles.has("brake")
	queue_redraw()


# =========================================================
# RYSOWANIE
# =========================================================

func _draw() -> void:
	match _mode:
		GameSettings.ControlMode.JOYSTICK:
			_draw_joystick()
		GameSettings.ControlMode.BUTTONS:
			_draw_steer_buttons()
		GameSettings.ControlMode.GYRO:
			_draw_gyro()

	_draw_button(_gas_center, _gas_radius, "GAZ", Color(0.2, 0.85, 0.3), gas_pressed)
	var brake_label: String = "HAMULEC"
	if _player != null and is_instance_valid(_player) and _player.is_reversing:
		brake_label = "WSTECZ"
	_draw_button(_brake_center, _brake_radius, brake_label, Color(0.9, 0.2, 0.2), brake_pressed)

	var boost_color: Color
	var boost_label: String = _player.boost.get_selected_short_name() if _player != null else "BOOST"
	match _boost_state:
		BoostSystem.State.READY:
			boost_color = Color(1.0, 0.6, 0.1)
		BoostSystem.State.ACTIVE:
			boost_color = Color(0.1, 0.95, 0.25)
		BoostSystem.State.COOLDOWN:
			boost_color = Color(0.4, 0.4, 0.42)
		_:
			boost_color = Color(0.4, 0.33, 0.25)
			boost_label = "PORAŻENIE" if _player != null and _player.boost.is_shocked() else "BRUD"
	_draw_button(_boost_center, _boost_radius, boost_label, boost_color, boost_active)
	if _boost_state == BoostSystem.State.COOLDOWN and boost_cooldown_ratio > 0.0:
		var sweep: float = TAU * (1.0 - boost_cooldown_ratio)
		draw_arc(_boost_center, _boost_radius + 6.0, -PI * 0.5, -PI * 0.5 + sweep, 40, Color(1.0, 0.6, 0.1, 0.9), 6.0, true)


func _draw_joystick() -> void:
	var active: bool = _joy_pointer != -1
	# Podstawa: półprzezroczysta tarcza z podwójnym pierścieniem i znacznikami kierunków.
	draw_circle(_joy_origin + Vector2(0, 5), _joy_radius, Color(0, 0, 0, 0.22))
	draw_circle(_joy_origin, _joy_radius, Color(0.03, 0.08, 0.12, 0.42 if active else 0.3))
	draw_arc(_joy_origin, _joy_radius, 0.0, TAU, 64, Color(0.4, 0.95, 1.0, 0.75 if active else 0.5), 5.0, true)
	draw_arc(_joy_origin, _joy_radius * 0.62, 0.0, TAU, 48, Color(1, 1, 1, 0.16), 3.0, true)
	for side: float in [-1.0, 1.0]:
		var arrow_center: Vector2 = _joy_origin + Vector2(side * _joy_radius * 0.8, 0)
		draw_colored_polygon(PackedVector2Array([
			arrow_center + Vector2(side * 12, 0),
			arrow_center + Vector2(-side * 8, -13),
			arrow_center + Vector2(-side * 8, 13)]), Color(1, 1, 1, 0.32))
	# Gałka z cieniem i połyskiem.
	var knob: Vector2 = _joy_origin + _joy_vec * _joy_radius
	var knob_radius: float = _joy_radius * 0.42
	draw_circle(knob + Vector2(0, 5), knob_radius, Color(0, 0, 0, 0.3))
	draw_circle(knob, knob_radius, Color(0.0, 0.55, 0.7, 0.88))
	draw_circle(knob - Vector2(0, knob_radius * 0.15), knob_radius * 0.72, Color(0.2, 0.85, 0.95, 0.65))
	draw_arc(knob, knob_radius, 0.0, TAU, 40, Color(0.75, 1.0, 1.0, 0.9), 4.0, true)
	if not active:
		_draw_text(_joy_origin + Vector2(0, _joy_radius + 38), "SKRĘT", 28, Color(1, 1, 1, 0.6))
func _draw_steer_buttons() -> void:
	var roles: Array = _pointers.values()
	for data: Array in [[_btn_left, "◀", roles.has("left")], [_btn_right, "▶", roles.has("right")]]:
		var rect: Rect2 = data[0]
		var pressed: bool = data[2]
		var shadow := StyleBoxFlat.new()
		shadow.bg_color = Color(0, 0, 0, 0.25)
		shadow.set_corner_radius_all(int(rect.size.y * 0.22))
		draw_style_box(shadow, Rect2(rect.position + Vector2(0, 6), rect.size))
		var style := StyleBoxFlat.new()
		style.bg_color = Color(0.0, 0.55, 0.7, 0.62) if pressed else Color(0.03, 0.1, 0.15, 0.4)
		style.border_color = Color(0.45, 0.95, 1.0, 0.95 if pressed else 0.65)
		style.set_border_width_all(5)
		style.set_corner_radius_all(int(rect.size.y * 0.22))
		style.anti_aliasing = true
		draw_style_box(style, rect)
		_draw_text(rect.get_center() + Vector2(0, rect.size.y * 0.15), str(data[1]), int(rect.size.y * 0.42), Color(1, 1, 1, 0.95 if pressed else 0.8))
	# Wskaźnik aktualnego skrętu.
	var bar := Rect2(Vector2(_left_rect.position.x + _left_rect.size.x * 0.1, _btn_left.position.y - 34), Vector2(_left_rect.size.x * 0.8, 14))
	var bar_style := StyleBoxFlat.new()
	bar_style.bg_color = Color(1, 1, 1, 0.16)
	bar_style.set_corner_radius_all(7)
	draw_style_box(bar_style, bar)
	var center_x: float = bar.get_center().x
	var fill_style := StyleBoxFlat.new()
	fill_style.bg_color = Color(0.1, 0.9, 1.0, 0.95)
	fill_style.set_corner_radius_all(7)
	draw_style_box(fill_style, Rect2(Vector2(minf(center_x, center_x + steer * bar.size.x * 0.5), bar.position.y), Vector2(maxf(absf(steer) * bar.size.x * 0.5, 2.0), bar.size.y)))
func _draw_gyro() -> void:
	var center := Vector2(_left_rect.get_center().x, _left_rect.position.y + _left_rect.size.y * 0.4)
	var radius: float = _left_rect.size.y * 0.3
	draw_arc(center, radius, PI * 1.15, PI * 1.85, 32, Color(1, 1, 1, 0.45), 6.0, true)
	var angle: float = -PI * 0.5 + steer * PI * 0.35
	draw_line(center, center + Vector2(cos(angle), sin(angle)) * radius, Color(0.1, 0.9, 1.0, 0.95), 8.0, true)
	draw_circle(center, 12.0, Color(0.1, 0.9, 1.0, 0.95))
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.1, 0.8, 0.85, 0.5 if _calibrate_flash > 0.0 else 0.18)
	style.border_color = Color(1, 1, 1, 0.6)
	style.set_border_width_all(3)
	style.set_corner_radius_all(18)
	draw_style_box(style, _btn_calibrate)
	_draw_text(_btn_calibrate.get_center() + Vector2(0, 11), "KALIBRUJ", 30, Color(1, 1, 1, 0.9))


func _draw_button(center: Vector2, radius: float, label: String, color: Color, pressed: bool) -> void:
	var r: float = radius * (0.94 if pressed else 1.0)
	# Cień, korpus, połysk i wyraźny pierścień - przycisk wygląda na wypukły.
	draw_circle(center + Vector2(0, 7), r, Color(0, 0, 0, 0.28))
	draw_circle(center, r, Color(color.r * 0.3, color.g * 0.3, color.b * 0.3, 0.82 if pressed else 0.6))
	draw_circle(center - Vector2(0, r * 0.1), r * 0.84, Color(color.r, color.g, color.b, 0.5 if pressed else 0.26))
	draw_arc(center, r, 0.0, TAU, 56, Color(color.r, color.g, color.b, 1.0), 6.0, true)
	draw_arc(center, r * 0.9, PI * 1.1, PI * 1.9, 24, Color(1, 1, 1, 0.22), 4.0, true)
	var font_size: int = maxi(int(radius * 0.3), 20)
	_draw_text(center + Vector2(0, font_size * 0.35), label, font_size, Color(1, 1, 1, 0.98))
func _draw_text(center: Vector2, text: String, font_size: int, color: Color) -> void:
	var font: Font = ThemeDB.fallback_font
	var width: float = font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
	draw_string_outline(font, Vector2(center.x - width * 0.5, center.y), text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, 6, Color(0, 0, 0, 0.6))
	draw_string(font, Vector2(center.x - width * 0.5, center.y), text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, color)
