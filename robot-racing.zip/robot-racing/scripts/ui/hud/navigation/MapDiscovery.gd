class_name MapDiscovery
extends Node
## Odkrywanie obszaru mapy i pamięć odkrytych obszarów (per trasa).
##
## - Siatka komórek 0.5 m budowana z danych trasy (podłogi i przeszkody),
##   metodą rasteryzacji AABB (szybko także na Androidzie - poprzednia wersja
##   sprawdzała każdą komórkę z każdą przeszkodą).
## - Komórki odkrywa każdy robot w promieniu 1.5 m (jak dotychczas).
## - Zapis do user://track_maps/<trasa>_<hash>.cfg - ta sama nazwa pliku co
##   w poprzedniej wersji; stary format ("explored" jako lista tekstów) jest
##   odczytywany, nowy zapis to szybka mapa bitowa.

signal cells_discovered(cells: PackedInt32Array)

const CELL_SIZE: float = 0.5
const DISCOVERY_RADIUS: float = 1.5
const SAVE_INTERVAL: float = 5.0
const UPDATE_INTERVAL: float = 0.1

var map_min: Vector2 = Vector2.ZERO
var map_max: Vector2 = Vector2.ZERO
var width: int = 0
var height: int = 0
var walkable: PackedByteArray = PackedByteArray()
var explored: PackedByteArray = PackedByteArray()
var map_ready: bool = false
var file_path: String = ""

var racers: Array = []
var race_manager: RaceManager

var _dirty: bool = false
var _save_timer: float = 0.0
var _update_timer: float = 0.0
var _offsets: Array[Vector2i] = []


func build(track: TrackBase, robots: Array, manager: RaceManager) -> void:
	racers = robots
	race_manager = manager
	track.ensure_nav_data()
	_prepare_file_path(track.scene_file_path if not track.scene_file_path.is_empty() else track.track_id)

	var floor_height: float = track.nav_floor_height
	var floors: Array[AABB] = []
	for bounds: AABB in track.nav_floor_bounds:
		if absf(bounds.end.y - floor_height) <= 0.3:
			floors.append(bounds)
	if floors.is_empty():
		# Awaryjna mapa oparta na przebiegu toru. Nie blokuje minimapy,
		# gdy dana scena nie udostępnia AABB podłóg nawigacyjnych.
		if track.smooth_route.size() < 2:
			push_warning("MapDiscovery: brak podłóg i punktów trasy do mapy.")
			return
		var first: Vector3 = track.smooth_route[0]
		map_min = Vector2(first.x, first.z)
		map_max = map_min
		for point: Vector3 in track.smooth_route:
			map_min.x = minf(map_min.x, point.x)
			map_min.y = minf(map_min.y, point.z)
			map_max.x = maxf(map_max.x, point.x)
			map_max.y = maxf(map_max.y, point.z)
		map_min -= Vector2(12.0, 12.0)
		map_max += Vector2(12.0, 12.0)
	else:
		map_min = Vector2(floors[0].position.x, floors[0].position.z)
		map_max = Vector2(floors[0].end.x, floors[0].end.z)
		for bounds: AABB in floors:
			map_min.x = minf(map_min.x, bounds.position.x)
			map_min.y = minf(map_min.y, bounds.position.z)
			map_max.x = maxf(map_max.x, bounds.end.x)
			map_max.y = maxf(map_max.y, bounds.end.z)

	width = ceili((map_max.x - map_min.x) / CELL_SIZE)
	height = ceili((map_max.y - map_min.y) / CELL_SIZE)
	if width <= 0 or height <= 0:
		if track.smooth_route.size() < 2:
			push_warning("MapDiscovery: nie można wyznaczyć rozmiaru minimapy.")
			return
		var route_first: Vector3 = track.smooth_route[0]
		map_min = Vector2(route_first.x, route_first.z)
		map_max = map_min
		for route_point: Vector3 in track.smooth_route:
			map_min.x = minf(map_min.x, route_point.x)
			map_min.y = minf(map_min.y, route_point.z)
			map_max.x = maxf(map_max.x, route_point.x)
			map_max.y = maxf(map_max.y, route_point.z)
		map_min -= Vector2(12.0, 12.0)
		map_max += Vector2(12.0, 12.0)
		floors.clear()
		width = ceili((map_max.x - map_min.x) / CELL_SIZE)
		height = ceili((map_max.y - map_min.y) / CELL_SIZE)
		if width <= 0 or height <= 0:
			return

	walkable.resize(width * height)
	walkable.fill(0)
	explored.resize(width * height)
	explored.fill(0)

	if floors.is_empty():
		walkable.fill(1)
	else:
		for bounds: AABB in floors:
			_rasterize(bounds, 1)

	for bounds: AABB in track.nav_obstacle_bounds:
		var bottom: float = bounds.position.y
		var top: float = bounds.end.y
		if bottom > floor_height + 0.65 or top < floor_height + 0.15:
			continue
		_rasterize(bounds, 0)

	var radius_cells: int = ceili(DISCOVERY_RADIUS / CELL_SIZE)
	for dx: int in range(-radius_cells, radius_cells + 1):
		for dz: int in range(-radius_cells, radius_cells + 1):
			if Vector2(dx, dz).length() * CELL_SIZE <= DISCOVERY_RADIUS + CELL_SIZE * 0.5:
				_offsets.append(Vector2i(dx, dz))

	map_ready = true
	_load()


func _rasterize(bounds: AABB, value: int) -> void:
	var x0: int = maxi(ceili((bounds.position.x - map_min.x) / CELL_SIZE - 0.5), 0)
	var x1: int = mini(floori((bounds.end.x - map_min.x) / CELL_SIZE - 0.5), width - 1)
	var z0: int = maxi(ceili((bounds.position.z - map_min.y) / CELL_SIZE - 0.5), 0)
	var z1: int = mini(floori((bounds.end.z - map_min.y) / CELL_SIZE - 0.5), height - 1)
	for z: int in range(z0, z1 + 1):
		var row: int = z * width
		for x: int in range(x0, x1 + 1):
			walkable[row + x] = value


func is_walkable(x: int, z: int) -> bool:
	if x < 0 or z < 0 or x >= width or z >= height:
		return false
	return walkable[z * width + x] == 1


func is_explored(x: int, z: int) -> bool:
	if x < 0 or z < 0 or x >= width or z >= height:
		return false
	return explored[z * width + x] == 1


func _process(delta: float) -> void:
	if not map_ready:
		return

	_save_timer += delta
	if _dirty and _save_timer >= SAVE_INTERVAL:
		_save_timer = 0.0
		save()

	if race_manager != null and not race_manager.is_running():
		return

	_update_timer -= delta
	if _update_timer > 0.0:
		return
	_update_timer = UPDATE_INTERVAL

	var discovered := PackedInt32Array()
	for racer_variant: Variant in racers:
		var racer: Node3D = racer_variant as Node3D
		if racer == null or not is_instance_valid(racer):
			continue
		var position: Vector3 = racer.global_position
		var cx: int = floori((position.x - map_min.x) / CELL_SIZE)
		var cz: int = floori((position.z - map_min.y) / CELL_SIZE)
		for offset: Vector2i in _offsets:
			var x: int = cx + offset.x
			var z: int = cz + offset.y
			if x < 0 or z < 0 or x >= width or z >= height:
				continue
			var index: int = z * width + x
			if walkable[index] == 1 and explored[index] == 0:
				explored[index] = 1
				discovered.append(index)

	if not discovered.is_empty():
		_dirty = true
		cells_discovered.emit(discovered)


func _exit_tree() -> void:
	if _dirty:
		save()


# =========================================================
# ZAPIS I ODCZYT
# =========================================================

func _prepare_file_path(track_key: String) -> void:
	var file_name: String = track_key.get_file().get_basename() + "_" + str(absi(track_key.hash())) + ".cfg"
	var directory: String = OS.get_user_data_dir().path_join("track_maps")
	DirAccess.make_dir_recursive_absolute(directory)
	file_path = directory.path_join(file_name)


func _load() -> void:
	if SaveManager.test_mode or not FileAccess.file_exists(file_path):
		return
	var config := ConfigFile.new()
	if config.load(file_path) != OK:
		push_warning("MapDiscovery: nie można odczytać mapy.")
		return

	var saved_width: int = int(config.get_value("map", "width", 0))
	var saved_height: int = int(config.get_value("map", "height", 0))
	var bits: Variant = config.get_value("map", "explored_bits", null)
	if bits is PackedByteArray and saved_width == width and saved_height == height and (bits as PackedByteArray).size() == width * height:
		var data: PackedByteArray = bits
		for i: int in range(data.size()):
			if data[i] == 1 and walkable[i] == 1:
				explored[i] = 1
		return

	# Stary format: lista tekstów "x,z".
	var old_cells: Variant = config.get_value("map", "explored", [])
	if old_cells is Array:
		for entry: Variant in old_cells:
			var parts: PackedStringArray = str(entry).split(",")
			if parts.size() != 2:
				continue
			var x: int = int(parts[0])
			var z: int = int(parts[1])
			if is_walkable(x, z):
				explored[z * width + x] = 1
		_dirty = true


func save() -> void:
	if not map_ready or file_path.is_empty() or SaveManager.test_mode:
		return
	var config := ConfigFile.new()
	config.set_value("map", "version", 2)
	config.set_value("map", "width", width)
	config.set_value("map", "height", height)
	config.set_value("map", "explored_bits", explored)
	if config.save(file_path) != OK:
		push_warning("MapDiscovery: błąd zapisywania mapy.")
		return
	_dirty = false
