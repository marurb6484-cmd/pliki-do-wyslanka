extends HUDModule
## Renderowanie minimapy: odkryte obszary, linia trasy, ślady robotów, roboty.
##
## Optymalizacja względem poprzedniej wersji (rysowała tysiące prostokątów
## i linii w każdej klatce):
##  - odkryte komórki trafiają do tekstury (aktualizowanej tylko przy zmianach),
##  - ślady są przeliczane do współrzędnych mapy przyrostowo,
##  - przerysowanie ~12 razy na sekundę zamiast co klatkę.

const TRAIL_COLORS: Array[Color] = [
	Color(0.05, 0.85, 1.0),
	Color(1.0, 0.25, 0.15),
	Color(0.15, 1.0, 0.25),
	Color(1.0, 0.85, 0.05),
	Color(0.85, 0.25, 1.0)
]
const COLOR_FLOOR := Color(0.68, 0.70, 0.72, 1.0)
const COLOR_EDGE := Color(0.96, 0.97, 1.0, 0.95)

var discovery: MapDiscovery
var trail_recorder: TrailRecorder
var track: TrackBase
var robots: Array = []
var player: Robot

var _image: Image
var _texture: ImageTexture
var _texture_dirty: bool = false
var _map_rect: Rect2
var _trail_cache: Array[PackedVector2Array] = [] # punkty świata, nie współrzędne ekranu
var _route_world_points: Array[Vector3] = []
var _map_zoom: float = 1.62
var _focus_world: Vector2 = Vector2.ZERO


func bind(navigation: Node) -> void:
	discovery = navigation.get("discovery")
	trail_recorder = navigation.get("trails")


func _build() -> void:
	clip_contents = true


func _on_setup() -> void:
	track = context.get("track") as TrackBase
	player = context.get("player") as Robot
	robots = context.get("robots", [])
	if discovery == null or not discovery.map_ready:
		return

	_compute_map_rect()
	_build_texture()
	discovery.cells_discovered.connect(_on_cells_discovered)

	_route_world_points.clear()
	if track != null:
		for point: Vector3 in track.smooth_route:
			_route_world_points.append(point)
		if track.route_closed and not _route_world_points.is_empty():
			_route_world_points.append(_route_world_points[0])
	if player != null:
		_focus_world = Vector2(player.global_position.x, player.global_position.z)

	if trail_recorder != null:
		_trail_cache.clear()
		for i: int in range(trail_recorder.trails.size()):
			_trail_cache.append(_convert_trail(trail_recorder.trails[i]))
		trail_recorder.point_added.connect(_on_trail_point)
		trail_recorder.trail_trimmed.connect(_on_trail_trimmed)

	update_interval = 1.0 / 12.0
	queue_redraw()


func _compute_map_rect() -> void:
	var world_size := Vector2(maxf(discovery.map_max.x - discovery.map_min.x, 1.0), maxf(discovery.map_max.y - discovery.map_min.y, 1.0))
	var inner := Rect2(Vector2(8, 8), base_size - Vector2(16, 16))
	var factor: float = minf(inner.size.x / world_size.x, inner.size.y / world_size.y)
	var draw_size: Vector2 = world_size * factor
	_map_rect = Rect2(inner.position + (inner.size - draw_size) * 0.5, draw_size)


func _world_to_map(x: float, z: float) -> Vector2:
	var nx: float = (x - discovery.map_min.x) / maxf(discovery.map_max.x - discovery.map_min.x, 0.001)
	var nz: float = (z - discovery.map_min.y) / maxf(discovery.map_max.y - discovery.map_min.y, 0.001)
	var base_point := Vector2(_map_rect.position.x + nx * _map_rect.size.x, _map_rect.position.y + (1.0 - nz) * _map_rect.size.y)
	var focus_nx: float = (_focus_world.x - discovery.map_min.x) / maxf(discovery.map_max.x - discovery.map_min.x, 0.001)
	var focus_nz: float = (_focus_world.y - discovery.map_min.y) / maxf(discovery.map_max.y - discovery.map_min.y, 0.001)
	var focus_point := Vector2(_map_rect.position.x + focus_nx * _map_rect.size.x, _map_rect.position.y + (1.0 - focus_nz) * _map_rect.size.y)
	return base_size * 0.5 + (base_point - focus_point) * _map_zoom


func _zoomed_map_rect() -> Rect2:
	var focus := _world_to_map_unzoomed(_focus_world.x, _focus_world.y)
	var top_left := base_size * 0.5 + (_map_rect.position - focus) * _map_zoom
	return Rect2(top_left, _map_rect.size * _map_zoom)


func _world_to_map_unzoomed(x: float, z: float) -> Vector2:
	var nx: float = (x - discovery.map_min.x) / maxf(discovery.map_max.x - discovery.map_min.x, 0.001)
	var nz: float = (z - discovery.map_min.y) / maxf(discovery.map_max.y - discovery.map_min.y, 0.001)
	return Vector2(_map_rect.position.x + nx * _map_rect.size.x, _map_rect.position.y + (1.0 - nz) * _map_rect.size.y)


func _convert_trail(trail: PackedVector2Array) -> PackedVector2Array:
	return trail.duplicate()


func _build_texture() -> void:
	_image = Image.create(discovery.width, discovery.height, false, Image.FORMAT_RGBA8)
	_image.fill(Color(0, 0, 0, 0))
	for z: int in range(discovery.height):
		for x: int in range(discovery.width):
			if discovery.explored[z * discovery.width + x] == 1:
				_paint_cell(x, z)
	_texture = ImageTexture.create_from_image(_image)


func _paint_cell(x: int, z: int) -> void:
	var edge: bool = not discovery.is_walkable(x + 1, z) or not discovery.is_walkable(x - 1, z) or not discovery.is_walkable(x, z + 1) or not discovery.is_walkable(x, z - 1)
	_image.set_pixel(x, discovery.height - 1 - z, COLOR_EDGE if edge else COLOR_FLOOR)


func _on_cells_discovered(cells: PackedInt32Array) -> void:
	if _image == null:
		return
	for index: int in cells:
		_paint_cell(index % discovery.width, index / discovery.width)
	_texture_dirty = true


func _on_trail_point(racer_index: int, point: Vector2) -> void:
	if racer_index < _trail_cache.size():
		_trail_cache[racer_index].append(point)


func _on_trail_trimmed(racer_index: int) -> void:
	if racer_index < _trail_cache.size():
		_trail_cache[racer_index] = _convert_trail(trail_recorder.trails[racer_index])


func _refresh() -> void:
	if player != null and is_instance_valid(player):
		_focus_world = Vector2(player.global_position.x, player.global_position.z)
	if _texture_dirty and _texture != null:
		_texture.update(_image)
		_texture_dirty = false
	queue_redraw()


func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, base_size), Color(0.035, 0.045, 0.055, 0.9), true)

	if preview:
		_draw_preview()
		return
	if discovery == null or not discovery.map_ready:
		return

	if _texture != null:
		draw_texture_rect(_texture, _zoomed_map_rect(), false)

	if _route_world_points.size() > 1:
		var route_screen := PackedVector2Array()
		for point: Vector3 in _route_world_points:
			route_screen.append(_world_to_map(point.x, point.z))
		draw_polyline(route_screen, Color(0.015, 0.025, 0.035, 1.0), 12.0, true)
		draw_polyline(route_screen, Color(0.0, 0.95, 1.0, 1.0), 8.0, true)

	for i: int in range(_trail_cache.size()):
		if _trail_cache[i].size() > 1:
			var trail_screen := PackedVector2Array()
			for point: Vector2 in _trail_cache[i]:
				trail_screen.append(_world_to_map(point.x, point.y))
			draw_polyline(trail_screen, TRAIL_COLORS[i % TRAIL_COLORS.size()], 2.6, true)

	for i: int in range(robots.size()):
		var robot: Robot = robots[i] as Robot
		if robot == null or not is_instance_valid(robot):
			continue
		_draw_robot(robot, TRAIL_COLORS[i % TRAIL_COLORS.size()], robot == player)

	draw_rect(Rect2(Vector2.ZERO, base_size), Color(0.9, 0.95, 1.0, 1.0), false, 2.0)


func _draw_robot(robot: Robot, color: Color, is_player: bool) -> void:
	var position_2d: Vector2 = _world_to_map(robot.global_position.x, robot.global_position.z)
	var marker: float = 8.5 if is_player else 7.0
	draw_circle(position_2d, marker + 3.0, Color(0, 0, 0, 0.95))
	if is_player:
		draw_circle(position_2d, marker + 1.5, Color.WHITE)
	draw_circle(position_2d, marker, color)
	draw_circle(position_2d, 2.5, Color.WHITE)
	var forward: Vector3 = -robot.global_transform.basis.z
	var direction := Vector2(forward.x, -forward.z).normalized()
	draw_line(position_2d, position_2d + direction * (marker + 9.0), Color.BLACK, 5.0, true)
	draw_line(position_2d, position_2d + direction * (marker + 9.0), Color.WHITE, 2.5, true)


func _draw_preview() -> void:
	var rect := Rect2(Vector2(30, 30), base_size - Vector2(60, 60))
	var points := PackedVector2Array()
	for i: int in range(33):
		var angle: float = TAU * i / 32.0
		points.append(rect.get_center() + Vector2(cos(angle) * rect.size.x * 0.45, sin(angle) * rect.size.y * 0.42))
	draw_polyline(points, Color(0.68, 0.70, 0.72), 26.0, true)
	draw_polyline(points, Color(0.0, 0.95, 1.0), 8.0, true)
	draw_circle(points[4], 9.0, TRAIL_COLORS[0])
	draw_circle(points[9], 7.0, TRAIL_COLORS[1])
	draw_rect(Rect2(Vector2.ZERO, base_size), Color(0.9, 0.95, 1.0, 1.0), false, 2.0)


func _show_preview() -> void:
	queue_redraw()
