extends Control
## NavigationHUD - łączy moduły nawigacji i przekazuje między nimi dane.
##
## Sam nie liczy ani nie rysuje. Odpowiedzialności:
##  - MapDiscovery        - odkrywanie i pamięć mapy (zapis per trasa),
##  - TrailRecorder       - ślad przejazdu robotów,
##  - WaypointNavigator   - waypointy i kierunek nadchodzącego zakrętu,
##  - SurroundingsDetector- rywale obok, przeszkody i brud przed graczem,
##  - MinimapRenderer     - rysowanie minimapy (moduł HUD, edytowalny),
##  - NavigationMarkers   - strzałki i znaczniki (moduł HUD, edytowalny).

@onready var discovery: MapDiscovery = $MapDiscovery
@onready var trails: TrailRecorder = $TrailRecorder
@onready var navigator: WaypointNavigator = $WaypointNavigator
@onready var detector: SurroundingsDetector = $SurroundingsDetector
@onready var minimap: HUDModule = $MinimapRenderer
@onready var markers: HUDModule = $NavigationMarkers


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


## Wywoływane przez RaceHUD przed setup() modułów.
func setup(context: Dictionary) -> void:
	var track: TrackBase = context.get("track") as TrackBase
	var robots: Array = context.get("robots", [])
	var player: Robot = context.get("player") as Robot
	var race: RaceManager = context.get("race_manager") as RaceManager
	var dirt: DirtManager = context.get("dirt_manager") as DirtManager

	if track == null:
		return

	discovery.build(track, robots, race)
	trails.setup(robots, race)
	navigator.setup(track, player)
	detector.setup(player, robots, track, dirt)

	minimap.call("bind", self)
	navigator.direction_changed.connect(_on_direction_changed)
	detector.surroundings_changed.connect(_on_surroundings_changed)


func _on_direction_changed(kind: String, severity: int, distance: float) -> void:
	markers.call("set_direction", kind, severity, distance)


func _on_surroundings_changed(data: Dictionary) -> void:
	markers.call("set_surroundings", data)


## Podgląd w edytorze HUD - wyłączamy logikę, moduły pokazują przykładowe dane.
func enter_preview() -> void:
	for node: Node in [discovery, trails, navigator, detector]:
		node.set_process(false)
