extends HUDModule
## Znaczniki nawigacyjne: rajdowa strzałka zakrętu (kolor = ostrość),
## odległość do zakrętu, ostrzeżenie o przeszkodzie, rywale obok/za graczem,
## najbliższy brud. Przerysowanie tylko przy zmianie danych.

const PANEL_ALPHA: float = 0.45
const ARROW_ALPHA: float = 0.85

var kind: String = "straight"
var severity: int = 1
var distance: float = 0.0
var surroundings: Dictionary = {}


func set_direction(new_kind: String, new_severity: int, new_distance: float) -> void:
	var rounded: float = snappedf(new_distance, 5.0)
	if new_kind == kind and new_severity == severity and rounded == distance:
		return
	kind = new_kind
	severity = new_severity
	distance = rounded
	queue_redraw()


func set_surroundings(data: Dictionary) -> void:
	surroundings = data
	queue_redraw()


func _draw() -> void:
	var center := Vector2(base_size.x * 0.5, base_size.y * 0.42)

	if kind != "straight":
		_draw_arrow(center)

	var font: Font = ThemeDB.fallback_font

	# Przeszkoda przed graczem.
	var obstacle: float = float(surroundings.get("obstacle_distance", -1.0))
	if obstacle >= 0.0 and obstacle < 18.0:
		var side: float = float(surroundings.get("obstacle_side", 0.0))
		var warn_pos := Vector2(base_size.x * 0.5 + side * 70.0, base_size.y - 26.0)
		var triangle := PackedVector2Array([warn_pos + Vector2(0, -24), warn_pos + Vector2(22, 14), warn_pos + Vector2(-22, 14)])
		draw_colored_polygon(triangle, Color(1.0, 0.75, 0.1, 0.9))
		draw_string(font, warn_pos + Vector2(-6, 10), "!", HORIZONTAL_ALIGNMENT_LEFT, -1, 30, Color.BLACK)
		draw_string(font, warn_pos + Vector2(28, 10), "%d m" % int(obstacle), HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color(1.0, 0.85, 0.3))

	# Rywale obok i za graczem.
	var rival_color := Color(1.0, 0.35, 0.25, 0.95)
	if bool(surroundings.get("rival_left", false)):
		_draw_chevron(Vector2(16, center.y), -1.0, rival_color)
	if bool(surroundings.get("rival_right", false)):
		_draw_chevron(Vector2(base_size.x - 16, center.y), 1.0, rival_color)
	if bool(surroundings.get("rival_behind", false)):
		var base_point := Vector2(base_size.x * 0.5, base_size.y - 4)
		draw_colored_polygon(PackedVector2Array([base_point + Vector2(-18, -14), base_point + Vector2(18, -14), base_point]), rival_color)

	# Brud przed graczem.
	var dirt: float = float(surroundings.get("dirt_distance", -1.0))
	if dirt >= 0.0 and kind == "straight":
		var dirt_side: float = float(surroundings.get("dirt_side", 0.0))
		var dirt_pos := Vector2(base_size.x * 0.5 + dirt_side * 50.0, 40.0)
		draw_circle(dirt_pos, 11.0, Color(0.55, 0.4, 0.25, 0.9))
		draw_arc(dirt_pos, 11.0, 0.0, TAU, 16, Color(1, 1, 1, 0.8), 2.0, true)
		draw_string(font, dirt_pos + Vector2(16, 8), "%d m" % int(dirt), HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color(0.9, 0.8, 0.6))


func _draw_chevron(point: Vector2, direction: float, color: Color) -> void:
	var tip: Vector2 = point
	var back: float = -direction * 22.0
	draw_colored_polygon(PackedVector2Array([tip, tip + Vector2(back, -20), tip + Vector2(back * 0.5, 0), tip + Vector2(back, 20)]), color)


func _draw_arrow(center: Vector2) -> void:
	var arrow_color: Color
	if severity <= 2:
		arrow_color = Color(0.0, 1.0, 0.15, ARROW_ALPHA)
	elif severity == 3:
		arrow_color = Color(1.0, 0.85, 0.0, ARROW_ALPHA)
	else:
		arrow_color = Color(1.0, 0.05, 0.05, ARROW_ALPHA)

	var panel_size := Vector2(190, 150)
	var panel := Rect2(center - panel_size * 0.5, panel_size)
	draw_rect(panel, Color(0.015, 0.02, 0.03, PANEL_ALPHA), true)
	draw_rect(panel, Color(1, 1, 1, PANEL_ALPHA), false, 2.0)

	# Geometryczna strzałka (kształt z poprzedniej wersji, lustrzany dla prawego zakrętu).
	var points := PackedVector2Array([
		Vector2(8, 48), Vector2(-8, 48), Vector2(-8, 2), Vector2(-42, 2), Vector2(-42, 18),
		Vector2(-66, -6), Vector2(-42, -30), Vector2(-42, -14), Vector2(8, -14)
	])
	var final_points := PackedVector2Array()
	var mirror: float = -1.0 if kind == "right" else 1.0
	for point: Vector2 in points:
		final_points.append(center + Vector2(point.x * mirror, point.y) * 1.15 + Vector2(8.0 * mirror, -4.0))

	var outline := final_points.duplicate()
	outline.append(final_points[0])
	draw_colored_polygon(final_points, Color(0, 0, 0, PANEL_ALPHA))
	draw_polyline(outline, Color(0, 0, 0, 0.8), 5.0, true)
	draw_colored_polygon(final_points, arrow_color)

	# Ostrość zakrętu (kropki) i odległość.
	for i: int in range(severity - 1):
		draw_circle(center + Vector2(-30 + i * 20, 62), 6.0, arrow_color)
	if distance > 0.0:
		draw_string(ThemeDB.fallback_font, center + Vector2(40, 70), "%d m" % int(distance), HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color(1, 1, 1, 0.9))


func _show_preview() -> void:
	kind = "left"
	severity = 3
	distance = 25.0
	surroundings = {"rival_right": true, "obstacle_distance": 12.0, "obstacle_side": 1.0}
	queue_redraw()
