class_name SurroundingsDetector
extends Node
## Wykrywanie informacji o otoczeniu gracza:
##  - rywale tuż obok (lewo/prawo) i za plecami,
##  - przeszkoda na torze przed graczem (odległość, strona),
##  - najbliższy brud przed graczem.

signal surroundings_changed(data: Dictionary)

const UPDATE_INTERVAL: float = 0.15

var player: Robot
var racers: Array = []
var track: TrackBase
var dirt_manager: DirtManager
var data: Dictionary = {}

var _timer: float = 0.0
var _hint: int = -1


func setup(player_robot: Robot, robots: Array, race_track: TrackBase, dirt: DirtManager) -> void:
	player = player_robot
	racers = robots
	track = race_track
	dirt_manager = dirt


func _process(delta: float) -> void:
	_timer -= delta
	if _timer > 0.0 or player == null or not is_instance_valid(player):
		return
	_timer = UPDATE_INTERVAL

	var result: Dictionary = {
		"rival_left": false, "rival_right": false, "rival_behind": false,
		"obstacle_distance": -1.0, "obstacle_side": 0.0,
		"dirt_distance": -1.0, "dirt_side": 0.0
	}

	var transform_inverse: Transform3D = player.global_transform.affine_inverse()
	for racer_variant: Variant in racers:
		var other: Node3D = racer_variant as Node3D
		if other == null or other == player or not is_instance_valid(other):
			continue
		var local: Vector3 = transform_inverse * other.global_position
		if local.length() > 7.0:
			continue
		if local.z > 1.0 and absf(local.x) < 2.0:
			result["rival_behind"] = true
		elif absf(local.z) < 2.5 and absf(local.x) > 0.8:
			if local.x < 0.0:
				result["rival_left"] = true
			else:
				result["rival_right"] = true

	if track != null:
		var projection: Dictionary = track.project_point(player.global_position, _hint)
		_hint = int(projection["index"])
		var distance: float = float(projection["distance"])
		var lateral: float = float(projection["lateral"])

		var best: float = INF
		for obstacle: Dictionary in track.obstacles:
			var ahead: float = track.wrap_distance(float(obstacle["distance"]) - distance) if track.route_closed else float(obstacle["distance"]) - distance
			if ahead < 0.0 or ahead > 25.0 or ahead >= best:
				continue
			if absf(float(obstacle["lateral"]) - lateral) < float(obstacle["radius"]) + 1.2:
				best = ahead
				result["obstacle_distance"] = ahead
				result["obstacle_side"] = signf(float(obstacle["lateral"]) - lateral)

		if dirt_manager != null:
			var pickup: Dictionary = dirt_manager.find_pickup_ahead(distance, 1.0, 22.0)
			if not pickup.is_empty():
				result["dirt_distance"] = float(pickup["ahead"])
				result["dirt_side"] = signf(float(pickup["lateral"]) - lateral) if absf(float(pickup["lateral"]) - lateral) > 0.8 else 0.0

	if result != data:
		data = result
		surroundings_changed.emit(data)
