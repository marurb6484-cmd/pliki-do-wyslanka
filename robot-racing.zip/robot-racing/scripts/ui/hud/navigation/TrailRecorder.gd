class_name TrailRecorder
extends Node
## Zapisywanie przebytej trasy (ślad przejazdu) wszystkich robotów.
## Próbkowanie co 0.4 m, 10 razy na sekundę, z limitem punktów na robota.

signal point_added(racer_index: int, point: Vector2)
signal trail_trimmed(racer_index: int)

const SAMPLE_DISTANCE: float = 0.4
const MAX_POINTS: int = 1500
const UPDATE_INTERVAL: float = 0.1

var racers: Array = []
var race_manager: RaceManager
var trails: Array[PackedVector2Array] = []
var _last_points: Array[Vector2] = []
var _timer: float = 0.0


func setup(robots: Array, manager: RaceManager) -> void:
	racers = robots
	race_manager = manager
	trails.clear()
	_last_points.clear()
	for racer_variant: Variant in racers:
		var racer: Node3D = racer_variant as Node3D
		var start := Vector2(racer.global_position.x, racer.global_position.z)
		var trail := PackedVector2Array()
		trail.append(start)
		trails.append(trail)
		_last_points.append(start)


func _process(delta: float) -> void:
	if race_manager == null or not race_manager.is_running():
		return
	_timer -= delta
	if _timer > 0.0:
		return
	_timer = UPDATE_INTERVAL

	for i: int in range(racers.size()):
		var racer: Node3D = racers[i] as Node3D
		if racer == null or not is_instance_valid(racer):
			continue
		var point := Vector2(racer.global_position.x, racer.global_position.z)
		if point.distance_to(_last_points[i]) < SAMPLE_DISTANCE:
			continue
		_last_points[i] = point
		trails[i].append(point)
		if trails[i].size() > MAX_POINTS:
			trails[i] = trails[i].slice(MAX_POINTS / 4)
			trail_trimmed.emit(i)
		else:
			point_added.emit(i, point)
