class_name WaypointNavigator
extends Node
## Obsługa waypointów i wskazówek kierunku (rajdowe strzałki).
##
## Logika przeniesiona z poprzedniego NavigationHUD:
##  - wykrywanie najbliższego odcinka trasy,
##  - kierunek i ostrość nadchodzącego zakrętu (stopnie 2-5),
##  - strzałka pokazywana ~2 s przed zakrętem,
##  - po minięciu zakrętu strzałka zostaje jeszcze 1 s.

signal direction_changed(kind: String, severity: int, distance: float)

const LOOKAHEAD_TIME: float = 2.0
const AFTER_TURN_TIME: float = 1.0
const UPDATE_INTERVAL: float = 0.1

var waypoints: Array[Vector3] = []
var player: Robot

var direction_kind: String = "straight"
var direction_severity: int = 1
var distance_to_turn: float = 0.0
var next_waypoint_index: int = 0

var _last_segment_index: int = -1
var _turn_was_visible: bool = false
var _post_turn_timer: float = 0.0
var _post_turn_kind: String = "straight"
var _post_turn_severity: int = 1
var _timer: float = 0.0


func setup(track: TrackBase, player_robot: Robot) -> void:
	waypoints = track.route.duplicate()
	player = player_robot


func _process(delta: float) -> void:
	_timer -= delta
	_post_turn_timer = maxf(_post_turn_timer - delta, 0.0)
	if _timer > 0.0:
		return
	_timer = UPDATE_INTERVAL

	var old_kind: String = direction_kind
	var old_severity: int = direction_severity
	_update_direction()
	if old_kind != direction_kind or old_severity != direction_severity or direction_kind != "straight":
		direction_changed.emit(direction_kind, direction_severity, distance_to_turn)


func _closest_segment() -> Dictionary:
	var result: Dictionary = {"index": -1, "progress": 0.0, "distance": INF}
	if waypoints.size() < 3 or player == null:
		return result
	var position := Vector2(player.global_position.x, player.global_position.z)
	for i: int in range(waypoints.size()):
		var a := Vector2(waypoints[i].x, waypoints[i].z)
		var next: Vector3 = waypoints[(i + 1) % waypoints.size()]
		var b := Vector2(next.x, next.z)
		var segment: Vector2 = b - a
		var length_sq: float = segment.length_squared()
		if length_sq < 0.001:
			continue
		var progress: float = clampf((position - a).dot(segment) / length_sq, 0.0, 1.0)
		var distance: float = position.distance_to(a + segment * progress)
		if distance < float(result["distance"]):
			result = {"index": i, "progress": progress, "distance": distance}
	return result


func _update_direction() -> void:
	if player == null or not is_instance_valid(player) or waypoints.size() < 3:
		direction_kind = "straight"
		direction_severity = 1
		return

	var segment: Dictionary = _closest_segment()
	var segment_index: int = int(segment["index"])
	if segment_index < 0:
		direction_kind = "straight"
		return
	next_waypoint_index = (segment_index + 1) % waypoints.size()

	# Wykrycie przejazdu przez punkt zakrętu.
	if _last_segment_index >= 0:
		var expected: int = (_last_segment_index + 1) % waypoints.size()
		if segment_index == expected and _turn_was_visible:
			_post_turn_timer = AFTER_TURN_TIME
			_post_turn_kind = direction_kind
			_post_turn_severity = direction_severity
			_turn_was_visible = false
	_last_segment_index = segment_index

	if _post_turn_timer > 0.0:
		direction_kind = _post_turn_kind
		direction_severity = _post_turn_severity
		distance_to_turn = 0.0
		return

	var count: int = waypoints.size()
	var corner_index: int = (segment_index + 1) % count
	var after_index: int = (corner_index + 1) % count
	var a := Vector2(waypoints[segment_index].x, waypoints[segment_index].z)
	var corner := Vector2(waypoints[corner_index].x, waypoints[corner_index].z)
	var b := Vector2(waypoints[after_index].x, waypoints[after_index].z)

	var incoming: Vector2 = (corner - a).normalized()
	var outgoing: Vector2 = (b - corner).normalized()
	var angle: float = rad_to_deg(atan2(incoming.x * outgoing.y - incoming.y * outgoing.x, clampf(incoming.dot(outgoing), -1.0, 1.0)))
	var absolute: float = absf(angle)

	if absolute < 25.0:
		direction_kind = "straight"
		direction_severity = 1
		_turn_was_visible = false
		return

	# Dodatni kąt = zakręt w prawo (oś Z w dół mapy).
	direction_kind = "right" if angle > 0.0 else "left"
	if absolute > 120.0:
		direction_severity = 5
	elif absolute > 85.0:
		direction_severity = 4
	elif absolute > 55.0:
		direction_severity = 3
	else:
		direction_severity = 2

	var speed: float = absf(player.forward_speed)
	distance_to_turn = (corner - a).length() * (1.0 - float(segment["progress"]))
	if speed < 0.5:
		direction_kind = "straight"
		_turn_was_visible = false
		return

	if distance_to_turn / speed <= LOOKAHEAD_TIME:
		_turn_was_visible = true
	else:
		direction_kind = "straight"
		_turn_was_visible = false
