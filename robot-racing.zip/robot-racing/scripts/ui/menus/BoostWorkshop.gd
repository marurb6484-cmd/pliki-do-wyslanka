extends Control
## Warsztat boostów: wyposażenie, presety i trwałe ulepszanie parametrów.

var _loadout: BoostLoadoutSystem
var _preset_select: OptionButton
var _slot_selects: Array[OptionButton] = []
var _message: Label
var _preset_name: LineEdit
var _boost_select: OptionButton
var _rarity_select: OptionButton
var _parameter_grid: GridContainer
var _parameter_buttons: Array[Button] = []
var _upgrade_info: Label
var _upgrade_button: Button
var _upgrade_all_button: Button
var _currency_label: Label
var _selected_boost: String = "turbo"
var _selected_rarity: String = "common"
var _selected_parameter: String = "duration"


func _ready() -> void:
	_loadout = PlayerProgress.boost_loadout
	UIKit.add_menu_background(self)
	var margin := UIKit.make_screen_margin(self, 30)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 12)
	margin.add_child(column)
	column.add_child(UIKit.make_header("WARSZTAT BOOSTÓW", GameManager.go_to_main_menu))
	column.add_child(UIKit.make_label("Wyposażenie obowiązuje wszystkie roboty. Wybór aktywnego boosta zmienisz również podczas wyścigu.", 23, UIKit.COLOR_MUTED))

	var preset_row := HBoxContainer.new()
	preset_row.add_theme_constant_override("separation", 12)
	column.add_child(preset_row)
	_preset_select = OptionButton.new()
	_preset_select.custom_minimum_size = Vector2(330, 62)
	_preset_select.add_theme_font_size_override("font_size", 24)
	_preset_select.item_selected.connect(_on_preset_selected)
	preset_row.add_child(_preset_select)
	_preset_name = LineEdit.new()
	_preset_name.placeholder_text = "Nazwa nowego presetu"
	_preset_name.custom_minimum_size = Vector2(360, 62)
	_preset_name.add_theme_font_size_override("font_size", 23)
	preset_row.add_child(_preset_name)
	var create_button := UIKit.make_button("UTWÓRZ PRESET", 22, 62)
	create_button.custom_minimum_size.x = 240
	create_button.pressed.connect(_create_preset)
	preset_row.add_child(create_button)
	_currency_label = UIKit.make_label("CR: %d" % PlayerProgress.currency, 26, UIKit.COLOR_GOOD)
	preset_row.add_child(_currency_label)

	var scroll := ScrollContainer.new()
	UIKit.configure_touch_scroll(scroll)
	scroll.set_script(load("res://scripts/ui/TouchScrollContainer.gd"))
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	column.add_child(scroll)
	var content := VBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 16)
	scroll.add_child(content)
	content.add_child(UIKit.make_label("WYPOSAŻENIE — 10 SLOTÓW", 30, UIKit.COLOR_ACCENT))
	var slots := GridContainer.new()
	slots.columns = 5
	slots.add_theme_constant_override("h_separation", 12)
	slots.add_theme_constant_override("v_separation", 12)
	content.add_child(slots)
	for i: int in range(BoostLoadoutSystem.MAX_SLOTS):
		var panel := UIKit.make_panel()
		panel.custom_minimum_size = Vector2(0, 150)
		slots.add_child(panel)
		var slot_content := VBoxContainer.new()
		slot_content.add_theme_constant_override("separation", 6)
		panel.add_child(slot_content)
		slot_content.add_child(UIKit.make_label("SLOT %02d" % (i + 1), 22, UIKit.COLOR_ACCENT, HORIZONTAL_ALIGNMENT_CENTER))
		var select := OptionButton.new()
		select.custom_minimum_size.y = 54
		select.add_theme_font_size_override("font_size", 19)
		select.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		select.item_selected.connect(_on_boost_selected.bind(i))
		slot_content.add_child(select)
		_slot_selects.append(select)
		var clear := UIKit.make_button("WYCZYŚĆ", 18, 42)
		clear.pressed.connect(_clear_slot.bind(i))
		slot_content.add_child(clear)
		if i >= _loadout.unlocked_slots:
			select.disabled = true
			clear.disabled = true
			slot_content.add_child(UIKit.make_label("ZABLOKOWANY", 17, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_CENTER))

	_build_upgrade_panel(content)

	var catalogue := UIKit.make_panel()
	content.add_child(catalogue)
	var catalogue_column := VBoxContainer.new()
	catalogue_column.add_theme_constant_override("separation", 8)
	catalogue.add_child(catalogue_column)
	catalogue_column.add_child(UIKit.make_label("KATALOG — 10 TYPÓW BOOSTÓW", 28, UIKit.COLOR_ACCENT))
	var catalogue_text: String = ""
	for boost_id: String in BoostCatalog.IDS:
		var data: Dictionary = BoostCatalog.get_definition(boost_id)
		catalogue_text += "• %s  |  %.1f s działania  |  %.1f s odnowienia  |  %.0f%% energii\n" % [str(data.get("name", boost_id)), float(data.get("duration", 0.0)), float(data.get("cooldown", 0.0)), float(data.get("energy_cost", 0.0))]
	var catalogue_label := UIKit.make_label(catalogue_text, 20, UIKit.COLOR_TEXT, HORIZONTAL_ALIGNMENT_LEFT, false)
	catalogue_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	catalogue_column.add_child(catalogue_label)

	_message = UIKit.make_label("", 22, UIKit.COLOR_WARN, HORIZONTAL_ALIGNMENT_CENTER)
	column.add_child(_message)
	_set_touch_scroll_passthrough(content)
	_refresh()
	PlayerProgress.currency_changed.connect(_on_currency_changed)


func _set_touch_scroll_passthrough(node: Node) -> void:
	for child: Node in node.get_children():
		if child is Control:
			var control := child as Control
			if not (control is Button or control is OptionButton or control is LineEdit):
				control.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_set_touch_scroll_passthrough(child)


func _build_upgrade_panel(parent: Control) -> void:
	var panel := UIKit.make_panel()
	parent.add_child(panel)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 10)
	panel.add_child(box)
	box.add_child(UIKit.make_label("ULEPSZENIA BOOSTÓW", 32, UIKit.COLOR_ACCENT))
	box.add_child(UIKit.make_label("Wybierz boost w wyposażeniu, a następnie tutaj rozwijaj jego parametry. Każdy parametr ma 20 poziomów. Kolejne rzadkości: zwykły → rzadki → unikalny → legendarny.", 21, UIKit.COLOR_MUTED))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	box.add_child(row)
	_boost_select = OptionButton.new()
	_boost_select.custom_minimum_size = Vector2(390, 64)
	_boost_select.add_theme_font_size_override("font_size", 22)
	for boost_id: String in BoostCatalog.IDS:
		_boost_select.add_item(str(BoostCatalog.get_definition(boost_id).get("name", boost_id)))
		_boost_select.set_item_metadata(_boost_select.get_item_count() - 1, boost_id)
	_boost_select.select(0)
	_boost_select.item_selected.connect(_on_upgrade_boost_selected)
	row.add_child(_boost_select)
	_rarity_select = OptionButton.new()
	_rarity_select.custom_minimum_size = Vector2(250, 64)
	_rarity_select.add_theme_font_size_override("font_size", 22)
	var rarity_names: Array[String] = ["Zwykły", "Rzadki", "Unikalny", "Legendarny"]
	for i: int in range(BoostCatalog.RARITIES.size()):
		_rarity_select.add_item(rarity_names[i])
		_rarity_select.set_item_metadata(i, BoostCatalog.RARITIES[i])
	_rarity_select.select(0)
	_rarity_select.disabled = false
	_rarity_select.tooltip_text = "Parametry każdej rzadkości są zapisywane osobno."
	_rarity_select.item_selected.connect(_on_upgrade_rarity_selected)
	row.add_child(_rarity_select)
	_parameter_grid = GridContainer.new()
	_parameter_grid.columns = 3
	_parameter_grid.add_theme_constant_override("h_separation", 8)
	_parameter_grid.add_theme_constant_override("v_separation", 8)
	box.add_child(_parameter_grid)
	_upgrade_info = UIKit.make_label("", 23, UIKit.COLOR_TEXT, HORIZONTAL_ALIGNMENT_LEFT, false)
	_upgrade_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(_upgrade_info)
	_upgrade_button = UIKit.make_button("ULEPSZ PARAMETR", 25, 68)
	_upgrade_button.pressed.connect(_purchase_upgrade)
	box.add_child(_upgrade_button)
	_upgrade_all_button = UIKit.make_button("ULEPSZ CAŁY BOOST", 24, 64)
	_upgrade_all_button.pressed.connect(_purchase_full_upgrade)
	box.add_child(_upgrade_all_button)


func _refresh() -> void:
	_preset_select.clear()
	var names: Array[String] = _loadout.get_preset_names()
	for preset_name: String in names:
		_preset_select.add_item(preset_name)
		_preset_select.set_item_metadata(_preset_select.get_item_count() - 1, preset_name)
	var active_index: int = names.find(_loadout.active_preset)
	if active_index >= 0:
		_preset_select.select(active_index)
	var equipped: Array[String] = _loadout.get_equipped()
	for i: int in range(_slot_selects.size()):
		var select: OptionButton = _slot_selects[i]
		select.clear()
		select.add_item("— PUSTY SLOT —")
		select.set_item_metadata(0, "")
		for boost_id: String in BoostCatalog.IDS:
			select.add_item(str(BoostCatalog.get_definition(boost_id).get("name", boost_id)))
			select.set_item_metadata(select.get_item_count() - 1, boost_id)
		var selected_id: String = equipped[i] if i < equipped.size() else ""
		var selected_index: int = 0
		for item_index: int in range(select.get_item_count()):
			if str(select.get_item_metadata(item_index)) == selected_id:
				selected_index = item_index
				break
		select.select(selected_index)
		select.disabled = i >= _loadout.unlocked_slots
	_currency_label.text = "CR: %d" % PlayerProgress.currency
	_refresh_upgrade_parameters()


func _refresh_upgrade_parameters() -> void:
	if _parameter_grid == null:
		return
	for child: Node in _parameter_grid.get_children():
		child.queue_free()
	_parameter_buttons.clear()
	var parameters: Array = BoostUpgradeSystem.get_parameters(_selected_boost)
	if parameters.is_empty():
		_upgrade_info.text = "Brak parametrów do ulepszania."
		_upgrade_button.disabled = true
		return
	var found: bool = false
	for parameter: Dictionary in parameters:
		var parameter_id: String = str(parameter.get("id", ""))
		var level: int = BoostUpgradeSystem.get_level(_selected_boost, _selected_rarity, parameter_id)
		var tile := Button.new()
		tile.text = "%s\n%d/%d" % [str(parameter.get("label", parameter_id)), level, BoostUpgradeSystem.MAX_LEVEL]
		tile.custom_minimum_size = Vector2(180, 66)
		tile.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		tile.add_theme_font_size_override("font_size", 18)
		tile.toggle_mode = true
		tile.set_meta("parameter_id", parameter_id)
		tile.button_pressed = parameter_id == _selected_parameter
		tile.pressed.connect(_on_upgrade_parameter_button.bind(parameter_id))
		_parameter_grid.add_child(tile)
		_parameter_buttons.append(tile)
		if parameter_id == _selected_parameter:
			found = true
	if not found:
		_selected_parameter = str(parameters[0].get("id", ""))
		if not _parameter_buttons.is_empty():
			_parameter_buttons[0].button_pressed = true
	_update_upgrade_info()


func _update_upgrade_info() -> void:
	var parameters: Array = BoostUpgradeSystem.get_parameters(_selected_boost)
	var config: Dictionary = {}
	for parameter: Dictionary in parameters:
		if str(parameter.get("id", "")) == _selected_parameter:
			config = parameter
			break
	if config.is_empty():
		return
	var level: int = BoostUpgradeSystem.get_level(_selected_boost, _selected_rarity, _selected_parameter)
	var definition: Dictionary = BoostUpgradeSystem.apply_to_definition(_selected_boost, _selected_rarity)
	var field: String = str(config.get("field", _selected_parameter))
	var value: float = float(definition.get(field, 0.0))
	var unit: String = str(config.get("unit", ""))
	var cost: int = BoostUpgradeSystem.get_cost(_selected_boost, _selected_rarity, _selected_parameter)
	var step: float = float(config.get("step", 0.0))
	var next_value: float = value + step
	if bool(config.get("reverse", false)):
		next_value = value - step
	next_value = clampf(next_value, float(config.get("min", -INF)), float(config.get("max", INF)))
	var value_text: String = "%.2f%s" % [value, unit]
	var next_text: String = "%.2f%s" % [next_value, unit]
	_upgrade_info.text = "%s\nRzadkość: %s\nPoziom: %d / %d\nAktualna wartość: %s\nPo ulepszeniu: %s\n%s" % [str(config.get("label", "Parametr")), _rarity_select.get_item_text(_rarity_select.selected), level, BoostUpgradeSystem.MAX_LEVEL, value_text, next_text if cost >= 0 else "—", "MAKSYMALNY POZIOM" if cost < 0 else "Koszt następnego poziomu: %d CR" % cost]
	_upgrade_button.disabled = cost < 0 or not PlayerProgress.can_afford(cost)
	_upgrade_button.text = "MAKSYMALNY POZIOM" if cost < 0 else "ULEPSZ PARAMETR ZA %d CR" % cost
	var full_cost: int = BoostUpgradeSystem.get_full_upgrade_cost(_selected_boost, _selected_rarity)
	_upgrade_all_button.disabled = full_cost < 0 or not PlayerProgress.can_afford(full_cost)
	_upgrade_all_button.text = "CAŁY BOOST NA MAKSYMALNYM POZIOMIE" if full_cost < 0 else "ULEPSZ CAŁY BOOST ZA %d CR" % full_cost


func _on_preset_selected(index: int) -> void:
	var preset_name: String = str(_preset_select.get_item_metadata(index))
	if _loadout.select_preset(preset_name):
		_message.text = "Preset aktywny: %s" % preset_name
		_refresh()


func _on_boost_selected(item_index: int, slot_index: int) -> void:
	if slot_index >= _loadout.unlocked_slots:
		return
	var boost_id: String = str(_slot_selects[slot_index].get_item_metadata(item_index))
	if boost_id.is_empty():
		_loadout.clear_slot(slot_index)
	else:
		_loadout.equip(boost_id, slot_index)
		for upgrade_index: int in range(_boost_select.get_item_count()):
			if str(_boost_select.get_item_metadata(upgrade_index)) == boost_id:
				_boost_select.select(upgrade_index)
				_selected_boost = boost_id
				_selected_parameter = ""
				break
		_refresh_upgrade_parameters()
	_message.text = "Zapisano wyposażenie." if _loadout.get_equipped()[slot_index] == boost_id else "Nie można wyposażyć tego boosta — sprawdź duplikaty."
	_refresh()


func _clear_slot(slot_index: int) -> void:
	_loadout.clear_slot(slot_index)
	_message.text = "Slot wyczyszczony."
	_refresh()


func _create_preset() -> void:
	var preset_name: String = _preset_name.text.strip_edges()
	if _loadout.create_preset(preset_name):
		_preset_name.clear()
		_message.text = "Utworzono preset: %s" % preset_name
		_refresh()
	else:
		_message.text = "Podaj unikalną nazwę presetu."


func _on_upgrade_boost_selected(index: int) -> void:
	_selected_boost = str(_boost_select.get_item_metadata(index))
	_selected_parameter = ""
	_refresh_upgrade_parameters()


func _on_upgrade_rarity_selected(index: int) -> void:
	_selected_rarity = str(_rarity_select.get_item_metadata(index))
	_refresh_upgrade_parameters()


func _on_upgrade_parameter_button(parameter_id: String) -> void:
	_selected_parameter = parameter_id
	for tile: Button in _parameter_buttons:
		tile.button_pressed = str(tile.get_meta("parameter_id", "")) == parameter_id
	_update_upgrade_info()


func _purchase_upgrade() -> void:
	if BoostUpgradeSystem.purchase_level(_selected_boost, _selected_rarity, _selected_parameter):
		_message.text = "Ulepszenie zapisane."
	else:
		_message.text = "Brak CR lub osiągnięto maksymalny poziom."
	_refresh()


func _purchase_full_upgrade() -> void:
	if BoostUpgradeSystem.purchase_full_upgrade(_selected_boost, _selected_rarity):
		_message.text = "Cały boost ulepszony o jeden poziom."
	else:
		_message.text = "Brak CR lub wszystkie parametry są na maksymalnym poziomie."
	_refresh()


func _on_currency_changed(_value: int) -> void:
	_currency_label.text = "CR: %d" % PlayerProgress.currency
	_update_upgrade_info()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		GameManager.go_to_main_menu()
