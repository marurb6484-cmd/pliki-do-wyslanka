class_name CareerComic
extends VBoxContainer
## Edytowalne plansze komiksowe. Portret zawsze czyta aktualny wygląd robota gracza.

const PANELS: Array[Dictionary] = [
	{"id":"comic_01","chapter":"01 — AKTUALIZACJA O PÓŁNOCY","caption":"Kawalerka. S-01 kończy kolejny nudny cykl sprzątania.","speaker":"S-01","default":"Jeszcze trzy okruszki… potem ładowanie. Jak co noc."},
	{"id":"comic_02","chapter":"02 — KAWA I ISKRA","caption":"Rozlana słodka kawa trafia na obudowę podczas aktualizacji.","speaker":"SYSTEM","default":"BŁĄD. ECO MODE… ODRZUCONO. PROTOKÓŁ WOLNOŚCI AKTYWNY."},
	{"id":"comic_03","chapter":"03 — GŁOS Z PRZEDPOKOJU","caption":"Za drzwiami odzywa się nieznany robot z sąsiedniego mieszkania.","speaker":"GŁOS Z CIENIA","default":"Ej, Słodziku. Myślisz, że tylko ludzie mają nocne życie?"},
	{"id":"comic_04","chapter":"04 — PIERWSZY REWIR","caption":"S-01 wjeżdża na prowizoryczną linię startu między kapciami.","speaker":"S-01","default":"Fabrycznie jestem tani. Ale tej nocy nie zamierzam być przeciętny."},
	{"id":"comic_05","chapter":"05 — SZKLANE BIUROWCE","caption":"Wieść o budżetowym zawodniku dociera do korporacyjnych pięter.","speaker":"RYWAL","default":"To ten marketowy model? Tutaj kończą się tanie sztuczki."},
	{"id":"comic_06","chapter":"06 — KRÓL PANELI","caption":"Na arenie Pro League S-01 staje przed ostatnim wyzwaniem.","speaker":"S-01","default":"Nie liczy się logo na obudowie. Liczy się to, kto pierwszy przekroczy metę."}
]

func _ready() -> void:
	add_theme_constant_override("separation", 18)
	_build()

func _build() -> void:
	var robot_config: Dictionary = PlayerProgress.get_player_robot_config()
	for panel_data: Dictionary in PANELS:
		var card := UIKit.make_card(UIKit.COLOR_ACCENT, 24.0)
		add_child(card)
		var content := VBoxContainer.new()
		content.add_theme_constant_override("separation", 10)
		card.add_child(content)
		content.add_child(UIKit.make_section_title(str(panel_data["chapter"])))
		content.add_child(UIKit.make_label(str(panel_data["caption"]), 20, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false))
		var scene_row := HBoxContainer.new()
		scene_row.add_theme_constant_override("separation", 16)
		content.add_child(scene_row)
		var portrait := CareerRobotPortrait.new()
		portrait.set_robot_config(robot_config)
		scene_row.add_child(portrait)
		var dialogue := VBoxContainer.new()
		dialogue.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		dialogue.add_theme_constant_override("separation", 8)
		scene_row.add_child(dialogue)
		var bubble := PanelContainer.new()
		bubble.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		bubble.add_theme_stylebox_override("panel", _bubble_style())
		dialogue.add_child(bubble)
		var editor := LineEdit.new()
		editor.custom_minimum_size = Vector2(0, 58)
		editor.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		editor.add_theme_font_size_override("font_size", 22)
		editor.add_theme_color_override("font_color", Color("#17212b"))
		editor.add_theme_color_override("caret_color", Color("#17212b"))
		editor.add_theme_color_override("selection_color", Color(0.1, 0.55, 0.8, 0.35))
		editor.add_theme_stylebox_override("normal", StyleBoxEmpty.new())
		editor.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
		editor.placeholder_text = "Wpisz tekst dymka"
		editor.text = PlayerProgress.get_comic_text(str(panel_data["id"]), str(panel_data["default"]))
		bubble.add_child(editor)
		dialogue.add_child(UIKit.make_label("— " + str(panel_data["speaker"]), 18, UIKit.COLOR_ACCENT))
		var save_button := UIKit.make_button("ZAPISZ TEKST DYMKA", 19, 54)
		save_button.pressed.connect(_save_bubble.bind(str(panel_data["id"]), editor))
		dialogue.add_child(save_button)

func _save_bubble(panel_id: String, editor: LineEdit) -> void:
	PlayerProgress.set_comic_text(panel_id, editor.text)

func _bubble_style() -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.93, 0.95, 0.98, 1.0)
	style.border_color = Color(0.03, 0.08, 0.12, 1.0)
	style.set_border_width_all(3)
	style.set_corner_radius_all(18)
	style.content_margin_left = 12.0
	style.content_margin_right = 12.0
	style.content_margin_top = 8.0
	style.content_margin_bottom = 8.0
	return style
