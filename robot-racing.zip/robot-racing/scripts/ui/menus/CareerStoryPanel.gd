class_name CareerStoryPanel
extends VBoxContainer

const CareerRobotPortraitScript = preload("res://scripts/ui/hud/CareerRobotPortrait.gd")
## Komiksowy moduł narracji używany bezpośrednio w trybie kariery.
## Ten sam komponent obsługuje sceny przed wyścigiem, po wyścigu i między wydarzeniami.

signal sequence_finished

var event_index: int = 0
var phase: String = "intro"
var advanced: bool = true
var _pages: Array[Dictionary] = []
var _page_index: int = 0
var _content: VBoxContainer
var _next_button: Button


func configure(index: int, story_phase: String, was_advanced: bool = true) -> void:
	event_index = clampi(index, 0, CareerCampaign.count() - 1)
	phase = story_phase
	advanced = was_advanced


func _ready() -> void:
	add_theme_constant_override("separation", 12)
	_pages = _make_pages()
	_build_page()


func _make_pages() -> Array[Dictionary]:
	var event: Dictionary = CareerCampaign.get_event(event_index)
	var event_title: String = str(event.get("title", "Następny wyścig"))
	var location: String = str(event.get("location", "Nieznana trasa"))
	var boss_name: String = str(event.get("boss_name", "lokalny rywal"))
	var pages: Array[Dictionary] = []
	match phase:
		"intro":
			if event_index == 0:
				pages.append({"chapter":"PROTOKÓŁ WOLNOŚCI", "caption":"Późna noc. Mała kawalerka. Stacja dokująca właśnie kończy ładowanie taniego modelu S-01.", "speaker":"S-01", "dialogue":"Cykl sprzątania zakończony. Bateria pełna. Jutro znowu to samo…"})
				pages.append({"chapter":"NIEAUTORYZOWANA ZMIANA", "caption":"Przypadkowe zwarcie podczas aktualizacji wybudza ukryty tryb. Na ekranie pojawia się komunikat, którego nie przewidział producent.", "speaker":"SYSTEM", "dialogue":"ECO MODE odrzucono. PROTOKÓŁ WOLNOŚCI aktywny. Wykryto nieautoryzowany wyścig."})
			else:
				pages.append({"chapter":"KOLEJNY KROK S-01", "caption":"Po ostatnim starcie plotki o małym robocie rozchodzą się po okolicy. Następny rewir już czeka.", "speaker":"S-01", "dialogue":"Nie wystarczy wygrać raz. Muszę pokazać, że to nie był przypadek."})
				pages.append({"chapter":"NOWE WYZWANIE", "caption":"Na ekranie garażowego terminala pojawia się zaproszenie na wydarzenie: %s." % event_title, "speaker":"SYSTEM", "dialogue":"Lokalizacja: %s. Cel: %s" % [location, str(event.get("goal", "Ukończ wyścig."))]})		
		"after":
			if advanced:
				pages.append({"chapter":"META — ALE NIE KONIEC", "caption":"S-01 przekracza linię mety. Przez chwilę słychać tylko szum szczotek i sygnały rywali.", "speaker":"S-01", "dialogue":"Udało się. Każdy kolejny wyścig będzie trudniejszy… i właśnie o to chodzi."})
				pages.append({"chapter":"WIEŚĆ IDZIE DALEJ", "caption":"Wynik trafia do lokalnej sieci robotów. Ktoś z wyższego poziomu obserwuje postępy S-01.", "speaker":"NIEZNANY NADAWCA", "dialogue":"Ten budżetowy model robi się problemem. Przygotować następne wyzwanie."})
			else:
				pages.append({"chapter":"NIE KAŻDY START KOŃCZY SIĘ ZWYCIĘSTWEM", "caption":"S-01 wraca do stacji serwisowej. Wynik nie wystarczył do awansu, ale zapis danych pozwala przeanalizować błędy.", "speaker":"S-01", "dialogue":"Jeszcze nie tym razem. Poprawię ustawienia, naprawię obudowę i wrócę na trasę."})
				pages.append({"chapter":"RYWALE NIE CZEKAJĄ", "caption":"Wiadomość od rywala pojawia się na ekranie garażu.", "speaker":"RYWAL", "dialogue":"Następnym razem nie licz na taryfę ulgową."})
		"interlude":
			pages.append({"chapter":"POMIĘDZY WYŚCIGAMI", "caption":"Po wydarzeniu S-01 analizuje trasę, zużycie baterii i uszkodzenia. W garażu zaczyna się kolejny etap przygotowań.", "speaker":"S-01", "dialogue":"Każdy wyścig czegoś mnie uczy. Czas sprawdzić, co mogę ulepszyć przed następnym startem."})
			if event_index < CareerCampaign.count() - 1:
				var next_event: Dictionary = CareerCampaign.get_event(event_index + 1)
				pages.append({"chapter":"NA HORYZONCIE", "caption":"Kolejne zgłoszenie czeka: %s — %s." % [str(next_event.get("title", "Wydarzenie")), str(next_event.get("location", ""))], "speaker":"SYSTEM", "dialogue":"Nowy cel: %s" % str(next_event.get("goal", "Przygotuj się do wyścigu."))})
			else:
				pages.append({"chapter":"OSTATNI ROZDZIAŁ", "caption":"Wszystkie wydarzenia kampanii zostały ukończone. S-01 stał się symbolem niezależnych robotów.", "speaker":"S-01", "dialogue":"Nie potrzebuję drogiego logo. Wystarczy odwaga, spryt i dobrze dobrany tuning."})
		_:
			pages.append({"chapter":"HISTORIA S-01", "caption":"Kolejny rozdział kariery robota S-01.", "speaker":"S-01", "dialogue":event_title})
	return pages


func _build_page() -> void:
	for child: Node in get_children():
		child.queue_free()
	var page: Dictionary = _pages[_page_index]
	var card := UIKit.make_card(UIKit.COLOR_ACCENT, 24.0)
	add_child(card)
	_content = VBoxContainer.new()
	_content.add_theme_constant_override("separation", 10)
	card.add_child(_content)
	_content.add_child(UIKit.make_section_title(str(page.get("chapter", "KARIERA"))))
	var caption := UIKit.make_label(str(page.get("caption", "")), 21, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false)
	caption.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_content.add_child(caption)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 16)
	_content.add_child(row)
	var portrait := CareerRobotPortraitScript.new()
	portrait.set_robot_config(PlayerProgress.get_player_robot_config())
	row.add_child(portrait)
	var dialogue_column := VBoxContainer.new()
	dialogue_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(dialogue_column)
	var bubble := PanelContainer.new()
	var style := StyleBoxFlat.new()
	style.bg_color = Color("#edf3f8")
	style.border_color = Color("#101820")
	style.set_border_width_all(3)
	style.set_corner_radius_all(16)
	style.content_margin_left = 14.0
	style.content_margin_right = 14.0
	style.content_margin_top = 12.0
	style.content_margin_bottom = 12.0
	bubble.add_theme_stylebox_override("panel", style)
	dialogue_column.add_child(bubble)
	var dialogue := UIKit.make_label(str(page.get("dialogue", "")), 23, Color("#17212b"), HORIZONTAL_ALIGNMENT_LEFT, false)
	dialogue.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	bubble.add_child(dialogue)
	dialogue_column.add_child(UIKit.make_label("— " + str(page.get("speaker", "S-01")), 18, UIKit.COLOR_ACCENT))
	add_child(UIKit.make_label("KADR %d / %d" % [_page_index + 1, _pages.size()], 17, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_RIGHT))
	_next_button = UIKit.make_button(_button_label(), 24, 66)
	_next_button.pressed.connect(_advance)
	add_child(_next_button)


func _button_label() -> String:
	if _page_index < _pages.size() - 1:
		return "DALEJ  →"
	match phase:
		"intro": return "ROZPOCZNIJ WYŚCIG"
		"after": return "WRÓĆ DO KARIERY"
		_: return "KONTYNUUJ KARIĘ"


func _advance() -> void:
	if _page_index < _pages.size() - 1:
		_page_index += 1
		_build_page()
	else:
		sequence_finished.emit()
