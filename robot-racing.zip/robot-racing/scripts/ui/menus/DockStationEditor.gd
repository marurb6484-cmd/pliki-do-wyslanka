
class_name DockStationEditor
extends Control
## Edytor stacji dokującej.
## Logika danych i wizualizacja są wydzielone do osobnych skryptów.

const SAVE_SECTION: String = "docking_stations"

var _robot_index: int = 0
var _data: Dictionary = {}

var _preview_root: Node3D
var _preview_camera: Camera3D
var _preview_zoom: HSlider
var _station_model: Node3D
var _station_visuals: StationVisuals
var _preview_dragging: bool = false
var _preview_last_pointer: Vector2 = Vector2.ZERO
var _preview_vertical_offset: float = 0.28

var _led_picker: ColorPickerButton
var _type_box: HBoxContainer
var _level_box: VBoxContainer
var _service_box: VBoxContainer
var _bonus_box: VBoxContainer

var _rotation_label: Label
var _rotation_slider: HSlider
var _status: Label
var _currency_label: Label
var _slots_label: Label

var _controls_scroll: ScrollContainer

var _dirty: bool = false
var _has_loaded: bool = false
var _ui_ready: bool = false


func _ready() -> void:
	_station_visuals = StationVisuals.new()

	_build_ui()
	_ui_ready = true

	if not PlayerProgress.currency_changed.is_connected(_on_currency_changed):
		PlayerProgress.currency_changed.connect(_on_currency_changed)

	set_robot_index(_robot_index)


# =========================================================
# DANE STACJI
# =========================================================

func set_robot_index(index: int) -> void:
	var robot_count: int = RobotDatabase.count()

	if robot_count <= 0:
		return

	var safe_index: int = clampi(index, 0, robot_count - 1)

	if _has_loaded and safe_index == _robot_index:
		return

	if _dirty:
		_save_data(false)

	_robot_index = safe_index

	var robot: Dictionary = RobotDatabase.get_robot(_robot_index)

	var saved: Dictionary = SaveManager.get_dict(
		SAVE_SECTION,
		str(_robot_index)
	)

	_data = StationConfig.normalize(
		saved,
		robot["color"]
	)

	_has_loaded = true
	_dirty = false

	_refresh_ui()
	_update_preview()


func _normalize_equipped_bonuses() -> void:
	_data = StationConfig.normalize_equipped_bonuses(_data)


func _save_data(show_message: bool = true) -> void:
	if not _has_loaded:
		return

	SaveManager.set_value(
		SAVE_SECTION,
		str(_robot_index),
		_data.duplicate(true)
	)

	SaveManager.save_now()

	_dirty = false

	if show_message and _status != null:
		var robot: Dictionary = RobotDatabase.get_robot(_robot_index)

		_status.text = "ZAPISANO STACJĘ DLA: %s" % str(
			robot["name"]
		)

		_status.add_theme_color_override(
			"font_color",
			UIKit.COLOR_GOOD
		)


func _save() -> void:
	_save_data(true)


func _on_currency_changed(_value: int) -> void:
	if _ui_ready and _has_loaded:
		_refresh_ui()


# =========================================================
# BUDOWA INTERFEJSU
# =========================================================

func _build_ui() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var layout := HBoxContainer.new()
	layout.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layout.add_theme_constant_override("separation", 22)
	add_child(layout)

	_build_preview_panel(layout)
	_build_controls_panel(layout)


func _build_preview_panel(layout: HBoxContainer) -> void:
	var panel := UIKit.make_panel(
		Color(0.025, 0.045, 0.07, 0.96)
	)

	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.size_flags_stretch_ratio = 1.25
	layout.add_child(panel)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 8)
	panel.add_child(column)

	column.add_child(
		UIKit.make_label(
			"PODGLĄD STACJI",
			34,
			UIKit.COLOR_ACCENT,
			HORIZONTAL_ALIGNMENT_CENTER
		)
	)

	var viewport_container := SubViewportContainer.new()
	viewport_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	viewport_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	viewport_container.custom_minimum_size = Vector2(0, 420)
	viewport_container.stretch = true
	viewport_container.mouse_filter = Control.MOUSE_FILTER_STOP
	viewport_container.gui_input.connect(_on_preview_input)
	column.add_child(viewport_container)

	var viewport := SubViewport.new()
	viewport.size = Vector2i(1000, 650)
	viewport.own_world_3d = true
	viewport.transparent_bg = true

	viewport.msaa_3d = (
		Viewport.MSAA_2X
		if GameSettings.quality >= GameSettings.Quality.HIGH
		else Viewport.MSAA_DISABLED
	)

	viewport_container.add_child(viewport)

	var world := WorldEnvironment.new()
	var env := Environment.new()

	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.025, 0.045, 0.07)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.65, 0.75, 0.9)
	env.ambient_light_energy = 0.85
	env.glow_enabled = GameSettings.glow_allowed()

	world.environment = env
	viewport.add_child(world)

	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-38, -28, 0)
	light.light_energy = 1.5
	light.shadow_enabled = GameSettings.shadows_enabled
	viewport.add_child(light)

	_preview_root = Node3D.new()
	viewport.add_child(_preview_root)

	_preview_camera = Camera3D.new()
	_preview_camera.position = Vector3(3.5, 2.4, 4.6)
	_preview_camera.fov = 31.0
	viewport.add_child(_preview_camera)
	_preview_camera.look_at(Vector3(0, 0.42, 0), Vector3.UP)

	var zoom_row := HBoxContainer.new()
	zoom_row.add_theme_constant_override("separation", 8)
	zoom_row.add_child(UIKit.make_label("ZOOM", 22, UIKit.COLOR_MUTED))
	var zoom_out := UIKit.make_button("−", 24, 46)
	zoom_out.pressed.connect(func() -> void: _change_station_zoom(-0.15))
	zoom_row.add_child(zoom_out)
	_preview_zoom = HSlider.new()
	_preview_zoom.min_value = 1.6
	_preview_zoom.max_value = 4.8
	_preview_zoom.step = 0.1
	_preview_zoom.value = 3.0
	_preview_zoom.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_preview_zoom.value_changed.connect(_set_station_zoom)
	_set_station_zoom(_preview_zoom.value)
	zoom_row.add_child(_preview_zoom)
	var zoom_in := UIKit.make_button("+", 24, 46)
	zoom_in.pressed.connect(func() -> void: _change_station_zoom(0.15))
	zoom_row.add_child(zoom_in)
	column.add_child(zoom_row)

	column.add_child(
		UIKit.make_label(
			"PRZESUŃ PALCEM: OBRÓT I WYSOKOŚĆ PODGLĄDU",
			22,
			UIKit.COLOR_MUTED,
			HORIZONTAL_ALIGNMENT_CENTER
		)
	)

	var rotation_row := HBoxContainer.new()
	rotation_row.add_child(
		UIKit.make_label("OBRÓT STACJI", 26)
	)

	_rotation_label = UIKit.make_label(
		"0°",
		27,
		UIKit.COLOR_ACCENT
	)

	rotation_row.add_child(_rotation_label)
	column.add_child(rotation_row)

	_rotation_slider = UIKit.make_slider(
		0.0,
		359.0,
		1.0,
		0.0
	)

	_rotation_slider.value_changed.connect(_on_rotation_changed)
	column.add_child(_rotation_slider)


func _change_station_zoom(delta: float) -> void:
	if _preview_zoom != null:
		_preview_zoom.value = clampf(_preview_zoom.value + delta, _preview_zoom.min_value, _preview_zoom.max_value)


func _set_station_zoom(value: float) -> void:
	if _preview_camera != null:
		_preview_camera.fov = 48.0 / maxf(value, 0.1)


func _build_controls_panel(layout: HBoxContainer) -> void:
	_controls_scroll = ScrollContainer.new()
	_controls_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_controls_scroll.size_flags_stretch_ratio = 1.0
	_controls_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_controls_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	_controls_scroll.mouse_filter = Control.MOUSE_FILTER_STOP
	layout.add_child(_controls_scroll)

	var controls := VBoxContainer.new()
	controls.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	controls.add_theme_constant_override("separation", 12)
	_controls_scroll.add_child(controls)

	var header := HBoxContainer.new()
	controls.add_child(header)

	header.add_child(
		UIKit.make_label(
			"PERSONALIZACJA STACJI",
			34,
			UIKit.COLOR_ACCENT
		)
	)

	_currency_label = UIKit.make_label(
		"0 CR",
		30,
		UIKit.COLOR_GOOD
	)

	_currency_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_currency_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	header.add_child(_currency_label)

	controls.add_child(
		UIKit.make_label(
			"TYP KONSTRUKCJI",
			30,
			UIKit.COLOR_ACCENT
		)
	)

	_type_box = HBoxContainer.new()
	_type_box.add_theme_constant_override("separation", 8)
	controls.add_child(_type_box)

	controls.add_child(
		UIKit.make_label(
			"POZIOM STACJI",
			30,
			UIKit.COLOR_ACCENT
		)
	)

	_level_box = VBoxContainer.new()
	_level_box.add_theme_constant_override("separation", 8)
	controls.add_child(_level_box)

	controls.add_child(
		UIKit.make_label(
			"KOLOR OBUDOWY",
			25,
			UIKit.COLOR_ACCENT
		)
	)

	controls.add_child(
		UIKit.make_label(
			"Kolor obudowy jest automatycznie dopasowany do robota.",
			22,
			UIKit.COLOR_MUTED
		)
	)

	controls.add_child(
		UIKit.make_label(
			"PODŚWIETLENIE LED",
			25,
			UIKit.COLOR_ACCENT
		)
	)

	_led_picker = ColorPickerButton.new()
	_led_picker.custom_minimum_size.y = 64
	_led_picker.color_changed.connect(_on_led_color)
	controls.add_child(_led_picker)

	controls.add_child(
		UIKit.make_label(
			"MODUŁY SERWISOWE",
			30,
			UIKit.COLOR_ACCENT
		)
	)

	controls.add_child(
		UIKit.make_label(
			"Kup moduły i aktywuj je w swojej stacji.",
			22,
			UIKit.COLOR_MUTED
		)
	)

	_service_box = VBoxContainer.new()
	_service_box.add_theme_constant_override("separation", 8)
	controls.add_child(_service_box)

	controls.add_child(
		UIKit.make_label(
			"MODUŁY BONUSOWE",
			30,
			UIKit.COLOR_ACCENT
		)
	)

	_slots_label = UIKit.make_label(
		"SLOTY: 0/1",
		26,
		UIKit.COLOR_GOOD
	)

	controls.add_child(_slots_label)

	controls.add_child(
		UIKit.make_label(
			"Bonusy musisz najpierw kupić. Możesz je później dowolnie zmieniać.",
			22,
			UIKit.COLOR_MUTED
		)
	)

	_bonus_box = VBoxContainer.new()
	_bonus_box.add_theme_constant_override("separation", 8)
	controls.add_child(_bonus_box)

	var save_button := UIKit.make_button(
		"ZAPISZ WYGLĄD STACJI",
		30,
		86
	)

	save_button.pressed.connect(_save)
	controls.add_child(save_button)

	_status = UIKit.make_label(
		"Zmiany nie są zapisane.",
		22,
		UIKit.COLOR_WARN,
		HORIZONTAL_ALIGNMENT_CENTER,
		false
	)

	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	controls.add_child(_status)


# =========================================================
# ODŚWIEŻANIE INTERFEJSU
# =========================================================

func _refresh_ui() -> void:
	if not _ui_ready or not _has_loaded:
		return

	_currency_label.text = "%d CR" % PlayerProgress.currency

	var robot: Dictionary = RobotDatabase.get_robot(_robot_index)
	_data["body_color"] = robot["color"]

	_led_picker.color = _data["led_color"]

	_rotation_label.text = "%d°" % int(
		_data["rotation_degrees"]
	)

	_rotation_slider.set_value_no_signal(
		float(_data["rotation_degrees"])
	)

	_refresh_types()
	_refresh_levels()
	_refresh_service_modules()
	_refresh_bonus_modules()


func _clear_box(box: Control) -> void:
	for child: Node in box.get_children():
		box.remove_child(child)
		child.queue_free()


# =========================================================
# KARTA MODUŁU - TEKST + OSOBNY PRZYCISK
# =========================================================

func _make_card(
	title: String,
	description: String,
	action_text: String,
	disabled: bool,
	callback: Callable
) -> PanelContainer:
	var panel := UIKit.make_panel(
		Color(0.04, 0.07, 0.1, 0.94)
	)

	# Karta nie przechwytuje dotyku.
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE

	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 12)
	panel.add_child(row)

	# Lewa strona: zwykłe napisy.
	var text_column := VBoxContainer.new()
	text_column.mouse_filter = Control.MOUSE_FILTER_IGNORE
	text_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	text_column.add_theme_constant_override("separation", 4)
	row.add_child(text_column)

	var title_label := UIKit.make_label(
		title,
		26,
		UIKit.COLOR_TEXT
	)
	title_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	text_column.add_child(title_label)

	var desc := UIKit.make_label(
		description,
		21,
		UIKit.COLOR_MUTED,
		HORIZONTAL_ALIGNMENT_LEFT,
		false
	)

	desc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	text_column.add_child(desc)

	# Prawa strona: tylko przycisk akcji.
	var button := UIKit.make_button(
		action_text,
		24,
		82
	)

	button.custom_minimum_size.x = 250
	button.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	button.disabled = disabled
	button.pressed.connect(callback)
	row.add_child(button)

	return panel


# =========================================================
# TYP STACJI
# =========================================================

func _refresh_types() -> void:
	_clear_box(_type_box)

	for i: int in range(StationDatabase.STATION_TYPES.size()):
		var selected: bool = int(_data["type"]) == i

		var button := UIKit.make_button(
			("✔ " if selected else "") + StationDatabase.STATION_TYPES[i],
			23,
			76
		)

		button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		button.disabled = selected
		button.pressed.connect(_on_type_changed.bind(i))

		_type_box.add_child(button)


func _on_type_changed(index: int) -> void:
	_data["type"] = clampi(
		index,
		0,
		StationDatabase.STATION_TYPES.size() - 1
	)

	_update_preview()
	_mark_dirty("Zmieniono typ stacji.")
	_refresh_ui()


# =========================================================
# POZIOMY KONSTRUKCJI
# =========================================================

func _refresh_levels() -> void:
	_clear_box(_level_box)

	var current_level: int = int(_data["level"])

	var current_label := UIKit.make_label(
		"AKTUALNY POZIOM: %d  |  %d SLOTÓW BONUSOWYCH" % [
			current_level,
			current_level
		],
		25,
		UIKit.COLOR_GOOD
	)

	_level_box.add_child(current_label)

	if current_level >= StationDatabase.get_max_level():
		_level_box.add_child(
			UIKit.make_label(
				"MAKSYMALNY POZIOM KONSTRUKCJI",
				23,
				UIKit.COLOR_ACCENT
			)
		)
		return

	var next_level: int = current_level + 1
	var cost: int = StationDatabase.get_level_cost(current_level)

	var description: String = (
		"Odblokuje poziom %d i %d sloty na moduły bonusowe."
		% [next_level, next_level]
	)

	var button_text: String = "ULEPSZ  %d CR" % cost

	var card := _make_card(
		"POZIOM %d → %d" % [current_level, next_level],
		description,
		button_text,
		not PlayerProgress.can_afford(cost),
		_on_buy_level
	)

	_level_box.add_child(card)


func _on_buy_level() -> void:
	var current_level: int = int(_data["level"])

	if current_level >= StationDatabase.get_max_level():
		return

	var cost: int = StationDatabase.get_level_cost(current_level)

	if not PlayerProgress.spend(cost):
		_set_status("Za mało CR na ulepszenie stacji.", false)
		return

	_data["level"] = current_level + 1

	_normalize_equipped_bonuses()

	_save_data(false)
	_update_preview()
	_refresh_ui()

	_set_status(
		"Zakupiono poziom %d stacji!" % int(_data["level"]),
		true
	)


# =========================================================
# MODUŁY SERWISOWE
# =========================================================

func _refresh_service_modules() -> void:
	_clear_box(_service_box)

	var owned: Array = _data["service_owned"]
	var equipped: Array = _data["service_equipped"]

	for module: Dictionary in StationDatabase.SERVICE_MODULES:
		var module_id: String = str(module["id"])
		var is_owned: bool = owned.has(module_id)
		var is_equipped: bool = equipped.has(module_id)

		var action_text: String
		var disabled: bool = false
		var callback: Callable

		if not is_owned:
			action_text = "KUP %d CR" % int(module["cost"])
			disabled = not PlayerProgress.can_afford(int(module["cost"]))
			callback = _on_buy_service.bind(module_id)
		elif is_equipped:
			action_text = "ZAMONTOWANO"
			callback = _on_toggle_service.bind(module_id)
		else:
			action_text = "ZAMONTUJ"
			callback = _on_toggle_service.bind(module_id)

		var panel := _make_card(
			str(module["name"]),
			_module_description(module_id),
			action_text,
			disabled,
			callback
		)

		_service_box.add_child(panel)


func _on_buy_service(module_id: String) -> void:
	var module: Dictionary = StationDatabase.find_service_module(module_id)

	if module.is_empty():
		return

	var owned: Array = _data["service_owned"]

	if owned.has(module_id):
		return

	var cost: int = int(module["cost"])

	if not PlayerProgress.spend(cost):
		_set_status("Za mało CR na ten moduł.", false)
		return

	owned.append(module_id)
	_data["service_owned"] = owned

	var equipped: Array = _data["service_equipped"]

	if not equipped.has(module_id):
		equipped.append(module_id)

	_data["service_equipped"] = equipped

	_save_data(false)
	_update_preview()
	_refresh_ui()

	_set_status(
		"Zakupiono moduł: %s" % str(module["name"]),
		true
	)


func _on_toggle_service(module_id: String) -> void:
	var owned: Array = _data["service_owned"]

	if not owned.has(module_id):
		return

	var equipped: Array = _data["service_equipped"]

	if equipped.has(module_id):
		equipped.erase(module_id)
	else:
		equipped.append(module_id)

	_data["service_equipped"] = equipped

	_save_data(false)
	_update_preview()
	_refresh_ui()


# =========================================================
# MODUŁY BONUSOWE
# =========================================================

func _refresh_bonus_modules() -> void:
	_clear_box(_bonus_box)

	var owned: Array = _data["bonus_owned"]
	var equipped: Array = _data["bonus_equipped"]

	var level: int = int(_data["level"])
	var used_slots: int = equipped.size()

	_slots_label.text = "ZAJĘTE SLOTY: %d/%d" % [
		used_slots,
		level
	]

	for module: Dictionary in StationDatabase.BONUS_MODULES:
		var module_id: String = str(module["id"])
		var is_owned: bool = owned.has(module_id)
		var is_equipped: bool = equipped.has(module_id)

		var action_text: String
		var disabled: bool = false
		var callback: Callable

		if not is_owned:
			action_text = "KUP %d CR" % int(module["cost"])
			disabled = not PlayerProgress.can_afford(int(module["cost"]))
			callback = _on_buy_bonus.bind(module_id)
		elif is_equipped:
			action_text = "ZDEJMIJ"
			callback = _on_toggle_bonus.bind(module_id)
		else:
			action_text = "ZAŁÓŻ"
			disabled = used_slots >= level
			callback = _on_toggle_bonus.bind(module_id)

		var panel := _make_card(
			str(module["name"]),
			_module_description(module_id),
			action_text,
			disabled,
			callback
		)

		_bonus_box.add_child(panel)


func _on_buy_bonus(module_id: String) -> void:
	var module: Dictionary = StationDatabase.find_bonus_module(module_id)

	if module.is_empty():
		return

	var owned: Array = _data["bonus_owned"]

	if owned.has(module_id):
		return

	var cost: int = int(module["cost"])

	if not PlayerProgress.spend(cost):
		_set_status("Za mało CR na ten bonus.", false)
		return

	owned.append(module_id)
	_data["bonus_owned"] = owned

	var equipped: Array = _data["bonus_equipped"]
	var level: int = int(_data["level"])

	if equipped.size() < level:
		equipped.append(module_id)
		_data["bonus_equipped"] = equipped

	_save_data(false)
	_update_preview()
	_refresh_ui()

	_set_status(
		"Zakupiono bonus: %s" % str(module["name"]),
		true
	)


func _on_toggle_bonus(module_id: String) -> void:
	var owned: Array = _data["bonus_owned"]

	if not owned.has(module_id):
		return

	var equipped: Array = _data["bonus_equipped"]
	var level: int = int(_data["level"])

	if equipped.has(module_id):
		equipped.erase(module_id)
	else:
		if equipped.size() >= level:
			_set_status(
				"Brak wolnych slotów. Ulepsz stację.",
				false
			)
			return

		equipped.append(module_id)

	_data["bonus_equipped"] = equipped

	_save_data(false)
	_update_preview()
	_refresh_ui()


# =========================================================
# OPISY MODUŁÓW
# =========================================================

func _module_description(module_id: String) -> String:
	match module_id:
		"repair_arm":
			return "Mechaniczny moduł obsługi i naprawy robota."
		"cleaning_system":
			return "Dodatkowy moduł czyszczący stację i robota."
		"power_coil":
			return "Rozbudowany moduł zasilania stacji."
		"shield_frame":
			return "Dodatkowe panele ochronne konstrukcji."
		"quick_charge":
			return "Większy zapas boosta na starcie."
		"turbo_start":
			return "Krótkie przyspieszenie po starcie."
		"traction":
			return "Lepsza przyczepność na początku wyścigu."
		"dirt_storage":
			return "Większa pojemność na początku wyścigu."
		"stabilizer":
			return "Mniejsze skutki utraty kontroli."
		"aero":
			return "Krótkotrwały bonus prędkości."

	return "Moduł rozbudowy stacji dokującej."


# =========================================================
# PODGLĄD 3D
# =========================================================

func _update_preview() -> void:
	if _preview_root == null or not _has_loaded:
		return

	if not is_instance_valid(_station_model):
		_station_model = Node3D.new()
		_station_model.name = "StationModel"
		_preview_root.add_child(_station_model)
		_preview_root.position.y = _preview_vertical_offset

	_station_model.rotation_degrees.y = float(
		_data["rotation_degrees"]
	)

	_station_visuals.build(
		_station_model,
		_data
	)


# =========================================================
# KOLORY I OBRÓT
# =========================================================

func _on_led_color(color: Color) -> void:
	_data["led_color"] = color

	_update_preview()
	_mark_dirty("Zmieniono kolor podświetlenia LED.")


func _on_rotation_changed(value: float) -> void:
	_data["rotation_degrees"] = value

	_rotation_label.text = "%d°" % int(value)

	_update_preview()
	_mark_dirty("Zmieniono obrót stacji.")


func _on_preview_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var touch := event as InputEventScreenTouch
		_preview_dragging = touch.pressed
		_preview_last_pointer = touch.position
		get_viewport().set_input_as_handled()
	elif event is InputEventScreenDrag and _preview_dragging:
		var drag := event as InputEventScreenDrag
		_rotate_station_preview(drag.relative)
		_preview_last_pointer = drag.position
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton:
		var button := event as InputEventMouseButton
		if button.button_index == MOUSE_BUTTON_LEFT:
			_preview_dragging = button.pressed
			_preview_last_pointer = button.position
			get_viewport().set_input_as_handled()
	elif event is InputEventMouseMotion and _preview_dragging:
		var motion := event as InputEventMouseMotion
		_rotate_station_preview(motion.position - _preview_last_pointer)
		_preview_last_pointer = motion.position
		get_viewport().set_input_as_handled()


func _rotate_station_preview(delta: Vector2) -> void:
	if _preview_root == null:
		return
	_preview_root.rotate_y(-delta.x * 0.012)
	_preview_vertical_offset = clampf(_preview_vertical_offset - delta.y * 0.0045, -0.9, 1.2)
	_preview_root.position.y = _preview_vertical_offset


# =========================================================
# KOMUNIKATY
# =========================================================

func _mark_dirty(message: String) -> void:
	_dirty = true
	_set_status("NIEZAPISANE — " + message, false)


func _set_status(message: String, success: bool) -> void:
	if _status == null:
		return

	_status.text = message

	_status.add_theme_color_override(
		"font_color",
		UIKit.COLOR_GOOD if success else UIKit.COLOR_WARN
	)

