extends Control

const CareerStoryPanelScript = preload("res://scripts/ui/menus/CareerStoryPanel.gd")
## Lokalne centrum funkcji v0.3. Funkcje bez gotowej infrastruktury są
## jawnie oznaczone jako WKRÓTCE, bez udawania działających usług online.

const YOUTUBE_URL := "https://youtube.com/@szakalpcandroid?si=xlUUiiSp1gqcj9nu"
const FACEBOOK_URL := "https://www.facebook.com/share/1GxWnyqZVD/"

var _nickname: LineEdit
var _message: Label


func _ready() -> void:
	if GameManager.hub_page == "comic":
		GameManager.hub_page = "career"
		GameManager.change_scene(GameManager.SCENE_FEATURE_HUB)
		return
	UIKit.add_menu_background(self)
	var margin := UIKit.make_screen_margin(self, 34)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 18)
	margin.add_child(column)
	var page := GameManager.hub_page
	column.add_child(UIKit.make_header(_page_title(page), GameManager.go_to_main_menu))

	var scroll := ScrollContainer.new()
	UIKit.configure_touch_scroll(scroll)
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	column.add_child(scroll)
	var body := VBoxContainer.new()
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 18)
	scroll.add_child(body)

	match page:
		"profile": _build_profile(body)
		"career": _build_career(body)
		"career_story": _build_career_story(body)
		"challenges": _build_challenges(body)
		"creator": _build_creator(body)
		"multiplayer": _build_multiplayer_page(body)
		"monster_city": _build_coming_soon(body, "MONSTER CITY — CITY TOUR", "Osobny świat dużych robotów: miasto inspirowane rzeczywistymi ulicami, swobodna jazda i wyścigi miejskie. Ten tryb jest zaplanowany, ale nie został jeszcze wdrożony.")
		"store": _build_coming_soon(body, "SKLEP SPOŁECZNOŚCIOWY", "Planowane kategorie: roboty, skórki, trasy, boosty, stacje i otoczenie. Zakupy CR, Testownia, oceny, opinie i panel twórcy. Obecnie nie ma jeszcze działającego sklepu społecznościowego.")
		"community": _build_coming_soon(body, "SPOŁECZNOŚĆ", "Publikowanie, pobieranie i ocenianie tras, robotów, skórek oraz dodatków przygotowanych przez graczy.")
		"editor": _build_editor_page(body)
		"skin_creator": _build_coming_soon(body, "SKANUJ I STWÓRZ — SKÓRKI ZE ZDJĘĆ", "Gracz będzie mógł wybrać szablon konkretnego robota lub stacji, zrobić zdjęcie własnego rysunku albo wzoru, dopasować perspektywę i przycięcie, a następnie obejrzeć skórkę na modelu 3D. Import zdjęć i aparat nie są jeszcze podłączone.")
		"mods": _build_coming_soon(body, "MODY", "Planowane lokalne dodatki: grafika, dźwięki, UI, roboty, skórki i trasy. Paczki będą walidowane; dodatki nie będą mogły uruchamiać dowolnego kodu. Modów nie można jeszcze instalować.")
		_: _build_career(body)

	_message = UIKit.make_label("", 24, UIKit.COLOR_WARN, HORIZONTAL_ALIGNMENT_CENTER)
	column.add_child(_message)


func _page_title(page: String) -> String:
	var titles := {
		"profile": "PROFIL GRACZA", "career": "KARIERA", "challenges": "WYZWANIA",
		"creator": "O TWÓRCY", "multiplayer": "MULTIPLAYER", "store": "SKLEP",
		"editor": "EDYTUJ", "monster_city": "MONSTER CITY", "skin_creator": "SKANUJ I STWÓRZ",
		"community": "SPOŁECZNOŚĆ"
	}
	return str(titles.get(page, "CENTRUM GRACZA"))


func _add_panel(parent: Control, title: String, description: String) -> VBoxContainer:
	var panel := UIKit.make_card(UIKit.COLOR_ACCENT, 26.0)
	parent.add_child(panel)
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 14)
	panel.add_child(content)
	content.add_child(UIKit.make_section_title(title))
	var label := UIKit.make_label(description, 26, UIKit.COLOR_TEXT, HORIZONTAL_ALIGNMENT_LEFT, false)
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	content.add_child(label)
	return content


func _build_profile(parent: Control) -> void:
	var profile_id := SaveManager.get_string("profile", "local_id", "")
	if profile_id.is_empty():
		profile_id = "RR-%04X-%04X" % [randi_range(0, 65535), randi_range(0, 65535)]
		SaveManager.set_value("profile", "local_id", profile_id)
		SaveManager.save_now()
	var panel := _add_panel(parent, "TWOJE DANE", "Profil lokalny działa offline. ID jest identyfikatorem tego zapisu na urządzeniu; nie jest jeszcze globalnym identyfikatorem konta online.")
	panel.add_child(UIKit.make_label("ID PROFILU: " + profile_id, 28, UIKit.COLOR_GOOD))
	_nickname = LineEdit.new()
	_nickname.placeholder_text = "Wpisz nick gracza"
	_nickname.text = SaveManager.get_string("profile", "nickname", "Gracz")
	_nickname.custom_minimum_size.y = 74
	_nickname.add_theme_font_size_override("font_size", 28)
	panel.add_child(_nickname)
	var save_button := UIKit.make_button("ZAPISZ NICK", 28, 76)
	save_button.pressed.connect(_save_profile)
	panel.add_child(save_button)
	var stats: Dictionary = PlayerProgress.stats
	_add_panel(parent, "STATYSTYKI", "Wyścigi: %d\nZwycięstwa: %d\nPodia: %d\nŁącznie zdobyte CR: %d" % [int(stats.get("races", 0)), int(stats.get("wins", 0)), int(stats.get("podiums", 0)), int(stats.get("earned_total", 0))])


func _save_profile() -> void:
	var clean := _nickname.text.strip_edges()
	if clean.is_empty():
		_message.text = "Nick nie może być pusty."
		return
	if clean.length() > 20:
		_message.text = "Nick może mieć maksymalnie 20 znaków."
		return
	SaveManager.set_value("profile", "nickname", clean)
	SaveManager.save_now()
	_message.text = "Profil zapisany."


func _build_career(parent: Control) -> void:
	var stats: Dictionary = PlayerProgress.stats
	var event_index: int = PlayerProgress.get_career_event_index()
	var event: Dictionary = PlayerProgress.get_career_event()
	var completed: bool = event.is_empty()
	var progress_panel := _add_panel(parent, "S-01: OD POMOCNIKA DO KRÓLA PANELI", "Jesteś budżetową jednostką Model S-01. Po nocnym spięciu od kawy uruchomił się Protokół Wolności. Teraz walczysz o szacunek w nocnym świecie wyścigów.\n\nWyścigi: %d  •  Zwycięstwa: %d  •  Podia: %d\nSaldo: %d CR — Kurz / Bit-Baterie" % [int(stats.get("races", 0)), int(stats.get("wins", 0)), int(stats.get("podiums", 0)), PlayerProgress.currency])
	var chapter_index: int = 3 if completed else int(event.get("chapter", 0))
	var chapter_names: Array[String] = ["DNO HARMONOGRAMU", "KORPORACYJNY WYŚCIG SZCZURÓW", "PRO LEAGUE", "KRÓL PANELI"]
	progress_panel.add_child(UIKit.make_section_title("ETAP %d / 3 — %s" % [mini(chapter_index + 1, 3), chapter_names[chapter_index]]))
	var chapter_descriptions: Array[String] = [
		"Kawalerka i parter. Przetarte szczotki, kanapa, kable i lokalni rewiranci. Najpierw musisz udowodnić, że nie jesteś tylko tanim sprzętem z promocji.",
		"Biura i open space'y. Śliskie korytarze, większe pule nagród i korporacyjni rywale. Twoje modyfikacje zaczynają zwracać uwagę producentów.",
		"Oficjalne mistrzostwa robotów wyścigowych. Kwalifikacje, półfinał i finał. Zwycięstwo może uczynić z S-01 Króla Paneli.",
		"Kampania ukończona. S-01 udowodnił, że liczy się kierowca i tuning, a nie logo producenta."
	]
	progress_panel.add_child(UIKit.make_label(chapter_descriptions[chapter_index], 23, UIKit.COLOR_TEXT, HORIZONTAL_ALIGNMENT_LEFT, false))
	if completed:
		var finish_card := _add_panel(parent, "KAMPANIA UKOŃCZONA", "Zdobyłeś tytuł Króla Paneli. Możesz nadal jeździć w pozostałych trybach, rozwijać garaż i poprawiać rekordy.")
		finish_card.add_child(UIKit.make_label("Wydarzenia ukończone: %d / %d" % [CareerCampaign.count(), CareerCampaign.count()], 22, UIKit.COLOR_GOOD))
	else:
		var event_panel := _add_panel(parent, "NAJBLIŻSZE WYDARZENIE", "%s\n%s\n\n%s\n\nPora dnia: %s  •  Okrążenia: %d  •  Rywale: %d\nNagrody: %s" % [str(event.get("title", "")), str(event.get("location", "")), str(event.get("goal", "")), _time_label(str(event.get("time_of_day", "day"))), int(event.get("laps", 3)), int(event.get("opponents", 4)), "wysokie — boss" if bool(event.get("boss", false)) else "standardowe"])
		var launch := UIKit.make_button("ROZPOCZNIJ WYDARZENIE", 30, 82)
		launch.pressed.connect(_launch_career_event)
		event_panel.add_child(launch)
		if bool(event.get("boss", false)):
			event_panel.add_child(UIKit.make_label("BOSS: " + str(event.get("boss_name", "RYWAL")), 22, UIKit.COLOR_WARN))
		var requirement := "Zwycięstwo wymagane" if bool(event.get("boss", false)) else "Wystarczy miejsce 1–3"
		event_panel.add_child(UIKit.make_label("Warunek awansu: " + requirement, 19, UIKit.COLOR_WARN))
	var stages := _add_panel(parent, "MAPA KAMPANII", "Każdy etap zawiera trzy wydarzenia. Bossowie zamykają rozdziały.")
	for i in range(3):
		var status: String = "UKOŃCZONO" if event_index >= (i + 1) * 3 else ("AKTUALNY ETAP" if chapter_index == i else "ZABLOKOWANY")
		stages.add_child(UIKit.make_label("%d. %s  —  %s" % [i + 1, chapter_names[i], status], 21, UIKit.COLOR_GOOD if status == "UKOŃCZONO" else (UIKit.COLOR_ACCENT if status == "AKTUALNY ETAP" else UIKit.COLOR_MUTED)))
	var time_panel := _add_panel(parent, "TRZY PORY DNIA — TRZY POWODY DO JAZDY", "☀ Dzień: spokojniejsze trasy, mniejszy mnożnik, premia za czystą jazdę.\n🌆 Wieczór: więcej przeszkód i 1,5× nagród.\n🌙 Noc: mniejsza przyczepność, mocniejszy drift i 2× nagród. Nocne bossy pilnują wejścia do kolejnych lig.")
	if event_index > 0:
		var story := CareerStoryPanelScript.new()
		story.configure(event_index - 1, "interlude", GameManager.career_result_advanced)
		story.sequence_finished.connect(func() -> void: story.queue_free())
		parent.add_child(story)
	var actions := HBoxContainer.new()
	actions.add_theme_constant_override("separation", 12)
	parent.add_child(actions)
	var garage_button := UIKit.make_button("GARAŻ I TUNING", 23, 68)
	garage_button.pressed.connect(func() -> void: GameManager.change_scene(GameManager.SCENE_GARAGE))
	actions.add_child(garage_button)


func _time_label(time_id: String) -> String:
	match time_id:
		"evening": return "Wieczór"
		"night": return "Noc"
		_: return "Dzień"


func _launch_career_event() -> void:
	if PlayerProgress.get_career_event().is_empty():
		_message.text = "Kampania ukończona — wszystkie wydarzenia zaliczone."
		return
	GameManager.hub_page = "career_story"
	GameManager.change_scene(GameManager.SCENE_FEATURE_HUB)


func _build_career_story(parent: Control) -> void:
	var index: int = PlayerProgress.get_career_event_index()
	if index >= CareerCampaign.count():
		GameManager.open_hub("career")
		return
	var event: Dictionary = PlayerProgress.get_career_event()
	_add_panel(parent, "PRZED WYŚCIGIEM", "%s  •  %s\nPrzed startem poznaj kolejny fragment historii S-01." % [str(event.get("title", "Wydarzenie")), str(event.get("location", ""))])
	var story := CareerStoryPanelScript.new()
	story.configure(index, "intro")
	story.sequence_finished.connect(func() -> void: GameManager.launch_career_event())
	parent.add_child(story)


func _build_challenges(parent: Control) -> void:
	var stats: Dictionary = PlayerProgress.stats
	var races: int = int(stats.get("races", 0))
	var wins: int = int(stats.get("wins", 0))
	var podiums: int = int(stats.get("podiums", 0))
	var dirt: int = int(float(stats.get("dirt_total", 0.0)))
	_add_panel(parent, "POSTĘP", "Wyścigi: %d  •  Zwycięstwa: %d  •  Podia: %d\nZebrany brud: %d" % [races, wins, podiums, dirt])
	var claimed: Array = SaveManager.get_array("achievements", "claimed")
	var achievements: Array[Dictionary] = [
		{"id":"first_race", "title":"PIERWSZY START", "description":"Ukończ pierwszy wyścig.", "progress":races, "target":1, "reward":100},
		{"id":"first_podium", "title":"NA PODIUM", "description":"Zdobądź pierwsze podium.", "progress":podiums, "target":1, "reward":150},
		{"id":"dirt_100", "title":"ŁOWCA KURZU", "description":"Zbierz 100 jednostek brudu.", "progress":dirt, "target":100, "reward":150},
		{"id":"five_wins", "title":"PIĘĆ ZWYCIĘSTW", "description":"Wygraj pięć wyścigów.", "progress":wins, "target":5, "reward":300},
		{"id":"twenty_five_races", "title":"DOŚWIADCZONY ZAWODNIK", "description":"Ukończ 25 wyścigów.", "progress":races, "target":25, "reward":400},
		{"id":"ten_wins", "title":"MISTRZ TORU", "description":"Wygraj dziesięć wyścigów.", "progress":wins, "target":10, "reward":550},
		{"id":"ten_podiums", "title":"STAŁY BYWALEC PODIUM", "description":"Zdobądź dziesięć podiów.", "progress":podiums, "target":10, "reward":450},
		{"id":"fifty_races", "title":"WETERAN WYŚCIGÓW", "description":"Ukończ 50 wyścigów.", "progress":races, "target":50, "reward":700},
		{"id":"dirt_500", "title":"WIELKIE SPRZĄTANIE", "description":"Zbierz 500 jednostek brudu.", "progress":dirt, "target":500, "reward":500},
		{"id":"dirt_1000", "title":"KRÓL CZYSTOŚCI", "description":"Zbierz 1000 jednostek brudu.", "progress":dirt, "target":1000, "reward":900}
	]
	var panel := _add_panel(parent, "OSIĄGNIĘCIA I NAGRODY", "Cele działają lokalnie i offline. Każdą nagrodę można odebrać tylko raz.")
	for achievement: Dictionary in achievements:
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		panel.add_child(row)
		var text_column := VBoxContainer.new()
		text_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(text_column)
		var current: int = mini(int(achievement["progress"]), int(achievement["target"]))
		var complete: bool = int(achievement["progress"]) >= int(achievement["target"])
		var was_claimed: bool = claimed.has(str(achievement["id"]))
		text_column.add_child(UIKit.make_label(str(achievement["title"]), 25, UIKit.COLOR_ACCENT))
		text_column.add_child(UIKit.make_label("%s  •  %d / %d  •  Nagroda: %d CR" % [str(achievement["description"]), current, int(achievement["target"]), int(achievement["reward"])], 19, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false))
		var button := UIKit.make_button("ODEBRANO" if was_claimed else ("ODBIERZ %d CR" % int(achievement["reward"]) if complete else "W TRAKCIE"), 18, 46)
		button.disabled = was_claimed or not complete
		button.pressed.connect(_claim_achievement.bind(str(achievement["id"]), int(achievement["reward"])))
		row.add_child(button)
	var daily_panel := _add_panel(parent, "WYZWANIA DZIENNE", "Trzy lokalne zadania odnawiają się według daty urządzenia. Postęp i odebrane nagrody są zapisywane offline.")
	var daily_date: Dictionary = Time.get_date_dict_from_system()
	daily_panel.add_child(UIKit.make_label("DZISIAJ: %02d.%02d.%04d" % [int(daily_date.get("day", 1)), int(daily_date.get("month", 1)), int(daily_date.get("year", 2000))], 20, UIKit.COLOR_MUTED))
	for challenge: Dictionary in PlayerProgress.get_daily_challenges():
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		daily_panel.add_child(row)
		var text_column := VBoxContainer.new()
		text_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(text_column)
		var current: int = mini(int(challenge["progress"]), int(challenge["target"]))
		var complete: bool = int(challenge["progress"]) >= int(challenge["target"])
		var claimed_daily: bool = bool(challenge["claimed"])
		text_column.add_child(UIKit.make_label(str(challenge["title"]), 24, UIKit.COLOR_ACCENT))
		text_column.add_child(UIKit.make_label("%s  •  %d / %d  •  %d CR" % [str(challenge["description"]), current, int(challenge["target"]), int(challenge["reward"])], 19, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false))
		var daily_button := UIKit.make_button("ODEBRANO" if claimed_daily else ("ODBIERZ" if complete else "W TRAKCIE"), 18, 46)
		daily_button.disabled = claimed_daily or not complete
		daily_button.pressed.connect(_claim_daily_challenge.bind(str(challenge["id"])))
		row.add_child(daily_button)
	_add_panel(parent, "WYDARZENIA SEZONOWE", "Turnieje, rankingi online i wydarzenia społecznościowe wymagają jeszcze infrastruktury sieciowej. Nie są prezentowane jako aktywne, dopóki nie powstanie backend.")


func _claim_daily_challenge(challenge_id: String) -> void:
	if not PlayerProgress.claim_daily_challenge(challenge_id):
		return
	SaveManager.save_now()
	GameManager.hub_page = "challenges"
	GameManager.change_scene(GameManager.SCENE_FEATURE_HUB)


func _claim_achievement(achievement_id: String, reward: int) -> void:
	var claimed: Array = SaveManager.get_array("achievements", "claimed")
	if claimed.has(achievement_id):
		return
	claimed.append(achievement_id)
	SaveManager.set_value("achievements", "claimed", claimed)
	PlayerProgress.add_currency(reward)
	SaveManager.save_now()
	GameManager.hub_page = "challenges"
	GameManager.change_scene(GameManager.SCENE_FEATURE_HUB)


func _build_creator(parent: Control) -> void:
	_add_panel(parent, "SZAKAL PC ON ANDROID", "Poradniki • Gry PC na Androidzie • Emulacja\nOficjalny kanał twórcy gry.")
	var youtube := UIKit.make_button("ODWIEDŹ KANAŁ YOUTUBE", 30, 82)
	youtube.pressed.connect(func() -> void: OS.shell_open(YOUTUBE_URL))
	parent.add_child(youtube)
	var facebook := UIKit.make_button("OTWÓRZ FACEBOOK", 30, 82)
	facebook.pressed.connect(func() -> void: OS.shell_open(FACEBOOK_URL))
	parent.add_child(facebook)


func _build_editor_page(parent: Control) -> void:
	var intro := _add_panel(parent, "CENTRUM TWORZENIA", "Wszystkie narzędzia do budowania i personalizacji gry w jednym miejscu. Gotowe narzędzia można otworzyć, a planowane moduły są oznaczone jako WKRÓTCE.")
	var tracks := UIKit.make_button("EDYTOR TRAS — GENERATOR I EDYTOR RĘCZNY", 27, 76)
	tracks.pressed.connect(func() -> void: GameManager.change_scene(GameManager.SCENE_TRACK_GENERATOR))
	intro.add_child(tracks)
	var boosts := UIKit.make_button("EDYTOR BOOSTÓW", 27, 76)
	boosts.pressed.connect(func() -> void: GameManager.change_scene(GameManager.SCENE_BOOST_WORKSHOP))
	intro.add_child(boosts)
	var garage := UIKit.make_button("EDYTOR GARAŻU — ROBOTY I STACJE", 27, 76)
	garage.pressed.connect(func() -> void: GameManager.change_scene(GameManager.SCENE_GARAGE))
	intro.add_child(garage)
	var skins := UIKit.make_button("SKANUJ I STWÓRZ — WŁASNE SKÓRKI  •  WKRÓTCE", 25, 72)
	skins.pressed.connect(func() -> void: GameManager.open_hub("skin_creator"))
	intro.add_child(skins)
	var skin_note := UIKit.make_label("Szablony dla konkretnego robota lub stacji, zdjęcie z aparatu albo galerii, dopasowanie perspektywy i podgląd 3D.", 20, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false)
	skin_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	intro.add_child(skin_note)
	_add_panel(parent, "ZAPIS I UDOSTĘPNIANIE", "Na początek projekty będą zapisywane lokalnie. Udostępnianie w sklepie społecznościowym zostanie włączone po przygotowaniu bezpiecznego systemu paczek i moderacji.")


func _build_multiplayer_page(parent: Control) -> void:
	if GameSettings.is_simple_play_style():
		var lan_simple := _add_panel(parent, "LAN / WI-FI", "Połącz dwa urządzenia w tej samej sieci Wi-Fi lub przez hotspot. Na obecnym etapie działa połączenie i wykrycie obecności drugiego urządzenia.")
		var lan_simple_button := UIKit.make_button("POŁĄCZ PRZEZ WI-FI", 28, 76)
		lan_simple_button.pressed.connect(func() -> void: GameManager.change_scene("res://scenes/LanMultiplayer.tscn"))
		lan_simple.add_child(lan_simple_button)
		var online_simple := _add_panel(parent, "MULTIPLAYER ONLINE — TEST", "Bezpośrednie połączenie internetowe. Potrzebny jest publiczny adres IP i dostępny port UDP. Synchronizacja wyścigu jest kolejnym etapem.")
		var online_simple_button := UIKit.make_button("POŁĄCZ ONLINE", 28, 76)
		online_simple_button.pressed.connect(func() -> void: GameManager.change_scene(GameManager.SCENE_ONLINE_MULTIPLAYER))
		online_simple.add_child(online_simple_button)
		return

	var local := _add_panel(parent, "MULTIPLAYER LOKALNY", "Rozgrywka na jednym urządzeniu. Obecny tryb lokalny można uruchomić z wyborem trasy.")
	var local_button := UIKit.make_button("GRAJ LOKALNIE", 28, 76)
	local_button.pressed.connect(func() -> void:
		GameManager.mode = GameManager.GameMode.LOCAL_MULTIPLAYER
		GameManager.change_scene(GameManager.SCENE_TRACK_SELECT)
	)
	local.add_child(local_button)
	var split := _add_panel(parent, "SPLIT-SCREEN 2–4 GRACZY", "Kilku graczy na jednym ekranie lub urządzeniu, z niezależnym robotem, kamerą i HUD-em.")
	var split_button := UIKit.make_button("WKRÓTCE — SZCZEGÓŁY", 24, 66)
	split_button.pressed.connect(func() -> void: _show_info_dialog("SPLIT-SCREEN 2–4 GRACZY", "Tryb dla dwóch, trzech lub czterech graczy. Wymaga dopracowania sterowania, podziału ekranu i wydajności."))
	split.add_child(split_button)
	var lan := _add_panel(parent, "LAN / WI-FI", "Połączenie urządzeń w tej samej sieci lub przez hotspot. Otwórz istniejący ekran połączenia.")
	var lan_button := UIKit.make_button("OTWÓRZ LAN / WI-FI", 28, 76)
	lan_button.pressed.connect(func() -> void: GameManager.change_scene("res://scenes/LanMultiplayer.tscn"))
	lan.add_child(lan_button)
	var online := _add_panel(parent, "MULTIPLAYER ONLINE", "Pokoje internetowe przez Cloudflare Worker i bezpieczny WebSocket. Gracze mogą dołączyć do lobby, wspólnie rozpocząć wyścig i synchronizować pozycje robotów. Weryfikacja wyników przez serwer i matchmaking są kolejnymi etapami.")
	var online_button := UIKit.make_button("OTWÓRZ MULTIPLAYER ONLINE", 26, 72)
	online_button.pressed.connect(func() -> void: GameManager.change_scene(GameManager.SCENE_ONLINE_MULTIPLAYER))
	online.add_child(online_button)
	var team := _add_panel(parent, "TEAM RACE 2v2", "Dwie drużyny po dwa roboty. Współpraca, wspólne wyniki i taktyka zespołowa.")
	var team_button := UIKit.make_button("WKRÓTCE — SZCZEGÓŁY", 24, 66)
	team_button.pressed.connect(func() -> void: _show_info_dialog("TEAM RACE 2v2", "Dwie drużyny po dwa roboty. Tryb jest zaplanowany, ale nie został jeszcze wdrożony."))
	team.add_child(team_button)


func _show_info_dialog(title: String, description: String) -> void:
	var dialog := AcceptDialog.new()
	dialog.title = title
	dialog.dialog_text = description + "\n\nSTATUS: WKRÓTCE — funkcja jest zaplanowana w Robot Racing v0.3."
	dialog.ok_button_text = "ROZUMIEM"
	add_child(dialog)
	dialog.confirmed.connect(dialog.queue_free)
	dialog.canceled.connect(dialog.queue_free)
	dialog.popup_centered(Vector2i(760, 360))


func _build_coming_soon(parent: Control, title: String, description: String) -> void:
	var content := _add_panel(parent, title, description)
	content.add_child(UIKit.make_badge("WKRÓTCE", UIKit.COLOR_WARN))
	var note := UIKit.make_label("Ta zakładka jest już uwzględniona w menu v0.3, ale jej pełna funkcjonalność nie została jeszcze wdrożona.", 23, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false)
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	content.add_child(note)


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		GameManager.go_to_main_menu()
