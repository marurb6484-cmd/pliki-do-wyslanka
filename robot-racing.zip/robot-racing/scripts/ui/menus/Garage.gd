
extends Control
## Garaż: wybór i odblokowywanie robotów, podgląd 3D, skórki i kolory neonów,
## statystyki, ulepszenia (5 poziomów z limitami), naprawa uszkodzeń.
## Waluta (CR) zdobywana wyłącznie w grze.

const STAT_ROWS: Array[Array] = [
	["max_speed", "Prędkość"],
	["acceleration", "Przyspieszenie"],
	["grip", "Przyczepność"],
	["capacity", "Zbiornik brudu"],
	["battery_capacity", "Bateria"],
	["boost_speed_multiplier", "Moc boosta"]
]

var _viewed: int = 0

var _currency_label: Label
var _preview_root: Node3D
var _preview_visuals: RobotVisuals
var _preview_camera: Camera3D
var _preview_zoom: HSlider
var _preview_dragging: bool = false
var _preview_last_pointer: Vector2 = Vector2.ZERO
var _preview_vertical_offset: float = 0.22
var _name_label: Label
var _ovr_label: Label
var _description_label: Label
var _stat_bars: Dictionary = {}
var _stat_values: Dictionary = {}
var _action_button: Button
var _robot_buttons: Array[Button] = []
var _skin_box: GridContainer
var _neon_box: GridContainer
var _upgrade_box: VBoxContainer
var _repair_label: Label
var _repair_bar: ProgressBar
var _repair_button: Button
var _message_label: Label
var _docking_editor: DockStationEditor
var _robot_body: HBoxContainer
var _mode_robot_button: Button
var _mode_station_button: Button
var _engine_sound_option: OptionButton


func _ready() -> void:
	_viewed = PlayerProgress.selected_robot

	UIKit.add_menu_background(self)

	var margin := UIKit.make_screen_margin(self, 30)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 16)
	margin.add_child(column)

	var header := UIKit.make_header("GARAŻ", _go_back)

	_currency_label = UIKit.make_label("", 44, UIKit.COLOR_GOOD)
	header.add_child(_currency_label)

	column.add_child(header)

	# Główne przełączanie trybów.
	var mode_row := HBoxContainer.new()
	mode_row.add_theme_constant_override("separation", 14)

	_mode_robot_button = UIKit.make_button("🤖  ROBOT", 32, 82)
	_mode_station_button = UIKit.make_button("▣  STACJA DOKUJĄCA", 32, 82)

	_mode_robot_button.pressed.connect(_show_robot_mode)
	_mode_station_button.pressed.connect(_show_station_mode)

	mode_row.add_child(_mode_robot_button)
	mode_row.add_child(_mode_station_button)

	column.add_child(mode_row)

	var body := HBoxContainer.new()
	_robot_body = body
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 24)

	column.add_child(body)

	# =====================================================
	# LEWA CZĘŚĆ - PODGLĄD ROBOTA
	# =====================================================

	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.add_theme_constant_override("separation", 10)

	body.add_child(left)

	left.add_child(_build_preview())

	var info := UIKit.make_panel()
	left.add_child(info)

	var info_column := VBoxContainer.new()
	info_column.add_theme_constant_override("separation", 6)
	info.add_child(info_column)

	_name_label = UIKit.make_label("", 44, UIKit.COLOR_ACCENT)
	info_column.add_child(_name_label)

	_ovr_label = UIKit.make_label("OVR: --", 38, UIKit.COLOR_GOOD)
	info_column.add_child(_ovr_label)

	_description_label = UIKit.make_label(
		"",
		26,
		UIKit.COLOR_MUTED,
		HORIZONTAL_ALIGNMENT_LEFT,
		false
	)

	_description_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info_column.add_child(_description_label)

	var stats := GridContainer.new()
	stats.columns = 3
	stats.add_theme_constant_override("h_separation", 16)

	info_column.add_child(stats)

	for row: Array in STAT_ROWS:
		stats.add_child(UIKit.make_label(str(row[1]), 26))

		var bar := UIKit.make_bar(20, UIKit.COLOR_ACCENT)
		bar.custom_minimum_size.x = 380
		bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL

		stats.add_child(bar)
		_stat_bars[row[0]] = bar

		var value := UIKit.make_label("", 26, UIKit.COLOR_MUTED)
		value.custom_minimum_size.x = 120

		stats.add_child(value)
		_stat_values[row[0]] = value

	_action_button = UIKit.make_button("", 36, 100)
	_action_button.pressed.connect(_on_action)

	info_column.add_child(_action_button)

	# =====================================================
	# PRAWA CZĘŚĆ - ZAKŁADKI
	# =====================================================

	var tabs := TabContainer.new()
	tabs.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tabs.custom_minimum_size = Vector2(1000, 0)

	body.add_child(tabs)

	tabs.add_child(_build_robots_tab())
	tabs.add_child(_build_look_tab())
	tabs.add_child(_build_upgrades_tab())
	tabs.add_child(_build_repair_tab())

	# =====================================================
	# EDYTOR STACJI DOKUJĄCEJ
	# =====================================================

	_docking_editor = DockStationEditor.new()
	_docking_editor.size_flags_vertical = Control.SIZE_EXPAND_FILL

	column.add_child(_docking_editor)
	_docking_editor.visible = false

	_message_label = UIKit.make_label(
		"",
		30,
		UIKit.COLOR_WARN,
		HORIZONTAL_ALIGNMENT_CENTER
	)

	column.add_child(_message_label)

	PlayerProgress.currency_changed.connect(
		func(_value: int) -> void:
			_refresh()
	)

	_refresh()
	_show_robot_mode()


func _on_engine_sound_selected(profile: int) -> void:
	SaveManager.set_value("robot_audio", str(_viewed), clampi(profile, 0, 2))
	AudioManager.play_engine_preview(profile)


# =========================================================
# PODGLĄD 3D
# =========================================================

func _build_preview() -> Control:
	var wrapper := VBoxContainer.new()
	wrapper.add_theme_constant_override("separation", 6)
	var container := SubViewportContainer.new()

	container.stretch = true
	container.custom_minimum_size = Vector2(0, 390)
	container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	container.mouse_filter = Control.MOUSE_FILTER_STOP
	container.gui_input.connect(_on_preview_gui_input)

	var viewport := SubViewport.new()
	viewport.own_world_3d = true
	viewport.transparent_bg = true

	viewport.msaa_3d = (
		Viewport.MSAA_2X
		if GameSettings.quality >= GameSettings.Quality.HIGH
		else Viewport.MSAA_DISABLED
	)

	container.add_child(viewport)
	wrapper.add_child(container)

	var world := WorldEnvironment.new()
	var environment := Environment.new()

	environment.background_mode = Environment.BG_CLEAR_COLOR
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.6, 0.7, 0.8)
	environment.ambient_light_energy = 0.7
	environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	environment.glow_enabled = GameSettings.glow_allowed()

	world.environment = environment
	viewport.add_child(world)

	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-50, 35, 0)
	light.light_energy = 1.2
	light.shadow_enabled = GameSettings.shadows_enabled

	viewport.add_child(light)

	var platform := MeshInstance3D.new()
	var cylinder := CylinderMesh.new()

	cylinder.top_radius = 1.6
	cylinder.bottom_radius = 1.7
	cylinder.height = 0.1
	cylinder.radial_segments = 48

	platform.mesh = cylinder

	var platform_material := StandardMaterial3D.new()
	platform_material.albedo_color = Color(0.12, 0.14, 0.18)
	platform_material.metallic = 0.5
	platform_material.roughness = 0.3

	platform.material_override = platform_material
	platform.position = Vector3(0, -0.05, 0)

	viewport.add_child(platform)

	_preview_root = Node3D.new()
	viewport.add_child(_preview_root)

	_preview_camera = Camera3D.new()
	_preview_camera.position = Vector3(0, 0.92, 1.95)
	_preview_camera.fov = 29.0
	viewport.add_child(_preview_camera)
	_preview_camera.look_at_from_position(
		_preview_camera.position,
		Vector3(0, 0.22, 0),
		Vector3.UP
	)

	var zoom_row := HBoxContainer.new()
	zoom_row.add_theme_constant_override("separation", 10)
	zoom_row.add_child(UIKit.make_label("ZOOM PODGLĄDU", 22, UIKit.COLOR_MUTED))
	var zoom_out := UIKit.make_button("−", 26, 48)
	zoom_out.pressed.connect(func() -> void: _change_preview_zoom(-0.15))
	zoom_row.add_child(zoom_out)
	_preview_zoom = HSlider.new()
	_preview_zoom.min_value = 1.6
	_preview_zoom.max_value = 5.0
	_preview_zoom.step = 0.1
	_preview_zoom.value = 5.0
	_preview_zoom.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_preview_zoom.value_changed.connect(_set_preview_zoom)
	_set_preview_zoom(_preview_zoom.value)
	zoom_row.add_child(_preview_zoom)
	var zoom_in := UIKit.make_button("+", 26, 48)
	zoom_in.pressed.connect(func() -> void: _change_preview_zoom(0.15))
	zoom_row.add_child(zoom_in)
	wrapper.add_child(zoom_row)
	wrapper.add_child(UIKit.make_label("PRZESUŃ PALCEM: OBRÓT ORAZ WYSOKOŚĆ ROBOTA", 20, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_CENTER))
	return wrapper


func _on_preview_gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var mouse_button := event as InputEventMouseButton
		if mouse_button.button_index == MOUSE_BUTTON_LEFT:
			_preview_dragging = mouse_button.pressed
			_preview_last_pointer = mouse_button.position
			if mouse_button.pressed:
				get_viewport().set_input_as_handled()
	elif event is InputEventMouseMotion and _preview_dragging:
		var mouse_motion := event as InputEventMouseMotion
		_rotate_preview(mouse_motion.position - _preview_last_pointer)
		_preview_last_pointer = mouse_motion.position
		get_viewport().set_input_as_handled()
	elif event is InputEventScreenTouch:
		var touch := event as InputEventScreenTouch
		_preview_dragging = touch.pressed
		_preview_last_pointer = touch.position
		get_viewport().set_input_as_handled()
	elif event is InputEventScreenDrag and _preview_dragging:
		var drag := event as InputEventScreenDrag
		_rotate_preview(drag.relative)
		_preview_last_pointer = drag.position
		get_viewport().set_input_as_handled()


func _rotate_preview(delta: Vector2) -> void:
	if _preview_root != null:
		_preview_root.rotate_y(-delta.x * 0.012)
		# Pionowy ruch przesuwa cały model w oknie, niezależnie od zoomu.
		_preview_vertical_offset = clampf(_preview_vertical_offset - delta.y * 0.0045, -0.9, 1.2)
		_preview_root.position.y = _preview_vertical_offset


func _change_preview_zoom(delta: float) -> void:
	if _preview_zoom != null:
		_preview_zoom.value = clampf(_preview_zoom.value + delta, _preview_zoom.min_value, _preview_zoom.max_value)


func _set_preview_zoom(value: float) -> void:
	if _preview_camera != null:
		_preview_camera.fov = 45.0 / maxf(value, 0.1)


func _process(delta: float) -> void:
	if _preview_root != null and not _preview_dragging:
		_preview_root.rotate_y(delta * 0.22)


# =========================================================
# KONFIGURACJA PODGLĄDU ROBOTA
# =========================================================

func _get_preview_config() -> Dictionary:
	var unlocked: bool = PlayerProgress.is_robot_unlocked(_viewed)

	var upgrades: Dictionary = {}

	if unlocked:
		upgrades = PlayerProgress.get_upgrades(_viewed).duplicate(true)
	else:
		# Robot niekupiony jest prezentowany w konfiguracji fabrycznej.
		for upgrade: Dictionary in RobotDatabase.UPGRADES:
			upgrades[str(upgrade["id"])] = 0

	var skin: int = 0
	var neon: int = 0

	if unlocked:
		skin = PlayerProgress.get_skin(_viewed)
		neon = PlayerProgress.get_neon(_viewed)

	return RobotDatabase.build_config(
		_viewed,
		upgrades,
		skin,
		neon
	)


func _update_preview() -> void:
	if _preview_visuals != null:
		_preview_visuals.queue_free()
		_preview_visuals = null

	var config: Dictionary = _get_preview_config()

	_preview_visuals = RobotVisuals.new()
	_preview_root.add_child(_preview_visuals)
	_preview_root.position.y = _preview_vertical_offset

	_preview_visuals.build(config, true)


# =========================================================
# TRYBY GARAŻU
# =========================================================

func _show_robot_mode() -> void:
	_robot_body.visible = true
	_docking_editor.visible = false
	_style_mode_buttons(true)


func _show_station_mode() -> void:
	_robot_body.visible = false
	_docking_editor.visible = true
	_style_mode_buttons(false)
	if _docking_editor != null:
		_docking_editor.set_robot_index(_viewed)


## Aktywna zakładka jest podświetlona i nie reaguje na ponowne dotknięcie.
func _style_mode_buttons(robot_active: bool) -> void:
	for pair: Array in [[_mode_robot_button, robot_active], [_mode_station_button, not robot_active]]:
		var button: Button = pair[0]
		var active: bool = pair[1]
		button.disabled = active
		if active:
			button.add_theme_stylebox_override("disabled", UIKit.panel_style(Color(0.0, 0.4, 0.52), UIKit.COLOR_ACCENT, 20, 3, 24.0))
			button.add_theme_color_override("font_disabled_color", Color.WHITE)
		else:
			button.remove_theme_stylebox_override("disabled")
			button.remove_theme_color_override("font_disabled_color")

# =========================================================
# TWORZENIE ZAKŁADEK
# =========================================================

func _make_tab(title: String) -> VBoxContainer:
	var scroll := ScrollContainer.new()
	UIKit.configure_touch_scroll(scroll)

	scroll.name = title
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED

	var column := VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 12)

	scroll.add_child(column)

	return column.get_parent() if column.get_parent() != null else _attach_tab(scroll, column)


func _attach_tab(scroll: ScrollContainer, column: VBoxContainer) -> VBoxContainer:
	return column


func _build_robots_tab() -> Control:
	var scroll := ScrollContainer.new()
	UIKit.configure_touch_scroll(scroll)
	scroll.name = "ROBOTY"
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED

	var column := VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 12)

	scroll.add_child(column)

	for i: int in range(RobotDatabase.count()):
		var button := UIKit.make_button("", 32, 96)

		button.toggle_mode = true
		button.alignment = HORIZONTAL_ALIGNMENT_LEFT
		button.pressed.connect(_view_robot.bind(i))

		column.add_child(button)
		_robot_buttons.append(button)

	return scroll


func _build_look_tab() -> Control:
	var scroll := ScrollContainer.new()
	UIKit.configure_touch_scroll(scroll)
	scroll.name = "WYGLĄD"
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED

	var column := VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 12)

	scroll.add_child(column)

	column.add_child(
		UIKit.make_label("SKÓRKI", 34, UIKit.COLOR_ACCENT)
	)

	_skin_box = GridContainer.new()
	_skin_box.columns = 2
	_skin_box.add_theme_constant_override("h_separation", 12)
	_skin_box.add_theme_constant_override("v_separation", 12)

	column.add_child(_skin_box)

	column.add_child(
		UIKit.make_label("KOLOR NEONU", 34, UIKit.COLOR_ACCENT)
	)

	_neon_box = GridContainer.new()
	_neon_box.columns = 4
	_neon_box.add_theme_constant_override("h_separation", 12)
	_neon_box.add_theme_constant_override("v_separation", 12)

	column.add_child(_neon_box)

	column.add_child(UIKit.make_label("DŹWIĘK ODKURZACZA", 32, UIKit.COLOR_ACCENT))
	_engine_sound_option = OptionButton.new()
	_engine_sound_option.add_item("Fabryczny – elektryczny", 0)
	_engine_sound_option.add_item("Sportowy – wyższy i ostrzejszy", 1)
	_engine_sound_option.add_item("Basowy – głębszy po modyfikacjach", 2)
	_engine_sound_option.item_selected.connect(_on_engine_sound_selected)
	column.add_child(_engine_sound_option)
	var preview_engine := UIKit.make_button("ODSŁUCHAJ DŹWIĘK", 28, 76)
	preview_engine.pressed.connect(func() -> void: AudioManager.play_engine_preview(_engine_sound_option.selected))
	column.add_child(preview_engine)

	return scroll


func _build_upgrades_tab() -> Control:
	var scroll := ScrollContainer.new()
	UIKit.configure_touch_scroll(scroll)
	scroll.set_script(load("res://scripts/ui/TouchScrollContainer.gd"))
	scroll.name = "ULEPSZENIA"
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED

	var column := VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 12)

	scroll.add_child(column)

	_upgrade_box = column
	column.mouse_filter = Control.MOUSE_FILTER_IGNORE

	return scroll


func _build_repair_tab() -> Control:
	var scroll := ScrollContainer.new()
	UIKit.configure_touch_scroll(scroll)
	scroll.name = "NAPRAWA"
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED

	var column := VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 12)

	scroll.add_child(column)

	_repair_label = UIKit.make_label(
		"",
		34,
		UIKit.COLOR_TEXT,
		HORIZONTAL_ALIGNMENT_LEFT,
		false
	)

	_repair_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(_repair_label)

	_repair_bar = UIKit.make_bar(28, UIKit.COLOR_GOOD)
	column.add_child(_repair_bar)

	_repair_button = UIKit.make_button("", 36, 110)
	_repair_button.pressed.connect(_on_repair)

	column.add_child(_repair_button)

	var note := UIKit.make_label(
		"Uszkodzenia zmniejszają prędkość, przyspieszenie i przyczepność. Przy braku środków wykonywana jest naprawa częściowa.",
		26,
		UIKit.COLOR_MUTED,
		HORIZONTAL_ALIGNMENT_LEFT,
		false
	)

	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(note)

	return scroll


# =========================================================
# ODŚWIEŻANIE GARAŻU
# =========================================================

func _refresh() -> void:
	_currency_label.text = "%d CR" % PlayerProgress.currency
	_currency_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT

	for i: int in range(_robot_buttons.size()):
		var data: Dictionary = RobotDatabase.get_robot(i)
		var status: String = ""
		var list_upgrades: Dictionary = PlayerProgress.get_upgrades(i) if PlayerProgress.is_robot_unlocked(i) else RobotDatabase.empty_upgrades()
		var list_config: Dictionary = RobotDatabase.build_config(i, list_upgrades, 0, 0)
		var list_ovr: int = int(list_config.get("ovr", RobotDatabase.calculate_ovr(list_config)))

		if i == PlayerProgress.selected_robot:
			status = "  ✔ WYBRANY"
		elif not PlayerProgress.is_robot_unlocked(i):
			status = "  🔒 %d CR" % int(data["cost"])

		_robot_buttons[i].text = "%s  •  OVR %d%s" % [str(data["name"]), list_ovr, status]
		_robot_buttons[i].set_pressed_no_signal(i == _viewed)

	var robot: Dictionary = RobotDatabase.get_robot(_viewed)
	var unlocked: bool = PlayerProgress.is_robot_unlocked(_viewed)

	var config: Dictionary = _get_preview_config()

	_name_label.text = str(robot["name"])
	_ovr_label.text = "OVR: %d / 100" % int(config.get("ovr", RobotDatabase.calculate_ovr(config)))

	if not unlocked:
		_name_label.text += "  •  PODGLĄD"
		_ovr_label.text += "  •  FABRYCZNY"

	_description_label.text = str(robot["description"])

	for row: Array in STAT_ROWS:
		var key: String = row[0]
		var value: float = float(config[key])

		(_stat_bars[key] as ProgressBar).value = clampf(
			RobotDatabase.normalized_stat(key, value),
			0.05,
			1.0
		)

		var value_text: String = "%.1f" % value

		if key == "max_speed":
			value_text = "%.1f km/h" % (value * 3.6)
		elif key == "boost_speed_multiplier":
			value_text = "×%.2f" % value
		elif key == "capacity":
			value_text = "%d" % int(value)

		(_stat_values[key] as Label).text = value_text

	# Osobny przycisk zakupu lub wyboru.
	if not unlocked:
		_action_button.text = "ODBLOKUJ ZA %d CR" % int(robot["cost"])
		_action_button.disabled = not PlayerProgress.can_afford(
			int(robot["cost"])
		)

	elif _viewed == PlayerProgress.selected_robot:
		_action_button.text = "✔ WYBRANY DO WYŚCIGU"
		_action_button.disabled = true

	else:
		_action_button.text = "WYBIERZ TEGO ROBOTA"
		_action_button.disabled = false

	if _engine_sound_option != null:
		_engine_sound_option.select(clampi(SaveManager.get_int("robot_audio", str(_viewed), 0), 0, 2))
	_refresh_look(unlocked)
	_refresh_upgrades(unlocked)
	_refresh_repair(unlocked)

	if _docking_editor != null:
		_docking_editor.set_robot_index(_viewed)

	_update_preview()


# =========================================================
# WYGLĄD
# =========================================================

func _refresh_look(unlocked: bool) -> void:
	for child: Node in _skin_box.get_children():
		child.queue_free()

	for child: Node in _neon_box.get_children():
		child.queue_free()

	var current_skin: int = PlayerProgress.get_skin(_viewed)

	var last_category: String = ""
	for i: int in range(RobotDatabase.SKINS.size()):
		var skin: Dictionary = RobotDatabase.get_skin(i)
		var owned: bool = PlayerProgress.is_skin_unlocked(i)

		# Nagłówek kategorii stylu (jak w skórkach mebli), zajmuje cały wiersz siatki.
		var category_id: String = str(skin.get("category", "factory"))
		if category_id != last_category:
			if _skin_box.get_child_count() % 2 == 1:
				_skin_box.add_child(Control.new())
			last_category = category_id
			var category_name: String = category_id.to_upper()
			for category: Dictionary in RobotDatabase.SKIN_CATEGORIES:
				if str(category["id"]) == category_id:
					category_name = str(category["name"])
			_skin_box.add_child(UIKit.make_label(category_name, 26, UIKit.COLOR_ACCENT))
			_skin_box.add_child(Control.new())

		var label: String = str(skin["name"])

		if i == current_skin and unlocked:
			label = "✔ " + label
		elif not owned:
			label += "  (%d CR)" % int(skin["cost"])

		var button := UIKit.make_button(label, 28, 90)

		var color: Color = (
			RobotDatabase.get_robot(_viewed)["color"]
			if skin["primary"] == null
			else skin["primary"]
		)

		var style := UIKit.panel_style(
			color.darkened(0.45),
			color,
			14,
			4,
			12
		)

		button.add_theme_stylebox_override("normal", style)

		# Nie można kupować ani zmieniać skórek,
		# oglądając nieodblokowanego robota.
		button.disabled = not unlocked

		button.pressed.connect(_on_skin.bind(i))
		_skin_box.add_child(button)

	var current_neon: int = PlayerProgress.get_neon(_viewed)

	for i: int in range(RobotDatabase.NEON_COLORS.size()):
		var neon: Dictionary = RobotDatabase.NEON_COLORS[i]

		var label: String = str(neon["name"])

		if i == current_neon and unlocked:
			label = "✔ " + label

		var button := UIKit.make_button(label, 24, 84)

		var neon_color: Color = neon["color"]

		button.add_theme_stylebox_override(
			"normal",
			UIKit.panel_style(
				neon_color.darkened(0.6),
				neon_color,
				14,
				4,
				8
			)
		)

		button.disabled = not unlocked
		button.pressed.connect(_on_neon.bind(i))

		_neon_box.add_child(button)


# =========================================================
# ULEPSZENIA
# =========================================================

func _refresh_upgrades(unlocked: bool) -> void:
	for child: Node in _upgrade_box.get_children():
		child.queue_free()

	if not unlocked:
		_upgrade_box.add_child(
			UIKit.make_label(
				"Odblokuj robota, aby go ulepszać.",
				30,
				UIKit.COLOR_MUTED
			)
		)
		return

	var upgrades: Dictionary = PlayerProgress.get_upgrades(_viewed)

	for upgrade: Dictionary in RobotDatabase.UPGRADES:
		var id: String = str(upgrade["id"])
		var level: int = int(upgrades[id])

		var panel := UIKit.make_panel(
			Color(0.04, 0.07, 0.1, 0.9)
		)
		panel.mouse_filter = Control.MOUSE_FILTER_IGNORE

		_upgrade_box.add_child(panel)

		var row := HBoxContainer.new()
		row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		row.add_theme_constant_override("separation", 16)

		panel.add_child(row)

		var text_column := VBoxContainer.new()
		text_column.mouse_filter = Control.MOUSE_FILTER_IGNORE
		text_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL

		row.add_child(text_column)

		var title_label := UIKit.make_label(
				"%s   %s" % [
					str(upgrade["name"]),
					"■".repeat(level) + "□".repeat(
						RobotDatabase.UPGRADE_MAX_LEVEL - level
					)
				],
				30
			)
		title_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		text_column.add_child(title_label)

		var description_label := UIKit.make_label(
			str(upgrade["description"]),
			22,
			UIKit.COLOR_MUTED
		)
		description_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		description_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		text_column.add_child(description_label)

		var cost: int = RobotDatabase.get_upgrade_cost(level)

		var button := UIKit.make_button(
			"MAKS." if cost < 0 else "ULEPSZ  %d CR" % cost,
			28,
			90
		)

		button.custom_minimum_size = Vector2(148, 64)
		button.size_flags_horizontal = Control.SIZE_SHRINK_END
		button.add_theme_font_size_override("font_size", 18)

		button.disabled = (
			cost < 0
			or not PlayerProgress.can_afford(cost)
		)

		button.pressed.connect(_on_upgrade.bind(id))

		row.add_child(button)
	_set_touch_scroll_passthrough(_upgrade_box)


func _set_touch_scroll_passthrough(node: Node) -> void:
	for child: Node in node.get_children():
		if child is Control:
			var control := child as Control
			if not (control is Button or control is OptionButton or control is LineEdit):
				control.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_set_touch_scroll_passthrough(child)


# =========================================================
# NAPRAWA
# =========================================================

func _refresh_repair(unlocked: bool) -> void:
	var damage: float = PlayerProgress.get_damage(_viewed)

	var stage: int = (
		3 if damage >= 75.0
		else 2 if damage >= 50.0
		else 1 if damage >= 25.0
		else 0
	)

	_repair_label.text = "Stan robota: %s (%d%%)" % [
		DamageSystem.STAGE_NAMES[stage],
		int(damage)
	]

	_repair_label.add_theme_color_override(
		"font_color",
		DamageSystem.STAGE_COLORS[stage]
	)

	_repair_bar.value = 1.0 - damage / 100.0

	UIKit.set_bar_color(
		_repair_bar,
		DamageSystem.STAGE_COLORS[stage]
	)

	var cost: int = PlayerProgress.get_repair_cost(_viewed)

	if damage <= 0.0 or not unlocked:
		_repair_button.text = (
			"ROBOT SPRAWNY"
			if unlocked
			else "ROBOT ZABLOKOWANY"
		)

		_repair_button.disabled = true

	elif PlayerProgress.currency >= cost:
		_repair_button.text = "NAPRAW  (%d CR)" % cost
		_repair_button.disabled = false

	else:
		_repair_button.text = (
			"NAPRAW CZĘŚCIOWO  (%d CR)"
			% PlayerProgress.currency
		)

		_repair_button.disabled = PlayerProgress.currency <= 0


# =========================================================
# AKCJE
# =========================================================

func _view_robot(index: int) -> void:
	if index < 0 or index >= RobotDatabase.count():
		return

	_viewed = index
	_message_label.text = ""

	_refresh()


func _on_action() -> void:
	if not PlayerProgress.is_robot_unlocked(_viewed):
		var robot: Dictionary = RobotDatabase.get_robot(_viewed)
		var cost: int = int(robot["cost"])

		if not PlayerProgress.can_afford(cost):
			_message_label.text = "Za mało kredytów."
			return

		if PlayerProgress.unlock_robot(_viewed):
			_message_label.text = "Odblokowano robota!"
			AudioManager.play("finish", -6.0)
		else:
			_message_label.text = "Nie udało się odblokować robota."

	else:
		PlayerProgress.select_robot(_viewed)

		_message_label.text = "Wybrano: %s" % str(
			RobotDatabase.get_robot(_viewed)["name"]
		)

	_refresh()


func _on_skin(index: int) -> void:
	if not PlayerProgress.is_robot_unlocked(_viewed):
		return

	if not PlayerProgress.is_skin_unlocked(index):
		if not PlayerProgress.unlock_skin(index):
			_message_label.text = "Za mało kredytów na tę skórkę."
			return

		_message_label.text = (
			"Odblokowano skórkę (dostępna dla wszystkich robotów)."
		)

	PlayerProgress.set_skin(_viewed, index)
	_refresh()


func _on_neon(index: int) -> void:
	if not PlayerProgress.is_robot_unlocked(_viewed):
		return

	PlayerProgress.set_neon(_viewed, index)
	_refresh()


func _on_upgrade(upgrade_id: String) -> void:
	if PlayerProgress.buy_upgrade(_viewed, upgrade_id):
		_message_label.text = "Ulepszenie zakupione! Robot zyskał nowy element."
		AudioManager.play("lap", -4.0)
		_update_preview()
	else:
		_message_label.text = "Nie można kupić ulepszenia."

	_refresh()


func _on_repair() -> void:
	var repaired: float = PlayerProgress.repair(_viewed)

	if repaired > 0.0:
		_message_label.text = "Naprawiono %d%% uszkodzeń." % int(
			round(repaired)
		)
	else:
		_message_label.text = "Brak środków na naprawę."

	_refresh()


# =========================================================
# POWRÓT
# =========================================================

func _go_back() -> void:
	GameManager.go_to_main_menu()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_go_back()
