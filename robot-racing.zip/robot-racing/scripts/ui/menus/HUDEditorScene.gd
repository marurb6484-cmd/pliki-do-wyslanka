extends Control
## Edytor układu HUD uruchamiany z ustawień (bez wyścigu).
## Pokazuje HUD z przykładowymi danymi i od razu otwiera edytor.

const HUD_SCENE: PackedScene = preload("res://ui/hud/RaceHUD.tscn")


func _ready() -> void:
	UIKit.add_menu_background(self)
	var hint := UIKit.make_label("Podgląd HUD - przesuń elementy i zapisz układ", 30, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_CENTER)
	hint.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	hint.offset_top = -60
	add_child(hint)

	var hud: Node = HUD_SCENE.instantiate()
	add_child(hud)
	hud.call("enter_preview")
	hud.call("open_editor")


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		GameManager.go_back()
