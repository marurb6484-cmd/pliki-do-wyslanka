extends Control
## Pierwszy ekran po uruchomieniu gry: wybór uproszczonego lub pełnego interfejsu.

func _ready() -> void:
	get_tree().paused = false
	UIKit.add_menu_background(self)
	var margin := UIKit.make_screen_margin(self, 48)
	var column := VBoxContainer.new()
	column.alignment = BoxContainer.ALIGNMENT_CENTER
	column.add_theme_constant_override("separation", 24)
	margin.add_child(column)
	column.add_child(UIKit.make_label("ROBOT RACING", 76, UIKit.COLOR_ACCENT, HORIZONTAL_ALIGNMENT_CENTER))
	column.add_child(UIKit.make_label("WYBIERZ WERSJĘ INTERFEJSU", 34, UIKit.COLOR_TEXT, HORIZONTAL_ALIGNMENT_CENTER))
	var cards := HBoxContainer.new()
	cards.size_flags_vertical = Control.SIZE_EXPAND_FILL
	cards.add_theme_constant_override("separation", 24)
	column.add_child(cards)
	var simple := UIKit.make_tile("TRYB PROSTY", "Duże przyciski i czytelne elementy.\nMniej ekranów i prostsza obsługa telefonu.\nNajważniejsze dostępne funkcje.", UIKit.COLOR_GOOD, func() -> void: _select_mode("simple"), "✓", "POLECANY NA TELEFON", 300, 42)
	simple.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	simple.size_flags_vertical = Control.SIZE_EXPAND_FILL
	cards.add_child(simple)
	var advanced := UIKit.make_tile("TRYB ZAAWANSOWANY", "Pełne obecne menu Robot Racing.\nRozbudowane edytory i ustawienia.\nDostęp do wszystkich sekcji projektu.", UIKit.COLOR_ACCENT, func() -> void: _select_mode("advanced"), "⚙", "PEŁNA KONTROLA", 300, 42)
	advanced.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	advanced.size_flags_vertical = Control.SIZE_EXPAND_FILL
	cards.add_child(advanced)
	column.add_child(UIKit.make_label("Wyboru możesz później dokonać ponownie w USTAWIENIACH.", 22, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_CENTER))


func _select_mode(mode: String) -> void:
	GameSettings.set_play_style(mode)
	GameManager.change_scene(GameManager.SCENE_MAIN_MENU)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_select_mode("simple")
