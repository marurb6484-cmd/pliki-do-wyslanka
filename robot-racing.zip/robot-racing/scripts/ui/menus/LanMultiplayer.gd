extends Control
## Ekran połączenia dwóch telefonów przez wspólne Wi-Fi lub hotspot.

var _ip: LineEdit
var _status: Label
var _room: LineEdit
var _host_button: Button
var _join_button: Button

func _ready() -> void:
	UIKit.add_menu_background(self)
	var margin := UIKit.make_screen_margin(self, 36)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 18)
	margin.add_child(column)
	column.add_child(UIKit.make_header("MULTIPLAYER — WI-FI", GameManager.go_to_main_menu))
	column.add_child(UIKit.make_label("Połącz dwa telefony w tej samej sieci Wi-Fi albo podłącz drugi telefon do hotspotu pierwszego.", 24, UIKit.COLOR_MUTED))
	_room = LineEdit.new()
	_room.placeholder_text = "Nazwa pokoju"
	_room.text = "Robot Racing"
	_room.custom_minimum_size.y = 58
	column.add_child(_room)
	_host_button = UIKit.make_button("UTWÓRZ POKÓJ", 28, 66)
	_host_button.pressed.connect(_host)
	column.add_child(_host_button)
	column.add_child(UIKit.make_label("DOŁĄCZ DO DRUGIEGO TELEFONU", 25, UIKit.COLOR_ACCENT))
	_ip = LineEdit.new()
	_ip.placeholder_text = "Adres IPv4 hosta, np. 192.168.1.20"
	_ip.custom_minimum_size.y = 58
	column.add_child(_ip)
	_join_button = UIKit.make_button("DOŁĄCZ", 28, 66)
	_join_button.pressed.connect(_join)
	column.add_child(_join_button)
	_status = UIKit.make_label(LanNetworkSession.get_local_ip_hint(), 21, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false)
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(_status)
	var disconnect_button := UIKit.make_button("ROZŁĄCZ", 22, 56)
	disconnect_button.pressed.connect(func() -> void:
		LanNetworkSession.disconnect_room()
		_status.text = "Rozłączono."
	)
	column.add_child(disconnect_button)
	column.add_child(UIKit.make_label("Uwaga: ta wersja zestawia i utrzymuje połączenie LAN oraz potwierdza obecność drugiego telefonu. Synchronizacja pełnego wyścigu przez sieć jest kolejnym etapem. Bluetooth nie jest jeszcze obsługiwany.", 20, UIKit.COLOR_WARN))
	LanNetworkSession.status_changed.connect(_on_status)
	LanNetworkSession.peer_joined.connect(func(_id: int) -> void: _status.text = "Drugi telefon jest w pokoju.")
	LanNetworkSession.room_info_received.connect(func(data: Dictionary) -> void: _status.text = "Połączono z pokojem: %s" % str(data.get("name", "Robot Racing")))

func _host() -> void:
	var result := LanNetworkSession.host_room(_room.text)
	if result == OK:
		_status.text = "Pokój uruchomiony na porcie %d. Drugi telefon musi być w tej samej sieci. %s" % [LanNetworkSession.DEFAULT_PORT, LanNetworkSession.get_local_ip_hint()]

func _join() -> void:
	LanNetworkSession.join_room(_ip.text)

func _on_status(message: String) -> void:
	_status.text = message

func _exit_tree() -> void:
	if LanNetworkSession.status_changed.is_connected(_on_status):
		LanNetworkSession.status_changed.disconnect(_on_status)
	LanNetworkSession.disconnect_room()
