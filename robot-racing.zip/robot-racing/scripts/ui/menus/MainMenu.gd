extends Control
## Główne menu Robot Racing v0.3.
## GRAJ i EDYTUJ są głównymi wejściami. Centrum gracza otwiera profil.

var _currency_label: Label
var _currency_chip: PanelContainer
var _robot_label: Label
var _stats_label: Label
var _profile_name_label: Label
var _creator_thumbnail: TextureRect
var _creator_thumbnail_button: Button
var _creator_http: HTTPRequest

const CREATOR_CHANNEL_URL := "https://youtube.com/@szakalpcandroid?si=xlUUiiSp1gqcj9nu"


func _ready() -> void:
	get_tree().paused = false
	if GameSettings.is_simple_play_style():
		_build_simple_menu()
	else:
		_build_advanced_menu()
	if not GameSettings.graphics_quality_chosen:
		call_deferred("_show_first_run_quality_prompt")
	else:
		call_deferred("_show_style_pack_intro")


func _build_simple_menu() -> void:
	get_tree().paused = false
	UIKit.add_menu_background(self)
	var margin := UIKit.make_screen_margin(self, 42)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 18)
	margin.add_child(root)

	var header := VBoxContainer.new()
	header.add_theme_constant_override("separation", 2)
	root.add_child(header)
	var title := UIKit.make_label("ROBOT RACING", 76, UIKit.COLOR_ACCENT, HORIZONTAL_ALIGNMENT_CENTER)
	title.add_theme_font_size_override("font_size", 76)
	header.add_child(title)
	header.add_child(UIKit.make_label("WYBIERZ, CO CHCESZ ZROBIĆ", 25, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_CENTER))

	var actions := GridContainer.new()
	actions.columns = 2
	actions.size_flags_vertical = Control.SIZE_EXPAND_FILL
	actions.add_theme_constant_override("h_separation", 20)
	actions.add_theme_constant_override("v_separation", 16)
	root.add_child(actions)
	var play := UIKit.make_button("▶  GRAJ", 40, 104)
	play.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	play.size_flags_vertical = Control.SIZE_EXPAND_FILL
	play.pressed.connect(func() -> void: GameManager.change_scene(GameManager.SCENE_MODE_SELECT))
	actions.add_child(play)
	var garage := UIKit.make_button("🤖  GARAŻ", 40, 104)
	garage.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	garage.size_flags_vertical = Control.SIZE_EXPAND_FILL
	garage.pressed.connect(func() -> void: GameManager.change_scene(GameManager.SCENE_GARAGE))
	actions.add_child(garage)
	var multiplayer := UIKit.make_button("🌐  MULTIPLAYER", 40, 104)
	multiplayer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	multiplayer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	multiplayer.pressed.connect(func() -> void: GameManager.open_hub("multiplayer"))
	actions.add_child(multiplayer)
	var settings := UIKit.make_button("⚙  USTAWIENIA", 40, 104)
	settings.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	settings.size_flags_vertical = Control.SIZE_EXPAND_FILL
	settings.pressed.connect(func() -> void: GameManager.open_settings(GameManager.SCENE_MAIN_MENU))
	actions.add_child(settings)

	var creator := Button.new()
	creator.custom_minimum_size = Vector2(0, 92)
	creator.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	creator.text = "SZAKAL PC ON ANDROID  •  PORADNIKI I GRY PC NA ANDROIDZIE  •  OTWÓRZ KANAŁ ▶"
	creator.add_theme_font_size_override("font_size", 25)
	creator.pressed.connect(func() -> void: OS.shell_open(CREATOR_CHANNEL_URL))
	root.add_child(creator)

	var ad_slot := PanelContainer.new()
	ad_slot.name = "ReservedAdSlot"
	ad_slot.custom_minimum_size = Vector2(0, 100)
	ad_slot.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var ad_style := StyleBoxFlat.new()
	ad_style.bg_color = Color(0.04, 0.06, 0.09, 0.42)
	ad_style.border_color = Color(0.45, 0.55, 0.62, 0.28)
	ad_style.set_border_width_all(1)
	ad_style.set_corner_radius_all(10)
	ad_slot.add_theme_stylebox_override("panel", ad_style)
	ad_slot.add_child(UIKit.make_label("MIEJSCE NA REKLAMĘ 320 × 100", 22, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_CENTER))
	root.add_child(ad_slot)

	var footer := HBoxContainer.new()
	footer.add_theme_constant_override("separation", 14)
	root.add_child(footer)
	footer.add_child(UIKit.make_label("%d CR" % PlayerProgress.currency, 25, UIKit.COLOR_GOOD))
	var profile := UIKit.make_button("PROFIL", 22, 58, "ghost")
	profile.pressed.connect(func() -> void: GameManager.open_hub("profile"))
	footer.add_child(profile)
	var quit := UIKit.make_button("WYJŚCIE", 22, 58, "danger")
	quit.pressed.connect(_on_quit)
	footer.add_child(quit)


func _build_advanced_menu() -> void:
	get_tree().paused = false
	UIKit.add_menu_background(self)
	var margin := UIKit.make_screen_margin(self, 30)

	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 14)
	margin.add_child(root)

	# --- Pasek górny: logo po lewej, saldo po prawej ---
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 20)
	root.add_child(header)
	var branding := VBoxContainer.new()
	branding.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	branding.add_theme_constant_override("separation", 0)
	header.add_child(branding)
	var title := UIKit.make_label("ROBOT RACING", 68, UIKit.COLOR_ACCENT)
	title.add_theme_constant_override("outline_size", 12)
	branding.add_child(title)
	branding.add_child(UIKit.make_label("Wyścigi robotów sprzątających", 24, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false))
	_currency_chip = UIKit.make_chip("0 CR", UIKit.COLOR_GOOD, 36)
	_currency_chip.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	header.add_child(_currency_chip)
	_currency_label = _currency_chip.get_child(0) as Label

	# --- Środek: dwa duże kafelki i panel gracza ---
	var main_row := HBoxContainer.new()
	main_row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	main_row.add_theme_constant_override("separation", 26)
	root.add_child(main_row)

	var play_card: Button = UIKit.make_tile("GRAJ", "Single-player • Multi • Monster City\nWybierz świat i sposób rozgrywki.", UIKit.COLOR_ACCENT, func() -> void: GameManager.change_scene(GameManager.SCENE_MODE_SELECT), "▶", "", 220, 48)
	play_card.size_flags_vertical = Control.SIZE_EXPAND_FILL
	main_row.add_child(play_card)

	var edit_card: Button = UIKit.make_tile("EDYTUJ", "Edytor tras • Edytor boostów\nEdytor garażu • Własne skórki.", UIKit.COLOR_GOOD, func() -> void: GameManager.open_hub("editor"), "✎", "", 220, 48)
	edit_card.size_flags_vertical = Control.SIZE_EXPAND_FILL
	main_row.add_child(edit_card)

	# Cały panel gracza jest jednym przyciskiem (bez osobnego wejścia PROFIL).
	var profile_card: Button = UIKit.make_tile_shell(UIKit.COLOR_ACCENT, 220)
	profile_card.custom_minimum_size.x = 470
	profile_card.size_flags_horizontal = Control.SIZE_FILL
	profile_card.size_flags_vertical = Control.SIZE_EXPAND_FILL
	profile_card.pressed.connect(func() -> void: GameManager.open_hub("profile"))
	var creator_column := VBoxContainer.new()
	creator_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	creator_column.size_flags_vertical = Control.SIZE_EXPAND_FILL
	creator_column.add_theme_constant_override("separation", 10)
	creator_column.custom_minimum_size.x = 470
	main_row.add_child(creator_column)
	creator_column.add_child(profile_card)

	var info: VBoxContainer = profile_card.get_meta("content")
	info.add_child(UIKit.make_label("CENTRUM GRACZA  ›", 30, UIKit.COLOR_ACCENT))
	_profile_name_label = UIKit.make_label("", 26, UIKit.COLOR_TEXT)
	info.add_child(_profile_name_label)
	_robot_label = UIKit.make_label("", 22)
	info.add_child(_robot_label)
	_stats_label = UIKit.make_label("", 19, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false)
	_stats_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info.add_child(_stats_label)
	info.add_spacer(false)
	info.add_child(UIKit.make_label("Dotknij, aby otworzyć profil gracza.", 17, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false))

	# Panel twórcy pod Centrum Gracza — miniatura najnowszego filmu z kanału.
	var creator_panel := PanelContainer.new()
	creator_panel.custom_minimum_size = Vector2(0, 190)
	creator_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var creator_style := StyleBoxFlat.new()
	creator_style.bg_color = Color(0.035, 0.055, 0.075, 0.94)
	creator_style.border_color = Color(0.0, 0.78, 0.78, 0.85)
	creator_style.set_border_width_all(2)
	creator_style.set_corner_radius_all(12)
	creator_panel.add_theme_stylebox_override("panel", creator_style)
	creator_column.add_child(creator_panel)
	var creator_row := HBoxContainer.new()
	creator_row.add_theme_constant_override("separation", 14)
	creator_panel.add_child(creator_row)
	# Miniatura filmu jest głównym przyciskiem reklamy kanału.
	_creator_thumbnail_button = Button.new()
	_creator_thumbnail_button.custom_minimum_size = Vector2(250, 141)
	_creator_thumbnail_button.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_creator_thumbnail_button.flat = true
	_creator_thumbnail_button.tooltip_text = "Otwórz kanał SZAKAL PC ON ANDROID na YouTube"
	_creator_thumbnail_button.pressed.connect(func() -> void: OS.shell_open(CREATOR_CHANNEL_URL))
	_creator_thumbnail = TextureRect.new()
	_creator_thumbnail.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_creator_thumbnail.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_creator_thumbnail.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	_creator_thumbnail.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_creator_thumbnail_button.add_child(_creator_thumbnail)
	creator_row.add_child(_creator_thumbnail_button)
	var creator_text := VBoxContainer.new()
	creator_text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	creator_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	creator_text.add_child(UIKit.make_label("SZAKAL PC ON ANDROID", 21, UIKit.COLOR_ACCENT))
	var invite := UIKit.make_label("Gry PC na Androidzie • poradniki • emulacja\nDOTKNIJ MINIATURY, ABY OTWORZYĆ KANAŁ  ▶", 17, UIKit.COLOR_TEXT, HORIZONTAL_ALIGNMENT_LEFT, false)
	invite.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	creator_text.add_child(invite)
	creator_row.add_child(creator_text)
	_request_creator_thumbnail()

	# Rezerwa na niewielki format reklamowy; obecnie jest to tylko neutralny placeholder.
	var ad_slot := PanelContainer.new()
	ad_slot.name = "ReservedAdSlot"
	# Standardowy format mobilny Large Banner 320x100; szerokość dopasowuje się do ekranu.
	ad_slot.custom_minimum_size = Vector2(0, 100)
	ad_slot.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var ad_style := StyleBoxFlat.new()
	ad_style.bg_color = Color(0.04, 0.06, 0.09, 0.42)
	ad_style.border_color = Color(0.45, 0.55, 0.62, 0.28)
	ad_style.set_border_width_all(1)
	ad_style.set_corner_radius_all(10)
	ad_slot.add_theme_stylebox_override("panel", ad_style)
	var ad_label := UIKit.make_label("MIEJSCE NA REKLAMĘ 320 × 100", 18, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_CENTER)
	ad_slot.add_child(ad_label)
	root.add_child(ad_slot)

	# --- Dolny rząd skrótów ---
	var shortcuts := HBoxContainer.new()
	shortcuts.add_theme_constant_override("separation", 14)
	root.add_child(shortcuts)
	_add_shortcut(shortcuts, "SKLEP", "store")
	_add_shortcut(shortcuts, "SPOŁECZNOŚĆ", "community")
	_add_shortcut(shortcuts, "USTAWIENIA", GameManager.SCENE_SETTINGS)
	_add_shortcut(shortcuts, "O TWÓRCY", "creator")
	_add_shortcut(shortcuts, "WYJŚCIE", "quit")

	_refresh()
	PlayerProgress.currency_changed.connect(func(_value: int) -> void: _refresh())
	PlayerProgress.progress_changed.connect(_refresh)


func _show_play_style_intro() -> void:
	# Wybór profilu interfejsu odbywa się przed wejściem do menu głównego.
	_show_style_pack_intro()


func _request_creator_thumbnail() -> void:
	# Pobieramy najnowszy film przez publiczny kanał RSS YouTube.
	# Feed po handle wymaga ID kanału, więc rozwiąż je ze strony kanału.
	_creator_http = HTTPRequest.new()
	_creator_http.timeout = 12.0
	add_child(_creator_http)
	_creator_http.request_completed.connect(_on_creator_feed_loaded)
	var page_request := HTTPRequest.new()
	page_request.timeout = 12.0
	add_child(page_request)
	page_request.request_completed.connect(_on_creator_channel_loaded)
	page_request.request("https://www.youtube.com/@szakalpcandroid")


func _on_creator_channel_loaded(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300:
		return
	var html := body.get_string_from_utf8()
	var regex := RegEx.new()
	regex.compile("\"(?:channelId|externalId)\"\\s*:\\s*\"(UC[A-Za-z0-9_-]{22})\"")
	var found := regex.search(html)
	if found == null:
		return
	if _creator_http != null:
		_creator_http.request("https://www.youtube.com/feeds/videos.xml?channel_id=" + found.get_string(1))


func _on_creator_feed_loaded(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300:
		return
	var regex := RegEx.new()
	regex.compile("<yt:videoId>([^<]+)</yt:videoId>")
	var found := regex.search(body.get_string_from_utf8())
	if found == null:
		return
	var image_request := HTTPRequest.new()
	image_request.timeout = 12.0
	add_child(image_request)
	image_request.request_completed.connect(_on_creator_image_loaded)
	image_request.request("https://i.ytimg.com/vi/" + found.get_string(1) + "/hqdefault.jpg")


func _on_creator_image_loaded(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300 or body.is_empty():
		return
	var image := Image.new()
	if image.load_jpg_from_buffer(body) == OK:
		_creator_thumbnail.texture = ImageTexture.create_from_image(image)




func _show_first_run_quality_prompt() -> void:
	if GameSettings.graphics_quality_chosen:
		return
	GameManager.launch_first_run_graphics_wizard()


func _show_style_pack_intro() -> void:
	if not StylePackManager.should_show_intro():
		return
	var dialog := AcceptDialog.new()
	dialog.title = "DODATKOWE MODELE 3D"
	dialog.dialog_text = "Pobieraj dodatkowe modele 3D mebli, przeszkód i zabrudzeń. Po instalacji działają offline.\nŹródło: Poly Haven • CC0 1.0 Universal."
	dialog.get_ok_button().text = "PÓŹNIEJ"
	dialog.custom_action.connect(func(action: StringName) -> void:
		if action == "open_style_packs":
			StylePackManager.mark_intro_seen()
			GameManager.open_settings(GameManager.SCENE_MAIN_MENU)
		elif action == "never":
			StylePackManager.mark_intro_seen()
	)
	dialog.add_button("ZOBACZ PAKIETY", true, "open_style_packs")
	dialog.add_button("NIE POKAZUJ PONOWNIE", false, "never")
	add_child(dialog)
	dialog.popup_centered(Vector2i(500, 210))


func _add_shortcut(parent: HBoxContainer, title: String, destination: String) -> void:
	var variant: String = "danger" if destination == "quit" else "ghost"
	var button := UIKit.make_button(title, 20, 60, variant)
	button.pressed.connect(func() -> void:
		if destination == "quit":
			_on_quit()
		elif destination == GameManager.SCENE_SETTINGS:
			GameManager.open_settings(GameManager.SCENE_MAIN_MENU)
		else:
			GameManager.open_hub(destination)
	)
	parent.add_child(button)


func _refresh() -> void:
	var stats: Dictionary = PlayerProgress.stats
	var player_name := SaveManager.get_string("profile", "nickname", "Gracz")
	_profile_name_label.text = player_name
	_currency_label.text = "%d CR" % PlayerProgress.currency
	_robot_label.text = "Wybrany robot: %s" % str(RobotDatabase.get_robot(PlayerProgress.selected_robot)["name"])
	_stats_label.text = "Wyścigi: %d   Wygrane: %d   Podia: %d\nZebrany brud: %d" % [int(stats.get("races", 0)), int(stats.get("wins", 0)), int(stats.get("podiums", 0)), int(stats.get("dirt_total", 0.0))]
	var damage: float = PlayerProgress.get_damage(PlayerProgress.selected_robot)
	if damage >= 25.0:
		_stats_label.text += "\nRobot uszkodzony: %d%% — napraw w garażu" % int(damage)


func _on_quit() -> void:
	SaveManager.save_now()
	get_tree().quit()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_on_quit()
