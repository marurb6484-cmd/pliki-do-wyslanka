extends Control
## Główny podział sekcji GRAJ: single-player, multi i Monster City.


func _ready() -> void:
	UIKit.add_menu_background(self)
	var margin := UIKit.make_screen_margin(self, 36)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 26)
	margin.add_child(column)
	column.add_child(UIKit.make_header("GRAJ — WYBIERZ TRYB", GameManager.go_to_main_menu))

	var cards := HBoxContainer.new()
	cards.size_flags_vertical = Control.SIZE_EXPAND_FILL
	cards.add_theme_constant_override("separation", 26)
	column.add_child(cards)
	var single: Button = UIKit.make_tile("SINGLE-PLAYER", "Wyścigi z AI, jazda na czas, kariera i wyzwania.\nTryby dla jednego gracza.", UIKit.COLOR_ACCENT, func() -> void: GameManager.change_scene(GameManager.SCENE_SINGLE_PLAYER), "▶", "", 320, 44)
	single.size_flags_vertical = Control.SIZE_EXPAND_FILL
	cards.add_child(single)
	var multi: Button = UIKit.make_tile("MULTI", "Gra lokalna, LAN/Wi-Fi i bezpośrednie połączenie online (test).", UIKit.COLOR_GOOD, func() -> void: GameManager.open_hub("multiplayer"), "▶", "", 320, 44)
	multi.size_flags_vertical = Control.SIZE_EXPAND_FILL
	cards.add_child(multi)
	if not GameSettings.is_simple_play_style():
		var monster: Button = UIKit.make_tile("MONSTER CITY", "Osobny świat wielkich robotów, miasto, swobodna jazda i wyścigi.\nPlanowane w Robot Racing v0.3.", UIKit.COLOR_MUTED, func() -> void: GameManager.open_hub("monster_city"), "", "WKRÓTCE", 320, 44)
		monster.size_flags_vertical = Control.SIZE_EXPAND_FILL
		cards.add_child(monster)


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		GameManager.go_to_main_menu()
