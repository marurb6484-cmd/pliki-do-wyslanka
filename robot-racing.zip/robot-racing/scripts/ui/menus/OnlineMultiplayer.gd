extends Control
## Internet multiplayer via Cloudflare Worker + Durable Objects (WSS).

const DEFAULT_WORKER_URL := "https://robot-racing-multiplayer.marurb6484.workers.dev"
const SERVER_CONFIG_PATH := "user://online_servers.cfg"

var _worker_url: LineEdit
var _server_select: OptionButton
var _saved_server_urls: Array[String] = []
var _player_name: LineEdit
var _room_code: LineEdit
var _status: Label
var _current_room_label: Label
var _players_list: VBoxContainer
var _rooms_list: VBoxContainer
var _ready_button: Button
var _start_button: Button
var _ai_count_select: OptionButton
var _is_host: bool = false
var _is_ready: bool = false
var _launching_online_race: bool = false

func _ready() -> void:
	UIKit.add_menu_background(self)
	var margin := UIKit.make_screen_margin(self, 36)
	var scroll := preload("res://scripts/ui/TouchScrollContainer.gd").new() as ScrollContainer
	UIKit.configure_touch_scroll(scroll)
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	margin.add_child(scroll)
	var column := VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 16)
	scroll.add_child(column)
	column.add_child(UIKit.make_header("MULTIPLAYER ONLINE", _go_back))
	var info := UIKit.make_label("Utwórz pokój albo wybierz istniejący z listy. Maksymalnie 6 graczy.", 22, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false)
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(info)
	_current_room_label = UIKit.make_label("AKTUALNY POKÓJ: —  |  GRACZE: 0/6", 26, UIKit.COLOR_ACCENT, HORIZONTAL_ALIGNMENT_LEFT, false)
	_current_room_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_current_room_label.add_theme_color_override("font_color", Color(0.45, 1.0, 0.72))
	column.add_child(_current_room_label)
	column.add_child(UIKit.make_section_title("SERWER CLOUDFLARE"))
	_server_select = OptionButton.new()
	_server_select.custom_minimum_size.y = 58
	_server_select.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_child(_server_select)
	_worker_url = LineEdit.new()
	_worker_url.placeholder_text = "https://nazwa-projektu.twoje-konto.workers.dev"
	_worker_url.custom_minimum_size.y = 62
	_worker_url.text = DEFAULT_WORKER_URL
	column.add_child(_worker_url)
	var save_server := UIKit.make_button("DODAJ / ZAPISZ TEN SERWER", 20, 58, "ghost")
	save_server.pressed.connect(_save_current_server)
	column.add_child(save_server)
	_load_saved_servers()
	_server_select.item_selected.connect(_on_server_selected)
	_player_name = LineEdit.new()
	_player_name.placeholder_text = "Nazwa gracza"
	_player_name.text = "Robot"
	_player_name.custom_minimum_size.y = 62
	column.add_child(_player_name)
	var create := UIKit.make_button("UTWÓRZ POKÓJ", 27, 70)
	create.pressed.connect(_create_room)
	column.add_child(create)
	column.add_child(UIKit.make_section_title("DOSTĘPNE POKOJE"))
	var refresh := UIKit.make_button("ODŚWIEŻ LISTĘ POKOI", 23, 62, "ghost")
	refresh.pressed.connect(_refresh_rooms)
	column.add_child(refresh)
	_rooms_list = VBoxContainer.new()
	_rooms_list.add_theme_constant_override("separation", 10)
	column.add_child(_rooms_list)
	column.add_child(UIKit.make_section_title("DOŁĄCZ KODEM"))
	_room_code = LineEdit.new()
	_room_code.placeholder_text = "8-znakowy kod pokoju"
	_room_code.max_length = 8
	_room_code.custom_minimum_size.y = 62
	column.add_child(_room_code)
	var join := UIKit.make_button("DOŁĄCZ", 27, 70)
	join.pressed.connect(_join_room)
	column.add_child(join)
	var disconnect := UIKit.make_button("ROZŁĄCZ", 24, 62, "ghost")
	disconnect.pressed.connect(func() -> void: CloudflareOnlineSession.disconnect_room())
	column.add_child(disconnect)
	_status = UIKit.make_label("Status: niepołączono.", 22, UIKit.COLOR_ACCENT, HORIZONTAL_ALIGNMENT_LEFT, false)
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(_status)
	column.add_child(UIKit.make_section_title("GRACZE W LOBBY"))
	_players_list = VBoxContainer.new()
	_players_list.add_theme_constant_override("separation", 8)
	column.add_child(_players_list)
	_ready_button = UIKit.make_button("GOTOWY DO WYŚCIGU", 24, 66)
	_ready_button.pressed.connect(_toggle_ready)
	_ready_button.disabled = true
	column.add_child(_ready_button)
	column.add_child(UIKit.make_section_title("PRZECIWNICY AI W WYŚCIGU"))
	_ai_count_select = OptionButton.new()
	_ai_count_select.custom_minimum_size.y = 58
	_ai_count_select.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for ai_count: int in range(4):
		_ai_count_select.add_item(LocaleManager.tr_text("%d %s" % [ai_count, "robotów AI" if ai_count != 1 else "robot AI"]))
	_ai_count_select.select(0)
	_ai_count_select.disabled = true
	column.add_child(_ai_count_select)
	var ai_note := UIKit.make_label("Host wybiera 0–3 roboty AI. Liczba może zostać ograniczona wolnymi miejscami na starcie.", 18, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false)
	ai_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(ai_note)
	_start_button = UIKit.make_button("ROZPOCZNIJ WYŚCIG (HOST)", 24, 66)
	_start_button.pressed.connect(_request_start)
	_start_button.disabled = true
	column.add_child(_start_button)
	var note := UIKit.make_label("Lobby pokazuje gotowość każdego gracza. Host może rozpocząć wyścig, gdy dołączą co najmniej dwie osoby i wszyscy będą gotowi.", 19, UIKit.COLOR_WARN, HORIZONTAL_ALIGNMENT_LEFT, false)
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(note)
	if not CloudflareOnlineSession.status_changed.is_connected(_on_status):
		CloudflareOnlineSession.status_changed.connect(_on_status)
	if not CloudflareOnlineSession.connected_to_room.is_connected(_on_connected):
		CloudflareOnlineSession.connected_to_room.connect(_on_connected)
	if not CloudflareOnlineSession.players_changed.is_connected(_on_players_changed):
		CloudflareOnlineSession.players_changed.connect(_on_players_changed)
	if not CloudflareOnlineSession.lobby_changed.is_connected(_on_lobby_changed):
		CloudflareOnlineSession.lobby_changed.connect(_on_lobby_changed)
	if not CloudflareOnlineSession.rooms_received.is_connected(_on_rooms_received):
		CloudflareOnlineSession.rooms_received.connect(_on_rooms_received)
	if not CloudflareOnlineSession.race_starting.is_connected(_on_race_starting):
		CloudflareOnlineSession.race_starting.connect(_on_race_starting)
	if not CloudflareOnlineSession.packet_received.is_connected(_on_packet):
		CloudflareOnlineSession.packet_received.connect(_on_packet)
	if CloudflareOnlineSession.connected:
		_on_players_changed(CloudflareOnlineSession.get_players())
		_on_lobby_changed(CloudflareOnlineSession.get_players(), CloudflareOnlineSession.host_id)
	_refresh_rooms()

func _load_saved_servers() -> void:
	_saved_server_urls.clear()
	var config := ConfigFile.new()
	if config.load(SERVER_CONFIG_PATH) == OK:
		var stored: Variant = config.get_value("servers", "urls", [])
		if stored is Array:
			for item: Variant in stored:
				var url := str(item).strip_edges().trim_suffix("/")
				if url.begins_with("https://") and not _saved_server_urls.has(url):
					_saved_server_urls.append(url)
	if not _saved_server_urls.has(DEFAULT_WORKER_URL):
		_saved_server_urls.push_front(DEFAULT_WORKER_URL)
	_refresh_server_selector(DEFAULT_WORKER_URL)

func _refresh_server_selector(selected_url: String) -> void:
	_server_select.clear()
	var selected_index := 0
	for i in range(_saved_server_urls.size()):
		var url := _saved_server_urls[i]
		var display := "Mój serwer Robot Racing" if url == DEFAULT_WORKER_URL else url
		_server_select.add_item(display)
		_server_select.set_item_metadata(i, url)
		if url == selected_url:
			selected_index = i
	if _server_select.item_count > 0:
		_server_select.select(selected_index)
		_worker_url.text = str(_server_select.get_item_metadata(selected_index))

func _on_server_selected(index: int) -> void:
	if index >= 0 and index < _server_select.item_count:
		_worker_url.text = str(_server_select.get_item_metadata(index))
		_refresh_rooms()

func _save_current_server() -> void:
	var url := _worker_url.text.strip_edges().trim_suffix("/")
	if not url.begins_with("https://") or url.length() < 16:
		_on_status("Adres musi zaczynać się od https:// i być poprawnym adresem Workera.")
		return
	if not _saved_server_urls.has(url):
		_saved_server_urls.append(url)
	var config := ConfigFile.new()
	config.set_value("servers", "urls", _saved_server_urls)
	var save_error := config.save(SERVER_CONFIG_PATH)
	if save_error != OK:
		_on_status("Nie udało się zapisać serwera: %s" % error_string(save_error))
		return
	_refresh_server_selector(url)
	_on_status("Serwer zapisany. Będzie dostępny na kolejnych uruchomieniach gry.")
	_refresh_rooms()

func _create_room() -> void:
	_is_ready = false
	_ready_button.text = LocaleManager.tr_text("GOTOWY DO WYŚCIGU")
	CloudflareOnlineSession.create_room(_worker_url.text, _player_name.text)

func _join_room() -> void:
	_is_ready = false
	_ready_button.text = LocaleManager.tr_text("GOTOWY DO WYŚCIGU")
	CloudflareOnlineSession.join_room(_worker_url.text, _room_code.text, _player_name.text)

func _refresh_rooms() -> void:
	CloudflareOnlineSession.list_rooms(_worker_url.text)

func _on_rooms_received(rooms: Array) -> void:
	for child in _rooms_list.get_children():
		child.queue_free()
	if rooms.is_empty():
		_rooms_list.add_child(UIKit.make_label("Brak otwartych pokoi. Utwórz pokój lub odśwież listę.", 19, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false))
		return
	for item: Variant in rooms:
		if not item is Dictionary:
			continue
		var code := str(item.get("room_code", ""))
		var count := int(item.get("players_count", 0))
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		var label := UIKit.make_label(LocaleManager.tr_text("%s   Gracze: %d/6" % [code, count]), 20, UIKit.COLOR_TEXT, HORIZONTAL_ALIGNMENT_LEFT, false)
		label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(label)
		var button := UIKit.make_button("DOŁĄCZ", 19, 54)
		button.disabled = count >= 6
		button.pressed.connect(_join_listed_room.bind(code))
		row.add_child(button)
		_rooms_list.add_child(row)

func _join_listed_room(code: String) -> void:
	_room_code.text = code
	_join_room()

func _on_status(message: String) -> void:
	_status.text = "Status: " + message
	if not CloudflareOnlineSession.connected:
		_update_current_room_label(0)

func _on_connected(code: String, _id: String) -> void:
	_room_code.text = code
	_update_current_room_label()
	_ready_button.disabled = false
	_on_players_changed(CloudflareOnlineSession.get_players())
	_refresh_rooms()

func _on_players_changed(players: Array) -> void:
	_update_current_room_label(players.size())
	for child in _players_list.get_children():
		child.queue_free()
	if players.is_empty():
		_players_list.add_child(UIKit.make_label("Nie jesteś obecnie w lobby.", 20, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false))
		return
	for player: Variant in players:
		if not player is Dictionary:
			continue
		var name := str(player.get("player_name", "Robot"))
		var is_host := str(player.get("player_id", "")) == CloudflareOnlineSession.host_id
		var ready_text := "GOTOWY" if bool(player.get("ready", false)) else "OCZEKUJE"
		var host_text := "  • HOST" if is_host else ""
		var robot := str(player.get("robot_name", "Robot"))
		var ovr := clampi(int(player.get("ovr", 1)), 1, 100)
		var row := UIKit.make_label(LocaleManager.tr_text("%s%s   —   %s | %s • OVR %d" % [name, host_text, ready_text, robot, ovr]), 21, UIKit.COLOR_TEXT, HORIZONTAL_ALIGNMENT_LEFT, false)
		row.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		_players_list.add_child(row)

func _on_lobby_changed(players: Array, host_id: String) -> void:
	_on_players_changed(players)
	_update_current_room_label(players.size())
	var is_host := host_id == CloudflareOnlineSession.player_id and not host_id.is_empty()
	var all_ready := players.size() >= 2
	for player: Variant in players:
		if not player is Dictionary or not bool(player.get("ready", false)):
			all_ready = false
	_is_host = is_host
	_ai_count_select.disabled = not is_host
	var free_ai_slots: int = maxi(5 - players.size(), 0)
	for ai_index: int in range(_ai_count_select.item_count):
		_ai_count_select.set_item_disabled(ai_index, ai_index > free_ai_slots)
	if _ai_count_select.selected > free_ai_slots:
		_ai_count_select.select(free_ai_slots)
	_start_button.disabled = not is_host or not all_ready
	_start_button.text = LocaleManager.tr_text("ROZPOCZNIJ WYŚCIG (HOST)" if is_host else "OCZEKIWANIE NA HOSTA")

func _update_current_room_label(player_count: int = -1) -> void:
	if _current_room_label == null:
		return
	var code := CloudflareOnlineSession.room_code
	var count := player_count if player_count >= 0 else CloudflareOnlineSession.get_players().size()
	if not CloudflareOnlineSession.connected or code.is_empty():
		_current_room_label.text = LocaleManager.tr_text("AKTUALNY POKÓJ: —  |  GRACZE: 0/6")
	else:
		_current_room_label.text = LocaleManager.tr_text("AKTUALNY POKÓJ: %s  |  GRACZE: %d/6" % [code, count])


func _toggle_ready() -> void:
	_is_ready = not _is_ready
	var result := CloudflareOnlineSession.set_ready(_is_ready)
	if result == OK:
		_ready_button.text = LocaleManager.tr_text("ANULUJ GOTOWOŚĆ" if _is_ready else "GOTOWY DO WYŚCIGU")

func _request_start() -> void:
	var result := CloudflareOnlineSession.request_race_start(_ai_count_select.selected)
	if result != OK:
		_on_status("Nie udało się wysłać polecenia startu.")

func _on_race_starting(start_at: int, ai_count: int) -> void:
	if _launching_online_race:
		return
	_launching_online_race = true
	_on_status("Start potwierdzony przez serwer. Przygotowanie wyścigu…")
	_ready_button.disabled = true
	_start_button.disabled = true
	GameManager.configure_online_race(start_at, ai_count)
	GameManager.launch_race()

func _on_packet(packet: Dictionary) -> void:
	if str(packet.get("type", "")) == "input":
		pass

func _go_back() -> void:
	CloudflareOnlineSession.disconnect_room()
	GameManager.go_to_main_menu()

func _exit_tree() -> void:
	if CloudflareOnlineSession.status_changed.is_connected(_on_status): CloudflareOnlineSession.status_changed.disconnect(_on_status)
	if CloudflareOnlineSession.connected_to_room.is_connected(_on_connected): CloudflareOnlineSession.connected_to_room.disconnect(_on_connected)
	if CloudflareOnlineSession.players_changed.is_connected(_on_players_changed): CloudflareOnlineSession.players_changed.disconnect(_on_players_changed)
	if CloudflareOnlineSession.lobby_changed.is_connected(_on_lobby_changed): CloudflareOnlineSession.lobby_changed.disconnect(_on_lobby_changed)
	if CloudflareOnlineSession.rooms_received.is_connected(_on_rooms_received): CloudflareOnlineSession.rooms_received.disconnect(_on_rooms_received)
	if CloudflareOnlineSession.race_starting.is_connected(_on_race_starting): CloudflareOnlineSession.race_starting.disconnect(_on_race_starting)
	if CloudflareOnlineSession.packet_received.is_connected(_on_packet): CloudflareOnlineSession.packet_received.disconnect(_on_packet)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_go_back()
