extends Control
## Dostępne tryby jednoosobowe i katalog planowanych trybów.


func _ready() -> void:
	UIKit.add_menu_background(self)
	var margin := UIKit.make_screen_margin(self, 40)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 22)
	margin.add_child(column)
	column.add_child(UIKit.make_header("SINGLE-PLAYER", func() -> void: GameManager.change_scene(GameManager.SCENE_MODE_SELECT)))

	var scroll := ScrollContainer.new()
	UIKit.configure_touch_scroll(scroll)
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	column.add_child(scroll)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	grid.add_theme_constant_override("h_separation", 22)
	grid.add_theme_constant_override("v_separation", 22)
	scroll.add_child(grid)

	_add_mode(grid, "WYŚCIG", "Ty kontra roboty AI. Poziomy trudności, okrążenia i nagrody.", _on_race)
	_add_mode(grid, "JAZDA NA CZAS", "Samotna jazda z duchem najlepszego okrążenia.", _on_time_trial)
	_add_hub_link(grid, "KARIERA", "Postęp, kolejne ligi i kolekcja odblokowanych robotów.", "career")
	_add_hub_link(grid, "WYZWANIA", "Osiągnięcia i zadania dzienne z nagrodami CR.", "challenges")
	_add_locked(grid, "CLEAN RACE", "Wyścig połączony ze sprzątaniem.")
	_add_locked(grid, "OBSTACLE CHALLENGE", "Próby na trasach pełnych przeszkód.")
	_add_locked(grid, "GHOST CHALLENGE", "Rywalizacja z zapisanymi przejazdami.")
	_add_locked(grid, "UNDERGROUND", "Pojedynki 1 na 1 oraz osobne wyścigi 1/8 mili.")
	_add_locked(grid, "NIGHT RACE", "Wyścigi w nocnym oświetleniu.")
	_add_locked(grid, "SURVIVAL RACE", "Przetrwaj dynamicznie zmieniające się warunki.")
	_add_locked(grid, "FREE ROAM", "Swobodna jazda i poznawanie tras.")


func _add_mode(parent: GridContainer, title: String, description: String, callback: Callable) -> void:
	parent.add_child(UIKit.make_tile(title, description, UIKit.COLOR_ACCENT, callback, "▶", "", 170, 34))


func _add_hub_link(parent: GridContainer, title: String, description: String, page: String) -> void:
	parent.add_child(UIKit.make_tile(title, description, UIKit.COLOR_GOOD, func() -> void: GameManager.open_hub(page), "▶", "", 170, 34))


func _add_locked(parent: GridContainer, title: String, description: String) -> void:
	parent.add_child(UIKit.make_tile(title, description, UIKit.COLOR_MUTED, _show_locked_info.bind(title, description), "", "WKRÓTCE", 170, 34))

func _show_locked_info(title: String, description: String) -> void:
	var dialog := AcceptDialog.new()
	dialog.title = title
	dialog.dialog_text = description + "\n\nSTATUS: WKRÓTCE — funkcja jest zaplanowana w Robot Racing v0.3."
	dialog.ok_button_text = "ROZUMIEM"
	add_child(dialog)
	dialog.confirmed.connect(dialog.queue_free)
	dialog.canceled.connect(dialog.queue_free)
	dialog.popup_centered(Vector2i(760, 360))


func _on_race() -> void:
	GameManager.mode = GameManager.GameMode.RACE
	GameManager.change_scene(GameManager.SCENE_TRACK_SELECT)


func _on_time_trial() -> void:
	GameManager.mode = GameManager.GameMode.TIME_TRIAL
	GameManager.change_scene(GameManager.SCENE_TRACK_SELECT)


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		GameManager.change_scene(GameManager.SCENE_MODE_SELECT)
