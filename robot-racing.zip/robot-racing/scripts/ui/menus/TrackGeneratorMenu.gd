extends Control

const TrackGeneratorScript = preload("res://scripts/tracks/TrackGenerator.gd")
## Generator tras: parametry, deterministyczny seed, podgląd 2D,
## walidacja, zapis lokalny i natychmiastowe uruchomienie wyścigu.

var _seed_input: LineEdit
var _name_input: LineEdit
var _manual_name_input: LineEdit
var _size_select: OptionButton
var _manual_size_select: OptionButton
var _complexity_select: OptionButton
var _obstacles_select: OptionButton
var _theme_select: OptionButton
var _tod_select: OptionButton
var _dark_select: OptionButton
var _manual_tod_select: OptionButton
var _manual_dark_select: OptionButton
var _manual_theme_select: OptionButton
var _laps_select: OptionButton
var _route_type_select: OptionButton
## Legacy fields retained so older saved routes with external floor textures still load.
var _texture_selected_path: String = ""
var _texture_selected_slug: String = ""
var _texture_selected_author: String = ""
var _manual_laps_select: OptionButton
var _animals_select: OptionButton
var _furniture_density_select: OptionButton
var _saved_select: OptionButton
var _status: Label
var _preview_container: Control
var _map_preview: TrackMapPreview
var _generator_panel: VBoxContainer
var _manual_panel: VBoxContainer
var _manual_route_closed: bool = false
var _manual_added_closure_point: bool = false
var _manual_mode: bool = false
var _manual_direction: Vector2 = Vector2.RIGHT
var _manual_segment_length: float = 6.0
var _manual_route_points: Array[Vector3] = []
var _mode_label: Label
var _object_scale_slider: HSlider
var _segment_length_slider: HSlider
var _manual_status: Label
var _manual_test_button: Button
var _pan_button: Button
var _route_stats_label: Label
var _current_data: Dictionary = {}
var _selected_obstacle: int = -1
var _obstacle_status: Label
var _decoration_select: OptionButton
var _decoration_status: Label
var _selected_decoration_index: int = -1
var _move_step_select: HSlider
var _move_step_label: Label
var _map_zoom_slider: HSlider
var _map_zoom_label: Label
var _segment_length_label: Label
var _dragging_decoration_index: int = -1
var _drag_changed: bool = false
var _move_step: float = 1.0
var _undo_stack: Array[Dictionary] = []
var _redo_stack: Array[Dictionary] = []
const EDIT_HISTORY_LIMIT: int = 40

const DECORATION_KINDS: Array[String] = ["plant", "sofa", "table", "lamp", "toy", "fish_tank", "bookshelf", "box", "pillow", "chair", "bed", "cabinet", "pet_bowl", "robot_toy", "rug", "tv", "scratching_post", "pet_bed", "cat", "dog", "rabbit", "bearded_dragon", "parrot", "hamster", "guinea_pig", "turtle", "hedgehog", "ferret", "shoe", "sock", "mug", "book", "remote", "tennis_ball", "yarn", "paper_scrap", "food_scraps", "cable", "backpack", "fridge", "bathtub", "sink", "kitchen_counter", "trash_bin", "floor_fan", "wall_clock", "speaker", "game_console", "laptop", "monitor", "microwave", "toaster", "kettle", "fruit_bowl", "dish_rack", "washing_machine", "toilet", "shower", "radiator", "coat_rack", "umbrella_stand", "suitcase", "toy_car", "pet_tunnel", "water_dispenser", "vase", "candle", "towel_rack", "hanging_plant", "nightstand", "wardrobe", "coffee_table", "side_table", "shoe_rack", "ottoman", "laundry_basket", "floor_mirror", "tv_wall"]
const DECORATION_NAMES: Array[String] = ["Roślina", "Sofa", "Stół", "Lampa", "Zabawka", "Akwarium", "Regał", "Pudełko", "Poduszka", "Krzesło", "Łóżko", "Szafka", "Miska", "Zabawka-robot", "Dywan", "Telewizor", "Drapak", "Legowisko", "Kot", "Pies", "Królik", "Agama brodata", "Papuga", "Chomik", "Świnka morska", "Żółw", "Jeż", "Fretka", "But sportowy", "Skarpetka", "Kubek", "Książka", "Pilot", "Piłka tenisowa", "Kłębek włóczki", "Papier", "Resztki jedzenia", "Kabel", "Plecak", "Lodówka", "Wanna", "Umywalka", "Blat kuchenny", "Kosz na śmieci", "Wentylator", "Zegar ścienny", "Głośnik", "Konsola", "Laptop", "Monitor", "Mikrofalówka", "Toster", "Czajnik", "Miska z owocami", "Suszarka do naczyń", "Pralka", "Toaleta", "Prysznic", "Grzejnik", "Wieszak na ubrania", "Stojak na parasole", "Walizka", "Autko-zabawka", "Tunel dla zwierzaka", "Dystrybutor wody", "Wazon", "Świeca", "Wieszak na ręczniki", "Wisząca roślina", "Szafka nocna", "Szafa", "Stolik kawowy", "Stolik boczny", "Stojak na buty", "Pufa", "Kosz na pranie", "Lustro stojące", "Telewizor ścienny"]

## Kategorie panelu wyboru przedmiotów (układ dotykowy). `kinds` odwołuje się do DECORATION_KINDS.
const OBJECT_CATEGORIES: Array = [
	{"name": "MEBLE", "icon": "🛋", "kinds": ["sofa", "table", "chair", "bed", "cabinet", "bookshelf", "tv", "fridge", "kitchen_counter", "coat_rack", "umbrella_stand", "radiator", "nightstand", "wardrobe", "coffee_table", "side_table", "shoe_rack", "ottoman", "laundry_basket", "floor_mirror", "tv_wall"]},
	{"name": "PRZEDMIOTY", "icon": "🧦", "kinds": ["shoe", "sock", "mug", "book", "remote", "tennis_ball", "yarn", "paper_scrap", "food_scraps", "cable", "backpack", "box", "toy", "robot_toy", "suitcase", "toy_car", "candle", "vase", "trash_bin"]},
	{"name": "DEKORACJE", "icon": "🪴", "kinds": ["plant", "lamp", "pillow", "rug", "fish_tank", "pet_bowl", "pet_bed", "scratching_post", "bathtub", "sink", "wall_clock", "floor_fan", "hanging_plant", "pet_tunnel", "towel_rack"]},
	{"name": "ŁAZIENKA I AGD", "icon": "🍳", "kinds": ["microwave", "toaster", "kettle", "fruit_bowl", "dish_rack", "washing_machine", "toilet", "shower", "water_dispenser"]},
	{"name": "ELEKTRONIKA", "icon": "🎮", "kinds": ["speaker", "game_console", "laptop", "monitor"]},
	{"name": "ZWIERZĘTA", "icon": "🐾", "kinds": ["cat", "dog", "rabbit", "bearded_dragon", "parrot", "hamster", "guinea_pig", "turtle", "hedgehog", "ferret"]},
	{"name": "PRZESZKODY", "icon": "🚧", "kinds": []},
]
const KIND_ICONS: Dictionary = {
	"plant": "🪴", "sofa": "🛋", "table": "🍽", "lamp": "💡", "toy": "🧸", "fish_tank": "🐠", "bookshelf": "📚", "box": "📦",
	"pillow": "🛏", "chair": "🪑", "bed": "🛌", "cabinet": "🗄", "pet_bowl": "🥣", "robot_toy": "🤖", "rug": "🟫", "tv": "📺",
	"scratching_post": "🪵", "pet_bed": "🧺", "cat": "🐱", "dog": "🐶", "rabbit": "🐰", "bearded_dragon": "🦎", "parrot": "🦜",
	"shoe": "👟", "sock": "🧦", "mug": "☕", "book": "📖", "remote": "🎛", "tennis_ball": "🎾", "yarn": "🧶", "paper_scrap": "📄",
	"food_scraps": "🍞", "cable": "🔌", "backpack": "🎒", "fridge": "🧊", "bathtub": "🛁", "sink": "🚰", "kitchen_counter": "🧱", "trash_bin": "🗑", "floor_fan": "🌀", "wall_clock": "🕒", "speaker": "🔊", "game_console": "🎮", "laptop": "💻", "monitor": "🖥", "microwave": "📡", "toaster": "🍞", "kettle": "🫖", "fruit_bowl": "🍎", "dish_rack": "🍽", "washing_machine": "🧺", "toilet": "🚽", "shower": "🚿", "radiator": "♨", "coat_rack": "🧥", "umbrella_stand": "☂", "suitcase": "🧳", "toy_car": "🚗", "pet_tunnel": "🐾", "water_dispenser": "🚰", "vase": "🏺", "candle": "🕯", "towel_rack": "🧻", "hanging_plant": "🌿", "nightstand": "🛏", "wardrobe": "🚪", "coffee_table": "🪵", "side_table": "🪑", "shoe_rack": "👟", "ottoman": "🛋", "laundry_basket": "🧺", "floor_mirror": "🪞", "tv_wall": "📺",
}
var _skin_select: OptionButton
var _preview_title: Label
var _quick_generate_button: Button
var _preview_start_button: Button
const GENERATOR_PREFS_PATH: String = "user://generator_preferences.cfg"
var _view_2d_button: Button
var _view_3d_button: Button
var _view_3d_mode: bool = false
var _track3d_container: SubViewportContainer
var _track3d_viewport: SubViewport
var _track3d_root: Node3D
var _track3d_camera: Camera3D
var _track3d_track: Node3D
var _track3d_yaw: float = 0.6
var _track3d_pitch: float = 0.9
var _track3d_distance: float = 24.0
var _track3d_fit_distance: float = 24.0
var _track3d_zoom: float = 1.0
var _track3d_focus: Vector3 = Vector3.ZERO
var _track3d_dirty: bool = true
var _variant_select: OptionButton
var _category_index: int = 0
var _item_grid: GridContainer
var _object_box: VBoxContainer
var _obstacle_box: VBoxContainer
var _item_preview_viewport: SubViewport
var _item_preview_root: Node3D
var _item_preview_title: Label
var _picker_variant: int = -1
var _snap_to_grid: bool = true
var _snap_button: CheckButton


func _ready() -> void:
	UIKit.add_menu_background(self)
	var margin := UIKit.make_screen_margin(self, 26)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 12)
	margin.add_child(column)
	column.add_child(UIKit.make_header("GENERATOR TRAS", GameManager.go_to_main_menu))
	var body := HBoxContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 12)
	column.add_child(body)

	var left_scroll := ScrollContainer.new()
	UIKit.configure_touch_scroll(left_scroll)
	left_scroll.custom_minimum_size = Vector2(300, 0)
	left_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left_scroll.size_flags_stretch_ratio = 0.78
	left_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_child(left_scroll)
	var controls := VBoxContainer.new()
	controls.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	controls.add_theme_constant_override("separation", 16)
	left_scroll.add_child(controls)
	var mode_grid := GridContainer.new()
	mode_grid.columns = 1
	mode_grid.add_theme_constant_override("h_separation", 12)
	mode_grid.add_theme_constant_override("v_separation", 10)
	controls.add_child(mode_grid)
	var random_mode_button := UIKit.make_button("LOSOWA TRASA", 21, 64)
	random_mode_button.pressed.connect(_set_editor_mode.bind(false))
	mode_grid.add_child(random_mode_button)
	var manual_mode_button := UIKit.make_button("TWORZENIE TRASY", 21, 64)
	manual_mode_button.pressed.connect(_set_editor_mode.bind(true))
	mode_grid.add_child(manual_mode_button)
	_mode_label = UIKit.make_label("TRYB: GENERATOR LOSOWY", 20, UIKit.COLOR_ACCENT)
	controls.add_child(_mode_label)
	_generator_panel = VBoxContainer.new()
	_generator_panel.add_theme_constant_override("separation", 10)
	controls.add_child(_generator_panel)
	_manual_panel = VBoxContainer.new()
	_manual_panel.add_theme_constant_override("separation", 16)
	_manual_panel.visible = false
	controls.add_child(_manual_panel)

	_generator_panel.add_child(UIKit.make_label("USTAWIENIA GENEROWANIA", 28, UIKit.COLOR_ACCENT))
	_seed_input = _add_line_edit(_generator_panel, "Seed aktualnej trasy", str(randi_range(10000, 999999)))
	_seed_input.editable = false
	_name_input = _add_line_edit(_generator_panel, "Nazwa trasy", "Moja trasa")
	_size_select = _add_option(_generator_panel, "ROZMIAR MAPY", ["Mała (~100 m²)", "Średnia (~200 m²)", "Duża (~350 m²)", "Bardzo duża (~500 m²)", "Hala (~750 m²)", "Gigantyczna hala (~1000 m²)"])
	_size_select.select(1)
	_complexity_select = _add_option(_generator_panel, "ZŁOŻONOŚĆ TRASY", ["1 — spokojna", "2 — normalna", "3 — kręta", "4 — wymagająca", "5 — ekstremalna"])
	_complexity_select.select(1)
	_obstacles_select = _add_option(_generator_panel, "PRZESZKODY POZA TOREM", ["Brak", "Mało", "Średnio", "Dużo", "Bardzo dużo", "Maksimum"])
	_obstacles_select.select(1)
	_theme_select = _add_option(_generator_panel, "STYL POMIESZCZENIA", ["Mieszkanie", "Kuchnia", "Sypialnia", "Arena futurystyczna", "Hala do sprzątania"])
	_theme_select.select(0)
	_tod_select = _add_option(_generator_panel, "PORA DNIA", ["Dzień", "Wieczór", "Noc"])
	_tod_select.item_selected.connect(_on_time_setting_changed.bind(false))
	_dark_select = _add_option(_generator_panel, "CIEMNY POKÓJ W NOCY (BEZ LAMP)", ["Tak", "Nie"])
	_dark_select.item_selected.connect(_on_time_setting_changed.bind(false))
	_animals_select = _add_option(_generator_panel, "LICZBA ZWIERZĄT NA TRASIE", ["0 — brak", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10 — wszystkie gatunki"])
	_animals_select.select(5)
	_furniture_density_select = _add_option(_generator_panel, "LICZBA PRZEDMIOTÓW W OTOCZENIU", ["Mało", "Normalnie", "Dużo", "Bardzo dużo", "Maksimum"])
	_furniture_density_select.select(2)
	_route_type_select = _add_option(_generator_panel, "RODZAJ TRASY", ["Okrążenia — pętla", "Odcinek — start i meta osobno"])
	_route_type_select.item_selected.connect(_on_route_type_selected)
	_laps_select = _add_option(_generator_panel, "OKRĄŻENIA", ["1", "2", "3", "5", "10"])
	_laps_select.select(2)
	_generator_panel.add_child(UIKit.make_label("MODELE 3D", 25, UIKit.COLOR_ACCENT))
	var model_source := _add_option(_generator_panel, "ŹRÓDŁO MODELI", ["Modele standardowe", "Pakiet dodatkowy + standardowe braki", "WYŁĄCZNIE modele z pakietu (bez standardowych)"])
	model_source.select(2 if StylePackManager.is_downloaded_only_mode() else (1 if StylePackManager.use_downloaded_models else 0))
	model_source.item_selected.connect(func(index: int) -> void:
		if index == 2:
			StylePackManager.set_downloaded_only_mode(true)
		else:
			StylePackManager.set_downloaded_only_mode(false)
			StylePackManager.set_use_downloaded_models(index == 1)
	)
	var model_note := UIKit.make_label("Możesz używać modeli dodatkowych jako zamienników albo wyłączyć standardowe modele całkowicie. W trybie wyłącznym brakujące modele są pomijane.", 17, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false)
	model_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_generator_panel.add_child(model_note)
	_move_step_label = UIKit.make_label("KROK PRZESUWANIA OBIEKTÓW: 1,00 m", 20, UIKit.COLOR_TEXT)
	_manual_panel.add_child(_move_step_label)
	_move_step_select = HSlider.new()
	_move_step_select.min_value = 0.25
	_move_step_select.max_value = 5.0
	_move_step_select.step = 0.25
	_move_step_select.value = 1.0
	_move_step_select.custom_minimum_size = Vector2(180, 78)
	_move_step_select.focus_mode = Control.FOCUS_NONE
	UIKit.apply_touch_slider(_move_step_select)
	_move_step_select.mouse_filter = Control.MOUSE_FILTER_STOP
	_move_step_select.value_changed.connect(_on_move_step_selected)
	_manual_panel.add_child(_move_step_select)

	# Skórka obiektów: zmienia tylko materiały, modele pozostają te same.
	_skin_select = _add_option(_manual_panel, "SKÓRKA OBIEKTÓW (WYGLĄD MODELI)", ObjectSkins.skin_names())
	_skin_select.select(ObjectSkins.index_of(GameSettings.object_skin))
	_skin_select.item_selected.connect(_on_skin_selected)

	# Wybór kategorii i przedmiotu — duże kafelki pod palec.
	_manual_panel.add_child(UIKit.make_label("DODAJ DO TRASY", 26, UIKit.COLOR_ACCENT))
	_decoration_select = OptionButton.new()  # Model danych wyboru (poza drzewem); steruje nim siatka kafelków.
	for item_name: String in DECORATION_NAMES:
		_decoration_select.add_item(item_name)
	_decoration_select.select(0)
	var category_grid := GridContainer.new()
	category_grid.columns = 2
	category_grid.add_theme_constant_override("h_separation", 8)
	category_grid.add_theme_constant_override("v_separation", 8)
	_manual_panel.add_child(category_grid)
	var category_group := ButtonGroup.new()
	for category_number: int in range(OBJECT_CATEGORIES.size()):
		var category: Dictionary = OBJECT_CATEGORIES[category_number]
		var category_button := UIKit.make_button("%s\n%s" % [str(category["icon"]), str(category["name"])], 19, 84)
		category_button.toggle_mode = true
		category_button.button_group = category_group
		category_button.button_pressed = category_number == 0
		category_button.pressed.connect(_on_category_pressed.bind(category_number))
		category_grid.add_child(category_button)

	_object_box = VBoxContainer.new()
	_object_box.add_theme_constant_override("separation", 10)
	_manual_panel.add_child(_object_box)
	_obstacle_box = VBoxContainer.new()
	_obstacle_box.add_theme_constant_override("separation", 10)
	_obstacle_box.visible = false
	_manual_panel.add_child(_obstacle_box)

	# Podgląd 3D prawdziwego modelu (tego samego, który trafia na trasę) + wariant.
	var preview_row := HBoxContainer.new()
	preview_row.add_theme_constant_override("separation", 12)
	_object_box.add_child(preview_row)
	var item_preview_container := SubViewportContainer.new()
	item_preview_container.custom_minimum_size = Vector2(92, 92)
	item_preview_container.stretch = true
	item_preview_container.mouse_filter = Control.MOUSE_FILTER_IGNORE
	preview_row.add_child(item_preview_container)
	_item_preview_viewport = SubViewport.new()
	_item_preview_viewport.size = Vector2i(92, 92)
	_item_preview_viewport.own_world_3d = true
	_item_preview_viewport.transparent_bg = true
	_item_preview_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	item_preview_container.add_child(_item_preview_viewport)
	_setup_item_preview_scene()
	var preview_info := VBoxContainer.new()
	preview_info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	preview_info.add_theme_constant_override("separation", 8)
	preview_row.add_child(preview_info)
	_item_preview_title = UIKit.make_label("", 24, UIKit.COLOR_TEXT, HORIZONTAL_ALIGNMENT_LEFT, false)
	_item_preview_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	preview_info.add_child(_item_preview_title)
	_variant_select = _add_option(preview_info, "WARIANT", ["Automatyczny", "Wariant 1", "Wariant 2", "Wariant 3", "Wariant 4"])
	_variant_select.item_selected.connect(_on_variant_selected)

	_item_grid = GridContainer.new()
	_item_grid.columns = 2
	_item_grid.add_theme_constant_override("h_separation", 8)
	_item_grid.add_theme_constant_override("v_separation", 8)
	_object_box.add_child(_item_grid)

	_decoration_status = UIKit.make_label("Wybierz przedmiot, aby dodać go do trasy.", 19, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false)
	_decoration_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_object_box.add_child(_decoration_status)
	_object_box.add_child(UIKit.make_label("Nowe przedmioty dodawaj przyciskiem DODAJ — generator sam ustawi je obok toru. Istniejące meble możesz zaznaczyć na mapie i przesuwać poza jezdnię.", 16, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false))

	var select_grid := GridContainer.new()
	select_grid.columns = 2
	select_grid.add_theme_constant_override("h_separation", 8)
	select_grid.add_theme_constant_override("v_separation", 8)
	_object_box.add_child(select_grid)
	_add_editor_button(select_grid, "◀ POPRZEDNI", _select_previous_decoration)
	_add_editor_button(select_grid, "NASTĘPNY ▶", _select_next_decoration)

	# Panel właściwości wybranego obiektu: przesuwanie, obrót, skala.
	_object_box.add_child(UIKit.make_label("WYBRANY OBIEKT", 22, UIKit.COLOR_ACCENT))
	var transform_grid := GridContainer.new()
	transform_grid.columns = 3
	transform_grid.add_theme_constant_override("h_separation", 8)
	transform_grid.add_theme_constant_override("v_separation", 8)
	_object_box.add_child(transform_grid)
	_add_editor_button(transform_grid, "↶ 15°", _rotate_decoration.bind(-deg_to_rad(15.0)))
	_add_editor_button(transform_grid, "▲", _move_decoration.bind(Vector3(0.0, 0.0, -1.0)))
	_add_editor_button(transform_grid, "↷ 15°", _rotate_decoration.bind(deg_to_rad(15.0)))
	_add_editor_button(transform_grid, "◀", _move_decoration.bind(Vector3(-1.0, 0.0, 0.0)))
	_add_editor_button(transform_grid, "RESET", _reset_decoration_transform)
	_add_editor_button(transform_grid, "▶", _move_decoration.bind(Vector3(1.0, 0.0, 0.0)))
	_add_editor_button(transform_grid, "− MNIEJ", _scale_decoration.bind(0.85))
	_add_editor_button(transform_grid, "▼", _move_decoration.bind(Vector3(0.0, 0.0, 1.0)))
	_add_editor_button(transform_grid, "+ WIĘCEJ", _scale_decoration.bind(1.18))
	_manual_panel.add_child(UIKit.make_label("ROZMIAR ZAZNACZONEGO OBIEKTU", 19, UIKit.COLOR_TEXT))
	_object_scale_slider = HSlider.new()
	_object_scale_slider.min_value = 0.6
	_object_scale_slider.max_value = 2.4
	_object_scale_slider.step = 0.05
	_object_scale_slider.value = 1.0
	_object_scale_slider.custom_minimum_size = Vector2(180, 78)
	_object_scale_slider.focus_mode = Control.FOCUS_NONE
	UIKit.apply_touch_slider(_object_scale_slider)
	_object_scale_slider.mouse_filter = Control.MOUSE_FILTER_STOP
	_object_scale_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_object_scale_slider.value_changed.connect(_on_object_scale_slider_changed)
	_object_scale_slider.drag_started.connect(_on_object_scale_drag_started)
	_manual_panel.add_child(_object_scale_slider)
	var action_grid := GridContainer.new()
	action_grid.columns = 2
	action_grid.add_theme_constant_override("h_separation", 8)
	action_grid.add_theme_constant_override("v_separation", 8)
	_object_box.add_child(action_grid)
	_add_editor_button(action_grid, "+ DODAJ", _add_decoration)
	_add_editor_button(action_grid, "DUPLIKUJ", _duplicate_decoration)
	_add_editor_button(action_grid, "USUŃ", _delete_decoration)
	_build_obstacle_panel()
	_on_category_pressed(0)

	_manual_panel.add_child(UIKit.make_label("HISTORIA EDYCJI", 23, UIKit.COLOR_ACCENT))
	var history_grid := GridContainer.new()
	history_grid.columns = 2
	history_grid.add_theme_constant_override("h_separation", 8)
	history_grid.add_theme_constant_override("v_separation", 8)
	_manual_panel.add_child(history_grid)
	_add_editor_button(history_grid, "↶ COFNIJ", _undo_edit)
	_add_editor_button(history_grid, "PONÓW ↷", _redo_edit)

	var generate_button := UIKit.make_button("GENERUJ / LOSUJ PONOWNIE", 24, 64)
	generate_button.pressed.connect(_generate_new)
	_generator_panel.add_child(generate_button)
	var save_button := UIKit.make_button("ZAPISZ TRASĘ LOKALNIE", 22, 58)
	save_button.pressed.connect(_save_current)
	_generator_panel.add_child(save_button)
	var start_button := UIKit.make_button("ROZPOCZNIJ WYŚCIG  ▶", 26, 68)
	start_button.pressed.connect(_start_race)
	_generator_panel.add_child(start_button)
	_generator_panel.add_child(UIKit.make_label("MOJE ZAPISANE TRASY", 24, UIKit.COLOR_ACCENT))
	_saved_select = OptionButton.new()
	_saved_select.custom_minimum_size.y = 56
	_saved_select.add_theme_font_size_override("font_size", 20)
	_saved_select.item_selected.connect(_on_saved_selected)
	_generator_panel.add_child(_saved_select)
	var delete_button := UIKit.make_button("USUŃ WYBRANĄ TRASĘ", 19, 50)
	delete_button.pressed.connect(_delete_selected)
	_generator_panel.add_child(delete_button)
	_status = UIKit.make_label("Wygeneruj trasę, sprawdź czytelny podgląd 2D i zapisz ją, jeśli Ci odpowiada.", 20, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false)
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_generator_panel.add_child(_status)

	var preview_panel := UIKit.make_panel()
	var preview_frame := StyleBoxFlat.new()
	preview_frame.bg_color = Color(0.035, 0.05, 0.085, 0.42)
	preview_frame.border_color = Color(0.48, 0.53, 0.60, 0.24)
	preview_frame.set_border_width_all(1)
	preview_frame.set_corner_radius_all(14)
	preview_frame.content_margin_left = 6.0
	preview_frame.content_margin_right = 6.0
	preview_frame.content_margin_top = 6.0
	preview_frame.content_margin_bottom = 6.0
	preview_frame.shadow_size = 0
	preview_panel.add_theme_stylebox_override("panel", preview_frame)
	preview_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	preview_panel.size_flags_stretch_ratio = 1.0
	preview_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_child(preview_panel)
	var preview_root := VBoxContainer.new()
	preview_root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	preview_root.size_flags_vertical = Control.SIZE_EXPAND_FILL
	preview_root.add_theme_constant_override("separation", 8)
	preview_panel.add_child(preview_root)
	var preview_column := VBoxContainer.new()
	preview_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	preview_column.size_flags_vertical = Control.SIZE_EXPAND_FILL
	preview_column.add_theme_constant_override("separation", 10)
	preview_root.add_child(preview_column)
	var preview_header := HBoxContainer.new()
	preview_column.add_child(preview_header)
	_preview_title = UIKit.make_label("PODGLĄD 2D", 26, UIKit.COLOR_ACCENT)
	_preview_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	preview_header.add_child(_preview_title)
	var quick_generate_row := HBoxContainer.new()
	quick_generate_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	quick_generate_row.add_theme_constant_override("separation", 10)
	_quick_generate_button = UIKit.make_button("LOSUJ NOWĄ TRASĘ  ↻", 18, 48)
	_quick_generate_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_quick_generate_button.pressed.connect(_generate_new)
	quick_generate_row.add_child(_quick_generate_button)
	_preview_start_button = UIKit.make_button("START WYŚCIGU  ▶", 18, 48)
	_preview_start_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_preview_start_button.pressed.connect(_start_race)
	quick_generate_row.add_child(_preview_start_button)
	preview_column.add_child(quick_generate_row)
	var view_group := ButtonGroup.new()
	_view_2d_button = UIKit.make_button("2D", 18, 44)
	_view_2d_button.toggle_mode = true
	_view_2d_button.button_group = view_group
	_view_2d_button.button_pressed = true
	_view_2d_button.custom_minimum_size.x = 64
	_view_2d_button.size_flags_horizontal = Control.SIZE_SHRINK_END
	_view_2d_button.pressed.connect(_set_view_mode.bind(false))
	preview_header.add_child(_view_2d_button)
	_view_3d_button = UIKit.make_button("3D", 18, 44)
	_view_3d_button.toggle_mode = true
	_view_3d_button.button_group = view_group
	_view_3d_button.custom_minimum_size.x = 64
	_view_3d_button.size_flags_horizontal = Control.SIZE_SHRINK_END
	_view_3d_button.pressed.connect(_set_view_mode.bind(true))
	preview_header.add_child(_view_3d_button)
	_pan_button = UIKit.make_button("PRZESUŃ MAPĘ", 15, 44)
	_pan_button.toggle_mode = true
	_pan_button.toggled.connect(_on_map_pan_toggled)
	preview_header.add_child(_pan_button)
	var fit_button := UIKit.make_button("WYŚRODKUJ", 15, 44)
	fit_button.pressed.connect(_fit_map_preview)
	preview_header.add_child(fit_button)
	_map_preview = TrackMapPreview.new()
	_map_preview.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_map_preview.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_map_preview.custom_minimum_size = Vector2(0, 260)
	_map_preview.mouse_filter = Control.MOUSE_FILTER_STOP
	_preview_container = _map_preview
	preview_column.add_child(_map_preview)
	_build_track_3d_view(preview_column)
	var zoom_row := HBoxContainer.new()
	_map_zoom_label = UIKit.make_label("ZOOM: 1,00×", 18, UIKit.COLOR_TEXT)
	zoom_row.add_child(_map_zoom_label)
	_map_zoom_slider = HSlider.new()
	_map_zoom_slider.min_value = 0.35
	_map_zoom_slider.max_value = 3.0
	_map_zoom_slider.step = 0.05
	_map_zoom_slider.value = 1.0
	_map_zoom_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_map_zoom_slider.custom_minimum_size = Vector2(120, 44)
	_map_zoom_slider.focus_mode = Control.FOCUS_NONE
	UIKit.apply_touch_slider(_map_zoom_slider)
	_map_zoom_slider.mouse_filter = Control.MOUSE_FILTER_STOP
	_map_zoom_slider.value_changed.connect(_on_map_zoom_slider_changed)
	zoom_row.add_child(_map_zoom_slider)
	preview_column.add_child(zoom_row)
	_map_preview.world_pressed.connect(_on_map_world_pressed)
	_map_preview.world_dragged.connect(_on_map_world_dragged)
	_map_preview.world_released.connect(_on_map_world_released)
	_map_preview.zoom_changed.connect(_on_map_zoom_changed)
	_route_stats_label = UIKit.make_label("ANALIZA TRASY: oczekiwanie na wygenerowanie", 16, UIKit.COLOR_TEXT, HORIZONTAL_ALIGNMENT_LEFT, false)
	_route_stats_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	preview_column.add_child(_route_stats_label)
	_build_manual_editor_panel(controls)
	# Długie teksty w panelu bocznym muszą się zawijać - inaczej rozpychają panel
	# i spychają podgląd trasy poza prawą krawędź ekranu.
	_constrain_panel_widths(controls)
	left_scroll.clip_contents = true
	preview_panel.clip_contents = true
	preview_panel.custom_minimum_size.x = 0
	body.clip_contents = true
	for option: OptionButton in [_size_select, _complexity_select, _obstacles_select, _theme_select, _tod_select, _dark_select, _route_type_select, _laps_select, _animals_select, _furniture_density_select, _manual_size_select, _manual_laps_select, _manual_theme_select, _manual_tod_select, _manual_dark_select]:
		if option != null:
			option.item_selected.connect(func(_index: int) -> void: _save_generator_preferences())
	if _name_input != null:
		_name_input.text_changed.connect(func(_value: String) -> void: _save_generator_preferences())
	_load_generator_preferences()
	_refresh_saved_tracks()
	_generate_new()
	_set_editor_mode(_manual_mode)


func _constrain_panel_widths(root_node: Node) -> void:
	for child: Node in root_node.get_children():
		if child is Label:
			var label: Label = child as Label
			label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			label.custom_minimum_size.x = 0
			label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		elif child is OptionButton:
			var option: OptionButton = child as OptionButton
			option.fit_to_longest_item = false
			option.clip_text = true
		elif child is Button:
			var button: Button = child as Button
			button.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			button.clip_text = true
			button.custom_minimum_size.x = 0
		elif child is LineEdit:
			(child as LineEdit).custom_minimum_size.x = 0
		elif child is HSlider:
			(child as HSlider).custom_minimum_size.x = 0
		_constrain_panel_widths(child)


func _build_manual_editor_panel(_parent: Control) -> void:
	var route_controls := VBoxContainer.new()
	route_controls.add_theme_constant_override("separation", 10)
	_manual_panel.add_child(route_controls)
	_manual_panel.move_child(route_controls, 0)
	route_controls.add_child(UIKit.make_label("EDYTOR RĘCZNY TRASY", 27, UIKit.COLOR_ACCENT))
	_manual_name_input = _add_line_edit(route_controls, "Nazwa własnej trasy", "Moja trasa")
	_manual_size_select = _add_option(route_controls, "ROZMIAR WŁASNEJ PLANSZY", ["Mała (~100 m²)", "Średnia (~200 m²)", "Duża (~350 m²)", "Bardzo duża (~500 m²)", "Hala (~750 m²)", "Gigantyczna hala (~1000 m²)"])
	_manual_size_select.select(1)
	_manual_theme_select = _add_option(route_controls, "STYL PLANSZY", ["Mieszkanie", "Kuchnia", "Sypialnia", "Arena futurystyczna", "Hala do sprzątania"])
	_manual_theme_select.select(0)
	_manual_tod_select = _add_option(route_controls, "PORA DNIA", ["Dzień", "Wieczór", "Noc"])
	_manual_tod_select.item_selected.connect(_on_time_setting_changed.bind(true))
	_manual_dark_select = _add_option(route_controls, "CIEMNY POKÓJ W NOCY (BEZ LAMP)", ["Tak", "Nie"])
	_manual_dark_select.item_selected.connect(_on_time_setting_changed.bind(true))
	_manual_laps_select = _add_option(route_controls, "OKRĄŻENIA TESTU", ["1", "2", "3", "5", "10"])
	_manual_laps_select.select(2)
	route_controls.add_child(UIKit.make_label("Początek jest stały i zawsze zawiera miejsce dla dwóch stacji. Wybierz kierunek kolejnego fragmentu, a następnie zamknij pętlę, aby odblokować test. Przykład: PROSTO 6 → PRAWO 6 → PRAWO 6 → LEWO 4 → PROSTO 4 → PRAWO 8 → ZAMKNIJ.", 17, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false))
	_snap_button = CheckButton.new()
	_snap_button.text = "PRZYCIĄGAJ OBIEKTY DO SIATKI 0,25 m"
	_snap_button.button_pressed = true
	_snap_button.custom_minimum_size.y = 58
	_snap_button.add_theme_font_size_override("font_size", 18)
	_snap_button.toggled.connect(func(enabled: bool) -> void: _snap_to_grid = enabled)
	route_controls.add_child(_snap_button)
	_segment_length_label = UIKit.make_label("DŁUGOŚĆ FRAGMENTU: 6 m", 20, UIKit.COLOR_TEXT)
	route_controls.add_child(_segment_length_label)
	_segment_length_slider = HSlider.new()
	_segment_length_slider.min_value = 3.0
	_segment_length_slider.max_value = 10.0
	_segment_length_slider.step = 0.5
	_segment_length_slider.value = _manual_segment_length
	_segment_length_slider.custom_minimum_size = Vector2(180, 78)
	_segment_length_slider.focus_mode = Control.FOCUS_NONE
	UIKit.apply_touch_slider(_segment_length_slider)
	_segment_length_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_segment_length_slider.value_changed.connect(_on_segment_length_changed)
	route_controls.add_child(_segment_length_slider)
	var direction_grid := GridContainer.new()
	direction_grid.add_theme_constant_override("h_separation", 10)
	direction_grid.add_theme_constant_override("v_separation", 8)
	route_controls.add_child(direction_grid)
	direction_grid.columns = 2
	_add_editor_button(direction_grid, "↑ PROSTO", _append_manual_segment.bind(0))
	_add_editor_button(direction_grid, "↶ LEWO 90°", _append_manual_segment.bind(1))
	_add_editor_button(direction_grid, "PRAWO 90° ↷", _append_manual_segment.bind(-1))
	_add_editor_button(direction_grid, "↖ LEWO 45°", _append_manual_segment.bind(2))
	_add_editor_button(direction_grid, "PRAWO 45° ↗", _append_manual_segment.bind(-2))
	var route_action_grid := GridContainer.new()
	route_action_grid.columns = 2
	route_action_grid.add_theme_constant_override("h_separation", 8)
	route_action_grid.add_theme_constant_override("v_separation", 8)
	route_controls.add_child(route_action_grid)
	_add_editor_button(route_action_grid, "NOWA TRASA", _start_manual_route)
	_add_editor_button(route_action_grid, "COFNIJ FRAGMENT", _undo_manual_segment)
	_add_editor_button(route_action_grid, "ZAMKNIJ PĘTLĘ", _close_manual_route)
	_add_editor_button(route_action_grid, "OTWÓRZ PĘTLĘ", _reopen_manual_route)
	_manual_status = UIKit.make_label("Utwórz trasę, dodając kolejne fragmenty.", 18, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false)
	_manual_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	route_controls.add_child(_manual_status)
	var manual_save_button := UIKit.make_button("ZAPISZ WŁASNĄ TRASĘ", 21, 62)
	manual_save_button.pressed.connect(_save_current)
	route_controls.add_child(manual_save_button)
	_manual_test_button = UIKit.make_button("TESTUJ TRASĘ  ▶", 24, 68)
	_manual_test_button.disabled = true
	_manual_test_button.pressed.connect(_start_race)
	route_controls.add_child(_manual_test_button)

## Podgląd 3D trasy: ta sama geometria co w wyścigu, kamera orbitalna sterowana palcem.
func _build_track_3d_view(parent: Control) -> void:
	_track3d_container = SubViewportContainer.new()
	_track3d_container.stretch = true
	_track3d_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_track3d_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_track3d_container.custom_minimum_size = Vector2(0, 260)
	_track3d_container.visible = false
	_track3d_container.gui_input.connect(_on_track3d_input)
	parent.add_child(_track3d_container)
	_track3d_viewport = SubViewport.new()
	_track3d_viewport.own_world_3d = true
	_track3d_viewport.render_target_update_mode = SubViewport.UPDATE_DISABLED
	_track3d_container.add_child(_track3d_viewport)
	_track3d_root = Node3D.new()
	_track3d_viewport.add_child(_track3d_root)
	_track3d_camera = Camera3D.new()
	_track3d_camera.far = 2000.0
	_track3d_camera.fov = 55.0
	_track3d_root.add_child(_track3d_camera)


func _set_view_mode(use_3d: bool) -> void:
	_view_3d_mode = use_3d
	_save_generator_preferences()
	_map_preview.visible = not use_3d
	_pan_button.visible = not use_3d
	_track3d_container.visible = use_3d
	_map_preview.custom_minimum_size.y = 260.0
	_track3d_container.custom_minimum_size.y = 260.0
	_map_zoom_label.text = ("ZOOM 3D: %.2f×" % _track3d_zoom) if use_3d else ("ZOOM 2D: %.2f×" % _map_preview.zoom)
	_map_zoom_slider.set_value_no_signal(_track3d_zoom if use_3d else _map_preview.zoom)
	_preview_title.text = "PODGLĄD 3D — przeciągnij = obrót, suwak = przybliżenie" if use_3d else "PODGLĄD 2D"
	if use_3d:
		_track3d_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
		_rebuild_track_3d()
	else:
		_track3d_viewport.render_target_update_mode = SubViewport.UPDATE_DISABLED
		_map_preview.call_deferred("fit_map")
		_map_preview.call_deferred("queue_redraw")


func _rebuild_track_3d() -> void:
	if _track3d_viewport == null or not _view_3d_mode:
		_track3d_dirty = true
		return
	_track3d_dirty = false
	if _track3d_track != null and is_instance_valid(_track3d_track):
		_track3d_track.queue_free()
		_track3d_track = null
	var route: Array = _current_data.get("route", [])
	if route.size() < 6:
		return
	var packed: PackedScene = load("res://scenes/TrackProcedural.tscn") as PackedScene
	if packed == null:
		return
	var preview_track: ProceduralTrack = packed.instantiate() as ProceduralTrack
	if preview_track == null:
		return
	var data: Dictionary = _current_data.duplicate(true)
	if bool(data.get("manual_editor", false)) and not _manual_route_closed:
		# Niezamknięta trasa ręczna: podgląd 3D pokazujemy dopiero po zamknięciu pętli.
		preview_track.queue_free()
		_preview_title.text = "PODGLĄD 3D — zamknij pętlę, aby zobaczyć trasę"
		return
	preview_track.room_ceiling_visible = false
	preview_track.configure(data)
	_track3d_track = preview_track
	_track3d_root.add_child(preview_track)
	var min_x: float = INF
	var max_x: float = -INF
	var min_z: float = INF
	var max_z: float = -INF
	for point: Variant in route:
		if point is Vector3:
			min_x = minf(min_x, point.x)
			max_x = maxf(max_x, point.x)
			min_z = minf(min_z, point.z)
			max_z = maxf(max_z, point.z)
	_track3d_focus = Vector3((min_x + max_x) * 0.5, 0.0, (min_z + max_z) * 0.5)
	var map_span: float = maxf(max_x - min_x, max_z - min_z)
	_track3d_fit_distance = maxf(9.0, map_span * 1.25)
	_track3d_zoom = 1.0
	_track3d_distance = _track3d_fit_distance
	_track3d_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	if _map_zoom_slider != null:
		_map_zoom_slider.set_value_no_signal(1.0)
	if _map_zoom_label != null:
		_map_zoom_label.text = "ZOOM 3D: 1.00×"
	_update_track3d_camera()


func _update_track3d_camera() -> void:
	if _track3d_camera == null:
		return
	var offset := Vector3(0.0, sin(_track3d_pitch), cos(_track3d_pitch))
	offset = offset.rotated(Vector3.UP, _track3d_yaw) * _track3d_distance
	_track3d_camera.position = _track3d_focus + offset
	_track3d_camera.look_at(_track3d_focus, Vector3.UP)


func _on_track3d_input(event: InputEvent) -> void:
	if event is InputEventScreenDrag:
		var drag: InputEventScreenDrag = event as InputEventScreenDrag
		_track3d_yaw -= drag.relative.x * 0.008
		_track3d_pitch = clampf(_track3d_pitch + drag.relative.y * 0.006, 0.25, 1.45)
		_update_track3d_camera()
	elif event is InputEventMouseMotion and ((event as InputEventMouseMotion).button_mask & MOUSE_BUTTON_MASK_LEFT) != 0:
		var motion: InputEventMouseMotion = event as InputEventMouseMotion
		_track3d_yaw -= motion.relative.x * 0.008
		_track3d_pitch = clampf(_track3d_pitch + motion.relative.y * 0.006, 0.25, 1.45)
		_update_track3d_camera()
	elif event is InputEventMouseButton and (event as InputEventMouseButton).pressed:
		var button: InputEventMouseButton = event as InputEventMouseButton
		if button.button_index == MOUSE_BUTTON_WHEEL_UP:
			_track3d_zoom = clampf(_track3d_zoom * 1.12, 0.35, 3.0)
			_track3d_distance = _track3d_fit_distance / _track3d_zoom
			_update_track3d_camera()
			_sync_zoom_control()
		elif button.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_track3d_zoom = clampf(_track3d_zoom / 1.12, 0.35, 3.0)
			_track3d_distance = _track3d_fit_distance / _track3d_zoom
			_update_track3d_camera()
			_sync_zoom_control()


func _set_editor_mode(manual_mode: bool) -> void:
	if _generator_panel == null or _manual_panel == null:
		return
	_manual_mode = manual_mode
	_generator_panel.visible = not manual_mode
	_manual_panel.visible = manual_mode
	_mode_label.text = "TRYB: EDYTOR RĘCZNY" if manual_mode else "TRYB: GENERATOR LOSOWY"
	if _quick_generate_button != null:
		_quick_generate_button.visible = not manual_mode
	if _map_preview != null:
		_map_preview.set_pan_mode(false)
		_map_preview.custom_minimum_size.y = 160.0
		_map_preview.call_deferred("fit_map")
		_map_preview.call_deferred("queue_redraw")
	if _pan_button != null:
		_pan_button.button_pressed = false
	_save_generator_preferences()
	if manual_mode and (_manual_route_points.is_empty() or not bool(_current_data.get("manual_editor", false))):
		_start_manual_route()

func _on_segment_length_changed(value: float) -> void:
	_manual_segment_length = value
	if _segment_length_label != null:
		_segment_length_label.text = "DŁUGOŚĆ FRAGMENTU: %.1f m" % value
	if _manual_status != null:
		_manual_status.text = "Długość kolejnego fragmentu: %.0f m." % value

func _start_manual_route() -> void:
	var seed_value: int = randi_range(10000, 2147483000)
	var themes: Array[String] = ["apartment", "kitchen", "bedroom", "futuristic", "cleaning_hall"]
	var theme: String = themes[clampi(_manual_theme_select.selected, 0, themes.size() - 1)]
	_current_data = TrackGeneratorScript.generate(seed_value, _manual_size_select.selected, _complexity_select.selected + 1, 0, theme, _name_input.text, 0, 0, 0)
	var generated_route: Array = _current_data.get("route", [])
	if generated_route.size() < 2:
		_manual_status.text = "Nie udało się przygotować stałego odcinka startowego."
		return
	_manual_route_points = [generated_route[0], generated_route[1]]
	_current_data["route"] = _manual_route_points.duplicate()
	_refresh_manual_room_layout()
	_current_data["route_closed"] = false
	_current_data["route_type"] = "segment"
	_current_data["generated"] = false
	_current_data["manual_editor"] = true
	_current_data["id"] = "manual_%d" % seed_value
	_current_data["track_id"] = str(_current_data["id"])
	var manual_name: String = _manual_name_input.text.strip_edges() if _manual_name_input != null else "Moja trasa"
	_current_data["name"] = manual_name if not manual_name.is_empty() else "Moja trasa"
	_current_data["display_name"] = _current_data["name"]
	_current_data["description"] = "Trasa utworzona ręcznie"
	_current_data["obstacles"] = []
	_current_data["decorations"] = []
	_current_data["animal_count"] = 0
	_current_data["furniture_density"] = 0
	_current_data["furniture_count"] = 5
	_current_data.erase("board_size")
	_current_data["docking_stations"] = TrackGeneratorScript.make_docking_stations(_manual_route_points, float(_current_data.get("track_width", 1.2)))
	_manual_direction = Vector2(_manual_route_points[1].x - _manual_route_points[0].x, _manual_route_points[1].z - _manual_route_points[0].z).normalized()
	_manual_route_closed = false
	_manual_added_closure_point = false
	if _manual_test_button != null:
		_manual_test_button.disabled = true
	_selected_decoration_index = -1
	_selected_obstacle = -1
	_undo_stack.clear()
	_redo_stack.clear()
	_show_preview()
	_manual_status.text = "Początek trasy gotowy. Stacje są już ustawione po obu stronach startu. Dodaj co najmniej sześć fragmentów, a następnie zamknij pętlę."
	_update_route_stats()

func _refresh_manual_room_layout() -> void:
	if _current_data.is_empty() or _manual_route_points.size() < 2:
		return
	var bounds: Dictionary = TrackGeneratorScript._route_room_bounds(_manual_route_points)
	var room_rng := RandomNumberGenerator.new()
	room_rng.seed = int(_current_data.get("seed", 1)) + 91421
	var layout: Dictionary = TrackGeneratorScript._generate_room_layout(
		bounds,
		room_rng,
		int(_current_data.get("complexity", 2)),
		str(_current_data.get("theme", "apartment"))
	)
	_current_data["room_partitions"] = layout.get("partitions", [])
	_current_data["room_bounds"] = layout.get("rooms", [])
	_current_data.erase("board_size")


func _append_manual_segment(turn_direction: int) -> void:
	if _manual_route_closed:
		_manual_status.text = "Najpierw otwórz pętlę, aby dalej edytować trasę."
		return
	if _manual_route_points.size() >= 35:
		_manual_status.text = "Osiągnięto limit punktów trasy. Zamknij pętlę lub cofnij fragment."
		return
	var previous_direction: Vector2 = _manual_direction
	if turn_direction != 0:
		# ±1 = skręt o 90°, ±2 = łagodniejszy skręt o 45°.
		var turn_angle: float = 90.0 if absi(turn_direction) == 1 else 45.0
		_manual_direction = _manual_direction.rotated(deg_to_rad(-turn_angle * signf(float(turn_direction)))).normalized()
	var last_point: Vector3 = _manual_route_points[_manual_route_points.size() - 1]
	var next_2d := Vector2(last_point.x, last_point.z) + _manual_direction * _manual_segment_length
	# Kontrola na żywo: nowy fragment nie może przecinać trasy ani zbliżać się do niej
	# na odległość mniejszą niż szerokość toru + zapas na ściany.
	var min_gap: float = float(_current_data.get("track_width", 1.2)) + 0.8
	var new_a := Vector2(last_point.x, last_point.z)
	for i: int in range(_manual_route_points.size() - 2):
		var c := Vector2(_manual_route_points[i].x, _manual_route_points[i].z)
		var d := Vector2(_manual_route_points[i + 1].x, _manual_route_points[i + 1].z)
		var too_close: bool = TrackGeneratorScript._segments_cross(new_a, next_2d, c, d) or TrackGeneratorScript._segment_distance(new_a, next_2d, c, d) < min_gap
		# Pierwszy fragment może dotykać początku pętli - sprawdzamy go łagodniej.
		if i == 0 and not TrackGeneratorScript._segments_cross(new_a, next_2d, c, d) and TrackGeneratorScript._segment_distance(new_a, next_2d, c, d) >= 6.0:
			too_close = false
		if too_close:
			_manual_direction = previous_direction
			_manual_status.text = "Ten fragment zbyt zbliża się do innej części trasy. Wybierz inny kierunek lub krótszy fragment."
			return
	_manual_route_points.append(Vector3(next_2d.x, 0.0, next_2d.y))
	_current_data["route"] = _manual_route_points.duplicate()
	_refresh_manual_room_layout()
	_current_data["docking_stations"] = TrackGeneratorScript.make_docking_stations(_manual_route_points, float(_current_data.get("track_width", 1.2)))
	_show_preview()
	_manual_status.text = "Dodano fragment %d. Kierunek: %s. Trasa jest jeszcze otwarta." % [_manual_route_points.size() - 1, "prosto" if turn_direction == 0 else ("w lewo" if turn_direction > 0 else "w prawo")]

func _undo_manual_segment() -> void:
	if _manual_route_closed:
		_manual_status.text = "Najpierw otwórz pętlę."
		return
	if _manual_route_points.size() <= 2:
		_manual_status.text = "Nie można cofnąć stałego odcinka startowego."
		return
	_manual_route_points.pop_back()
	_current_data["route"] = _manual_route_points.duplicate()
	_refresh_manual_room_layout()
	var last_index: int = _manual_route_points.size() - 1
	var previous: Vector3 = _manual_route_points[last_index - 1]
	var last: Vector3 = _manual_route_points[last_index]
	_manual_direction = Vector2(last.x - previous.x, last.z - previous.z).normalized()
	_current_data["docking_stations"] = TrackGeneratorScript.make_docking_stations(_manual_route_points, float(_current_data.get("track_width", 1.2)))
	_show_preview()
	_manual_status.text = "Usunięto ostatni fragment."

func _close_manual_route() -> void:
	if _manual_route_closed:
		_manual_status.text = "Trasa jest już zamknięta."
		return
	var candidate_route: Array[Vector3] = _manual_route_points.duplicate()
	var closure_point_added: bool = false
	var current: Vector3 = candidate_route[candidate_route.size() - 1]
	var start: Vector3 = candidate_route[0]
	if current.distance_to(start) < 12.0:
		var elbows: Array[Vector3] = [Vector3(start.x, 0.0, current.z), Vector3(current.x, 0.0, start.z)]
		var chosen_elbow: Vector3 = Vector3.ZERO
		var found_elbow: bool = false
		for elbow: Vector3 in elbows:
			if current.distance_to(elbow) >= 12.0 and elbow.distance_to(start) >= 12.0:
				chosen_elbow = elbow
				found_elbow = true
				break
		if not found_elbow:
			_manual_status.text = "Nie można bezpiecznie zamknąć pętli z tego miejsca. Dodaj kolejny fragment w innym kierunku."
			return
		candidate_route.append(chosen_elbow)
		closure_point_added = true
	if candidate_route.size() < 8:
		_manual_status.text = "Dodaj jeszcze fragmenty. Trasa musi mieć co najmniej osiem punktów po zamknięciu."
		return
	var candidate_data: Dictionary = _current_data.duplicate(true)
	candidate_data["route"] = candidate_route
	var closed_bounds: Dictionary = TrackGeneratorScript._route_room_bounds(candidate_route)
	var closed_room_rng := RandomNumberGenerator.new()
	closed_room_rng.seed = int(candidate_data.get("seed", 1)) + 91421
	var closed_layout: Dictionary = TrackGeneratorScript._generate_room_layout(closed_bounds, closed_room_rng, int(candidate_data.get("complexity", 2)), str(candidate_data.get("theme", "apartment")))
	candidate_data["room_partitions"] = closed_layout.get("partitions", [])
	candidate_data["room_bounds"] = closed_layout.get("rooms", [])
	candidate_data.erase("board_size")
	candidate_data["route_closed"] = true
	candidate_data["route_type"] = "lap"
	candidate_data["manual_closure_added_point"] = closure_point_added
	candidate_data["docking_stations"] = TrackGeneratorScript.make_docking_stations(candidate_route, float(candidate_data.get("track_width", 1.2)))
	var validation: Dictionary = TrackGeneratorScript.validate(candidate_data)
	if not bool(validation.get("valid", false)):
		_manual_status.text = "Trasa wymaga poprawy: %s" % str(validation.get("reason", "nieznany błąd"))
		return
	_manual_route_points = candidate_route
	_current_data = candidate_data
	_manual_route_closed = true
	_manual_added_closure_point = closure_point_added
	if _manual_test_button != null:
		_manual_test_button.disabled = false
	_show_preview()
	_manual_status.text = "PĘTLA ZAMKNIĘTA — trasa poprawna. Możesz ją przetestować lub zapisać."
	_status.text = "Ręczna trasa została poprawnie zamknięta."

func _reopen_manual_route() -> void:
	if not _manual_route_closed:
		_manual_status.text = "Trasa jest już otwarta."
		return
	_manual_route_points = _current_data.get("route", []).duplicate()
	if _manual_added_closure_point and not _manual_route_points.is_empty():
		_manual_route_points.pop_back()
	_manual_route_closed = false
	_manual_added_closure_point = false
	if _manual_test_button != null:
		_manual_test_button.disabled = true
	_current_data["route"] = _manual_route_points.duplicate()
	_refresh_manual_room_layout()
	_current_data["route_closed"] = false
	_current_data["route_type"] = "segment"
	_current_data["docking_stations"] = TrackGeneratorScript.make_docking_stations(_manual_route_points, float(_current_data.get("track_width", 1.2)))
	var last_index: int = _manual_route_points.size() - 1
	var previous: Vector3 = _manual_route_points[last_index - 1]
	var last: Vector3 = _manual_route_points[last_index]
	_manual_direction = Vector2(last.x - previous.x, last.z - previous.z).normalized()
	_show_preview()
	_manual_status.text = "Pętla otwarta. Możesz kontynuować budowanie."

func _on_object_scale_drag_started() -> void:
	_push_undo_snapshot()

func _on_object_scale_slider_changed(value: float) -> void:
	var items: Array = _get_decorations()
	if _selected_decoration_index < 0 or _selected_decoration_index >= items.size():
		return
	var item: Dictionary = items[_selected_decoration_index]
	item["scale"] = clampf(value, 0.6, 2.4)
	items[_selected_decoration_index] = item
	_current_data["decorations"] = items
	if _map_preview != null:
		_map_preview.refresh_map_data(_current_data, _selected_decoration_index, _selected_obstacle)
	_update_decoration_status()


func _build_obstacle_panel() -> void:
	_obstacle_box.add_child(UIKit.make_label("PRZESZKODY NA TRASIE", 24, UIKit.COLOR_ACCENT))
	_obstacle_status = UIKit.make_label("Brak zaznaczonej przeszkody", 19, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false)
	_obstacle_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_obstacle_box.add_child(_obstacle_status)
	var obstacle_grid := GridContainer.new()
	obstacle_grid.columns = 2
	obstacle_grid.add_theme_constant_override("h_separation", 8)
	obstacle_grid.add_theme_constant_override("v_separation", 8)
	_obstacle_box.add_child(obstacle_grid)
	_add_editor_button(obstacle_grid, "◀ POPRZEDNIA PRZESZKODA", _select_previous_obstacle)
	_add_editor_button(obstacle_grid, "NASTĘPNA PRZESZKODA ▶", _select_next_obstacle)
	_add_editor_button(obstacle_grid, "◀ LEWO", _move_obstacle.bind(Vector3(-1.0, 0.0, 0.0)))
	_add_editor_button(obstacle_grid, "PRAWO ▶", _move_obstacle.bind(Vector3(1.0, 0.0, 0.0)))
	_add_editor_button(obstacle_grid, "▲ DALEJ", _move_obstacle.bind(Vector3(0.0, 0.0, -1.0)))
	_add_editor_button(obstacle_grid, "▼ BLIŻEJ", _move_obstacle.bind(Vector3(0.0, 0.0, 1.0)))
	_add_editor_button(obstacle_grid, "+ DODAJ", _add_obstacle)
	_add_editor_button(obstacle_grid, "DUPLIKUJ", _duplicate_obstacle)
	_add_editor_button(obstacle_grid, "USUŃ", _delete_obstacle)


func _add_line_edit(parent: Control, hint: String, value: String) -> LineEdit:
	var edit := LineEdit.new()
	edit.placeholder_text = hint
	edit.text = value
	edit.custom_minimum_size.y = 56
	edit.add_theme_font_size_override("font_size", 21)
	parent.add_child(edit)
	return edit


func _add_option(parent: Control, title: String, options: Array) -> OptionButton:
	var option_group := VBoxContainer.new()
	option_group.add_theme_constant_override("separation", 5)
	parent.add_child(option_group)
	var title_label := UIKit.make_label(title, 19, UIKit.COLOR_TEXT)
	title_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	title_label.custom_minimum_size.y = 30
	option_group.add_child(title_label)
	var select := OptionButton.new()
	select.custom_minimum_size = Vector2(0, 62)
	select.add_theme_font_size_override("font_size", 19)
	select.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for option: Variant in options:
		select.add_item(str(option))
	option_group.add_child(select)
	var separator := HSeparator.new()
	separator.modulate = Color(0.25, 0.65, 0.75, 0.55)
	option_group.add_child(separator)
	return select


func _on_route_type_selected(index: int) -> void:
	_save_generator_preferences()
	if _laps_select != null:
		_laps_select.disabled = index == 1
	if index == 1 and _status != null:
		_status.text = "Odcinek będzie miał osobny start i metę, checkpointy oraz stację ładowania w połowie trasy."


func _generate_new() -> void:
	_save_generator_preferences()
	_manual_route_closed = false
	_manual_route_points.clear()
	# Każde naciśnięcie LOSUJ tworzy nowy seed; nie pokazujemy ponownie tej samej trasy.
	var seed_value: int = GameManager.get_unique_random_track_seed()
	var route_complexity: int = _complexity_select.selected + 1
	var route_style: int = GameManager.get_unique_random_track_style(route_complexity)
	_seed_input.text = str(seed_value)
	var theme_ids: Array[String] = ["apartment", "kitchen", "bedroom", "futuristic", "cleaning_hall"]
	_undo_stack.clear()
	_redo_stack.clear()
	_current_data = TrackGeneratorScript.generate(
		seed_value,
		_size_select.selected,
		_complexity_select.selected + 1,
		_obstacles_select.selected,
		theme_ids[_theme_select.selected],
		_name_input.text,
		_animals_select.selected,
		_furniture_density_select.selected,
		0,
		"segment" if _route_type_select != null and _route_type_select.selected == 1 else "lap",
		route_style
	)
	if not _texture_selected_path.is_empty():
		_current_data["external_floor_texture_path"] = _texture_selected_path
		_current_data["external_floor_texture_source"] = "Poly Haven"
		_current_data["external_floor_texture_slug"] = _texture_selected_slug
		_current_data["external_floor_texture_author"] = _texture_selected_author
	var validation: Dictionary = TrackGeneratorScript.validate(_current_data)
	var retry_count: int = 0
	while not bool(validation.get("valid", false)) and retry_count < 12:
		retry_count += 1
		seed_value = GameManager.get_unique_random_track_seed()
		route_style = GameManager.get_unique_random_track_style(route_complexity)
		_seed_input.text = str(seed_value)
		_current_data = TrackGeneratorScript.generate(
			seed_value,
			_size_select.selected,
			_complexity_select.selected + 1,
			_obstacles_select.selected,
			theme_ids[_theme_select.selected],
			_name_input.text,
			_animals_select.selected,
			_furniture_density_select.selected,
			0,
			"segment" if _route_type_select != null and _route_type_select.selected == 1 else "lap",
			route_style
		)
		if not _texture_selected_path.is_empty():
			_current_data["external_floor_texture_path"] = _texture_selected_path
			_current_data["external_floor_texture_source"] = "Poly Haven"
			_current_data["external_floor_texture_slug"] = _texture_selected_slug
			_current_data["external_floor_texture_author"] = _texture_selected_author
		validation = TrackGeneratorScript.validate(_current_data)
	if not bool(validation.get("valid", false)):
		_status.text = "NIE UDAŁO SIĘ UTWORZYĆ POPRAWNEJ TRASY PO 13 PRÓBACH: %s" % str(validation.get("reason", "Nieznany błąd"))
		return
	_selected_obstacle = 0 if not _get_obstacles().is_empty() else -1
	_selected_decoration_index = 0 if not _get_decorations().is_empty() else -1
	_show_preview()
	_update_obstacle_status()
	_update_decoration_status()
	var floor_names: Array[String] = ["płytki ceramiczne", "panele drewniane", "wykładzina", "beton / kamień", "panele futurystyczne"]
	var floor_index: int = clampi(int(_current_data.get("floor_texture", 0)), 0, floor_names.size() - 1)
	var route_source: String = "UWAGA: użyto zmiennej trasy awaryjnej" if bool(_current_data.get("route_fallback", false)) else "Wygenerowano nową geometrię trasy"
	var route_kind_text: String = "ODCINEK — osobny start i meta, 4 checkpointy" if str(_current_data.get("route_type", "lap" if bool(_current_data.get("route_closed", true)) else "segment")) == "segment" else "OKRĄŻENIA — zamknięta pętla z checkpointami"
	_status.text = "Nowa trasa: seed %d. %s. %s. Punktów trasy: %d. Cztery stacje niemal stykające się po prawej stronie startu. Brud: %d losowych punktów na jezdni. Podłoga: %s. Zwierzęta: %d. Meble: %d. Przeszkody automatycznie przy krawędziach. %s" % [seed_value, route_source, route_kind_text, (_current_data.get("route", []) as Array).size(), int(_current_data.get("dirt_pickup_count", 24)), floor_names[floor_index], int(_current_data.get("animal_count", 0)), int(_current_data.get("furniture_count", 0)), str(validation.get("reason", "Trasa poprawna."))]


## Pora dnia i ciemny pokój są wspólne dla obu trybów (losowego i ręcznego).
func _on_time_setting_changed(_index: int, from_manual: bool) -> void:
	if from_manual:
		_tod_select.select(_manual_tod_select.selected)
		_dark_select.select(_manual_dark_select.selected)
	else:
		_manual_tod_select.select(_tod_select.selected)
		_manual_dark_select.select(_dark_select.selected)
	if not _current_data.is_empty():
		_show_preview()


func _sync_time_selects_from_data() -> void:
	if _tod_select == null:
		return
	var index: int = RoomStyleCatalog.time_of_day_ids().find(str(_current_data.get("time_of_day", "day")))
	var dark_index: int = 0 if bool(_current_data.get("dark_room", true)) else 1
	for select: OptionButton in [_tod_select, _manual_tod_select]:
		select.select(maxi(index, 0))
	for select: OptionButton in [_dark_select, _manual_dark_select]:
		select.select(dark_index)


func _apply_time_settings() -> void:
	if _current_data.is_empty() or _tod_select == null:
		return
	var ids: Array[String] = RoomStyleCatalog.time_of_day_ids()
	_current_data["time_of_day"] = ids[clampi(_tod_select.selected, 0, ids.size() - 1)]
	_current_data["dark_room"] = _dark_select.selected == 0


func _show_preview() -> void:
	_apply_time_settings()
	if not _current_data.is_empty():
		# Tekstury pokoi liczą się w tle, więc start wyścigu się nie zacina.
		RoomTextures.prewarm(_current_data)
	_update_route_stats()
	_track3d_dirty = true
	if _view_3d_mode:
		_rebuild_track_3d()
	if _map_preview != null and is_instance_valid(_map_preview):
		_map_preview.set_map_data(_current_data, _selected_decoration_index, _selected_obstacle)
		_map_preview.visible = not _view_3d_mode
		_map_preview.call_deferred("fit_map")
		_map_preview.call_deferred("queue_redraw")
	if _map_zoom_slider != null:
		_map_zoom_slider.set_value_no_signal(_track3d_zoom if _view_3d_mode else 1.0)
	if _map_zoom_label != null:
		_map_zoom_label.text = "ZOOM 3D: %.2f×" % _track3d_zoom if _view_3d_mode else "ZOOM 2D: 1.00×"

func _fit_map_preview() -> void:
	if _map_preview != null and is_instance_valid(_map_preview):
		_map_preview.fit_map()
		_map_preview.queue_redraw()
	if _map_zoom_slider != null:
		_map_zoom_slider.set_value_no_signal(1.0)
	if _map_zoom_label != null:
		_map_zoom_label.text = "ZOOM 2D: 1.00×"

func _on_map_zoom_slider_changed(value: float) -> void:
	if _view_3d_mode:
		_track3d_zoom = clampf(value, 0.35, 3.0)
		_track3d_distance = _track3d_fit_distance / _track3d_zoom
		_update_track3d_camera()
		if _map_zoom_label != null:
			_map_zoom_label.text = "ZOOM 3D: %.2f×" % _track3d_zoom
	else:
		if _map_preview != null:
			_map_preview.set_zoom_level(value)

func _on_map_zoom_changed(value: float) -> void:
	if _map_zoom_slider != null and not _view_3d_mode:
		_map_zoom_slider.set_value_no_signal(value)
	if _map_zoom_label != null and not _view_3d_mode:
		_map_zoom_label.text = "ZOOM 2D: %.2f×" % value

func _sync_zoom_control() -> void:
	if _map_zoom_slider != null:
		_map_zoom_slider.set_value_no_signal(_track3d_zoom)
	if _map_zoom_label != null:
		_map_zoom_label.text = "ZOOM 3D: %.2f×" % _track3d_zoom

func _on_map_pan_toggled(enabled: bool) -> void:
	if _map_preview != null:
		_map_preview.set_pan_mode(enabled)

func _on_map_world_pressed(world_position: Vector3) -> void:
	if not _manual_mode or _current_data.is_empty():
		return
	_select_decoration_at_position(world_position)

func _on_map_world_dragged(world_position: Vector3) -> void:
	if _manual_mode and _dragging_decoration_index >= 0 and not _map_preview.pan_mode:
		if not _drag_changed:
			_push_undo_snapshot()
			_drag_changed = true
		_move_decoration_to_world_position(world_position)

func _on_map_world_released() -> void:
	if _dragging_decoration_index >= 0:
		if _drag_changed:
			if _map_preview != null:
				_map_preview.refresh_map_data(_current_data, _selected_decoration_index, _selected_obstacle)
			_update_route_stats()
			_update_decoration_status()
			_status.text = "Przesunięto zaznaczony obiekt. Zapisz trasę, aby zachować zmianę."
		_dragging_decoration_index = -1
		_drag_changed = false


func _select_decoration_at_position(world_position: Vector3) -> void:
	var items: Array = _get_decorations()
	if items.is_empty():
		return
	var nearest_index: int = -1
	var nearest_distance: float = INF
	for index: int in range(items.size()):
		if not (items[index] is Dictionary):
			continue
		var item: Dictionary = items[index]
		var point: Vector3 = item.get("position", Vector3.ZERO)
		var distance: float = Vector2(world_position.x - point.x, world_position.z - point.z).length()
		var kind: String = str(item.get("kind", ""))
		var hit_radius: float = 2.0 * float(item.get("scale", 1.0))
		if kind in ["sofa", "bed", "table", "bookshelf", "fish_tank"]:
			hit_radius = 2.8 * float(item.get("scale", 1.0))
		if _map_preview != null:
			hit_radius = maxf(hit_radius, _map_preview.get_world_units_per_pixel() * 22.0)
		if distance <= hit_radius and distance < nearest_distance:
			nearest_distance = distance
			nearest_index = index
	if nearest_index >= 0:
		_selected_decoration_index = nearest_index
		_dragging_decoration_index = nearest_index
		_drag_changed = false
		if _map_preview != null:
			_map_preview.set_selection(_selected_decoration_index, _selected_obstacle)
		_update_decoration_status()
		_status.text = "Zaznaczono obiekt. Przeciągnij go palcem albo użyj przycisków kierunkowych."
	else:
		_dragging_decoration_index = -1
		_drag_changed = false


func _manual_object_position_is_clear(kind: String, position_value: Vector3, ignore_index: int = -1, scale_value: float = 1.0) -> bool:
	var items: Array = _get_decorations()
	var spacing: float = TrackGeneratorScript._furniture_spacing_for_kind(kind) * maxf(scale_value, 0.6)
	var object_radius: float = maxf(0.28, spacing * 0.38)
	var route_points: Array[Vector3] = []
	for point_value: Variant in _current_data.get("route", []):
		if point_value is Vector3:
			route_points.append(point_value)
	var route_closed_value: bool = bool(_current_data.get("route_closed", false))
	if route_points.size() >= 2:
		var route_distance: float = TrackGeneratorScript._distance_to_route_xz(position_value, route_points, route_closed_value)
		var required_track_gap: float = float(_current_data.get("track_width", 1.65)) * 0.5 + object_radius + 0.30
		if route_distance < required_track_gap:
			return false
	var rooms: Array = _current_data.get("room_bounds", [])
	if not rooms.is_empty():
		var inside_room: bool = false
		for room_value: Variant in rooms:
			if not (room_value is Dictionary):
				continue
			var room: Dictionary = room_value
			if position_value.x >= float(room.get("min_x", -INF)) + object_radius and position_value.x <= float(room.get("max_x", INF)) - object_radius and position_value.z >= float(room.get("min_z", -INF)) + object_radius and position_value.z <= float(room.get("max_z", INF)) - object_radius:
				inside_room = true
				break
		if not inside_room:
			return false
	# Obiekt nie może trafić w pełną część ściany działowej. Otwory drzwiowe
	# są liczone tą samą funkcją co w geometrii 3D, więc przejazdy pozostają zgodne.
	for partition_value: Variant in _current_data.get("room_partitions", []):
		if not (partition_value is Dictionary):
			continue
		var partition: Dictionary = partition_value
		var vertical: bool = bool(partition.get("vertical", true))
		var axis: float = float(partition.get("axis", 0.0))
		var extent_min: float = float(partition.get("min", 0.0))
		var extent_max: float = float(partition.get("max", 0.0))
		var along: float = position_value.z if vertical else position_value.x
		var across: float = absf(position_value.x - axis) if vertical else absf(position_value.z - axis)
		if along < extent_min - object_radius or along > extent_max + object_radius:
			continue
		if across < object_radius + 0.18:
			var openings: Array[Vector2] = TrackGeneratorScript.get_room_partition_openings(route_points, vertical, axis, float(_current_data.get("track_width", 1.65)), extent_min, extent_max, route_closed_value)
			var inside_opening: bool = false
			for opening: Vector2 in openings:
				if along >= opening.x + object_radius and along <= opening.y - object_radius:
					inside_opening = true
					break
			if not inside_opening:
				return false
	var obstacle_values: Array = _get_obstacles()
	for obstacle_value: Variant in obstacle_values:
		if obstacle_value is Vector3:
			var obstacle_point: Vector3 = obstacle_value
			if Vector2(position_value.x - obstacle_point.x, position_value.z - obstacle_point.z).length() < object_radius + 0.35:
				return false
	for index: int in range(items.size()):
		if index == ignore_index or not (items[index] is Dictionary):
			continue
		var other: Dictionary = items[index]
		var other_position: Vector3 = other.get("position", Vector3.ZERO)
		var other_kind: String = str(other.get("kind", ""))
		var other_scale: float = maxf(float(other.get("scale", 1.0)), 0.6)
		var other_radius: float = maxf(0.28, TrackGeneratorScript._furniture_spacing_for_kind(other_kind) * other_scale * 0.38)
		var minimum_distance: float = object_radius + other_radius + 0.22
		if Vector2(position_value.x - other_position.x, position_value.z - other_position.z).length() < minimum_distance:
			return false
	return true


func _move_decoration_to_world_position(world_position: Vector3) -> void:
	var items: Array = _get_decorations()
	if _dragging_decoration_index < 0 or _dragging_decoration_index >= items.size():
		return
	var item: Dictionary = items[_dragging_decoration_index]
	world_position.y = 0.0
	if _snap_to_grid:
		world_position.x = snappedf(world_position.x, 0.25)
		world_position.z = snappedf(world_position.z, 0.25)
	if not _manual_object_position_is_clear(str(item.get("kind", "box")), world_position, _dragging_decoration_index, float(item.get("scale", 1.0))):
		_status.text = "To miejsce nachodzi na trasę, ścianę lub inny obiekt. Wybierz wolne miejsce."
		return
	item["position"] = world_position
	items[_dragging_decoration_index] = item
	_current_data["decorations"] = items
	if _map_preview != null:
		_map_preview.refresh_map_data(_current_data, _selected_decoration_index, _selected_obstacle)


func _update_route_stats() -> void:
	if _route_stats_label == null:
		return
	var route: Array = _current_data.get("route", [])
	if route.size() < 3:
		_route_stats_label.text = "ANALIZA TRASY: brak danych"
		return
	var total_length: float = 0.0
	var corner_count: int = 0
	var tight_corner_count: int = 0
	var route_is_closed: bool = bool(_current_data.get("route_closed", str(_current_data.get("route_type", "lap")) != "segment"))
	var segment_count: int = route.size() if route_is_closed else route.size() - 1
	for i: int in range(segment_count):
		var next_index: int = (i + 1) % route.size() if route_is_closed else i + 1
		total_length += route[i].distance_to(route[next_index])
	var first_corner: int = 0 if route_is_closed else 1
	var last_corner: int = route.size() if route_is_closed else route.size() - 1
	for i: int in range(first_corner, last_corner):
		var previous: Vector3 = route[posmod(i - 1, route.size())] if route_is_closed or i > 0 else route[i]
		var current: Vector3 = route[i]
		var following: Vector3 = route[(i + 1) % route.size()] if route_is_closed or i < route.size() - 1 else route[i]
		var incoming: Vector2 = Vector2(current.x - previous.x, current.z - previous.z).normalized()
		var outgoing: Vector2 = Vector2(following.x - current.x, following.z - current.z).normalized()
		var turn_angle: float = rad_to_deg(acos(clampf(incoming.dot(outgoing), -1.0, 1.0)))
		if turn_angle >= 18.0:
			corner_count += 1
		if turn_angle >= 42.0:
			tight_corner_count += 1
	var obstacles: Array = _current_data.get("obstacles", [])
	var decorations: Array = _current_data.get("decorations", [])
	var animal_count: int = int(_current_data.get("animal_count", 0))
	var floor_names: Array[String] = ["ceramika", "drewno", "wykładzina", "beton", "futurystyczna"]
	var floor_index: int = clampi(int(_current_data.get("floor_texture", 0)), 0, floor_names.size() - 1)
	var validation: Dictionary = TrackGeneratorScript.validate(_current_data)
	var validation_text: String = "POPRAWNA" if bool(validation.get("valid", false)) else "DO POPRAWY: %s" % str(validation.get("reason", "nieznany błąd"))
	var furniture_count: int = int(_current_data.get("furniture_count", 0))
	var obstacle_layout_name: String = "krawędzie"
	var dirt_count: int = int(_current_data.get("dirt_pickup_count", 18 + int(_current_data.get("complexity", 2)) * 2))
	_route_stats_label.text = "ANALIZA TRASY  •  %s  •  Długość: %.0f m  •  Zakręty: %d (ciasne: %d)  •  Przeszkody: %d (%s)  •  Meble: %d  •  Obiekty: %d  •  Zwierzęta: %d  •  Brud: %d  •  Podłoga: %s" % [validation_text, total_length, corner_count, tight_corner_count, obstacles.size(), obstacle_layout_name, furniture_count, decorations.size(), animal_count, dirt_count, floor_names[floor_index]]


func _on_move_step_selected(value: float) -> void:
	_move_step = value
	if _move_step_label != null:
		_move_step_label.text = "KROK PRZESUWANIA OBIEKTÓW: %.2f m" % _move_step
	_status.text = "Krok przesuwania ustawiony na %.2f m." % _move_step


func _on_category_pressed(category_number: int) -> void:
	_category_index = clampi(category_number, 0, OBJECT_CATEGORIES.size() - 1)
	var category: Dictionary = OBJECT_CATEGORIES[_category_index]
	var kinds: Array = category["kinds"]
	var is_obstacles: bool = kinds.is_empty()
	if _object_box != null:
		_object_box.visible = not is_obstacles
	if _obstacle_box != null:
		_obstacle_box.visible = is_obstacles
	if _item_grid == null:
		return
	for child: Node in _item_grid.get_children():
		_item_grid.remove_child(child)
		child.queue_free()
	var current_kind_index: int = _decoration_select.selected
	var first_kind_index: int = -1
	var selection_in_category: bool = false
	for kind: Variant in kinds:
		var kind_index: int = DECORATION_KINDS.find(str(kind))
		if kind_index < 0:
			continue
		if first_kind_index < 0:
			first_kind_index = kind_index
		if kind_index == current_kind_index:
			selection_in_category = true
		var tile := Button.new()
		tile.toggle_mode = true
		tile.focus_mode = Control.FOCUS_NONE
		tile.custom_minimum_size = Vector2(0, 96)
		tile.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		tile.add_theme_font_size_override("font_size", 18)
		tile.text = "%s\n%s" % [str(KIND_ICONS.get(str(kind), "▪")), DECORATION_NAMES[kind_index]]
		tile.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		tile.set_meta("kind_index", kind_index)
		tile.pressed.connect(_on_item_tile_pressed.bind(kind_index))
		_item_grid.add_child(tile)
	if not is_obstacles and not selection_in_category and first_kind_index >= 0:
		_decoration_select.select(first_kind_index)
	_refresh_item_tiles()
	_update_item_preview()


func _on_item_tile_pressed(kind_index: int) -> void:
	_decoration_select.select(clampi(kind_index, 0, DECORATION_KINDS.size() - 1))
	_refresh_item_tiles()
	_update_item_preview()
	if _decoration_status != null:
		_decoration_status.text = "Wybrano: %s. Naciśnij DODAJ, aby ustawić przedmiot obok toru." % DECORATION_NAMES[_decoration_select.selected]


func _refresh_item_tiles() -> void:
	if _item_grid == null:
		return
	for child: Node in _item_grid.get_children():
		var tile: Button = child as Button
		if tile != null:
			tile.button_pressed = int(tile.get_meta("kind_index", -1)) == _decoration_select.selected


func _on_variant_selected(index: int) -> void:
	_picker_variant = index - 1
	_update_item_preview()


func _on_skin_selected(index: int) -> void:
	var ids: Array[String] = ObjectSkins.skin_ids()
	GameSettings.set_object_skin(ids[clampi(index, 0, ids.size() - 1)])
	_update_item_preview()
	_show_preview()
	_status.text = "Skórka obiektów: %s. Zmieniły się tylko materiały — modele pozostały te same." % ObjectSkins.skin_names()[index]


func _setup_item_preview_scene() -> void:
	var environment := Environment.new()
	environment.background_mode = Environment.BG_CLEAR_COLOR
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.78, 0.82, 0.9)
	environment.ambient_light_energy = 0.75
	var world_environment := WorldEnvironment.new()
	world_environment.environment = environment
	_item_preview_viewport.add_child(world_environment)
	var camera := Camera3D.new()
	camera.position = Vector3(0.0, 1.55, 3.4)
	camera.rotation_degrees = Vector3(-17.0, 0.0, 0.0)
	camera.fov = 42.0
	_item_preview_viewport.add_child(camera)
	camera.current = true
	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-50.0, -30.0, 0.0)
	light.light_energy = 1.4
	_item_preview_viewport.add_child(light)
	_item_preview_root = Node3D.new()
	_item_preview_root.name = "ItemPreviewRoot"
	_item_preview_viewport.add_child(_item_preview_root)


## Podgląd korzysta z TEGO SAMEGO kodu modeli co trasa (ProceduralTrack.build_model_preview).
func _update_item_preview() -> void:
	if _item_preview_root == null or _decoration_select == null:
		return
	for child: Node in _item_preview_root.get_children():
		_item_preview_root.remove_child(child)
		child.queue_free()
	var kind_index: int = clampi(_decoration_select.selected, 0, DECORATION_KINDS.size() - 1)
	var kind: String = DECORATION_KINDS[kind_index]
	var model_root := Node3D.new()
	model_root.name = "Dekoracja_preview_%s" % kind
	var builder := ProceduralTrack.new()
	builder.build_model_preview(model_root, kind, maxi(_picker_variant, 0))
	model_root.scale = Vector3.ONE * 0.82
	builder.free()
	ObjectSkins.apply(model_root, GameSettings.object_skin)
	_item_preview_root.add_child(model_root)
	if _item_preview_title != null:
		_item_preview_title.text = "%s %s" % [str(KIND_ICONS.get(kind, "")), DECORATION_NAMES[kind_index]]


func _process(delta: float) -> void:
	if _item_preview_root != null and is_instance_valid(_item_preview_root):
		_item_preview_root.rotation.y += delta * 0.7


func _add_editor_button(parent: Control, title: String, callback: Callable) -> void:
	var button := UIKit.make_button(title, 18, 66)
	button.custom_minimum_size.x = 0
	button.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	button.pressed.connect(callback)
	parent.add_child(button)


func _get_obstacles() -> Array:
	var value: Variant = _current_data.get("obstacles", [])
	return value if value is Array else []


func _update_obstacle_status() -> void:
	if _obstacle_status == null:
		return
	var obstacles: Array = _get_obstacles()
	if obstacles.is_empty():
		_selected_obstacle = -1
		_obstacle_status.text = "Brak przeszkód. Dodaj pierwszą, aby rozpocząć edycję."
		return
	_selected_obstacle = clampi(_selected_obstacle, 0, obstacles.size() - 1)
	var point: Vector3 = obstacles[_selected_obstacle]
	_obstacle_status.text = "Przeszkoda %d / %d   •   X: %.1f   Z: %.1f\nPrzesuwanie: 1 metr na kliknięcie. Zmiany dotyczą zapisanej trasy." % [_selected_obstacle + 1, obstacles.size(), point.x, point.z]


func _refresh_obstacle_preview() -> void:
	_current_data["obstacles"] = _get_obstacles()
	_show_preview()
	_update_obstacle_status()


func _select_previous_obstacle() -> void:
	var obstacles: Array = _get_obstacles()
	if obstacles.is_empty():
		_update_obstacle_status()
		return
	_selected_obstacle = posmod(_selected_obstacle - 1, obstacles.size())
	_show_preview()
	_update_obstacle_status()


func _select_next_obstacle() -> void:
	var obstacles: Array = _get_obstacles()
	if obstacles.is_empty():
		_update_obstacle_status()
		return
	_selected_obstacle = posmod(_selected_obstacle + 1, obstacles.size())
	_show_preview()
	_update_obstacle_status()


func _obstacle_position_is_clear(point: Vector3, ignore_index: int = -1) -> bool:
	var route_points: Array[Vector3] = []
	for point_value: Variant in _current_data.get("route", []):
		if point_value is Vector3:
			route_points.append(point_value)
	if route_points.size() < 2:
		return false
	var closed_value: bool = bool(_current_data.get("route_closed", true))
	var route_distance: float = TrackGeneratorScript._distance_to_route_xz(point, route_points, closed_value)
	var safe_half_width: float = float(_current_data.get("track_width", 1.65)) * 0.5 - 0.18
	if route_distance > safe_half_width:
		return false
	var obstacles: Array = _get_obstacles()
	var small_track_items: Array[String] = ["toy", "box", "pillow", "shoe", "sock", "mug", "book", "remote", "tennis_ball", "yarn", "paper_scrap", "food_scraps", "cable", "pet_bowl"]
	for decoration_value: Variant in _get_decorations():
		if not (decoration_value is Dictionary):
			continue
		var decoration: Dictionary = decoration_value
		if not small_track_items.has(str(decoration.get("kind", ""))):
			continue
		var decoration_position: Vector3 = decoration.get("position", Vector3.ZERO)
		if Vector2(point.x - decoration_position.x, point.z - decoration_position.z).length() < 0.72:
			return false
	for index: int in range(obstacles.size()):
		if index == ignore_index or not (obstacles[index] is Vector3):
			continue
		if Vector2(point.x - obstacles[index].x, point.z - obstacles[index].z).length() < 0.78:
			return false
	return true


func _move_obstacle(offset: Vector3) -> void:
	var obstacles: Array = _get_obstacles()
	if _selected_obstacle < 0 or _selected_obstacle >= obstacles.size():
		_update_obstacle_status()
		return
	var point: Vector3 = obstacles[_selected_obstacle]
	point += offset * _move_step
	point.y = 0.0
	if _snap_to_grid:
		point.x = snappedf(point.x, 0.25)
		point.z = snappedf(point.z, 0.25)
	if not _obstacle_position_is_clear(point, _selected_obstacle):
		_status.text = "Przeszkoda musi pozostać na jezdni i nie może nachodzić na inną."
		return
	_push_undo_snapshot()
	obstacles[_selected_obstacle] = point
	_current_data["obstacles"] = obstacles
	_refresh_obstacle_preview()
	_status.text = "Przesunięto przeszkodę. Zapisz trasę, aby zachować zmiany."


func _add_obstacle() -> void:
	var route: Array = _current_data.get("route", [])
	if route.size() < 4:
		_status.text = "Najpierw wygeneruj poprawną trasę."
		return
	var obstacles: Array = _get_obstacles().duplicate(true)
	if obstacles.size() >= 60:
		_status.text = "Osiągnięto limit 60 przeszkód na trasie."
		return
	var point := Vector3.ZERO
	var found_position: bool = false
	for attempt: int in range(24):
		var route_index: int = 1 + posmod(obstacles.size() * 3 + attempt * 2 + 2, route.size() - 2)
		var candidate: Vector3 = route[route_index]
		var tangent: Vector3 = (route[route_index + 1] - route[route_index - 1]).normalized()
		var side: Vector3 = Vector3(-tangent.z, 0.0, tangent.x)
		candidate += tangent * (float((obstacles.size() + attempt) % 3) - 1.0) * 1.8 + side * (float(int((obstacles.size() + attempt) / 3) % 2) - 0.5) * 1.2
		candidate.y = 0.0
		if _obstacle_position_is_clear(candidate):
			point = candidate
			found_position = true
			break
	if not found_position:
		_status.text = "Nie znaleziono wolnego miejsca na jezdni dla kolejnej przeszkody."
		return
	_push_undo_snapshot()
	obstacles.append(point)
	_current_data["obstacles"] = obstacles
	_selected_obstacle = obstacles.size() - 1
	_refresh_obstacle_preview()
	_status.text = "Dodano okrągłą przeszkodę. Możesz ją przesunąć przyciskami."


func _duplicate_obstacle() -> void:
	var obstacles: Array = _get_obstacles()
	if _selected_obstacle < 0 or _selected_obstacle >= obstacles.size():
		_status.text = "Najpierw wybierz przeszkodę do skopiowania."
		return
	if obstacles.size() >= 60:
		_status.text = "Osiągnięto limit 60 przeszkód na trasie."
		return
	var source_point: Vector3 = obstacles[_selected_obstacle]
	var copied_point := Vector3.ZERO
	var found_position: bool = false
	for offset: Vector3 in [Vector3(0.8, 0.0, 0.0), Vector3(-0.8, 0.0, 0.0), Vector3(0.0, 0.0, 0.8), Vector3(0.0, 0.0, -0.8), Vector3(0.55, 0.0, 0.55), Vector3(-0.55, 0.0, -0.55)]:
		var candidate: Vector3 = source_point + offset
		if _obstacle_position_is_clear(candidate):
			copied_point = candidate
			found_position = true
			break
	if not found_position:
		_status.text = "Nie ma wolnego miejsca na jezdni obok tej przeszkody."
		return
	_push_undo_snapshot()
	obstacles.append(copied_point)
	_current_data["obstacles"] = obstacles
	_selected_obstacle = obstacles.size() - 1
	_refresh_obstacle_preview()
	_status.text = "Skopiowano przeszkodę. Przesuń ją, jeśli znajduje się zbyt blisko oryginału."


func _delete_obstacle() -> void:
	_push_undo_snapshot()
	var obstacles: Array = _get_obstacles()
	if _selected_obstacle < 0 or _selected_obstacle >= obstacles.size():
		_status.text = "Nie ma zaznaczonej przeszkody do usunięcia."
		return
	obstacles.remove_at(_selected_obstacle)
	_current_data["obstacles"] = obstacles
	_selected_obstacle = mini(_selected_obstacle, obstacles.size() - 1)
	_refresh_obstacle_preview()
	_status.text = "Usunięto przeszkodę. Zapisz trasę, aby zachować zmiany."


func _get_decorations() -> Array:
	var value: Variant = _current_data.get("decorations", [])
	return value if value is Array else []


func _update_decoration_status() -> void:
	if _decoration_status == null:
		return
	var items: Array = _get_decorations()
	if items.is_empty():
		_selected_decoration_index = -1
		if _object_scale_slider != null:
			_object_scale_slider.editable = false
		_decoration_status.text = "Brak przedmiotów. Wybierz typ i naciśnij DODAJ WYBRANY."
		return
	_selected_decoration_index = clampi(_selected_decoration_index, 0, items.size() - 1)
	var item: Dictionary = items[_selected_decoration_index]
	if _object_scale_slider != null:
		_object_scale_slider.editable = true
	var kind: String = str(item.get("kind", "box"))
	var name_index: int = DECORATION_KINDS.find(kind)
	var item_name: String = DECORATION_NAMES[name_index] if name_index >= 0 else kind
	var point: Vector3 = item.get("position", Vector3.ZERO)
	_decoration_status.text = "%s  •  %d / %d\nX: %.1f  Z: %.1f  •  Obrót: %.0f°  •  Skala: %.2f\nDotknij modelu, aby go zaznaczyć. Przeciągnij palcem lub użyj przycisków, aby go przesunąć." % [item_name, _selected_decoration_index + 1, items.size(), point.x, point.z, rad_to_deg(float(item.get("rotation", 0.0))), float(item.get("scale", 1.0))]
	if _object_scale_slider != null:
		_object_scale_slider.set_value_no_signal(clampf(float(item.get("scale", 1.0)), 0.6, 2.4))


func _refresh_decoration_preview() -> void:
	_current_data["decorations"] = _get_decorations()
	_show_preview()
	_update_decoration_status()


func _select_previous_decoration() -> void:
	var items: Array = _get_decorations()
	if items.is_empty():
		_update_decoration_status()
		return
	_selected_decoration_index = posmod(_selected_decoration_index - 1, items.size())
	_show_preview()
	_update_decoration_status()


func _select_next_decoration() -> void:
	var items: Array = _get_decorations()
	if items.is_empty():
		_update_decoration_status()
		return
	_selected_decoration_index = posmod(_selected_decoration_index + 1, items.size())
	_show_preview()
	_update_decoration_status()


func _move_decoration(offset: Vector3) -> void:
	var items: Array = _get_decorations()
	if _selected_decoration_index < 0 or _selected_decoration_index >= items.size():
		_update_decoration_status()
		return
	var item: Dictionary = items[_selected_decoration_index]
	var point: Vector3 = item.get("position", Vector3.ZERO)
	point += offset * _move_step
	point.y = 0.0
	if _snap_to_grid:
		point.x = snappedf(point.x, 0.25)
		point.z = snappedf(point.z, 0.25)
	if not _manual_object_position_is_clear(str(item.get("kind", "box")), point, _selected_decoration_index, float(item.get("scale", 1.0))):
		_status.text = "To miejsce nachodzi na trasę, ścianę lub inny obiekt. Wybierz wolne miejsce."
		return
	_push_undo_snapshot()
	item["position"] = point
	items[_selected_decoration_index] = item
	_current_data["decorations"] = items
	_refresh_decoration_preview()
	_status.text = "Przesunięto przedmiot. Zapisz trasę, aby zachować zmianę."


func _rotate_decoration(delta: float) -> void:
	var items: Array = _get_decorations()
	if _selected_decoration_index < 0 or _selected_decoration_index >= items.size():
		_update_decoration_status()
		return
	var item: Dictionary = items[_selected_decoration_index]
	if not _manual_object_position_is_clear(str(item.get("kind", "box")), item.get("position", Vector3.ZERO), _selected_decoration_index, float(item.get("scale", 1.0))):
		_status.text = "Obiekt nie ma wystarczającego odstępu od otoczenia."
		return
	_push_undo_snapshot()
	item["rotation"] = fposmod(float(item.get("rotation", 0.0)) + delta, TAU)
	items[_selected_decoration_index] = item
	_current_data["decorations"] = items
	_refresh_decoration_preview()
	_status.text = "Obrócono wybrany przedmiot. Zapisz trasę, aby zachować zmianę."


func _scale_decoration(factor: float) -> void:
	var items: Array = _get_decorations()
	if _selected_decoration_index < 0 or _selected_decoration_index >= items.size():
		_update_decoration_status()
		return
	var item: Dictionary = items[_selected_decoration_index]
	var new_scale: float = clampf(float(item.get("scale", 1.0)) * factor, 0.6, 2.4)
	if not _manual_object_position_is_clear(str(item.get("kind", "box")), item.get("position", Vector3.ZERO), _selected_decoration_index, new_scale):
		_status.text = "Nie można powiększyć obiektu — zabraknie miejsca przy trasie lub sąsiednich przedmiotach."
		return
	_push_undo_snapshot()
	item["scale"] = new_scale
	items[_selected_decoration_index] = item
	_current_data["decorations"] = items
	_refresh_decoration_preview()
	_status.text = "Zmieniono rozmiar przedmiotu. Zapisz trasę, aby zachować zmianę."


func _reset_decoration_transform() -> void:
	var items: Array = _get_decorations()
	if _selected_decoration_index < 0 or _selected_decoration_index >= items.size():
		_status.text = "Najpierw wybierz przedmiot."
		return
	var item: Dictionary = items[_selected_decoration_index]
	if not _manual_object_position_is_clear(str(item.get("kind", "box")), item.get("position", Vector3.ZERO), _selected_decoration_index, 1.0):
		_status.text = "Nie można przywrócić skali — obiekt nie ma wystarczającego miejsca."
		return
	_push_undo_snapshot()
	item["rotation"] = 0.0
	item["scale"] = 1.0
	items[_selected_decoration_index] = item
	_current_data["decorations"] = items
	_refresh_decoration_preview()
	_status.text = "Przywrócono domyślny obrót i skalę przedmiotu."


func _add_decoration() -> void:
	var route: Array = _current_data.get("route", [])
	if route.size() < 4:
		_status.text = "Najpierw wygeneruj poprawną trasę."
		return
	var items: Array = _get_decorations()
	var usable_segments: int = maxi(route.size() - 4, 1)
	var route_index: int = clampi(2 + posmod(items.size() * 3 + 1, usable_segments), 1, route.size() - 2)
	var point: Vector3 = route[route_index]
	var tangent: Vector3 = (route[route_index + 1] - route[route_index - 1]).normalized()
	var side: Vector3 = Vector3(-tangent.z, 0.0, tangent.x)
	var kind: String = DECORATION_KINDS[clampi(_decoration_select.selected, 0, DECORATION_KINDS.size() - 1)]
	var is_animal: bool = kind in ["cat", "dog", "rabbit", "bearded_dragon", "parrot", "hamster", "guinea_pig", "turtle", "hedgehog", "ferret"]
	var side_sign: float = -1.0 if items.size() % 2 == 0 else 1.0
	var object_clearance: float = 0.75 if is_animal else maxf(1.6, TrackGeneratorScript._furniture_spacing_for_kind(kind) * 1.25 * 0.38 + 0.35)
	point += side * side_sign * (float(_current_data.get("track_width", 1.2)) * 0.5 + object_clearance)
	point += tangent * (float((items.size() % 3) - 1) * 1.2)
	point.y = 0.0
	_add_decoration_at_position(point)


func _add_decoration_at_position(point: Vector3) -> void:
	var kind_index: int = clampi(_decoration_select.selected, 0, DECORATION_KINDS.size() - 1)
	var kind: String = DECORATION_KINDS[kind_index]
	var is_animal: bool = kind in ["cat", "dog", "rabbit", "bearded_dragon", "parrot", "hamster", "guinea_pig", "turtle", "hedgehog", "ferret"]
	var items: Array = _get_decorations().duplicate(true)
	if items.size() >= 200:
		_status.text = "Osiągnięto limit 200 dekoracji i zwierząt na trasie."
		return
	var animal_count: int = 0
	if is_animal:
		for existing: Dictionary in items:
			if str(existing.get("kind", "")) in ["cat", "dog", "rabbit", "bearded_dragon", "parrot", "hamster", "guinea_pig", "turtle", "hedgehog", "ferret"]:
				animal_count += 1
		if animal_count >= 10:
			_status.text = "Na jednej trasie może być maksymalnie dziesięć zwierząt."
			return
	point.y = 0.0
	if not _manual_object_position_is_clear(kind, point, -1, 1.25):
		_status.text = "Nie można tu ustawić obiektu: koliduje z trasą, ścianą lub innym przedmiotem."
		return
	_push_undo_snapshot()
	var tangent: Vector3 = Vector3.FORWARD
	var route: Array = _current_data.get("route", [])
	if route.size() >= 2:
		var nearest_index: int = 0
		var nearest_distance: float = INF
		for i: int in range(route.size()):
			var candidate: Vector3 = route[i]
			var distance: float = Vector2(candidate.x - point.x, candidate.z - point.z).length()
			if distance < nearest_distance:
				nearest_distance = distance
				nearest_index = i
		var before: Vector3 = route[posmod(nearest_index - 1, route.size())]
		var after: Vector3 = route[(nearest_index + 1) % route.size()]
		tangent = (after - before).normalized()
	var side: Vector3 = Vector3(-tangent.z, 0.0, tangent.x)
	var side_sign: float = -1.0 if items.size() % 2 == 0 else 1.0
	items.append({"kind":kind, "position":point, "rotation":0.0, "variant":_picker_variant if _picker_variant >= 0 else items.size() % 4, "scale":1.25, "animal_behavior":kind if is_animal else "", "animal_crossing_direction":-side * side_sign if is_animal else Vector3.ZERO, "animal_crossing_distance":float(_current_data.get("track_width", 1.2)) + 1.0 if is_animal else 0.0, "destructible":not is_animal})
	_current_data["decorations"] = items
	if is_animal:
		_current_data["animal_count"] = animal_count + 1
	_selected_decoration_index = items.size() - 1
	_refresh_decoration_preview()
	_status.text = "Dodano: %s. Obiekt umieszczono w wybranym miejscu mapy." % DECORATION_NAMES[kind_index]


func _duplicate_decoration() -> void:
	var items: Array = _get_decorations()
	if _selected_decoration_index < 0 or _selected_decoration_index >= items.size():
		_status.text = "Najpierw wybierz przedmiot do skopiowania."
		return
	if items.size() >= 200:
		_status.text = "Osiągnięto limit 200 dekoracji i zwierząt na trasie."
		return
	var source: Dictionary = items[_selected_decoration_index].duplicate(true)
	var kind: String = str(source.get("kind", ""))
	var is_animal: bool = kind in ["cat", "dog", "rabbit", "bearded_dragon", "parrot", "hamster", "guinea_pig", "turtle", "hedgehog", "ferret"]
	var animal_count: int = 0
	if is_animal:
		for existing: Dictionary in items:
			if str(existing.get("kind", "")) in ["cat", "dog", "rabbit", "bearded_dragon", "parrot", "hamster", "guinea_pig", "turtle", "hedgehog", "ferret"]:
				animal_count += 1
		if animal_count >= 10:
			_status.text = "Na jednej trasie może być maksymalnie dziesięć zwierząt."
			return
	var copied_position: Vector3 = source.get("position", Vector3.ZERO)
	copied_position += Vector3(2.5, 0.0, 2.5)
	if not _manual_object_position_is_clear(kind, copied_position, -1, float(source.get("scale", 1.0))):
		_status.text = "Nie ma wystarczająco wolnego miejsca na kopię tego obiektu."
		return
	_push_undo_snapshot()
	source["position"] = copied_position
	source["variant"] = int(source.get("variant", 0)) + 1
	items.append(source)
	_current_data["decorations"] = items
	if is_animal:
		_current_data["animal_count"] = mini(animal_count + 1, 10)
	_selected_decoration_index = items.size() - 1
	_refresh_decoration_preview()
	_status.text = "Skopiowano przedmiot wraz z jego wyglądem i ustawieniami."


func _push_undo_snapshot() -> void:
	if _current_data.is_empty():
		return
	_undo_stack.append(_current_data.duplicate(true))
	if _undo_stack.size() > EDIT_HISTORY_LIMIT:
		_undo_stack.pop_front()
	_redo_stack.clear()


func _undo_edit() -> void:
	if _undo_stack.is_empty():
		_status.text = "Nie ma wcześniejszych zmian do cofnięcia."
		return
	_redo_stack.append(_current_data.duplicate(true))
	_current_data = _undo_stack.pop_back()
	_selected_obstacle = clampi(_selected_obstacle, -1, _get_obstacles().size() - 1)
	_selected_decoration_index = clampi(_selected_decoration_index, -1, _get_decorations().size() - 1)
	_show_preview()
	_update_obstacle_status()
	_update_decoration_status()
	_status.text = "Cofnięto ostatnią zmianę edytora."


func _redo_edit() -> void:
	if _redo_stack.is_empty():
		_status.text = "Nie ma zmian do ponowienia."
		return
	_undo_stack.append(_current_data.duplicate(true))
	_current_data = _redo_stack.pop_back()
	_selected_obstacle = clampi(_selected_obstacle, -1, _get_obstacles().size() - 1)
	_selected_decoration_index = clampi(_selected_decoration_index, -1, _get_decorations().size() - 1)
	_show_preview()
	_update_obstacle_status()
	_update_decoration_status()
	_status.text = "Ponowiono zmianę edytora."


func _delete_decoration() -> void:
	_push_undo_snapshot()
	var items: Array = _get_decorations()
	if _selected_decoration_index < 0 or _selected_decoration_index >= items.size():
		_status.text = "Nie ma zaznaczonego przedmiotu do usunięcia."
		return
	var removed_item: Dictionary = items[_selected_decoration_index]
	var removed_kind: String = str(removed_item.get("kind", ""))
	items.remove_at(_selected_decoration_index)
	_current_data["decorations"] = items
	if removed_kind in ["cat", "dog", "rabbit", "bearded_dragon", "parrot", "hamster", "guinea_pig", "turtle", "hedgehog", "ferret"]:
		_current_data["animal_count"] = maxi(int(_current_data.get("animal_count", 0)) - 1, 0)
	_selected_decoration_index = mini(_selected_decoration_index, items.size() - 1)
	_refresh_decoration_preview()
	_status.text = "Usunięto wybrany przedmiot. Zapisz trasę, aby zachować zmianę."


func _save_current() -> void:
	if _current_data.is_empty():
		return
	if bool(_current_data.get("manual_editor", false)) and not _manual_route_closed:
		_manual_status.text = "Najpierw zamknij pętlę, aby zapisać trasę."
		return
	var final_name: String = _manual_name_input.text.strip_edges() if bool(_current_data.get("manual_editor", false)) and _manual_name_input != null else _name_input.text.strip_edges()
	if final_name.is_empty():
		final_name = "Trasa %d" % int(_current_data.get("seed", 0))
	_current_data["name"] = final_name
	_current_data["display_name"] = final_name
	var laps_options: Array[int] = [1, 2, 3, 5, 10]
	var laps_index: int = _manual_laps_select.selected if bool(_current_data.get("manual_editor", false)) else _laps_select.selected
	_current_data["default_laps"] = 1 if not bool(_current_data.get("route_closed", true)) else laps_options[clampi(laps_index, 0, laps_options.size() - 1)]
	if TrackLibrary.save_track(_current_data):
		_status.text = "Zapisano trasę lokalnie: %s" % final_name
		_refresh_saved_tracks()
	else:
		_status.text = "Nie udało się zapisać — trasa nie przeszła walidacji."


func _refresh_saved_tracks() -> void:
	_saved_select.clear()
	_saved_select.add_item("— Wybierz zapisaną trasę —")
	_saved_select.set_item_metadata(0, "")
	for data: Dictionary in TrackLibrary.get_saved_tracks():
		_saved_select.add_item(str(data.get("name", "Trasa")))
		_saved_select.set_item_metadata(_saved_select.get_item_count() - 1, str(data.get("id", "")))
	_saved_select.select(0)


func _on_saved_selected(index: int) -> void:
	if index <= 0:
		return
	var track_id: String = str(_saved_select.get_item_metadata(index))
	var saved: Dictionary = TrackLibrary.get_track(track_id)
	if saved.is_empty():
		return
	_current_data = saved.duplicate(true)
	_texture_selected_path = str(_current_data.get("external_floor_texture_path", ""))
	_texture_selected_slug = str(_current_data.get("external_floor_texture_slug", ""))
	_texture_selected_author = str(_current_data.get("external_floor_texture_author", ""))
	RoomStyleCatalog.ensure_defaults(_current_data)
	_sync_time_selects_from_data()
	_manual_route_closed = bool(saved.get("route_closed", saved.get("generated", true)))
	_manual_added_closure_point = bool(saved.get("manual_closure_added_point", false))
	_manual_route_points = saved.get("route", []).duplicate()
	_set_editor_mode(bool(saved.get("manual_editor", false)))
	if _manual_test_button != null:
		_manual_test_button.disabled = bool(saved.get("manual_editor", false)) and not _manual_route_closed
	_undo_stack.clear()
	_redo_stack.clear()
	_seed_input.text = str(saved.get("seed", 0))
	_name_input.text = str(saved.get("name", "Trasa"))
	if _manual_name_input != null:
		_manual_name_input.text = str(saved.get("name", "Trasa"))
	_size_select.select(int(saved.get("size_level", 1)))
	_manual_size_select.select(int(saved.get("size_level", 1)))
	_current_data.erase("board_size")
	_complexity_select.select(clampi(int(saved.get("complexity", 2)) - 1, 0, 4))
	_obstacles_select.select(clampi(int(saved.get("obstacle_density", 1)), 0, 5))
	_furniture_density_select.select(clampi(int(saved.get("furniture_density", 2)), 0, 4))
	var themes: Array[String] = ["apartment", "kitchen", "bedroom", "futuristic", "cleaning_hall"]
	_theme_select.select(maxi(themes.find(str(saved.get("theme", "apartment"))), 0))
	_manual_theme_select.select(maxi(themes.find(str(saved.get("theme", "apartment"))), 0))
	var saved_laps_options: Array[int] = [1, 2, 3, 5, 10]
	var saved_laps_index: int = maxi(saved_laps_options.find(int(saved.get("default_laps", 3))), 0)
	_manual_laps_select.select(saved_laps_index)
	_laps_select.select(saved_laps_index)
	if _route_type_select != null:
		_route_type_select.select(0 if bool(saved.get("route_closed", saved.get("generated", true))) else 1)
		_on_route_type_selected(_route_type_select.selected)
	_animals_select.select(clampi(int(saved.get("animal_count", 5)), 0, 10))
	_selected_obstacle = 0 if not _get_obstacles().is_empty() else -1
	_selected_decoration_index = 0 if not _get_decorations().is_empty() else -1
	_show_preview()
	_update_obstacle_status()
	_update_decoration_status()
	_status.text = "Wczytano zapisaną trasę: %s" % str(saved.get("name", "Trasa"))
	if bool(saved.get("manual_editor", false)) and _manual_status != null:
		_manual_status.text = "Wczytano własną trasę. Możesz ją testować albo otworzyć pętlę i kontynuować edycję."


func _delete_selected() -> void:
	var index: int = _saved_select.selected
	if index <= 0:
		_status.text = "Najpierw wybierz zapisaną trasę."
		return
	var track_id: String = str(_saved_select.get_item_metadata(index))
	if TrackLibrary.delete_track(track_id):
		_status.text = "Usunięto trasę z lokalnej biblioteki."
		_refresh_saved_tracks()


func _start_race() -> void:
	_save_generator_preferences()
	if _current_data.is_empty():
		_status.text = "Najpierw wygeneruj trasę."
		return
	_apply_time_settings()
	if bool(_current_data.get("manual_editor", false)) and not _manual_route_closed:
		_manual_status.text = "Najpierw zamknij pętlę, aby uruchomić test trasy."
		return
	var validation: Dictionary = TrackGeneratorScript.validate(_current_data)
	if not bool(validation.get("valid", false)):
		_status.text = "Nie można wystartować: %s" % str(validation.get("reason", "błąd walidacji"))
		return
	var laps_options: Array[int] = [1, 2, 3, 5, 10]
	var laps_index: int = _manual_laps_select.selected if bool(_current_data.get("manual_editor", false)) else _laps_select.selected
	var laps: int = 1 if not bool(_current_data.get("route_closed", true)) else laps_options[clampi(laps_index, 0, laps_options.size() - 1)]
	GameManager.configure_generated_race(_current_data, laps)
	GameManager.launch_race()


func _save_generator_preferences() -> void:
	var cfg := ConfigFile.new()
	cfg.load(GENERATOR_PREFS_PATH)
	var values: Dictionary = {
		"size": _size_select.selected if _size_select != null else 1,
		"complexity": _complexity_select.selected if _complexity_select != null else 1,
		"obstacles": _obstacles_select.selected if _obstacles_select != null else 1,
		"theme": _theme_select.selected if _theme_select != null else 0,
		"time": _tod_select.selected if _tod_select != null else 0,
		"dark": _dark_select.selected if _dark_select != null else 0,
		"route_type": _route_type_select.selected if _route_type_select != null else 0,
		"laps": _laps_select.selected if _laps_select != null else 2,
		"animals": _animals_select.selected if _animals_select != null else 5,
		"furniture": _furniture_density_select.selected if _furniture_density_select != null else 1,
		"obstacle_layout": 0,
		"view_3d": _view_3d_mode,
		"manual_size": _manual_size_select.selected if _manual_size_select != null else 1,
		"manual_laps": _manual_laps_select.selected if _manual_laps_select != null else 2,
		"manual_theme": _manual_theme_select.selected if _manual_theme_select != null else 0,
		"manual_time": _manual_tod_select.selected if _manual_tod_select != null else 0,
		"manual_dark": _manual_dark_select.selected if _manual_dark_select != null else 0,
		"editor_mode": _manual_mode,
		"name": _name_input.text if _name_input != null else "Moja trasa"
	}
	for key: String in values:
		cfg.set_value("generator", key, values[key])
	cfg.save(GENERATOR_PREFS_PATH)


func _load_generator_preferences() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(GENERATOR_PREFS_PATH) != OK:
		return
	var options: Array = [
		[_size_select, "size", 1], [_complexity_select, "complexity", 1],
		[_obstacles_select, "obstacles", 1], [_theme_select, "theme", 0],
		[_tod_select, "time", 0], [_dark_select, "dark", 0],
		[_route_type_select, "route_type", 0], [_laps_select, "laps", 2],
		[_animals_select, "animals", 5], [_furniture_density_select, "furniture", 1],
		
		[_manual_size_select, "manual_size", 1], [_manual_laps_select, "manual_laps", 2],
		[_manual_theme_select, "manual_theme", 0], [_manual_tod_select, "manual_time", 0],
		[_manual_dark_select, "manual_dark", 0]
	]
	for entry: Array in options:
		var option: OptionButton = entry[0] as OptionButton
		if option != null:
			option.select(clampi(int(cfg.get_value("generator", str(entry[1]), int(entry[2]))), 0, maxi(option.item_count - 1, 0)))
	if _name_input != null:
		_name_input.text = str(cfg.get_value("generator", "name", _name_input.text))
	# Podgląd startuje zawsze w 2D, żeby poprzednio zapamiętany tryb 3D
	# nie sprawiał wrażenia, że mapa 2D zniknęła.
	_view_3d_mode = false
	_view_2d_button.button_pressed = true
	_view_3d_button.button_pressed = false
	_manual_mode = bool(cfg.get_value("generator", "editor_mode", false))
	if _route_type_select != null:
		_on_route_type_selected(_route_type_select.selected)
	if _view_3d_mode:
		_view_3d_button.button_pressed = true
		_view_2d_button.button_pressed = false
		_set_view_mode(true)


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		GameManager.go_to_main_menu()
