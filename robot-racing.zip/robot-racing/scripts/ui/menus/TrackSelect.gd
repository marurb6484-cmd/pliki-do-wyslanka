extends Control
## Konfiguracja wyścigu / jazdy na czas: trasa, okrążenia, trudność,
## liczba przeciwników, duch, podsumowanie robota, start.

const LAP_OPTIONS: Array[int] = [1, 2, 3, 5, 10]
const TrackGeneratorScript = preload("res://scripts/tracks/TrackGenerator.gd")

var _track_index: int = 0
var _laps: int = 3
var _difficulty: int = 1
var _opponents: int = 4
var _ghost: bool = true

var _track_buttons: Array[Button] = []
var _lap_buttons: Array[Button] = []
var _difficulty_buttons: Array[Button] = []
var _opponent_buttons: Array[Button] = []
var _track_description: Label
var _records_label: Label
var _ghost_button: Button
var _is_time_trial: bool = false
var _is_local_multiplayer: bool = false
var _simple_route_select: OptionButton
var _simple_route_size_select: OptionButton
var _simple_generated_routes: Array[Dictionary] = []
var _simple_selected_route: int = 0
var _generated_size_level: int = 2
var _model_source_select: OptionButton
var _advanced_use_random_route: bool = true
var _random_track_button: Button


func _ready() -> void:
	_is_time_trial = GameManager.mode == GameManager.GameMode.TIME_TRIAL
	_is_local_multiplayer = GameManager.mode == GameManager.GameMode.LOCAL_MULTIPLAYER
	if GameManager.mode == GameManager.GameMode.GRAPHICS_TEST:
		GameManager.mode = GameManager.GameMode.RACE
	_track_index = TrackDatabase.find_index(PlayerProgress.selected_track_id)
	_laps = PlayerProgress.last_laps
	_difficulty = PlayerProgress.last_difficulty
	_opponents = PlayerProgress.last_opponents
	if _is_time_trial:
		_opponents = clampi(SaveManager.get_int("race_preferences", "time_trial_opponents", 0), 0, 4)
	_ghost = PlayerProgress.ghost_enabled
	if GameSettings.is_simple_play_style() and not _is_local_multiplayer:
		if not _is_time_trial:
			_ghost = false
		_generated_size_level = 5
		_build_simple_generated_route_choices()

	UIKit.add_menu_background(self)
	var margin := UIKit.make_screen_margin(self, 36)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 22)
	margin.add_child(column)

	column.add_child(UIKit.make_header("JAZDA NA CZAS" if _is_time_trial else ("LOKALNY MULTIPLAYER – 2 GRACZY" if _is_local_multiplayer else "KONFIGURACJA WYŚCIGU"), func() -> void: GameManager.change_scene(GameManager.SCENE_MODE_SELECT)))

	var body := HBoxContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 30)
	column.add_child(body)

	var scroll := ScrollContainer.new()
	UIKit.configure_touch_scroll(scroll)
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_stretch_ratio = 1.5
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	body.add_child(scroll)
	var options := VBoxContainer.new()
	options.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	options.add_theme_constant_override("separation", 14)
	scroll.add_child(options)

	options.add_child(UIKit.make_label("TRASA", 36, UIKit.COLOR_ACCENT))
	if _is_time_trial and GameSettings.is_simple_play_style():
		options.add_child(UIKit.make_label("WYBIERZ JEDNĄ Z 3 NAJWIĘKSZYCH TRAS GENERATORA", 25, UIKit.COLOR_GOOD))
		options.add_child(UIKit.make_label("Trasy są otwartymi odcinkami do jazdy na czas. Każda ma maksymalny rozmiar generatora.", 21, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false))
		_simple_route_select = OptionButton.new()
		for i: int in range(_simple_generated_routes.size()):
			_simple_route_select.add_item("DUŻY ODCINEK %d" % (i + 1))
		_simple_route_select.select(0)
		_simple_route_select.item_selected.connect(_on_simple_route_changed)
		options.add_child(_simple_route_select)
	elif _is_time_trial:
		options.add_child(UIKit.make_label("NOWA LOSOWA TRASA PRZY KAŻDYM STARCIE", 25, UIKit.COLOR_GOOD))
		options.add_child(UIKit.make_label("Jazda na czas odbywa się na otwartym odcinku — bez okrążeń. Każde uruchomienie otrzymuje nowy układ.", 21, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false))
		options.add_child(UIKit.make_label("WIELKOŚĆ TRASY", 27, UIKit.COLOR_ACCENT))
		_simple_route_size_select = OptionButton.new()
		_simple_route_size_select.add_item("Mała")
		_simple_route_size_select.add_item("Średnia")
		_simple_route_size_select.add_item("Duża")
		_simple_route_size_select.select(1)
		_simple_route_size_select.item_selected.connect(_on_simple_route_size_changed)
		options.add_child(_simple_route_size_select)
	elif GameSettings.is_simple_play_style() and not _is_local_multiplayer:
		options.add_child(UIKit.make_label("WYBIERZ JEDNĄ Z 3 NAJWIĘKSZYCH TRAS GENERATORA", 25, UIKit.COLOR_GOOD))
		options.add_child(UIKit.make_label("Każde wejście do tego menu przygotowuje trzy nowe, duże układy. Wszystkie mają maksymalny rozmiar generatora.", 21, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false))	
		_simple_route_select = OptionButton.new()
		for i: int in range(_simple_generated_routes.size()):
			_simple_route_select.add_item("DUŻA TRASA %d" % (i + 1))
		_simple_route_select.select(0)
		_simple_route_select.item_selected.connect(_on_simple_route_changed)
		options.add_child(_simple_route_select)
	else:
		var generator_button := UIKit.make_button("GENERATOR TRAS  ⚙", 25, 64)
		generator_button.pressed.connect(func() -> void: GameManager.change_scene(GameManager.SCENE_TRACK_GENERATOR))
		options.add_child(generator_button)
		if not _is_local_multiplayer:
			_random_track_button = UIKit.make_button("LOSOWA TRASA – NOWY UKŁAD", 30, 76)
			_random_track_button.toggle_mode = true
			_random_track_button.button_pressed = true
			_random_track_button.pressed.connect(_select_random_track)
			options.add_child(_random_track_button)
		var track_row := HBoxContainer.new()
		track_row.add_theme_constant_override("separation", 12)
		options.add_child(track_row)
		for i: int in range(TrackDatabase.count()):
			var button := UIKit.make_button(str(TrackDatabase.get_track(i)["name"]), 34, 96)
			button.toggle_mode = true
			button.pressed.connect(_select_track.bind(i))
			track_row.add_child(button)
			_track_buttons.append(button)
	_track_description = UIKit.make_label("", 28, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false)
	_track_description.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	options.add_child(_track_description)

	if not _is_local_multiplayer:
		options.add_child(UIKit.make_label("MODELE NA TRASIE", 36, UIKit.COLOR_ACCENT))
		_model_source_select = OptionButton.new()
		_model_source_select.add_item("Standardowe")
		_model_source_select.add_item("Dodatkowe pobrane")
		_model_source_select.add_item("Mieszane")
		_model_source_select.select(2 if StylePackManager.use_downloaded_models and not StylePackManager.is_downloaded_only_mode() else (1 if StylePackManager.is_downloaded_only_mode() else 0))
		_model_source_select.item_selected.connect(_on_model_source_changed)
		options.add_child(_model_source_select)
		var model_source_note := UIKit.make_label("Dodatkowe modele są obecnie pobierane z katalogu Poly Haven. Katalog modeli tworzonych przez graczy nie jest jeszcze dostępny.", 21, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false)
		model_source_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		options.add_child(model_source_note)
		var download_models := UIKit.make_button("POBIERZ / DODATKOWA ZAWARTOŚĆ", 27, 76)
		download_models.pressed.connect(_open_additional_content)
		options.add_child(download_models)

	if not _is_time_trial and not _is_local_multiplayer:
		options.add_child(UIKit.make_label("LICZBA OKRĄŻEŃ", 36, UIKit.COLOR_ACCENT))
		var laps_row := HBoxContainer.new()
		laps_row.add_theme_constant_override("separation", 12)
		options.add_child(laps_row)
		for laps: int in LAP_OPTIONS:
			var lap_button := UIKit.make_button(str(laps), 36, 96)
			lap_button.toggle_mode = true
			lap_button.pressed.connect(_select_laps.bind(laps))
			laps_row.add_child(lap_button)
			_lap_buttons.append(lap_button)

	if not _is_time_trial and not _is_local_multiplayer:
		options.add_child(UIKit.make_label("POZIOM TRUDNOŚCI AI", 36, UIKit.COLOR_ACCENT))
		var difficulty_row := HBoxContainer.new()
		difficulty_row.add_theme_constant_override("separation", 12)
		options.add_child(difficulty_row)
		for i: int in range(4):
			var difficulty_button := UIKit.make_button(AIDifficulty.NAMES[i], 30, 96)
			difficulty_button.toggle_mode = true
			difficulty_button.pressed.connect(_select_difficulty.bind(i))
			difficulty_row.add_child(difficulty_button)
			_difficulty_buttons.append(difficulty_button)

		options.add_child(UIKit.make_label("LICZBA PRZECIWNIKÓW", 36, UIKit.COLOR_ACCENT))
		var opponents_row := HBoxContainer.new()
		opponents_row.add_theme_constant_override("separation", 12)
		options.add_child(opponents_row)
		for count: int in range(1, 5):
			var opponent_button := UIKit.make_button(str(count), 36, 96)
			opponent_button.toggle_mode = true
			opponent_button.pressed.connect(_select_opponents.bind(count))
			opponents_row.add_child(opponent_button)
			_opponent_buttons.append(opponent_button)
	elif _is_time_trial:
		options.add_child(UIKit.make_label("POZIOM TRUDNOŚCI AI", 36, UIKit.COLOR_ACCENT))
		var time_trial_difficulty_row := HBoxContainer.new()
		time_trial_difficulty_row.add_theme_constant_override("separation", 12)
		options.add_child(time_trial_difficulty_row)
		for i: int in range(4):
			var difficulty_button := UIKit.make_button(AIDifficulty.NAMES[i], 30, 96)
			difficulty_button.toggle_mode = true
			difficulty_button.pressed.connect(_select_difficulty.bind(i))
			time_trial_difficulty_row.add_child(difficulty_button)
			_difficulty_buttons.append(difficulty_button)
		options.add_child(UIKit.make_label("LICZBA PRZECIWNIKÓW", 36, UIKit.COLOR_ACCENT))
		var time_trial_opponents_row := HBoxContainer.new()
		time_trial_opponents_row.add_theme_constant_override("separation", 12)
		options.add_child(time_trial_opponents_row)
		for count: int in range(0, 5):
			var opponent_button := UIKit.make_button(str(count), 36, 96)
			opponent_button.toggle_mode = true
			opponent_button.pressed.connect(_select_opponents.bind(count))
			time_trial_opponents_row.add_child(opponent_button)
			_opponent_buttons.append(opponent_button)
		if not GameSettings.is_simple_play_style():
			_ghost_button = UIKit.make_button("", 34, 96)
			_ghost_button.pressed.connect(_toggle_ghost)
			options.add_child(_ghost_button)

	# Prawa kolumna - robot, rekordy, start.
	var side := UIKit.make_panel()
	side.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_child(side)
	var side_column := VBoxContainer.new()
	side_column.add_theme_constant_override("separation", 16)
	side.add_child(side_column)

	var config: Dictionary = PlayerProgress.get_player_robot_config()
	side_column.add_child(UIKit.make_label("TWÓJ ROBOT", 34, UIKit.COLOR_ACCENT))
	side_column.add_child(UIKit.make_label(str(config["name"]), 42))
	var damage: float = PlayerProgress.get_damage(PlayerProgress.selected_robot)
	var damage_label := UIKit.make_label("Uszkodzenia: %d%%" % int(damage), 30, DamageSystem.STAGE_COLORS[_stage(damage)])
	side_column.add_child(damage_label)
	var garage := UIKit.make_button("ZMIEŃ / ULEPSZ (GARAŻ)", 30, 90)
	garage.pressed.connect(func() -> void: GameManager.change_scene(GameManager.SCENE_GARAGE))
	side_column.add_child(garage)

	_records_label = UIKit.make_label("", 28, UIKit.COLOR_MUTED, HORIZONTAL_ALIGNMENT_LEFT, false)
	_records_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_records_label.size_flags_vertical = Control.SIZE_EXPAND_FILL
	side_column.add_child(_records_label)

	var start := UIKit.make_button("START  ▶", 50, 140)
	start.pressed.connect(_on_start)
	side_column.add_child(start)

	_refresh()


func _on_model_source_changed(index: int) -> void:
	match index:
		0:
			StylePackManager.set_downloaded_only_mode(false)
			StylePackManager.set_use_downloaded_models(false)
		1:
			StylePackManager.set_downloaded_only_mode(true)
		2:
			StylePackManager.set_downloaded_only_mode(false)
			StylePackManager.set_use_downloaded_models(true)


func _open_additional_content() -> void:
	GameSettings.open_content_tab_requested = true
	GameManager.open_settings(GameManager.SCENE_TRACK_SELECT)


func _on_simple_route_changed(index: int) -> void:
	_simple_selected_route = clampi(index, 0, maxi(0, _simple_generated_routes.size() - 1))
	_refresh()


func _build_simple_generated_route_choices() -> void:
	_simple_generated_routes.clear()
	var route_rng := RandomNumberGenerator.new()
	route_rng.randomize()
	for i: int in range(3):
		var route_seed: int = GameManager.get_unique_random_track_seed()
		var route_complexity: int = 4
		var route_style: int = GameManager.get_unique_random_track_style(route_complexity)
		var generated: Dictionary = TrackGeneratorScript.generate(
			route_seed, 5, route_complexity, 1, "apartment", "DUŻA TRASA %d" % (i + 1),
			3, 3, route_rng.randi_range(0, 2), ("segment" if _is_time_trial else "lap"), route_style
		)
		generated["random_route_session"] = true
		generated["simple_large_route_choice"] = i
		_simple_generated_routes.append(generated)
	_simple_selected_route = 0


func _on_simple_route_size_changed(index: int) -> void:
	_generated_size_level = [0, 2, 4][index]
	_refresh()


func _stage(damage: float) -> int:
	return 3 if damage >= 75.0 else (2 if damage >= 50.0 else (1 if damage >= 25.0 else 0))


func _select_track(index: int) -> void:
	_track_index = index
	_advanced_use_random_route = false
	_laps = int(TrackDatabase.get_track(index).get("default_laps", _laps)) if not LAP_OPTIONS.has(_laps) else _laps
	_persist_race_preferences()
	_refresh()


func _select_random_track() -> void:
	_advanced_use_random_route = true
	_refresh()


func _select_laps(laps: int) -> void:
	_laps = laps
	_persist_race_preferences()
	_refresh()


func _select_difficulty(level: int) -> void:
	_difficulty = level
	_persist_race_preferences()
	_refresh()


func _select_opponents(count: int) -> void:
	_opponents = clampi(count, 0 if _is_time_trial else 1, 4)
	_persist_race_preferences()
	_refresh()


func _toggle_ghost() -> void:
	_ghost = not _ghost
	_persist_race_preferences()
	_refresh()


func _refresh() -> void:
	for i: int in range(_track_buttons.size()):
		_track_buttons[i].set_pressed_no_signal(i == _track_index and (_is_local_multiplayer or not _advanced_use_random_route))
	for i: int in range(_lap_buttons.size()):
		_lap_buttons[i].set_pressed_no_signal(LAP_OPTIONS[i] == _laps)
	for i: int in range(_difficulty_buttons.size()):
		_difficulty_buttons[i].set_pressed_no_signal(i == _difficulty)
	for i: int in range(_opponent_buttons.size()):
		_opponent_buttons[i].set_pressed_no_signal((i if _is_time_trial else i + 1) == _opponents)
	if _random_track_button != null:
		_random_track_button.set_pressed_no_signal(_advanced_use_random_route)
	if _ghost_button != null:
		_ghost_button.text = "DUCH NAJLEPSZEGO OKRĄŻENIA: %s" % ("WŁĄCZONY" if _ghost else "WYŁĄCZONY")

	var simple_generated_mode: bool = GameSettings.is_simple_play_style() and not _is_local_multiplayer
	var track: Dictionary = TrackDatabase.get_track(_track_index)
	if simple_generated_mode:
		var simple_route: Dictionary = _simple_generated_routes[_simple_selected_route] if not _simple_generated_routes.is_empty() else {}
		_track_description.text = "%s — maksymalny rozmiar generatora. Trasa jest gotowa do wyboru i nie zmienia się po naciśnięciu START." % str(simple_route.get("name", "Duża trasa"))
	elif not _is_time_trial and not _is_local_multiplayer and not GameSettings.is_simple_play_style() and _advanced_use_random_route:
		_track_description.text = "Każde wejście do wyścigu losuje świeży układ o innym archetypie niż trzy poprzednie losowania."
	else:
		_track_description.text = str(track.get("description", ""))

	var mode_id: String = "time_trial" if _is_time_trial else ("local_multiplayer" if _is_local_multiplayer else "race")
	if _is_time_trial and simple_generated_mode:
		_records_label.text = "DUŻE ODCINKI GENERATORA\nWybrany układ: %d z 3\nMaksymalny rozmiar mapy." % (_simple_selected_route + 1)
	elif _is_time_trial:
		_records_label.text = "JAZDA NA CZAS\nKażdy start losuje nowy, otwarty odcinek. Wynik zapisuje się dla konkretnego układu trasy."
	elif simple_generated_mode:
		_records_label.text = ("DUŻE ODCINKI GENERATORA" if _is_time_trial else "DUŻE TRASY GENERATORA") + "\nWybrany układ: %d z 3\nMaksymalny rozmiar mapy." % (_simple_selected_route + 1)
	else:
		var best: Dictionary = PlayerProgress.get_best(str(track["id"]), mode_id, _laps)
		_records_label.text = "REKORDY (%d okr.)\nNajlepszy czas: %s\nNajlepsze okrążenie: %s" % [
			_laps,
			UIKit.format_time(float(best.get("total", -1.0))),
			UIKit.format_time(float(best.get("best_lap", -1.0)))
		]
	if _is_time_trial:
		_records_label.text += "\n\nPrzeciwnicy: %d | Poziom AI: %s" % [_opponents, AIDifficulty.NAMES[_difficulty]]
	if not _is_time_trial and not _is_local_multiplayer:
		_records_label.text += "\n\nPoziom AI: %s | Przeciwnicy: %d | Okrążenia: %d" % [AIDifficulty.NAMES[_difficulty], _opponents, _laps]
		if not GameSettings.is_simple_play_style():
			_records_label.text += "\nNagrody: ×%.2f za poziom %s" % [AIDifficulty.REWARD_MULTIPLIER[_difficulty], AIDifficulty.NAMES[_difficulty]]


func _persist_race_preferences() -> void:
	var track_id: String = str(TrackDatabase.get_track(_track_index).get("id", "apartment"))
	if _is_time_trial:
		SaveManager.set_value("race_preferences", "time_trial_opponents", clampi(_opponents, 0, 4))
		SaveManager.save_now()
		PlayerProgress.set_race_preferences(track_id, _difficulty, _laps, PlayerProgress.last_opponents, _ghost)
	else:
		PlayerProgress.set_race_preferences(track_id, _difficulty, _laps, _opponents, _ghost)


func _on_start() -> void:
	_persist_race_preferences()
	if _is_local_multiplayer:
		GameManager.configure_local_multiplayer(_track_index, _laps)
	elif _is_time_trial:
		if GameSettings.is_simple_play_style():
			if _simple_generated_routes.is_empty():
				_build_simple_generated_route_choices()
			var selected_index: int = clampi(_simple_selected_route, 0, _simple_generated_routes.size() - 1)
			var selected_segment: Dictionary = _simple_generated_routes[selected_index].duplicate(true)
			GameManager.configure_generated_time_trial(selected_segment, _ghost, _opponents, _difficulty)
		else:
			var route_rng := RandomNumberGenerator.new()
			route_rng.randomize()
			var route_seed: int = GameManager.get_unique_random_track_seed()
			var route_complexity: int = route_rng.randi_range(2, 5)
			var route_style: int = GameManager.get_unique_random_track_style(route_complexity)
			var size_level: int = _generated_size_level
			var generated: Dictionary = TrackGeneratorScript.generate(route_seed, size_level, route_complexity, route_rng.randi_range(0, 2), "apartment", "JAZDA NA CZAS", 3, route_rng.randi_range(2, 4), route_rng.randi_range(0, 2), "segment", route_style)
			generated["random_route_session"] = true
			GameManager.configure_generated_time_trial(generated, _ghost, _opponents, _difficulty)
	else:
		var mode: int = GameManager.GameMode.RACE
		if GameSettings.is_simple_play_style():
			if _simple_generated_routes.is_empty():
				_build_simple_generated_route_choices()
			var selected_index: int = clampi(_simple_selected_route, 0, _simple_generated_routes.size() - 1)
			var selected_route: Dictionary = _simple_generated_routes[selected_index].duplicate(true)
			GameManager.configure_generated_race(selected_route, _laps, _difficulty, _opponents)
		else:
			if _advanced_use_random_route:
				var route_rng := RandomNumberGenerator.new()
				route_rng.randomize()
				var route_seed: int = GameManager.get_unique_random_track_seed()
				var route_complexity: int = route_rng.randi_range(2, 4)
				var route_style: int = GameManager.get_unique_random_track_style(route_complexity)
				var generated: Dictionary = TrackGeneratorScript.generate(route_seed, _generated_size_level, route_complexity, 1, "apartment", "TRASA WYŚCIGOWA", 3, 2, route_rng.randi_range(0, 2), "lap", route_style)
				generated["random_route_session"] = true
				GameManager.configure_generated_race(generated, _laps, _difficulty, _opponents)
			else:
				GameManager.configure_race(mode, _track_index, _laps, _difficulty, _opponents, _ghost)
	GameManager.launch_race()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		GameManager.change_scene(GameManager.SCENE_MODE_SELECT)
