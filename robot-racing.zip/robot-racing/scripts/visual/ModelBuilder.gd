class_name ModelBuilder
extends RefCounted
## Budowniczy modeli 3D z wielu miękkich brył scalanych w kilka siatek.
##
## Zamiast setek osobnych MeshInstance3D (jedna bryła = jeden draw call) bryły
## o tym samym materiale są scalane w jedną ArrayMesh. Model jest podzielony na
## nazwane CZĘŚCI (np. "Head", "Tail", "LegFL"), a każda część to osobny Node3D
## z pivotem w sensownym punkcie — dzięki temu model jest gotowy do animacji
## (obrót głowy, ogona, łap) bez zmiany geometrii.
##
## Materiały to zwykłe StandardMaterial3D w `material_override`, więc skórki
## (ObjectSkins) działają na każdym modelu bez żadnych zmian.
##
## Konwencja: model stoi na y = 0, "przód" zwrócony w stronę -Z.

var _parts: Dictionary = {}
var _part_order: Array[String] = []
var _current_part: String = "Body"


## Rozpoczyna nową część modelu. `pivot` to punkt obrotu części w układzie modelu.
func part(part_name: String, pivot: Vector3 = Vector3.ZERO) -> void:
	_current_part = part_name
	if not _parts.has(part_name):
		_parts[part_name] = {"pivot": pivot, "groups": {}}
		_part_order.append(part_name)


## Miękka bryła: `squareness` 2.0 = elipsoida, 3–4 = poduszka/zaokrąglony klocek.
func ellipsoid(pos: Vector3, radii: Vector3, color: Color, rot: Vector3 = Vector3.ZERO, squareness: float = 2.0, rough: float = 0.72, metal: float = 0.0) -> void:
	var arrays: Array = _superellipsoid_arrays(radii, squareness, 20, 12)
	_add_arrays(arrays, Transform3D(Basis.from_euler(rot), pos), color, rough, metal)


## Zaokrąglony klocek (mebel, książka, pudełko) o wymiarach `size`.
func soft_box(pos: Vector3, size: Vector3, color: Color, rot: Vector3 = Vector3.ZERO, roundness: float = 4.0, rough: float = 0.78, metal: float = 0.0) -> void:
	ellipsoid(pos, size * 0.5, color, rot, roundness, rough, metal)


func cylinder(pos: Vector3, top_radius: float, bottom_radius: float, height: float, color: Color, rot: Vector3 = Vector3.ZERO, rough: float = 0.72, metal: float = 0.0) -> void:
	var mesh := CylinderMesh.new()
	mesh.top_radius = top_radius
	mesh.bottom_radius = bottom_radius
	mesh.height = height
	mesh.radial_segments = 14
	mesh.rings = 1
	_add_arrays(mesh.get_mesh_arrays(), Transform3D(Basis.from_euler(rot), pos), color, rough, metal)


func cone(pos: Vector3, radius: float, height: float, color: Color, rot: Vector3 = Vector3.ZERO, rough: float = 0.72) -> void:
	cylinder(pos, 0.0, radius, height, color, rot, rough, 0.0)


func torus(pos: Vector3, inner_radius: float, outer_radius: float, color: Color, rot: Vector3 = Vector3.ZERO, rough: float = 0.6, metal: float = 0.0) -> void:
	var mesh := TorusMesh.new()
	mesh.inner_radius = inner_radius
	mesh.outer_radius = outer_radius
	mesh.rings = 20
	mesh.ring_segments = 10
	_add_arrays(mesh.get_mesh_arrays(), Transform3D(Basis.from_euler(rot), pos), color, rough, metal)


func box(pos: Vector3, size: Vector3, color: Color, rot: Vector3 = Vector3.ZERO, rough: float = 0.78, metal: float = 0.0) -> void:
	var mesh := BoxMesh.new()
	mesh.size = size
	_add_arrays(mesh.get_mesh_arrays(), Transform3D(Basis.from_euler(rot), pos), color, rough, metal)


## Tworzy węzły części i siatki jako dzieci `parent`. Zwraca liczbę dodanych węzłów części.
func build(parent: Node3D) -> int:
	var added: int = 0
	for part_name: String in _part_order:
		var data: Dictionary = _parts[part_name]
		var pivot: Vector3 = data["pivot"]
		var holder := Node3D.new()
		holder.name = part_name
		holder.position = pivot
		parent.add_child(holder)
		added += 1
		var groups: Dictionary = data["groups"]
		for key: Variant in groups.keys():
			var group: Dictionary = groups[key]
			var verts: PackedVector3Array = group["verts"]
			if verts.is_empty():
				continue
			var arrays: Array = []
			arrays.resize(Mesh.ARRAY_MAX)
			arrays[Mesh.ARRAY_VERTEX] = verts
			arrays[Mesh.ARRAY_NORMAL] = group["norms"]
			arrays[Mesh.ARRAY_INDEX] = group["idx"]
			var mesh := ArrayMesh.new()
			mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
			var instance := MeshInstance3D.new()
			instance.name = "Mesh_%s" % str(key)
			instance.mesh = mesh
			var material := StandardMaterial3D.new()
			material.albedo_color = group["color"]
			material.roughness = float(group["rough"])
			material.metallic = float(group["metal"])
			if (group["color"] as Color).a < 0.99:
				material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			instance.material_override = material
			instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
			holder.add_child(instance)
	return added


func _add_arrays(source: Array, xform: Transform3D, color: Color, rough: float, metal: float) -> void:
	if source.size() <= Mesh.ARRAY_VERTEX or source[Mesh.ARRAY_VERTEX] == null:
		return
	var data: Dictionary = _parts[_current_part] if _parts.has(_current_part) else _create_default_part()
	var pivot: Vector3 = data["pivot"]
	var local := Transform3D(xform.basis, xform.origin - pivot)
	var group_key: String = "%s_%d_%d" % [color.to_html(true), int(rough * 100.0), int(metal * 100.0)]
	var groups: Dictionary = data["groups"]
	if not groups.has(group_key):
		groups[group_key] = {"verts": PackedVector3Array(), "norms": PackedVector3Array(), "idx": PackedInt32Array(), "color": color, "rough": rough, "metal": metal}
	var group: Dictionary = groups[group_key]
	var verts: PackedVector3Array = group["verts"]
	var norms: PackedVector3Array = group["norms"]
	var indices: PackedInt32Array = group["idx"]
	var base_index: int = verts.size()
	var src_verts: PackedVector3Array = source[Mesh.ARRAY_VERTEX]
	var src_norms: PackedVector3Array = source[Mesh.ARRAY_NORMAL] if source[Mesh.ARRAY_NORMAL] != null else PackedVector3Array()
	var normal_basis: Basis = local.basis.inverse().transposed()
	for i: int in range(src_verts.size()):
		verts.append(local * src_verts[i])
		var normal: Vector3 = src_norms[i] if i < src_norms.size() else Vector3.UP
		norms.append((normal_basis * normal).normalized())
	var src_index: PackedInt32Array = PackedInt32Array()
	if source.size() > Mesh.ARRAY_INDEX and source[Mesh.ARRAY_INDEX] != null:
		src_index = source[Mesh.ARRAY_INDEX]
	if src_index.is_empty():
		for i: int in range(src_verts.size()):
			indices.append(base_index + i)
	else:
		for index_value: int in src_index:
			indices.append(base_index + index_value)
	group["verts"] = verts
	group["norms"] = norms
	group["idx"] = indices
	groups[group_key] = group


func _create_default_part() -> Dictionary:
	_parts[_current_part] = {"pivot": Vector3.ZERO, "groups": {}}
	_part_order.append(_current_part)
	return _parts[_current_part]


static func _signed_pow(value: float, exponent: float) -> float:
	return signf(value) * pow(absf(value), exponent)


## Superelipsoida (wykładnik `n`): n = 2 daje elipsoidę, n = 4 miękki "klocek".
## Kolejność wierzchołków jest zgodna z zasadą Godota (front = zgodnie z ruchem wskazówek zegara).
static func _superellipsoid_arrays(radii: Vector3, n: float, segments: int, rings: int) -> Array:
	var verts := PackedVector3Array()
	var norms := PackedVector3Array()
	var indices := PackedInt32Array()
	var e: float = 2.0 / maxf(n, 0.5)
	for i: int in range(rings + 1):
		var theta: float = PI * float(i) / float(rings)
		var sin_theta: float = sin(theta)
		var cos_theta: float = cos(theta)
		for j: int in range(segments + 1):
			var phi: float = TAU * float(j) / float(segments)
			var ux: float = _signed_pow(sin_theta * cos(phi), e)
			var uy: float = _signed_pow(cos_theta, e)
			var uz: float = _signed_pow(sin_theta * sin(phi), e)
			verts.append(Vector3(ux * radii.x, uy * radii.y, uz * radii.z))
			var normal := Vector3(
				_signed_pow(ux, n - 1.0) / radii.x,
				_signed_pow(uy, n - 1.0) / radii.y,
				_signed_pow(uz, n - 1.0) / radii.z
			)
			norms.append(normal.normalized() if normal.length() > 0.00001 else Vector3.UP)
	for i: int in range(rings):
		for j: int in range(segments):
			var a: int = i * (segments + 1) + j
			var b: int = a + segments + 1
			indices.append(a)
			indices.append(b)
			indices.append(a + 1)
			indices.append(a + 1)
			indices.append(b)
			indices.append(b + 1)
	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = norms
	arrays[Mesh.ARRAY_INDEX] = indices
	return arrays
