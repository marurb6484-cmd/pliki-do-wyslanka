class_name ObjectSkins
extends RefCounted
## Skórki obiektów: zmieniają WYŁĄCZNIE materiały, nigdy geometrię modeli.
##
## Ten sam model (mebel, przeszkoda, zwierzę) może wyglądać kreskówkowo,
## realistycznie, neonowo albo pastelowo. Oryginalny materiał każdej bryły jest
## zapamiętany w metadanych (`skin_original_material`), dlatego powrót do skórki
## kreskówkowej przywraca wygląd bez żadnej utraty. Stacje dokujące są pomijane.
##
## Dodanie nowej skórki: dopisz wpis w `SKINS` i przypadek w `_make_skinned_material`.

const DEFAULT_SKIN: String = "cartoon"
const META_ORIGINAL: String = "skin_original_material"
const META_IGNORE: String = "skin_ignore"

## id → {name, description}. Kolejność = kolejność w menu.
const SKINS: Dictionary = {
	"cartoon": {"name": "Kreskówkowa", "description": "Domyślny, nasycony wygląd gry."},
	"realistic": {"name": "Realistyczna", "description": "Stonowane kolory, ziarno materiału, naturalny połysk."},
	"neon": {"name": "Neonowa", "description": "Ciemne bryły ze świecącymi krawędziami barw."},
	"pastel": {"name": "Pastelowa", "description": "Jasne, miękkie kolory i matowe powierzchnie."},
}

static var _grain_texture: ImageTexture = null


static func skin_ids() -> Array[String]:
	var result: Array[String] = []
	for key: Variant in SKINS.keys():
		result.append(str(key))
	return result


static func skin_names() -> Array[String]:
	var result: Array[String] = []
	for key: Variant in SKINS.keys():
		result.append(str((SKINS[key] as Dictionary).get("name", key)))
	return result


static func normalize(skin_id: String) -> String:
	return skin_id if SKINS.has(skin_id) else DEFAULT_SKIN


static func index_of(skin_id: String) -> int:
	return maxi(skin_ids().find(normalize(skin_id)), 0)


## Stosuje skórkę do całego poddrzewa `root`. Bezpieczne do wielokrotnego wywołania.
static func apply(root: Node, skin_id: String) -> void:
	if root == null:
		return
	var skin: String = normalize(skin_id)
	var cache: Dictionary = {}
	_apply_recursive(root, skin, cache)


## Stosuje skórkę tylko do wybranych dzieci (np. dekoracje i przeszkody toru),
## pomijając resztę sceny: podłogę, ściany i stacje dokujące.
static func apply_to_named_children(parent: Node, name_prefixes: Array[String], skin_id: String) -> void:
	if parent == null:
		return
	var skin: String = normalize(skin_id)
	var cache: Dictionary = {}
	for child: Node in parent.get_children():
		for prefix: String in name_prefixes:
			if str(child.name).begins_with(prefix):
				_apply_recursive(child, skin, cache)
				break


static func _apply_recursive(node: Node, skin: String, cache: Dictionary) -> void:
	if node.has_meta(META_IGNORE):
		return
	if node is MeshInstance3D:
		_apply_to_mesh(node as MeshInstance3D, skin, cache)
	for child: Node in node.get_children():
		_apply_recursive(child, skin, cache)


static func _apply_to_mesh(instance: MeshInstance3D, skin: String, cache: Dictionary) -> void:
	var original: Material = null
	if instance.has_meta(META_ORIGINAL):
		original = instance.get_meta(META_ORIGINAL) as Material
	else:
		original = instance.material_override
		if original == null:
			return
		instance.set_meta(META_ORIGINAL, original)
	if original == null:
		return
	if skin == DEFAULT_SKIN:
		instance.material_override = original
		return
	var base: StandardMaterial3D = original as StandardMaterial3D
	if base == null or base.emission_enabled:
		# Materiały świecące (zaznaczenie w edytorze, lampy) zostają bez zmian.
		instance.material_override = original
		return
	var key: String = "%d_%s" % [base.get_instance_id(), skin]
	if not cache.has(key):
		cache[key] = _make_skinned_material(base, skin)
	instance.material_override = cache[key] as Material


static func _make_skinned_material(base: StandardMaterial3D, skin: String) -> StandardMaterial3D:
	var material: StandardMaterial3D = base.duplicate() as StandardMaterial3D
	var color: Color = base.albedo_color
	match skin:
		"realistic":
			material.albedo_color = Color.from_hsv(color.h, color.s * 0.70, color.v * 0.90, color.a)
			material.roughness = clampf(base.roughness * 0.92 + 0.04, 0.35, 0.92)
			if base.metallic > 0.3:
				material.clearcoat_enabled = true
				material.clearcoat = 0.35
			material.albedo_texture = _get_grain_texture()
			material.uv1_triplanar = true
			material.uv1_scale = Vector3(2.2, 2.2, 2.2)
		"neon":
			var dark: Color = Color.from_hsv(color.h, minf(color.s + 0.15, 1.0), color.v * 0.16, color.a)
			var glow: Color = Color.from_hsv(color.h, 0.85, 1.0)
			material.albedo_color = dark
			material.metallic = 0.15
			material.roughness = 0.35
			material.emission_enabled = true
			material.emission = glow
			material.emission_energy_multiplier = 1.15
		"pastel":
			var soft: Color = Color.from_hsv(color.h, color.s * 0.42, 0.82 + color.v * 0.16, color.a)
			material.albedo_color = soft
			material.roughness = 0.92
			material.metallic = 0.0
	return material


static func _get_grain_texture() -> ImageTexture:
	if _grain_texture != null:
		return _grain_texture
	var size: int = 64
	var image: Image = Image.create(size, size, false, Image.FORMAT_RGB8)
	var generator := RandomNumberGenerator.new()
	generator.seed = 7421
	for y: int in range(size):
		for x: int in range(size):
			# Delikatne ziarno + łagodne pasma (włókna drewna/tkaniny).
			var band: float = 0.5 + 0.5 * sin(float(x) * 0.55 + sin(float(y) * 0.21) * 2.0)
			var value: float = 0.82 + band * 0.10 + generator.randf_range(-0.045, 0.045)
			image.set_pixel(x, y, Color(value, value, value))
	_grain_texture = ImageTexture.create_from_image(image)
	return _grain_texture
