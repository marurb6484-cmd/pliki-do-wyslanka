extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	assert(BoostCatalog.IDS.size() == 10, "Katalog musi zawierać dokładnie 10 boostów")
	for boost_id: String in BoostCatalog.IDS:
		var definition: Dictionary = BoostCatalog.get_definition(boost_id)
		assert(not definition.is_empty(), "Brak definicji: %s" % boost_id)
		assert(not str(definition.get("name", "")).is_empty(), "Brak nazwy: %s" % boost_id)
		assert(float(definition.get("cooldown", -1.0)) >= 0.0, "Niepoprawny cooldown: %s" % boost_id)
		assert(float(definition.get("energy_cost", -1.0)) >= 0.0, "Niepoprawny koszt energii: %s" % boost_id)
		var parameters: Array = BoostUpgradeSystem.get_parameters(boost_id)
		assert(not parameters.is_empty(), "Brak parametrów ulepszeń: %s" % boost_id)
		for parameter: Dictionary in parameters:
			assert(not str(parameter.get("id", "")).is_empty(), "Pusty identyfikator parametru: %s" % boost_id)
			assert(float(parameter.get("step", 0.0)) != 0.0, "Zerowy krok ulepszenia: %s" % boost_id)
	for rarity: String in BoostCatalog.RARITIES:
		assert(BoostCatalog.get_rarity_index(rarity) >= 0)
	print("BoostCatalogRegressionTest: OK")
	quit()
