extends SceneTree
## Test systemu presetów boostów: sloty, duplikaty i trwały zapis.
## Uruchomienie: godot --headless --path . --script res://tests/BoostLoadoutTest.gd -- --test-save

var failures: int = 0


func _initialize() -> void:
	call_deferred("_run")


func _run() -> void:
	var loadout: BoostLoadoutSystem = BoostLoadoutSystem.new()
	_check(loadout.get_equipped().size() == 2, "Dwa sloty startowe")
	_check(loadout.get_equipped()[0] == "turbo", "Domyślny pierwszy boost")
	_check(loadout.get_equipped()[1] == "electric_pulse", "Domyślny drugi boost")
	_check(not loadout.equip("turbo", 1), "Blokada duplikatu w innym slocie")
	loadout.clear_slot(0)
	_check(loadout.get_equipped()[0].is_empty(), "Czyszczenie pierwszego slotu")
	_check(loadout.get_equipped()[1] == "electric_pulse", "Czyszczenie nie przesuwa drugiego slotu")
	_check(loadout.equip("turbo", 0), "Ponowne wyposażenie pustego slotu")
	_check(loadout.create_preset("Testowy"), "Tworzenie presetu")
	_check(loadout.select_preset("Domyślny"), "Powrót do domyślnego presetu")
	SaveManager.save_now()
	var loaded: BoostLoadoutSystem = BoostLoadoutSystem.new()
	_check(loaded.get_equipped()[0] == "turbo", "Zapis wyposażenia")
	_check(loaded.get_equipped()[1] == "electric_pulse", "Zapis kolejności slotów")
	_check(loaded.select_preset("Testowy"), "Zapis i odczyt listy presetów")
	_check(loaded.get_equipped().size() == 2, "Preset zachowuje liczbę slotów")
	PlayerProgress.boost_loadout.reset_to_defaults()
	SaveManager.save_now()
	print("BOOST_LOADOUT_TEST: %s (błędów: %d)" % ["ZALICZONY" if failures == 0 else "NIEZALICZONY", failures])
	quit(0 if failures == 0 else 1)


func _check(condition: bool, label: String) -> void:
	if condition:
		print("  OK   ", label)
	else:
		failures += 1
		printerr("  FAIL ", label)
