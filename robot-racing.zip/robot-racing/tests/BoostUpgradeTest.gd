extends SceneTree
## Test ulepszeń boostów. Uruchamiać wyłącznie z --test-save.

var failures: int = 0


func _initialize() -> void:
	call_deferred("_run")


func _run() -> void:
	PlayerProgress.add_currency(10000)
	BoostUpgradeSystem.reset_all()
	var before: Dictionary = BoostUpgradeSystem.apply_to_definition("turbo", "common")
	_check(BoostUpgradeSystem.get_level("turbo", "common", "duration") == 0, "Początkowy poziom parametru")
	_check(BoostUpgradeSystem.purchase_level("turbo", "common", "duration"), "Zakup poziomu za CR")
	var after: Dictionary = BoostUpgradeSystem.apply_to_definition("turbo", "common")
	_check(BoostUpgradeSystem.get_level("turbo", "common", "duration") == 1, "Zapis poziomu common")
	_check(float(after.get("duration", 0.0)) > float(before.get("duration", 0.0)), "Ulepszenie zwiększa czas Turbo")
	_check(BoostUpgradeSystem.purchase_level("turbo", "rare", "duration"), "Niezależny zakup poziomu rare")
	_check(BoostUpgradeSystem.get_level("turbo", "rare", "duration") == 1, "Oddzielny zapis rzadkości")
	_check(BoostUpgradeSystem.get_level("turbo", "common", "duration") == 1, "Common zachowuje własny poziom")
	var full_cost: int = BoostUpgradeSystem.get_full_upgrade_cost("turbo", "common")
	_check(full_cost > 0, "Wyliczanie kosztu ulepszenia całego boosta")
	_check(BoostUpgradeSystem.purchase_full_upgrade("turbo", "common"), "Zakup ulepszenia całego boosta")
	_check(BoostUpgradeSystem.get_level("turbo", "common", "speed_pct") == 1, "Ulepszenie całego boosta zwiększa pozostałe parametry")
	# Ulepszenia jednego boosta nie mogą przechodzić na inne boosty.
	var overdrive_params: Array = BoostUpgradeSystem.get_parameters("overdrive")
	var overdrive_has_speed: bool = false
	var overdrive_has_accel: bool = false
	for parameter: Dictionary in overdrive_params:
		overdrive_has_speed = overdrive_has_speed or str(parameter.get("id", "")) == "speed_pct"
		overdrive_has_accel = overdrive_has_accel or str(parameter.get("id", "")) == "accel_pct"
	_check(not overdrive_has_speed and not overdrive_has_accel, "Overdrive nie ma ulepszeń prędkości ani przyspieszenia")
	_check(BoostUpgradeSystem.get_level("electric_pulse", "common", "duration") == 0, "Ulepszenie Turbo nie przenosi się na Impuls elektryczny")
	BoostUpgradeSystem.reset_all()
	SaveManager.save_now()
	print("BOOST_UPGRADE_TEST: %s (błędów: %d)" % ["ZALICZONY" if failures == 0 else "NIEZALICZONY", failures])
	quit(0 if failures == 0 else 1)


func _check(condition: bool, label: String) -> void:
	if condition:
		print("  OK   ", label)
	else:
		failures += 1
		printerr("  FAIL ", label)
