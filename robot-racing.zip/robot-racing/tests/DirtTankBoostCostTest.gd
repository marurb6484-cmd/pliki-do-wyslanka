extends SceneTree
## Sprawdza stały koszt brudu dla użycia boosta i brak przepełniania zbiornika.

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var tank := DirtTank.new()
	root.add_child(tank)
	tank.setup(10.0)
	assert(is_equal_approx(tank.add(12.0), 10.0), "Zbiornik przyjmuje tylko wolne miejsce")
	assert(is_equal_approx(tank.charge, 10.0), "Zbiornik nie przekracza pojemności")
	assert(is_equal_approx(tank.total_collected, 10.0), "Statystyka liczy faktycznie przyjęty brud")

	var boost := BoostSystem.new()
	root.add_child(boost)
	boost.setup({"boost_cost": 5.0}, tank)
	assert(is_equal_approx(boost.cost, 5.0), "Wspólny koszt każdego boosta wynosi 5 jednostek")
	assert(boost.has_enough_dirt(), "Pełny zbiornik pozwala aktywować boost")
	assert(boost.try_activate(), "Aktywacja zużywa wymagany brud")
	assert(is_equal_approx(tank.charge, 5.0), "Po użyciu boosta zostaje 5 jednostek")
	boost.cancel()
	assert(is_equal_approx(tank.charge, 5.0), "Anulowanie działania nie zwraca zużytego brudu")
	assert(tank.consume(5.0), "Pozostały brud można zużyć")
	assert(is_equal_approx(tank.charge, 0.0), "Zbiornik po zużyciu jest pusty")
	assert(not boost.has_enough_dirt(), "Bez brudu boost nie jest gotowy")

	print("DirtTankBoostCostTest: OK")
	quit(0)
