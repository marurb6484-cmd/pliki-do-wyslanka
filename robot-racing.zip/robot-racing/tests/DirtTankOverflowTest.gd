extends SceneTree
## Pełny zbiornik nie może blokować zbierania punktów kurzu.

func _initialize() -> void:
	var tank := DirtTank.new()
	tank.setup(10.0)
	assert(is_equal_approx(tank.add(6.0), 6.0), "Pierwsza porcja powinna zostać zebrana")
	assert(is_equal_approx(tank.add(8.0), 8.0), "Nadmiar powinien nadal być zaliczany jako zebrany")
	assert(is_equal_approx(tank.charge, 10.0), "Ładunek użytkowy nie może przekroczyć pojemności")
	assert(is_equal_approx(tank.total_collected, 14.0), "Statystyka powinna uwzględnić również nadmiar")
	assert(tank.is_full(), "Zbiornik powinien pozostać oznaczony jako pełny")
	tank.free()
	print("DirtTankOverflowTest: OK")
	quit()
