extends SceneTree
## Test regresyjny modeli zabrudzeń. Uruchomić w Godot jako skrypt SceneTree.

func _initialize() -> void:
	var manager := DirtManager.new()
	for type_index: int in range(DirtManager.DIRT_TYPES.size()):
		var visual: Node3D = manager._build_dirt_visual(type_index, type_index + 1)
		assert(visual.get_child_count() >= 5, "Model zabrudzenia ma zbyt mało detali: %d" % type_index)
		visual.free()	
	var dark_marks: Node3D = manager._build_dark_crumb_marks(42)
	assert(dark_marks.get_child_count() >= 2 and dark_marks.get_child_count() <= 4, "Każdy punkt brudu musi mieć duży owal i kilka drobnych okruszków")
	var main_mark := dark_marks.get_child(0) as MeshInstance3D
	assert(main_mark.name == "DuzyCzarnyOwal", "Brakuje dużego owalu pod punktem brudu")
	assert(main_mark.scale.x >= 1.18 and main_mark.scale.x <= 1.42, "Duży owal ma zachować projektowaną szerokość")
	assert(is_equal_approx(dark_marks.scale.x, 0.42), "Ślady pod zabrudzeniami muszą być czytelne z kamery wyścigu")
	for mark: Node in dark_marks.get_children():
		var mesh_instance := mark as MeshInstance3D
		var material := mesh_instance.material_override as StandardMaterial3D
		assert(material.roughness >= 0.95 and not material.emission_enabled, "Okruszki mają być matowe i nieświecące")
	dark_marks.free()
	manager.free()
	print("DirtVisualRegressionTest: OK")
	quit()
