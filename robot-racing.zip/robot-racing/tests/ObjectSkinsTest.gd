extends SceneTree
## Test skórek obiektów: zmieniają tylko materiały, a powrót do skórki
## kreskówkowej przywraca oryginalne materiały. Uruchomienie w Godot 4.7.2:
##   godot --headless --path . --script res://tests/ObjectSkinsTest.gd

func _initialize() -> void:
	call_deferred("_run")


func _run() -> void:
	assert(ObjectSkins.skin_ids().size() >= 4, "Brak przykładowych skórek")
	assert(ObjectSkins.normalize("nieistniejaca") == ObjectSkins.DEFAULT_SKIN)
	var root := Node3D.new()
	var instance := MeshInstance3D.new()
	instance.mesh = SphereMesh.new()
	var original := StandardMaterial3D.new()
	original.albedo_color = Color("#d18d54")
	instance.material_override = original
	root.add_child(instance)
	var mesh_before: Mesh = instance.mesh
	for skin_id: String in ObjectSkins.skin_ids():
		ObjectSkins.apply(root, skin_id)
		assert(instance.mesh == mesh_before, "Skórka nie może zmieniać geometrii: %s" % skin_id)
		assert(instance.material_override != null, "Brak materiału po skórce: %s" % skin_id)
	ObjectSkins.apply(root, "neon")
	var neon: StandardMaterial3D = instance.material_override as StandardMaterial3D
	assert(neon.emission_enabled, "Skórka neonowa musi świecić")
	ObjectSkins.apply(root, "cartoon")
	assert(instance.material_override == original, "Powrót do kreskówkowej musi przywrócić oryginał")
	root.free()
	print("ObjectSkinsTest: OK")
	quit()
