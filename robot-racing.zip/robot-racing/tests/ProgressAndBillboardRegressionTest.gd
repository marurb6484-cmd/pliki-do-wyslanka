extends SceneTree

## Testy regresyjne bez renderowania: kierunek powierzchni banera i cele dzienne.
func _initialize() -> void:
	var tangent := Vector3(0.0, 0.0, -1.0)
	var approach := -tangent
	var billboard_basis := Basis.looking_at(approach, Vector3.UP)
	var front_normal := -billboard_basis.z.normalized()
	assert(front_normal.dot(approach.normalized()) > 0.99)
	print("ProgressAndBillboardRegressionTest: kierunek frontu banera OK")
	quit()
