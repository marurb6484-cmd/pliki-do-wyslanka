extends SceneTree

const TrackGeneratorScript = preload("res://scripts/tracks/TrackGenerator.gd")
## Sprawdza, czy dane dekoracji trafiają do drzewa 3D proceduralnej trasy.

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var data: Dictionary = TrackGeneratorScript.generate(734921, 1, 2, 1, "apartment", "Test dekoracji", 0)
	var track := ProceduralTrack.new()
	track.configure(data)
	root.add_child(track)
	assert(track.built, "Trasa nie została zbudowana")
	assert(track.generated_decorations.size() == data.get("decorations", []).size(), "Nie zgadza się liczba dekoracji w danych")
	var generated_kinds: Array[String] = []
	for decoration: Dictionary in data.get("decorations", []):
		generated_kinds.append(str(decoration.get("kind", "")))
	for required_kind: String in ["plant", "sofa", "table", "chair", "cabinet", "lamp"]:
		assert(generated_kinds.has(required_kind), "Generator nie rozstawił wymaganej grupy mebli: " + required_kind)
	var visible_objects: int = 0
	var destructible_objects: int = 0
	for child: Node in track.get_children():
		if child.name.begins_with("Dekoracja_") and child is Node3D and child.get_child_count() > 0:
			visible_objects += 1
			if child.get_script() == load("res://scripts/tracks/TrackDestructibleObject.gd"):
				destructible_objects += 1
				assert(child.get_node_or_null("StrefaZniszczenia") is Area3D, "Obiekt zniszczalny nie ma strefy kolizji")
	assert(visible_objects == track.generated_decorations.size(), "Nie wszystkie dekoracje utworzyły modele 3D")
	assert(destructible_objects > 0, "Brak przedmiotów z wytrzymałością")
	for child: Node in track.get_children():
		if child.name.begins_with("Dekoracja_") and child.get_script() == load("res://scripts/tracks/TrackDestructibleObject.gd"):
			if str(child.name).contains("_toy") or str(child.name).contains("_mug") or str(child.name).contains("_book"):
				assert(bool(child.get("movable")), "Mały przedmiot powinien dać się odepchnąć")
	print("TrackDecorationPlacementTest: OK — %d modeli" % visible_objects)
	track.queue_free()
	quit()
