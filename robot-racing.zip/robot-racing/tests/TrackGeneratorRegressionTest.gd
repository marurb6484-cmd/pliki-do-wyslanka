extends SceneTree

const TrackGeneratorScript = preload("res://scripts/tracks/TrackGenerator.gd")

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var partition_route: Array = [Vector3(-30.0, 0.0, -30.0), Vector3(30.0, 0.0, -30.0), Vector3(30.0, 0.0, 30.0), Vector3(-30.0, 0.0, 30.0)]
	var vertical_doors: Array[Vector2] = TrackGeneratorScript.get_room_partition_openings(partition_route, true, 0.0, 12.0, -50.0, 50.0)
	var horizontal_doors: Array[Vector2] = TrackGeneratorScript.get_room_partition_openings(partition_route, false, 0.0, 12.0, -50.0, 50.0)
	assert(not vertical_doors.is_empty() and not horizontal_doors.is_empty(), "Ściany działowe muszą mieć otwory drzwiowe tam, gdzie przecina je trasa")
	var open_partition_route: Array = [Vector3(-10.0, 0.0, 0.0), Vector3(10.0, 0.0, 0.0), Vector3(10.0, 0.0, 10.0)]
	var open_route_doors: Array[Vector2] = TrackGeneratorScript.get_room_partition_openings(open_partition_route, true, 0.0, 12.0, -20.0, 20.0, false)
	assert(open_route_doors.size() == 1, "Otwarty odcinek nie może tworzyć sztucznego połączenia między metą i startem przy wyznaczaniu drzwi")
	var wall_test_route: Array = [Vector3(-8.0, 0.0, 0.0), Vector3(8.0, 0.0, 0.0)]
	assert(not TrackGeneratorScript.wall_segment_clear_of_route(wall_test_route, true, 0.0, -8.0, 8.0, 2.45, false), "Ściana przecinająca trasę musi zostać bezwarunkowo odrzucona")
	assert(TrackGeneratorScript.wall_segment_clear_of_route(wall_test_route, false, 4.0, -8.0, 8.0, 2.45, false), "Ściana poza korytarzem bezpieczeństwa może pozostać")
	for doorway: Vector2 in vertical_doors:
		assert(doorway.y - doorway.x >= 13.7, "Pionowy otwór drzwiowy musi być szerszy niż tor z zapasem")
	for doorway: Vector2 in horizontal_doors:
		assert(doorway.y - doorway.x >= 13.7, "Poziomy otwór drzwiowy musi być szerszy niż tor z zapasem")
	for animal_count: int in range(6):
		var data: Dictionary = TrackGeneratorScript.generate(9000 + animal_count, 1, 2, 1, "apartment", "Test", animal_count)
		var validation: Dictionary = TrackGeneratorScript.validate(data)
		assert(bool(validation.get("valid", false)), "Generator validation failed: %s" % str(validation.get("reason", "")))
		assert((data["route"] as Array).size() >= 6)
		assert(int(data.get("generator_version", 0)) >= 43)
		assert(int(data.get("dirt_pickup_count", 0)) >= 66, "Generator musi przewidywać zwiększoną liczbę punktów brudu")
		assert((data.get("room_partitions", []) as Array).size() >= 1, "Mieszkanie musi mieć czytelne podziały pomieszczeń")
		assert((data.get("room_bounds", []) as Array).size() >= 2 and (data.get("room_bounds", []) as Array).size() <= 5, "Generator ma tworzyć mniej, większych pomieszczeń")
		var alcove_count: int = 0
		for partition: Dictionary in data.get("room_partitions", []):
			if bool(partition.get("alcove", false)):
				alcove_count += 1
		assert(alcove_count <= 1, "Generator nie może tworzyć nadmiaru małych wnęk")
		var route: Array = data["route"]
		var start_a: Vector3 = route[0]
		var start_b: Vector3 = route[1]
		assert(start_a.distance_to(start_b) >= 7.0, "Start i meta muszą mieć dłuższą prostą na wyścig i stacje")
		assert((data["docking_stations"] as Array).size() == 2)
		var stations: Array = data["docking_stations"]
		var tangent: Vector3 = (route[1] - route[0]).normalized()
		var side: Vector3 = Vector3(-tangent.z, 0.0, tangent.x)
		var center: Vector3 = (route[0] + route[1]) * 0.5
		var station_a: Vector3 = stations[0]["position"]
		var station_b: Vector3 = stations[1]["position"]
		assert((station_a - center).dot(side) > 0.0 and (station_b - center).dot(side) > 0.0, "Wszystkie stacje startowe muszą stać po prawej stronie toru")
		assert(absf((station_a - center).dot(tangent)) < 4.0)
		assert(absf((station_b - center).dot(tangent)) < 2.1)
		for station: Dictionary in stations:
			var lateral: float = (station["position"] - center).dot(side)
			assert(absf(lateral) >= float(data.get("track_width", 1.2)) * 0.5 + 0.80, "Stacje muszą mieć dodatkowy odstęp od jezdni")
			var expected_facing: Vector3 = -side * signf(lateral)
			var rotation_y: float = float(station["rotation"])
			var actual_facing := Vector3(-sin(rotation_y), 0.0, -cos(rotation_y))
			assert(actual_facing.dot(expected_facing) > 0.90, "Front stacji musi być skierowany do toru")
		assert(int(data.get("floor_texture", -1)) in range(5))
		assert(TrackGeneratorScript._route_has_safe_clearance(route, float(data.get("track_width", 1.2)) + 0.35), "Trasa musi zachować bezpieczny odstęp, ale generator może prowadzić ją bliżej środka")
		assert(int(data.get("animal_count", -1)) == animal_count)
	for size_index: int in range(6):
		var large_data: Dictionary = TrackGeneratorScript.generate(12000 + size_index, size_index, 4, 2, "futuristic", "Duża trasa", 3)
		var large_validation: Dictionary = TrackGeneratorScript.validate(large_data)
		assert(bool(large_validation.get("valid", false)), "Size %d: %s" % [size_index, str(large_validation.get("reason", ""))])
		assert(float(large_data.get("track_width", 0.0)) >= 1.65 + float(size_index) * 0.15)
		var large_route: Array = large_data.get("route", [])
		for point_index: int in range(large_route.size()):
			assert((large_route[point_index] as Vector3).distance_to(large_route[(point_index + 1) % large_route.size()]) >= 1.0)
	for furniture_level: int in range(2):
		for obstacle_layout: int in range(3):
			var advanced_data: Dictionary = TrackGeneratorScript.generate(22000 + furniture_level * 10 + obstacle_layout, 2, 3, 2, "apartment", "Test ustawień zaawansowanych", 2, furniture_level, obstacle_layout)
			var advanced_validation: Dictionary = TrackGeneratorScript.validate(advanced_data)
			assert(bool(advanced_validation.get("valid", false)), "Advanced generator settings invalid: %s" % str(advanced_validation.get("reason", "")))
			assert(int(advanced_data.get("furniture_count", -1)) == (8 if furniture_level == 0 else 24))
			assert(int(advanced_data.get("furniture_density", -1)) == furniture_level)
			assert(int(advanced_data.get("obstacle_layout", -1)) == obstacle_layout)
			assert((advanced_data.get("obstacles", []) as Array).size() == 2 * (3 + 3))
			var on_track_items: int = 0
			for decoration: Dictionary in advanced_data.get("decorations", []):
				if bool(decoration.get("on_track", false)):
					on_track_items += 1
					assert(not ["sofa", "table", "lamp", "bookshelf", "chair", "bed", "cabinet", "fridge", "bathtub", "sink", "kitchen_counter", "washing_machine", "shower", "wardrobe", "nightstand", "coffee_table", "shoe_rack", "ottoman", "floor_mirror"].has(str(decoration.get("kind", ""))), "Meble nie mogą być generowane na jezdni")
			assert(on_track_items == 0, "Małe przedmioty muszą być obok toru, nigdy na jezdni")
			assert(not (advanced_data.get("start_room_bounds", {}) as Dictionary).is_empty(), "Generator musi tworzyć osobny pokój startowy")
			assert((advanced_data.get("room_bounds", []) as Array).size() <= 5, "Pokój startowy nie może zwiększać liczby pokoi użytkowych")
			var decoration_route: Array[Vector3] = []
			for route_value: Variant in advanced_data.get("route", []):
				if route_value is Vector3:
					decoration_route.append(route_value)
			for decoration: Dictionary in advanced_data.get("decorations", []):
				assert(not bool(decoration.get("on_track", false)), "Żaden dekoracyjny przedmiot nie może blokować jezdni")
				var decoration_position: Vector3 = decoration.get("position", Vector3.ZERO)
				var required_gap: float = float(advanced_data.get("track_width", 1.8)) * 0.5 + maxf(0.50, TrackGeneratorScript._furniture_spacing_for_kind(str(decoration.get("kind", ""))) * 0.30)
				assert(TrackGeneratorScript._distance_to_route_xz(decoration_position, decoration_route, bool(advanced_data.get("route_closed", true))) >= required_gap, "Przedmioty dekoracyjne muszą stać obok toru z zapasem")
	# Trzy kolejne wymuszone archetypy muszą tworzyć wyraźnie różne geometrie,
	# nawet przy tym samym seedzie i tych samych parametrach bazowych.
	var archetype_a: Dictionary = TrackGeneratorScript.generate(45001, 2, 3, 1, "apartment", "Archetyp A", 3, 2, 0, "lap", 0)
	var archetype_b: Dictionary = TrackGeneratorScript.generate(45002, 2, 3, 1, "apartment", "Archetyp B", 3, 2, 0, "lap", 1)
	var archetype_c: Dictionary = TrackGeneratorScript.generate(45003, 2, 3, 1, "apartment", "Archetyp C", 3, 2, 0, "lap", 2)
	assert(archetype_a.get("route", []) != archetype_b.get("route", []), "Archetypy 0 i 1 muszą mieć różne przebiegi")
	assert(archetype_b.get("route", []) != archetype_c.get("route", []), "Archetypy 1 i 2 muszą mieć różne przebiegi")
	assert(archetype_a.get("route", []) != archetype_c.get("route", []), "Archetypy 0 i 2 muszą mieć różne przebiegi")
	var extreme_a: Dictionary = TrackGeneratorScript.generate(12000, 0, 5, 2)
	var extreme_b: Dictionary = TrackGeneratorScript.generate(12001, 0, 5, 2)
	assert(extreme_a.get("route", []) != extreme_b.get("route", []), "Różne seedy dają różne warianty układu")
	assert(bool(TrackGeneratorScript.validate(extreme_a).get("valid", false)) and bool(TrackGeneratorScript.validate(extreme_b).get("valid", false)), "Ekstremalne trasy muszą przechodzić walidację nawet po użyciu bezpiecznego wariantu awaryjnego")
	assert(TrackGeneratorScript._route_has_safe_clearance(extreme_a.get("route", []), float(extreme_a.get("track_width", 1.2)) + 0.35, true), "Ekstremalna trasa musi zachować odstępy poza ciasnymi, sąsiednimi zakrętami")
	for size_index: int in range(6):
		var base: Dictionary = TrackGeneratorScript.generate(31000 + size_index, size_index, 2, 0, "apartment", "Trasa ręczna", 0, 0, 1)
		var base_route: Array = base.get("route", [])
		var first_point: Vector3 = base_route[0]
		var second_point: Vector3 = base_route[1]
		var manual_route: Array[Vector3] = []
		manual_route.append(first_point)
		manual_route.append(second_point)
		var direction := Vector2(second_point.x - first_point.x, second_point.z - first_point.z).normalized()
		var turns: Array[int] = [0, -1, -1, 1, 0, -1]
		var lengths: Array[float] = [60.0, 60.0, 60.0, 35.0, 35.0, 100.0]
		for segment_index: int in range(turns.size()):
			direction = direction.rotated(-PI * 0.5 * float(turns[segment_index])).normalized()
			var last: Vector3 = manual_route[manual_route.size() - 1]
			var next_point: Vector2 = Vector2(last.x, last.z) + direction * lengths[segment_index]
			manual_route.append(Vector3(next_point.x, 0.0, next_point.y))
		var manual_data: Dictionary = base.duplicate(true)
		manual_data["route"] = manual_route
		manual_data["route_closed"] = true
		manual_data["manual_editor"] = true
		manual_data["generated"] = true
		manual_data["obstacles"] = []
		manual_data["decorations"] = []
		manual_data["animal_count"] = 0
		manual_data["furniture_density"] = 0
		manual_data["furniture_count"] = 5
		manual_data["docking_stations"] = TrackGeneratorScript.make_docking_stations(manual_route, float(manual_data.get("track_width", 1.2)))
		assert(bool(TrackGeneratorScript.validate(manual_data).get("valid", false)), "Przykładowa trasa ręczna musi przejść walidację dla rozmiaru %d" % size_index)
	var segment_data: Dictionary = TrackGeneratorScript.generate(45678, 1, 3, 1, "apartment", "Testowy odcinek", 2, 1, 1, "segment")
	var segment_route: Array = segment_data.get("route", [])
	assert(not bool(segment_data.get("route_closed", true)), "Odcinek musi być otwartą trasą")
	assert(segment_route[0].distance_to(segment_route[segment_route.size() - 1]) >= 20.0, "Odcinek musi mieć różne położenie startu i mety")
	assert((segment_data.get("midpoint_station", {}) as Dictionary).is_empty(), "Odcinek nie może mieć stacji ładowania w połowie trasy")
	assert(TrackGeneratorScript.make_midpoint_station(segment_route, float(segment_data.get("track_width", 1.8))).is_empty(), "Funkcja zgodności nie może już generować stacji pośrodku trasy")
	assert(int(segment_data.get("default_laps", 0)) == 1, "Odcinek jest pojedynczym przejazdem, a nie pętlą")
	assert(bool(TrackGeneratorScript.validate(segment_data).get("valid", false)), "Odcinek nie przeszedł walidacji: %s" % str(TrackGeneratorScript.validate(segment_data).get("reason", "")))
	# Regresja v28: geometria pozostaje w limicie walidatora i składa się z prostych segmentów.
	for size_index: int in range(6):
		for complexity_index: int in range(1, 6):
			var straight_data: Dictionary = TrackGeneratorScript.generate(71000 + size_index * 100 + complexity_index, size_index, complexity_index, 1, "apartment", "Regresja v33", 2)
			var straight_route: Array = straight_data.get("route", [])
			var straight_validation: Dictionary = TrackGeneratorScript.validate(straight_data)
			assert(bool(straight_validation.get("valid", false)), "Generator v31 nie może blokować trasy: %s" % str(straight_validation.get("reason", "")))
			assert(straight_route.size() <= 36, "Proste segmenty nie mogą przekroczyć limitu 36 punktów")
			assert(int(straight_data.get("generator_version", 0)) >= 33, "Nowa trasa musi być oznaczona rewizją 33")
	# Migracja zapisanej trasy v27: powiększenie geometrii, szersza jezdnia i długa prosta start/meta.
	var legacy_data: Dictionary = TrackGeneratorScript.generate(88001, 1, 2, 1, "apartment", "Stara zapisana trasa", 1)
	legacy_data["generator_version"] = 27
	var legacy_ratio: float = 0.034 / 0.073
	var legacy_route: Array = legacy_data.get("route", [])
	for point_index: int in range(legacy_route.size()):
		legacy_route[point_index] = (legacy_route[point_index] as Vector3) * legacy_ratio
	legacy_data["route"] = legacy_route
	legacy_data["track_width"] = 1.45
	var migrated_data: Dictionary = TrackGeneratorScript.normalize_legacy_data(legacy_data)
	assert(int(migrated_data.get("generator_version", 0)) >= 33, "Zapisana trasa musi zostać zmigrowana do v33")
	assert(not (migrated_data.get("start_room_bounds", {}) as Dictionary).is_empty(), "Migracja musi dodać osobny pokój startowy")
	assert(float(migrated_data.get("track_width", 0.0)) >= 1.80, "Migracja musi zwiększyć szerokość jezdni")
	assert((migrated_data["route"] as Array)[0].distance_to((migrated_data["route"] as Array)[1]) >= 7.0, "Migracja musi dodać dłuższą prostą start/meta")
	assert(bool(TrackGeneratorScript.validate(migrated_data).get("valid", false)), "Zmigrowana trasa musi przejść walidację")
	# Regresja v30: szósty poziom rozmiaru i otwarta hala do sprzątania.
	var giant_hall: Dictionary = TrackGeneratorScript.generate(990031, 5, 3, 1, "cleaning_hall", "Gigantyczna hala", 0)
	var giant_validation: Dictionary = TrackGeneratorScript.validate(giant_hall)
	assert(bool(giant_validation.get("valid", false)), "Gigantyczna hala musi przejść walidację: %s" % str(giant_validation.get("reason", "")))
	assert(is_equal_approx(float(giant_hall.get("track_width", 0.0)), 2.45), "Szósty poziom musi zachować szerokość 2.45 m")
	assert((giant_hall.get("room_partitions", []) as Array).is_empty(), "Hala do sprzątania ma pozostać otwarta, bez ścian działowych")
	assert((giant_hall.get("room_bounds", []) as Array).size() == 1, "Otwarta hala ma mieć jeden obszar pomieszczenia")
	var hall_styles: Array[Dictionary] = RoomStyleCatalog.assign_room_styles(giant_hall)
	assert(hall_styles.size() == 1 and str(hall_styles[0].get("type", "")) == "office", "Hala nie może otrzymać losowego umeblowania salonu")
	var opening_route: Array[Vector3] = [Vector3(-5.0, 0.0, 0.0), Vector3(5.0, 0.0, 0.0)]
	var safe_openings: Array[Vector2] = TrackGeneratorScript.get_room_partition_openings(opening_route, true, 0.0, 2.45, -10.0, 10.0, false)
	assert(safe_openings.size() == 1 and safe_openings[0].y - safe_openings[0].x >= 20.0, "Otwór w ścianie musi mieć szeroki, bezkolizyjny korytarz po obu stronach toru")
	var furnisher := RoomFurnisher.new()
	var wardrobe_axis: Vector2 = furnisher._half_extents("wardrobe", 1.0, 0.0)
	var wardrobe_diagonal: Vector2 = furnisher._half_extents("wardrobe", 1.0, PI * 0.25)
	assert(wardrobe_diagonal.x > wardrobe_axis.x and wardrobe_diagonal.y > wardrobe_axis.y, "Obrócone meble muszą zajmować poprawny obszar w podglądzie kolizji")
	print("TrackGeneratorRegressionTest: OK")
	quit()


func test_wider_track_sizes_and_varied_route() -> void:
	for size_index: int in range(6):
		var data: Dictionary = TrackGeneratorScript.generate(1000 + size_index, size_index, 4, 1, "apartment", "Test", 2)
		assert(float(data.get("track_width", 0.0)) >= 1.65 + float(size_index) * 0.15)
		assert(data.get("route", []).size() >= 16)
		assert(TrackGeneratorScript.validate(data).get("valid", false))
