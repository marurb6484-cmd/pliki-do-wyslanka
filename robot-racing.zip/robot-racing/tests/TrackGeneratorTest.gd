extends SceneTree

const TrackGeneratorScript = preload("res://scripts/tracks/TrackGenerator.gd")
## Test generatora proceduralnego i lokalnej biblioteki tras.
## Uruchamiać wyłącznie z --test-save.

var failures: int = 0


func _initialize() -> void:
	call_deferred("_run")


func _run() -> void:
	var first: Dictionary = TrackGeneratorScript.generate(24680, 1, 3, 2, "kitchen", "Test generatora")
	var second: Dictionary = TrackGeneratorScript.generate(24680, 1, 3, 2, "kitchen", "Test generatora")
	_check(TrackGeneratorScript.validate(first).get("valid", false), "Wygenerowana trasa przechodzi walidację")
	_check(first.get("route", []) == second.get("route", []), "Ten sam seed odtwarza tę samą trasę")
	_check((first.get("docking_stations", []) as Array).size() == 2, "Generator zawsze tworzy dwie stacje przy starcie")
	var stations: Array = first.get("docking_stations", [])
	var start_tangent: Vector3 = (first["route"][1] - first["route"][0]).normalized()
	var start_side: Vector3 = Vector3(-start_tangent.z, 0.0, start_tangent.x)
	var start_center: Vector3 = (first["route"][0] + first["route"][1]) * 0.5
	var station_a: Vector3 = stations[0]["position"]
	var station_b: Vector3 = stations[1]["position"]
	_check((station_a - start_center).dot(start_side) > 0.0 and (station_b - start_center).dot(start_side) > 0.0, "Obie stacje stoją po prawej stronie startu")
	_check(absf((station_a - start_center).dot(start_tangent)) < 3.0 and absf((station_b - start_center).dot(start_tangent)) < 2.1, "Stacje stoją w jednej linii po prawej stronie, wzdłuż prostej startowej")
	_check(stations[0].get("side", "") == "start_right" and stations[1].get("side", "") == "start_right", "Obie stacje należą do prawej strefy startowej")
	_check(int(first.get("floor_texture", -1)) >= 0 and int(first.get("floor_texture", -1)) <= 4, "Generator wybiera jedną z pięciu tekstur podłogi")
	_check(first.get("floor_texture") == second.get("floor_texture"), "Tekstura podłogi jest deterministyczna dla tego samego seedu")
	_check(int(first.get("dirt_pickup_count", 0)) >= 66, "Generator zwiększa liczbę punktów zbierania brudu")
	_check((first.get("room_partitions", []) as Array).size() >= 1, "Generator tworzy zróżnicowane ściany działowe")
	_check((first.get("room_bounds", []) as Array).size() >= 2 and (first.get("room_bounds", []) as Array).size() <= 5, "Generator tworzy mniej, większych pomieszczeń")
	var room_styles: Array[Dictionary] = RoomStyleCatalog.assign_room_styles(first)
	var bedroom_count: int = 0
	for room_style: Dictionary in room_styles:
		if str(room_style.get("type", "")) == "bedroom":
			bedroom_count += 1
	_check(bedroom_count >= 1, "Generator przydziela sypialnię w większym mieszkaniu")
	_check(room_styles.size() == (first.get("room_bounds", []) as Array).size(), "Każde pomieszczenie otrzymuje styl")
	var alcove_count: int = 0
	for partition: Dictionary in first.get("room_partitions", []):
		if bool(partition.get("alcove", false)):
			alcove_count += 1
	_check(alcove_count <= 1, "Generator ogranicza liczbę wnęk")
	var start_points: Array = first.get("route", [])
	var start_a: Vector3 = start_points[0]
	var start_b: Vector3 = start_points[1]
	_check(start_a.distance_to(start_b) >= 3.0 and absf(start_a.z - start_b.z) < 0.05, "Odcinek startowy jest prosty i ma odpowiednią długość")
	_check((first.get("decorations", []) as Array).size() >= 9, "Generator rozmieszcza zwierzęta i dekoracje")
	var decoration_kinds: Array[String] = []
	for decoration: Dictionary in first.get("decorations", []):
		decoration_kinds.append(str(decoration.get("kind", "")))
	_check(decoration_kinds.has("cat") and decoration_kinds.has("dog") and decoration_kinds.has("rabbit"), "Każda trasa ma kota, psa i królika")
	_check(decoration_kinds.has("bearded_dragon"), "Każda trasa ma agamę brodatą")
	_check(decoration_kinds.has("parrot"), "Każda trasa ma papugę")
	_check(decoration_kinds.has("plant") and decoration_kinds.has("sofa") and decoration_kinds.has("table"), "Każda trasa ma podstawowe dekoracje mieszkania")
	_check(first.get("decorations", []) == second.get("decorations", []), "Dekoracje są deterministyczne dla tego samego seedu")
	_check(first.get("room_partitions", []) == second.get("room_partitions", []), "Układ ścian działowych jest deterministyczny dla tego samego seedu")
	_check(first.get("room_bounds", []) == second.get("room_bounds", []), "Układ pomieszczeń jest deterministyczny dla tego samego seedu")
	for animal_count: int in range(6):
		var count_data: Dictionary = TrackGeneratorScript.generate(50000 + animal_count, 1, 2, 1, "apartment", "Liczba zwierząt", animal_count)
		_check(bool(TrackGeneratorScript.validate(count_data).get("valid", false)), "Walidacja generatora dla liczby zwierząt %d" % animal_count)
		_check(int(count_data.get("animal_count", -1)) == animal_count, "Generator zapisuje wybraną liczbę zwierząt %d" % animal_count)
	var legacy: Dictionary = first.duplicate(true)
	legacy.erase("docking_stations")
	var migrated: Dictionary = TrackGeneratorScript.normalize_legacy_data(legacy)
	var migrated_stations: Array = migrated.get("docking_stations", [])
	_check(migrated_stations.size() == 2, "Starsze zapisane trasy otrzymują stacje przy starcie")
	if migrated_stations.size() == 2:
		var migrated_a: Vector3 = migrated_stations[0]["position"]
		var migrated_b: Vector3 = migrated_stations[1]["position"]
		_check((migrated_a - start_center).dot(start_side) > 0.0 and (migrated_b - start_center).dot(start_side) > 0.0, "Migracja ustawia obie stacje po prawej stronie startu")
	_check(int(migrated.get("generator_version", 0)) >= 15, "Migracja oznacza nowy format generatora")
	_check(FurnitureModels.KINDS.has("tv_wall"), "Biblioteka modeli zawiera osobny telewizor ścienny")
	var generated_route: Array = first.get("route", [])
	_check(generated_route.size() >= 10, "Trasa ma odpowiednią liczbę punktów")
	_check(TrackLibrary.save_track(first), "Zapis trasy do lokalnej biblioteki")
	var loaded: Dictionary = TrackLibrary.get_track(str(first.get("id", "")))
	_check(not loaded.is_empty(), "Odczyt zapisanej trasy")
	_check(TrackLibrary.delete_track(str(first.get("id", ""))), "Usuwanie trasy z biblioteki")
	SaveManager.save_now()
	print("TRACK_GENERATOR_TEST: %s (błędów: %d)" % ["ZALICZONY" if failures == 0 else "NIEZALICZONY", failures])
	quit(0 if failures == 0 else 1)


func _check(condition: bool, label: String) -> void:
	if condition:
		print("  OK   ", label)
	else:
		failures += 1
		printerr("  FAIL ", label)
