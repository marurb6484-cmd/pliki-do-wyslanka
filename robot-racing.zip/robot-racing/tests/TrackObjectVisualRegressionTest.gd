extends SceneTree

const ApartmentTrackScript = preload("res://scripts/tracks/ApartmentTrack.gd")

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var track := ProceduralTrack.new()
	root.add_child(track)
	var furniture_kinds: Array[String] = ["plant", "sofa", "table", "lamp", "toy", "fish_tank", "bookshelf", "box", "pillow", "chair", "bed", "cabinet", "pet_bowl", "robot_toy", "rug", "tv", "scratching_post", "pet_bed", "shoe", "sock", "mug", "book", "remote", "tennis_ball", "yarn", "paper_scrap", "food_scraps", "cable", "backpack", "fridge", "bathtub", "sink", "kitchen_counter"]
	for kind: String in furniture_kinds:
		var holder := Node3D.new()
		track.add_child(holder)
		track._add_furniture_model(holder, kind, 2)
		assert(holder.get_child_count() > 0, "Brak modelu mebla: " + kind)
	var cached_a := TrackModelLibrary.make_furniture("sofa", 1)
	var cached_b := TrackModelLibrary.make_furniture("sofa", 1)
	assert(cached_a != cached_b, "Biblioteka musi zwracać osobne instancje węzłów")
	var mesh_a: MeshInstance3D = _first_mesh(cached_a)
	var mesh_b: MeshInstance3D = _first_mesh(cached_b)
	assert(mesh_a != null and mesh_b != null, "Brak siatki w modelu z biblioteki")
	assert(mesh_a.mesh == mesh_b.mesh, "Instancje nie współdzielą gotowej siatki modelu")
	var animal_kinds: Array[String] = ["cat", "dog", "rabbit", "bearded_dragon", "parrot"]
	for kind: String in animal_kinds:
		var holder := Node3D.new()
		track.add_child(holder)
		track._add_animal_model(holder, kind, 1)
		assert(holder.get_child_count() >= 5, "Model zwierzęcia ma za mało detali: " + kind)
	for obstacle_index: int in range(ObstacleModels.KIND_COUNT):
		var obstacle_holder := Node3D.new()
		track.add_child(obstacle_holder)
		track._build_obstacle_appearance(obstacle_holder, obstacle_index, 0.8, 0.7, Color("#d18d54"))
		assert(obstacle_holder.get_child_count() > 0, "Brak modelu przeszkody: %d" % obstacle_index)
		var obstacle_visual: Node = obstacle_holder.get_child(0)
		assert(obstacle_visual.get_child_count() > 0, "Pusty model przeszkody: %d" % obstacle_index)
	var apartment: Node = ApartmentTrackScript.new()
	root.add_child(apartment)
	assert(apartment.built, "Nie zbudowano istniejącej trasy mieszkania")
	for room_object: String in ["Kanapa", "Fotel", "StolikSalon", "Telewizor", "Lozko", "RegalZabawek", "Wanna", "Umywalka"]:
		var room_node: Node = apartment.get_node_or_null(room_object)
		assert(room_node != null, "Brak obiektu pomieszczenia: " + room_object)
		assert(room_node.get_node_or_null("Model3D") is Node3D, "Obiekt pomieszczenia nie korzysta ze wspólnej biblioteki modeli: " + room_object)
	var fixed_track_obstacle: Node = apartment.get_node_or_null("Przeszkoda_0_robot_toy")
	assert(fixed_track_obstacle != null and fixed_track_obstacle.get_node_or_null("Model3D") is Node3D, "Przeszkody stałej trasy nie korzystają z biblioteki modeli")
	print("TrackObjectVisualRegressionTest: OK")
	quit()

func _first_mesh(node: Node) -> MeshInstance3D:
	for child: Node in node.get_children():
		if child is MeshInstance3D:
			return child as MeshInstance3D
		var nested: MeshInstance3D = _first_mesh(child)
		if nested != null:
			return nested
	return null
