extends SceneTree
## Test: wczytuje każdy skrypt, scenę i zasób projektu i zgłasza błędy.
## Uruchomienie:  godot --headless --path . --script res://tests/load_all.gd

var _failures: int = 0
var _count: int = 0


func _initialize() -> void:
	_scan("res://")
	print("LOAD_ALL: sprawdzono plikow: ", _count, ", bledow: ", _failures)
	quit(1 if _failures > 0 else 0)


func _scan(path: String) -> void:
	var dir: DirAccess = DirAccess.open(path)
	if dir == null:
		return
	dir.list_dir_begin()
	var name: String = dir.get_next()
	while not name.is_empty():
		if name.begins_with("."):
			name = dir.get_next()
			continue
		var full: String = path.path_join(name)
		if dir.current_is_dir():
			if full != "res://tests":
				_scan(full)
		elif name.ends_with(".gd") or name.ends_with(".tscn") or name.ends_with(".tres") or name.ends_with(".gdshader"):
			_check(full)
		name = dir.get_next()


func _check(path: String) -> void:
	_count += 1
	var resource: Resource = ResourceLoader.load(path, "", ResourceLoader.CACHE_MODE_IGNORE)
	if resource == null:
		_failures += 1
		printerr("LOAD_FAIL: ", path)
		return
	if resource is GDScript:
		var script: GDScript = resource
		if not script.can_instantiate() and not path.begins_with("res://tests/"):
			_failures += 1
			printerr("SCRIPT_FAIL: ", path)
	if resource is PackedScene:
		var scene: PackedScene = resource
		if not scene.can_instantiate():
			_failures += 1
			printerr("SCENE_FAIL: ", path)
