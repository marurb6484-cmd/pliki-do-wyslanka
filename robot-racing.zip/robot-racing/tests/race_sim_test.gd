extends Node
## Test automatyczny rozgrywki (symulacja w silniku, bez udziału gracza).
##
## Uruchomienie (tryb: race | time_trial | graphics_test):
##   godot --headless --path . res://tests/RaceSimTest.tscn --fixed-fps 60 -- --test-save --scenario=race
##
## Robot gracza jedzie na autopilocie. Test sprawdza: odliczanie, start,
## ruch AI, zbieranie brudu, boosty, kolizje/uszkodzenia, okrążenia,
## zakończenie wyścigu, wyniki, nagrody i zapis.

const RACE_SCENE: String = "res://scenes/race/RaceScene.tscn"

var scenario: String = "race"
var race_scene: Node
var race: RaceManager
var frames: int = 0
var max_frames: int = 60 * 300
var boosts: Dictionary = {}
var hits: int = 0
var damage_hits: int = 0
var dirt_events: Dictionary = {}
var started_frame: int = -1
var failures: Array[String] = []
var finished: bool = false
var quality_cycle: int = 0


func _ready() -> void:
	# Bez limitu klatek, aby mierzyć rzeczywisty koszt CPU (zapis testowy, nie gracza).
	GameSettings.fps_limit = 0
	Engine.max_fps = 0
	var difficulty: int = AIDifficulty.Level.EXPERT
	var laps: int = 1
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--scenario="):
			scenario = argument.get_slice("=", 1)
		elif argument.begins_with("--difficulty="):
			difficulty = int(argument.get_slice("=", 1))
		elif argument.begins_with("--laps="):
			laps = int(argument.get_slice("=", 1))

	var start_currency: int = PlayerProgress.currency
	set_meta("start_currency", start_currency)

	match scenario:
		"time_trial":
			GameManager.configure_race(GameManager.GameMode.TIME_TRIAL, 0, 2, 1, 0, true)
		"graphics_test":
			GameManager.configure_graphics_test()
		_:
			GameManager.configure_race(GameManager.GameMode.RACE, 0, laps, difficulty, 4, false)

	GameManager.start_race()
	race_scene = (load(RACE_SCENE) as PackedScene).instantiate()
	add_child(race_scene)
	race = race_scene.get("race_manager")
	_check(race != null, "RaceManager utworzony")
	_check(race.racers.size() == (1 if scenario == "time_trial" else 5), "Liczba zawodników: %d" % race.racers.size())

	for robot: Robot in race_scene.get("robots"):
		boosts[robot.display_name] = 0
		dirt_events[robot.display_name] = 0
		robot.boost.boost_started.connect(func() -> void: boosts[robot.display_name] += 1)
		robot.dirt_collected.connect(func(_amount: float) -> void: dirt_events[robot.display_name] += 1)
		robot.collided.connect(func(_s: float, _p: Vector3, _r: bool, amount: float) -> void:
			hits += 1
			if amount > 0.0:
				damage_hits += 1)

	race.race_started.connect(func() -> void:
		started_frame = frames
		race_scene.call("enable_player_autopilot", true))
	race.race_finished.connect(_on_race_finished)
	print("TEST[%s]: trasa długość %.1f m, punktów %d, przeszkód %d, brudu %d" % [scenario, race.track.route_length, race.track.smooth_route.size(), race.track.obstacles.size(), (race_scene.get("dirt_manager") as DirtManager).pickups.size()])
	_report_corners()


func _report_corners() -> void:
	var track: TrackBase = race.track
	var max_curvature: float = 0.0
	for value: float in track.route_curvature:
		max_curvature = maxf(max_curvature, absf(value))
	print("TEST: najciaśniejszy zakręt promień %.1f m" % (1.0 / maxf(max_curvature, 0.0001)))


var _last_usec: int = 0
var _frame_total_usec: int = 0
var _frame_max_usec: int = 0
var _frame_samples: int = 0
var _spikes: int = 0


func _process(_delta: float) -> void:
	# Rzeczywisty czas klatki (CPU, bez renderowania w trybie headless).
	var now: int = Time.get_ticks_usec()
	if _last_usec > 0 and started_frame >= 0 and not finished:
		var frame_usec: int = now - _last_usec
		_frame_total_usec += frame_usec
		_frame_samples += 1
		_frame_max_usec = maxi(_frame_max_usec, frame_usec)
		if frame_usec > 8000:
			_spikes += 1
			if OS.get_cmdline_user_args().has("--trace-spikes"):
				print("SPIKE %.1f ms przy t=%.2f s (klatka %d) max_fps=%d" % [frame_usec / 1000.0, race.race_time, frames, Engine.max_fps])
	_last_usec = now


func _physics_process(_delta: float) -> void:
	frames += 1
	if finished:
		return

	if frames == 60 * 4 and started_frame < 0:
		_check(not GameManager.is_racing, "Odliczanie blokuje start (4 s)")
	if frames == 60 * 7:
		_check(GameManager.is_racing or race.state == RaceManager.State.FINISHED, "Wyścig wystartował po odliczaniu")

	# Test grafiki: przełączanie jakości w trakcie jazdy, potem zakończenie.
	if scenario == "graphics_test" and started_frame >= 0:
		if (frames - started_frame) % 300 == 0:
			quality_cycle += 1
			GameSettings.set_quality_preset(quality_cycle % 4)
		if frames - started_frame == 60 * 40:
			race_scene.call("end_test")

	if frames % 600 == 0:
		_print_status()

	if frames >= max_frames:
		_fail("Przekroczono limit czasu symulacji")
		_print_status()
		_finish()


func _print_status() -> void:
	var lines: Array[String] = []
	for racer: Dictionary in race.racers:
		var robot: Robot = racer["robot"]
		lines.append("%s poz%d okr%d dyst%.0f v%.1f km/h dmg%.0f brud%.0f" % [str(racer["name"]).substr(0, 12), int(racer["position"]), int(racer["laps_done"]), float(racer["total"]), robot.forward_speed * 3.6, robot.damage.damage, robot.tank.total_collected])
	print("t=%.0fs | %s" % [race.race_time, " | ".join(lines)])
	print("     CPU: proces %.2f ms, fizyka %.2f ms, obiekty %d, węzły %d" % [
		Performance.get_monitor(Performance.TIME_PROCESS) * 1000.0,
		Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS) * 1000.0,
		int(Performance.get_monitor(Performance.OBJECT_COUNT)),
		int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT))])


func _on_race_finished(results: Array) -> void:
	_print_status()
	print("TEST: wyniki:")
	for result: Dictionary in results:
		print("  %d. %s czas %s najl.okr %s meta=%s szac=%s brud=%.0f dmg=%.1f" % [int(result["position"]), result["name"], UIKit.format_time(float(result["time"])), UIKit.format_time(float(result["best_lap"])), str(result["finished"]), str(result["estimated"]), float(result["dirt"]), float(result["damage_taken"])])
	print("TEST: boosty: ", boosts)
	print("TEST: zebrany brud (zdarzenia): ", dirt_events)
	print("TEST: kolizje: %d, z uszkodzeniem: %d" % [hits, damage_hits])
	print("TEST: czas CPU klatki: średnio %.2f ms, maks. %.2f ms, klatek >8 ms: %d z %d" % [_frame_total_usec / 1000.0 / maxf(_frame_samples, 1), _frame_max_usec / 1000.0, _spikes, _frame_samples])
	var lap_sum: float = 0.0
	var lap_count: int = 0
	var rescues: int = 0
	for robot: Robot in race_scene.get("robots"):
		rescues += int(robot.get_meta("ai_rescues", 0))
		if robot.is_player:
			continue
		var racer: Dictionary = race.get_racer_for(robot)
		for lap_time: Variant in racer["lap_times"]:
			lap_sum += float(lap_time)
			lap_count += 1
	print("TEST: trudność %s - średni czas okrążenia AI: %.2f s (okrążeń %d), akcje ratunkowe AI: %d" % [AIDifficulty.NAMES[GameManager.difficulty], lap_sum / maxf(lap_count, 1), lap_count, rescues])

	_check(results.size() == race.racers.size(), "Wyniki dla wszystkich zawodników")
	var total_dirt: int = 0
	for key: String in dirt_events.keys():
		total_dirt += int(dirt_events[key])
	_check(total_dirt > 0, "Roboty zbierają brud")

	if scenario != "graphics_test":
		var player_finished: bool = false
		for result: Dictionary in results:
			if bool(result["is_player"]):
				player_finished = bool(result["finished"])
		_check(player_finished, "Robot gracza (autopilot) ukończył wyścig")

	if scenario == "race":
		var ai_boosts: int = 0
		var ai_dirt: int = 0
		for robot: Robot in race_scene.get("robots"):
			if not robot.is_player:
				ai_boosts += int(boosts[robot.display_name])
				ai_dirt += int(dirt_events[robot.display_name])
		_check(ai_dirt > 0, "AI zbiera brud")
		_check(ai_boosts > 0, "AI używa boosta")
		_check(PlayerProgress.currency > int(get_meta("start_currency")), "Nagrody przyznane (saldo %d)" % PlayerProgress.currency)
		_check(not GameManager.last_rewards.is_empty(), "Nagrody zapisane w GameManager")
	elif scenario == "graphics_test":
		_check(PlayerProgress.currency == int(get_meta("start_currency")), "Test grafiki nie przyznaje nagród")
		_check(PlayerProgress.stats.get("races", 0) == 0, "Test grafiki nie liczy się do statystyk")
	elif scenario == "time_trial":
		var best: Dictionary = PlayerProgress.get_best(race.track.track_id, "time_trial", 2)
		_check(float(best.get("best_lap", -1.0)) > 0.0, "Zapisano rekord okrążenia jazdy na czas")

	# Ekran wyników musi być widoczny.
	var hud: Node = race_scene.get("hud")
	var results_hud: Control = hud.get("results")
	_check(results_hud.visible, "Ekran wyników pokazany")
	_finish()


func _check(condition: bool, label: String) -> void:
	if condition:
		print("  OK   ", label)
	else:
		_fail(label)


func _fail(label: String) -> void:
	failures.append(label)
	printerr("  FAIL ", label)


func _finish() -> void:
	finished = true
	SaveManager.save_now()
	print("TEST[%s]: %s (błędów: %d)" % [scenario, "ZALICZONY" if failures.is_empty() else "NIEZALICZONY", failures.size()])
	await get_tree().create_timer(0.5).timeout
	get_tree().quit(0 if failures.is_empty() else 1)
