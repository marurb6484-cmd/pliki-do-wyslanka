extends Node
## Zrzuty ekranu do kontroli wizualnej (wymaga GPU - bez --headless).
##   godot --path . res://tests/ScreenshotTest.tscn --resolution 1560x720 -- --test-save --out=C:/folder --quality=2

var out_dir: String = "user://screens"
var quality: int = 2


func _ready() -> void:
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			out_dir = argument.get_slice("=", 1)
		elif argument.begins_with("--quality="):
			quality = int(argument.get_slice("=", 1))
	DirAccess.make_dir_recursive_absolute(out_dir)
	GameSettings.set_quality_preset(quality)
	GameSettings.set_show_fps(true)

	for path: String in ["res://scenes/MainMenu.tscn", "res://scenes/ModeSelect.tscn", "res://scenes/SinglePlayerSelect.tscn", "res://scenes/TrackSelect.tscn", "res://scenes/Garage.tscn", "res://scenes/Settings.tscn", "res://scenes/HUDEditor.tscn"]:
		var scene: Node = (load(path) as PackedScene).instantiate()
		add_child(scene)
		await _wait(0.6)
		_shot(path.get_file().get_basename())
		scene.queue_free()
		await _wait(0.1)

	GameManager.configure_race(GameManager.GameMode.RACE, 0, 1, 2, 4, false)
	GameManager.start_race()
	var race: Node = (load("res://scenes/race/RaceScene.tscn") as PackedScene).instantiate()
	add_child(race)
	await _wait(2.5)
	_shot("race_countdown_q%d" % quality)
	var manager: RaceManager = race.get("race_manager")
	await manager.race_started
	race.call("enable_player_autopilot", true)
	await _wait(6.0)
	_shot("race_running_q%d" % quality)
	(race.get("player") as Robot).boost.tank.add(10.0)
	(race.get("player") as Robot).request_boost()
	await _wait(0.5)
	_shot("race_boost_q%d" % quality)
	(race.get("player") as Robot).damage.setup(85.0)
	await _wait(1.5)
	_shot("race_damaged_q%d" % quality)
	race.get("hud").call("open_pause")
	await _wait(0.3)
	_shot("race_pause_q%d" % quality)
	get_tree().paused = false
	manager.force_end()
	await _wait(0.5)
	_shot("race_results_q%d" % quality)
	get_tree().quit()


func _wait(seconds: float) -> void:
	await get_tree().create_timer(seconds, true).timeout


func _shot(shot_name: String) -> void:
	var image: Image = get_viewport().get_texture().get_image()
	var path: String = out_dir.path_join("%s_%s.png" % [shot_name, GameSettings.get_renderer()])
	image.save_png(path)
	print("SHOT: ", path)
