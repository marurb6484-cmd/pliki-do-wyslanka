extends Node
## Test automatyczny menu, garażu, ekonomii, zapisu/odczytu, edytora HUD
## i systemu uszkodzeń.
##   godot --headless --path . res://tests/UIFlowTest.tscn -- --test-save

const SCENES: Array[String] = [
	"res://scenes/MainMenu.tscn",
	"res://scenes/ModeSelect.tscn",
	"res://scenes/SinglePlayerSelect.tscn",
	"res://scenes/TrackSelect.tscn",
	"res://scenes/Garage.tscn",
	"res://scenes/Settings.tscn",
	"res://scenes/HUDEditor.tscn"
]

var failures: Array[String] = []


func _ready() -> void:
	Engine.max_fps = 0
	await _test_scenes()
	_test_economy_and_save()
	_test_damage_system()
	_test_boost_system()
	await _test_hud_editor()
	_test_settings_persistence()
	print("TEST[ui]: %s (błędów: %d)" % ["ZALICZONY" if failures.is_empty() else "NIEZALICZONY", failures.size()])
	SaveManager.save_now()
	get_tree().quit(0 if failures.is_empty() else 1)


func _check(condition: bool, label: String) -> void:
	if condition:
		print("  OK   ", label)
	else:
		failures.append(label)
		printerr("  FAIL ", label)


func _frames(count: int) -> void:
	for i: int in range(count):
		await get_tree().process_frame


## Każda scena menu: wczytanie, kilka klatek, kliknięcie wszystkich
## przycisków, które nie zmieniają sceny (sprawdzenie, że nie ma błędów).
func _test_scenes() -> void:
	for path: String in SCENES:
		var scene: Node = (load(path) as PackedScene).instantiate()
		add_child(scene)
		await _frames(5)
		var buttons: Array[Node] = scene.find_children("*", "BaseButton", true, false)
		_check(scene.is_inside_tree(), "Scena działa: %s (przycisków: %d)" % [path.get_file(), buttons.size()])
		var clicked: int = 0
		for node: Node in buttons:
			if not is_instance_valid(node) or node.is_queued_for_deletion():
				continue
			var button: BaseButton = node as BaseButton
			if button.disabled or not button.is_visible_in_tree():
				continue
			var label: String = (button as Button).text if button is Button else ""
			# Pomijamy przyciski zmieniające scenę/wychodzące z gry.
			if _is_navigation(label):
				continue
			button.pressed.emit()
			if button.toggle_mode:
				button.toggled.emit(not button.button_pressed)
			clicked += 1
			await _frames(1)
			if not is_instance_valid(scene):
				break
		print("       kliknięto %d przycisków" % clicked)
		if is_instance_valid(scene):
			scene.queue_free()
		await _frames(3)


func _is_navigation(label: String) -> bool:
	for word: String in ["GRAJ", "GARAŻ", "USTAWIENIA", "WYJŚCIE", "WSTECZ", "WYBIERZ", "START", "EDYTUJ", "ZAPISZ", "ANULUJ", "RESETUJ", "ZMIEŃ", "TEST DŹWIĘKU"]:
		if label.contains(word):
			return true
	return false


func _test_economy_and_save() -> void:
	PlayerProgress.reset_progress()
	PlayerProgress.add_currency(5000)
	_check(PlayerProgress.currency == 5000, "Dodanie waluty")
	_check(PlayerProgress.unlock_robot(2), "Odblokowanie robota CleanBot (450 CR)")
	_check(PlayerProgress.currency == 4550, "Pobrano koszt odblokowania")
	PlayerProgress.select_robot(2)
	_check(PlayerProgress.buy_upgrade(2, "speed"), "Zakup ulepszenia prędkości")
	for i: int in range(6):
		PlayerProgress.buy_upgrade(2, "grip")
	_check(int(PlayerProgress.get_upgrades(2)["grip"]) == RobotDatabase.UPGRADE_MAX_LEVEL, "Limit poziomu ulepszeń (5)")
	_check(PlayerProgress.unlock_skin(3), "Odblokowanie skórki")
	PlayerProgress.set_skin(2, 3)
	PlayerProgress.set_neon(2, 4)
	PlayerProgress.set_damage(2, 40.0)
	var cost: int = PlayerProgress.get_repair_cost(2)
	_check(cost == 60, "Koszt naprawy 40% = 60 CR")
	var before: int = PlayerProgress.currency
	PlayerProgress.repair(2)
	_check(PlayerProgress.get_damage(2) == 0.0 and PlayerProgress.currency == before - cost, "Naprawa w garażu")
	PlayerProgress.submit_times("apartment", "time_trial", 3, 90.0, 28.5)
	var record: Dictionary = PlayerProgress.submit_times("apartment", "time_trial", 3, 95.0, 27.0)
	_check(not bool(record["new_total"]) and bool(record["new_lap"]), "Rekordy: gorszy czas nie nadpisuje, lepsze okrążenie tak")

	var config: Dictionary = PlayerProgress.get_player_robot_config()
	_check(str(config["name"]) == "CleanBot Ultra" and int(config["skin_index"]) == 3, "Konfiguracja robota gracza po zmianach")
	_check(float(config["grip"]) > float(RobotDatabase.get_robot(2)["grip"]), "Ulepszenia wpływają na statystyki")

	SaveManager.save_now()
	var file := ConfigFile.new()
	_check(file.load(SaveManager.save_path) == OK, "Plik zapisu istnieje")
	_check(int(file.get_value("progress", "currency", -1)) == PlayerProgress.currency, "Zapisane saldo")
	_check(int(file.get_value("selection", "robot", -1)) == 2, "Zapisany wybrany robot")
	var saved_upgrades: Dictionary = file.get_value("progress", "upgrades", {})
	_check(int((saved_upgrades.get("2", {}) as Dictionary).get("grip", 0)) == 5, "Zapisane ulepszenia")

	# Odporność na uszkodzone i stare wartości.
	var broken := ConfigFile.new()
	broken.set_value("graphics", "quality", "abc")
	broken.set_value("graphics", "fps_limit", 120)
	broken.set_value("progress", "upgrades", "niepoprawne")
	broken.set_value("economy", "player_points", 77)
	broken.save("user://broken_test.cfg")
	var loaded := ConfigFile.new()
	loaded.load("user://broken_test.cfg")
	_check(loaded.get_value("graphics", "quality") is String, "Przygotowano uszkodzony zapis")
	DirAccess.remove_absolute(ProjectSettings.globalize_path("user://broken_test.cfg"))


func _test_damage_system() -> void:
	var damage := DamageSystem.new()
	add_child(damage)
	damage.setup(0.0)
	damage.register_impact(2.0, 1, Vector3(0, 0, -1), Vector3.ZERO)
	_check(damage.damage == 0.0, "Lekkie dotknięcie (2 m/s) nie powoduje uszkodzeń")
	damage.register_impact(30.0, 2, Vector3(0, 0, -1), Vector3.ZERO)
	_check(damage.damage <= 12.0 and damage.damage > 0.0, "Limit uszkodzeń na jedno uderzenie (%.1f%%)" % damage.damage)
	var value: float = damage.damage
	var repeat: float = damage.register_impact(30.0, 2, Vector3(0, 0, -1), Vector3.ZERO)
	_check(repeat < 0.0 and damage.damage == value, "Ochrona przed wielokrotnym naliczeniem tej samej kolizji")
	damage.tick(1.0)
	damage.register_impact(30.0, 2, Vector3(0, 0, -1), Vector3.ZERO)
	_check(damage.damage > value, "Po czasie blokady kolejne uderzenie się liczy")
	damage.setup(80.0)
	_check(damage.get_stage() == DamageSystem.Stage.SEVERE, "Stopień: poważne przy 80%")
	_check(damage.speed_multiplier() < 1.0 and damage.speed_multiplier() > 0.7, "Uszkodzenia ograniczają prędkość (×%.2f)" % damage.speed_multiplier())
	damage.setup(100.0)
	_check(damage.speed_multiplier() >= 0.75, "Robot jedzie nawet przy 100% uszkodzeń")
	damage.queue_free()


func _test_boost_system() -> void:
	var tank := DirtTank.new()
	var boost := BoostSystem.new()
	add_child(tank)
	add_child(boost)
	tank.setup(10.0)
	boost.setup({"boost_cost": 5.0, "boost_duration": 2.0, "boost_cooldown": 3.0, "boost_speed_multiplier": 1.4}, tank)
	_check(not boost.try_activate(), "Boost zablokowany bez brudu")
	_check(tank.add(4.0) == 4.0 and tank.add(10.0) == 6.0, "Zbiornik przyjmuje brud do pojemności")
	_check(tank.add(1.0) == 0.0, "Pełny zbiornik nie przyjmuje brudu")
	_check(boost.try_activate() and tank.charge == 5.0, "Boost zużywa 5 jednostek brudu")
	_check(not boost.try_activate(), "Nie można włączyć boosta w trakcie działania")
	boost.tick(2.1)
	_check(boost.get_state() == BoostSystem.State.COOLDOWN, "Po boście następuje odnowienie")
	_check(not boost.try_activate(), "Blokada w czasie odnowienia")
	boost.tick(3.1)
	_check(boost.try_activate(), "Boost ponownie dostępny po odnowieniu")
	tank.queue_free()
	boost.queue_free()


func _test_hud_editor() -> void:
	var scene: Node = (load("res://scenes/HUDEditor.tscn") as PackedScene).instantiate()
	add_child(scene)
	await _frames(5)
	var hud: Node = scene.get_child(scene.get_child_count() - 1)
	var editor: Control = hud.get("editor")
	_check(editor.visible, "Edytor HUD otwarty")
	var modules: Array = hud.get("modules")
	_check(modules.size() >= 7, "Moduły HUD w edytorze: %d" % modules.size())
	var overlaps: Dictionary = editor.get("_overlapping")
	_check(overlaps.is_empty(), "Domyślny układ: brak nakładania ważnych elementów")

	var boost_module: HUDModule = null
	for module: HUDModule in modules:
		if module.module_id == "boost":
			boost_module = module
	var viewport_size: Vector2 = hud.call("get_viewport_size")
	boost_module.apply_layout(Vector2(0.5, 0.5), 1.3, viewport_size)
	editor.call("_update_overlaps")
	var layout: Dictionary = hud.call("collect_layout")
	GameSettings.set_hud_layout(hud.call("get_bucket"), layout)
	var restored: Dictionary = GameSettings.get_hud_layout(hud.call("get_bucket"))
	_check(is_equal_approx(float(restored["boost"]["scale"]), 1.3), "Zapis układu HUD (skala)")
	_check(SaveManager.get_dict("hud", "layouts").has(hud.call("get_bucket")), "Układ HUD w pliku zapisu")
	GameSettings.reset_hud_layout(hud.call("get_bucket"))
	_check(GameSettings.get_hud_layout(hud.call("get_bucket")).is_empty(), "Przywracanie domyślnego układu")
	scene.queue_free()
	await _frames(2)


func _test_settings_persistence() -> void:
	GameSettings.set_quality_preset(GameSettings.Quality.LOW)
	_check(not GameSettings.shadows_enabled, "Jakość NISKA wyłącza cienie")
	_check(is_equal_approx(get_viewport().scaling_3d_scale, 0.7), "Jakość NISKA zmniejsza skalę renderowania")
	GameSettings.set_fps_limit(45)
	_check(Engine.max_fps == 45, "Limit FPS 45 zastosowany w silniku")
	GameSettings.set_control_mode(GameSettings.ControlMode.GYRO)
	GameSettings.set_steering_sensitivity(1.35)
	GameSettings.set_volume("engine", 0.3)
	SaveManager.save_now()
	var file := ConfigFile.new()
	file.load(SaveManager.save_path)
	_check(int(file.get_value("graphics", "quality", -1)) == 0, "Zapisana jakość grafiki")
	_check(int(file.get_value("graphics", "fps_limit", -1)) == 45, "Zapisany limit FPS")
	_check(int(file.get_value("controls", "mode", -1)) == 2, "Zapisany tryb sterowania")
	_check(is_equal_approx(float(file.get_value("controls", "sensitivity", 0.0)), 1.35), "Zapisana czułość")
	_check(is_equal_approx(float(file.get_value("audio", "engine", 0.0)), 0.3), "Zapisana głośność")
	Engine.max_fps = 0
