ROBOT RACING – TŁUMACZENIA

Językiem źródłowym gry jest polski. Teksty w skryptach/scenach pozostają
polskimi tekstami źródłowymi. Brakujący wpis w katalogu języka automatycznie
pozostawia tekst źródłowy, zamiast wyświetlać pusty napis.

DODANIE NOWEGO JĘZYKA:
1. Skopiuj translations/Locale_en.gd jako Locale_<kod>.gd, np. Locale_de.gd.
2. Zmień komentarz i uzupełnij const STRINGS: Dictionary.
3. Każdy wpis ma postać: "polski tekst źródłowy": "tłumaczenie".
4. Dodaj katalog do LANGUAGE_CATALOGS w scripts/autoload/LocaleManager.gd:
   "de": {"name": "Deutsch", "catalog": preload("res://translations/Locale_de.gd")}
5. Nie zmieniaj kluczy źródłowych. Wartości tłumaczeń mogą zawierać 
.

ZASADY:
- Nie tłumacz nazw kluczy technicznych, identyfikatorów, ścieżek ani kodów.
- Zachowuj znaczniki formatowania, symbole i placeholdery (%s, %d, {name}).
- Każdy nowy tekst widoczny dla gracza należy dodać do każdego katalogu.
- Do czasu pełnego tłumaczenia brakujące wpisy pokażą polski tekst źródłowy.
- Po dodaniu języka pojawi się automatycznie w zakładce JĘZYK.

Obecny katalog EN jest punktem startowym, a nie kompletnym tłumaczeniem
całej gry. README opisuje docelowy, rozszerzalny format katalogów.
